//
//  ViewController.swift
//  PriceCalculator
//
//  Created by Swapna Dasari on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amount: UITextField!
    
    
    @IBOutlet weak var discount: UITextField!
    
    @IBOutlet weak var result: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func enterButton(_ sender: UIButton) {
      
//            let amountValue = amount.text
//            let discountValue = discount.text
//
//       var result = amountValue! - (discountValue/100*100)
//        var result = ("\(randomNumber)" - "\(secondRandomNumber)")
//        var  result.text = result
//
        var amountValue = amount.text
        var discountValue = discount.text
        var  result.text = amountValue - discountValue
       
     
        
    }
    
    
    
}

