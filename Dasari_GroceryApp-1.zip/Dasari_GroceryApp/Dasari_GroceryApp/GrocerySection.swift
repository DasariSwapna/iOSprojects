//
//  GrocerySection.swift
//  Dasari_GroceryApp
//
//  Created by Dasari,Swapna on 4/12/22.
//

import Foundation

struct Grocery {
var section = ""
var items_Array:[GroceryItem] = []
}

struct GroceryItem{
    var itemName = ""
    var itemImage = ""
    var itemInfo = ""
}

let groceryitem1 = Grocery(section:"Food",items_Array:[GroceryItem(itemName:"Dosa",itemImage:"masaladosa",itemInfo:"A crispy, rice-batter crepe encases a spicy mix of mashed potato, which is then dipped in coconut chutney, pickles, tomato-and-lentil-based sauces and other condiments. It's a fantastic breakfast food that'll keep you going till lunch, when you'll probably come back for another."), GroceryItem(itemName: "Hummus", itemImage: "hummus", itemInfo: "This humble Middle Eastern spread, made with chickpeas, garlic, lemon juice and tahini has become a fridge staple all around the world. This tangy treat tastes good as a dip, with breads, with meats, with vegetables, beans or -- hear us out -- on a Marmite rice cake."), GroceryItem(itemName: "Basic crab", itemImage: "buttergarliccrab", itemInfo: "This one claims no roots in Chinese, Continental or Indian cuisines. It comes from Butter Land, an imaginary best foods paradise balanced on the premise that anything tastes great with melted butter. This delicious, simple dish is made by drowning a large crab in a gallon of butter-garlic sauce, which seeps into every nook and cranny and coats every inch of flesh. The sea gods of Butter Land are benevolent carnivores and this, their gift to the world, is their signature dish."), GroceryItem(itemName: "souce", itemImage: "corn", itemInfo: "God probably created corn just to have an excuse to invent melted butter. There's something about biting down on a cob of corn -- it's a delicate enough operation to require concentration but primal enough to make you feel like the caveman you always wanted to be. Great food is caveman food."), GroceryItem(itemName: "Sushi", itemImage: "sushi", itemInfo: "When Japan wants to build something right, it builds it really right. Brand giants such as Toyota, Nintendo, Sony, Nikon and Yamaha may have been created by people fueled by nothing more complicated than raw fish and rice, but it's how the fish and rice is put together that makes this a global first-date favorite. The Japanese don't live practically forever for no reason -- they want to keep eating this stuff.")] )

let groceryitem2 = Grocery( section: "Toys", items_Array: [GroceryItem(itemName: "Hasbro’s Star Wars", itemImage: "toy1", itemInfo: "Hasbro’s Star Wars Collection: The Child Animatronic Edition with sounds and motorized sequences! He may look like “Baby Yoda,” but this lovable creature is called The Child -- and now you can become his protector with this animatronic toy from Star Wars."), GroceryItem(itemName: "Story Time Chess", itemImage: "toy2", itemInfo: "Story Time Chess is a board game that teaches chess to young children using silly stories, vibrant illustrations, custom chess pieces, and a unique chess board. The stories and supporting materials communicate the rules of chess to children ages 3 and up in a way that makes learning chess simple and fun. "), GroceryItem(itemName: "Comic Remastered", itemImage: "toy3", itemInfo: "In 1992, the very first Spawn comic book hit the shelves setting a sales record for an independent comic book. A few years later, in 1995, the first Spawn action figure was released to critical acclaim and helped usher in a whole new way of giving you detail and ‘art’ to your action figures."), GroceryItem(itemName: "The Razor Crest™", itemImage: "toy4", itemInfo: "Kids can role-play as heroic warrior The Mandalorian and play out action-packed Star Wars: The Mandalorian scenes with this detailed, LEGO brick model of The Razor Crest (75292) starship"), GroceryItem(itemName: "Pokémon", itemImage: "toy5", itemInfo: "This set includes everything two players need to battle. Trade, collect, or duel with these cards. Choose between beloved monsters like Charizard or Pikachu to lead your team in a fight against another trainer. Make Ash Ketchum proud and battle with the best!")] )

let groceryitem3 = Grocery( section: "jornals", items_Array: [GroceryItem(itemName: "Europe the history", itemImage: "book1", itemInfo: "A Tale of Two Cities is an 1859 historical novel by Charles Dickens, set in London and Paris before and during the French Revolution. The novel tells the story of the French Doctor Manette, his 18-year-long imprisonment in the Bastille in Paris, and his release to live in London with his daughter Lucie whom he had never met. "), GroceryItem(itemName: "Prince of erupe", itemImage: "book2", itemInfo: "The Little Prince (French: Le Petit Prince, pronounced [lə p(ə)ti pʁɛ̃s]) is a novella by French aristocrat, writer, and military aviator Antoine de Saint-Exupéry. It was first published in English and French in the United States by Reynal & Hitchcock in April 1943. "), GroceryItem(itemName: "Stone Era", itemImage: "book3", itemInfo: "Harry Potter and the Philosopher's Stone is a fantasy novel written by British author J. K. Rowling. The first novel in the Harry Potter series and Rowling's debut novel, it follows Harry Potter, a young wizard who discovers his magical heritage on his eleventh birthday, when he receives a letter of acceptance to Hogwarts School of Witchcraft and Wizardry."), GroceryItem(itemName: "There is something", itemImage: "book4", itemInfo: "And Then There Were None is a mystery novel by the English writer Agatha Christie, described by her as the most difficult of her books to write.[2] It was first published in the United Kingdom by the Collins Crime Club on 6 November 1939, as Ten Little Niggers."), GroceryItem(itemName: "Day Deram", itemImage: "book5", itemInfo: "Dream of the Red Chamber (Honglou Meng) or The Story of the Stone (Shitou Ji) is a novel composed by Cao Xueqin in the middle of the 18th century. One of the Four Great Classical Novels of Chinese literature, it is known for its psychological scope, and its observation of the world view, aesthetics, life-styles, and social relations of 18th-century China.")] )






let grocerys = [groceryitem1, groceryitem2, groceryitem3]

