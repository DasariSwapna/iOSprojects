//
//  RestaurantDetailsViewController.swift
//  Dasari_RestaurantApp
//
//  Created by Swapna Dasari on 4/26/22.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {

    var name : RestDetails?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    
        var imgn = name?.image
        imageOutlet.image = UIImage(named: imgn!)
        
     
        
        
    }
//

    
    
    @IBOutlet weak var imageOutlet: UIImageView!
    
    
    
    @IBOutlet weak var detail1: UILabel!
    
    
    
    @IBOutlet weak var detail2: UILabel!
    
    
    
    @IBOutlet weak var detail3: UILabel!
    
    
    @IBOutlet weak var detail4: UILabel!
    
    
    @IBOutlet weak var detail5: UILabel!
    
    
    
  
    
    @IBAction func clickbutton(_ sender: UIButton) {
        detail1.text = "\(name?.item1)!"
        detail2.text = " \(name?.item2)!"
        detail3.text = " \(name?.item3) "
        detail4.text = " \(name?.item4) "
        detail5.text = " \(name?.item5) "
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
