//
//  ViewController.swift
//  Dasari_RestaurantApp
//
//  Created by Swapna Dasari on 4/26/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurentsArr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = restaurentsArr[indexPath.row].name
        return cell
    }
    
    var restaurent = Restarant()
    
    var restaurentsArr = restaurants
   
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        self.title = "Grocery Sections"
        
              tableViewOutlet.delegate = self
              tableViewOutlet.dataSource = self
        
        
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "RestaurantdetailsSegue"{
            let destination = segue.destination as! RestaurantDetailsViewController
            destination.name = restaurentsArr[(tableViewOutlet.indexPathForSelectedRow?.row)!].details

        }
    }


}

