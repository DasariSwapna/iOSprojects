//
//  ViewController.swift
//  Dasari_SearchApp
//
//  Created by Swapna Dasari on 3/1/22.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    
    @IBOutlet weak var searchButtonAction: UIButton!
    
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    @IBOutlet weak var ShowPrevImagesBtn: UIButton!
    
    
    
    @IBOutlet weak var showNextImagesBtn: UIButton!
    
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    @IBOutlet weak var resetButton: UIButton!
    
    var array = [["actoress1","actoress2","actoress3","actoress4","actoress5"],["plant1","plant2","plant3","plant4","plant5"],["bird1","bird2","bird3","bird4","bird5",],["bg","404"]]
    
    var actressess = ["actoress","actoresses","heroin","tollywood","celebrities"]
    
    var plants = ["flowering plants","flower plants","jasmine","jasmines"]
    
    var birds = ["bird","birds", "humming birds","Dove","Pigeon"]
    
    var topic = 0
    var imag1:Int!
    var imag2:Int!
    var imag3:Int!
    var name1:Int!
    var name2:Int!
    var name3:Int!
    var text1:Int!
    var text2:Int!
    var text3:Int!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        searchButtonAction.isEnabled = false
        resetButton.isHidden = true
        resultImage.image = UIImage(named: array[3][0])
        topicInfoText.text = nil
    }
    
    
    @IBAction func textentered(_ sender: Any) {
        searchButtonAction.isEnabled = true
        if(searchTextField.text == ""){
            searchButtonAction.isEnabled = false
            
        }
    else{

        ShowPrevImagesBtn.isEnabled = true
        showNextImagesBtn.isEnabled = false
        searchButtonAction.isEnabled = true
        resetButton.isHidden = false
        }
    }
    
    var actoress =
        [["Krithi Shetty","Keerthy Suresh","Tamannaah Bhatia","Rakul Preet Singh","Pooja Hegde"],["An actor or actress is a person who portrays a character in a performance. The actor performs in the flesh in the traditional medium of the theatre or in modern media such as film, radio, and television"]]
    
    var plant =  [["Snowdrop","Cherry blossom","Bluebell","Daffodil","Tulip"],["A flower, also known as a bloom or blossom, is the reproductive structure found in flowering plants. The flower structure contains the plant's reproductive organs, and its function is to produce seeds through reproduction."]]

    var bird = [["Sparrow","Dove","Peacock","Ostrich","Pigeon"],["Birds are a group of warm-blooded vertebrates constituting the class Aves, characterised by feathers, toothless beaked jaws, the laying of hard-shelled eggs, a high metabolic rate, a four-chambered heart, and a strong yet lightweight skeleton."]]
    
    
    
    
    @IBAction func prevbuttonfunc(_ sender: UIButton) {
        if(topic == 1){
            imag1 -= 1
            name1 -= 1
            text1 -= 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 -= 1
            name2 -= 1
            text2 -= 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 -= 1
            name3 -= 1
            text3 -= 1
            dataUpdate(imgNo: imag3)
        }
    }
    @IBAction func nextbuttonfunc(_ sender: UIButton) {
        if(topic == 1){
            imag1 += 1
            name1 += 1
            text1 += 1
            dataUpdate(imgNo: imag1)
        }
        if(topic == 2){
            imag2 += 1
            name2 += 1
            text2 += 1
            dataUpdate(imgNo: imag2)
        }
        if(topic == 3){
            imag3 += 1
            name3 += 1
            text3 += 1
            dataUpdate(imgNo: imag3)
        }
    }
    
    
    @IBAction func searchbuttonfunc(_ sender: UIButton) {
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        ShowPrevImagesBtn.isHidden = false
        showNextImagesBtn.isHidden = false
        ShowPrevImagesBtn.isEnabled = false
        showNextImagesBtn.isEnabled = false
        resetButton.isEnabled = true
        if(actressess.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: array[0][imag1])
            topic = 1
            topicInfoText.text = actoress[1][0]
        }
        else if(plants.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: array[1][imag2])
            topic = 2
            topicInfoText.text = plant[1][0]
        }
        else if(birds.contains(searchTextField.text!)){
            showNextImagesBtn.isEnabled = true
            ShowPrevImagesBtn.isEnabled = false
            resultImage.image = UIImage(named: array[2][imag3])
            topic = 3
            topicInfoText.text = bird[1][0]
        }
        else{
            resultImage.image = UIImage(named: array[3][1])
            topicInfoText.text = nil
            ShowPrevImagesBtn.isHidden = true
            showNextImagesBtn.isHidden = true
            resetButton.isEnabled = true
        }
        
        
        
    }
    
    
    func dataUpdate(imgNo: Int){
        if(topic == 1){
            if imag1 == array[0].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[0][imag1])
                topicInfoText.text = actoress[1][0]
            }
            else if(imag1 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[0][imag1])
                topicInfoText.text = actoress[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[0][imag1])
                topicInfoText.text = actoress[1][0]
            }
        }
        if(topic == 2){
            if imag2 == array[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[1][imag2])
                topicInfoText.text = plant[1][0]
            }
            else if(imag2 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[1][imag2])
                topicInfoText.text = plant[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[1][imag2])
                topicInfoText.text = plant[1][0]
                
            }
        }
        if(topic == 3){
            if imag3 == array[1].count-1 {
                showNextImagesBtn.isEnabled = false
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[2][imag3])
                topicInfoText.text = bird[1][0]
            }
            else if(imag3 == 0){
                ShowPrevImagesBtn.isEnabled = false
                showNextImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[2][imag3])
                topicInfoText.text = bird[1][0]
            }
            else{
                showNextImagesBtn.isEnabled = true
                ShowPrevImagesBtn.isEnabled = true
                resultImage.image = UIImage(named: array[2][imag3])
                topicInfoText.text = bird[1][0]
                
            }
        }
    }
    
    
    
    @IBAction func resetbuttonfunc(_ sender: UIButton) {
        ShowPrevImagesBtn.isHidden = true
        showNextImagesBtn.isHidden = true
        resultImage.image = nil
        topicInfoText.text = nil
        searchTextField.text = nil
        resetButton.isHidden = true
        imag1 = 0
        imag2 = 0
        imag3 = 0
        name1 = 0
        name2 = 0
        name3 = 0
        text1 = 0
        text2 = 0
        text3 = 0
        topic = 0
    }

}

