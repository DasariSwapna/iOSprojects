//
//  ViewController.swift
//  Dasari_Calculator
//
//  Created by Swapna Dasari on 2/17/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var result: UILabel!
    
    
   
       
       var num1 = ""
       var num2 = ""
       var result1 = ""
       var operation = ""
       var currNum = ""
       var opChange = false
       var inChainmode = false
    

    func setData(_ number: String){
            if result.text == "0"{
                result.text = ""
            }
            else{
                if !opChange{
                    result.text! += number
                    num1 += number
                }
                else{
                    if !inChainmode{
                        result.text! += number
                        num2 += number
                    }
                    else{
                        result.text = ""
                        result.text! += number
                        num2 += number
                    }
                }
            }
        }
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    func clearAll(){
           num1 = ""
           num2 = ""
           opChange = false
           operation = ""
           currNum = ""
        result.text = ""
           inChainmode = false
       }
    @IBAction func ACButton(_ sender: UIButton) {
        clearAll()
    }
   
    
    func calTemp(_ operation:String)->String {
            if num1 != "" && num2 != ""{
                if operation == "+"{
                    num1 = String(Double(num1)! + Double(num2)!)
                    currNum = num2
                    num2 = ""
                    return String(num1)
                }
                if operation == "-"{
                    num1 = String(Double(num1)! - Double(num2)!)
                    currNum = num2
                    num2 = ""
                    
                    return String(num1)
                }
                if operation == "*"{
                    num1 = String(Double(num1)! * Double(num2)!)
                    currNum = num2
                    num2 = ""
                    return String(num1)
                }
                if operation == "/"{
                    num1 = String(Double(num1)! / Double(num2)!)
                    currNum = num2
                    num2 = ""
                    return String(num1)
                }
                if operation == "%" {
                    let s1 = Double(num1)!
                    let s2 = Double(num2)!
                    var r = s1.remainder(dividingBy: s2)
                    num1 = String(r)
                    currNum = num2
                    num2 = ""
                    return String(num1)
                }
            }
            return ""
        }
    
    
    func resultFormatter(_ result:String)->String {
          let value = Double(result)!
          var resultStr = String(round(value * 100000) / 100000.0)
          
          if resultStr.contains(".0"){
              resultStr.removeSubrange(resultStr.index(resultStr.endIndex, offsetBy: -2)..<resultStr.endIndex)
          }
          
          return resultStr
  }
    
    
    
   
    @IBAction func CButtton(_ sender: UIButton) {
        num2 = ""
        result.text = ""
        }
    
    
    @IBAction func PlusorMinus(_ sender: UIButton) {
        let pm = result.text!
              var RunningTotal = (pm as NSString).doubleValue
              if(RunningTotal > 0){
                  RunningTotal = RunningTotal * -1;
                  let std = String(format: "%.0f", RunningTotal)
                result.text = std;
      //            workings = std;
              }
              else{
                  RunningTotal = RunningTotal * -1;
                  let std = String(format: "%.0f", RunningTotal)
                result.text = std;
      //            workings = std;
              }
    }
    
    
    @IBAction func divideBy(_ sender: UIButton) {
        let temp = calTemp(operation)
              operation = "/"
        result.text = (temp != "") ? resultFormatter(temp) : ""
                if temp != "" {
                    //            inChainmode = true
                    if num2 != ""{
                        inChainmode = true
                        
                        if opChange {
                            result1 = String(Double(temp)! / Double(num2)!)
                            print(result1)
                            if result1 == "inf"{
                                result.text! = "Error"
                            }else{
                                result.text! = resultFormatter(result1)
                            }
                        }
                    }
                }
                opChange = true
        
        
    }
    
    
    
    @IBAction func Number7(_ sender: UIButton) {
        setData("7")
    }
    
    
    
    
    @IBAction func Number8(_ sender: UIButton) {
        setData("8")
    }
    
    
    
    @IBAction func Number9(_ sender: UIButton) {
        setData("9")
    }
    
    
    
    @IBAction func Number4(_ sender: UIButton) {
        setData("4")
    }
    
    
    
    @IBAction func Number5(_ sender: UIButton) {
        setData("5")
    }
    
    
    
    @IBAction func Number6(_ sender: UIButton) {
        setData("6")
    }
    
    
    @IBAction func Number1(_ sender: UIButton) {
        setData("1")
    }
    
    @IBAction func Number2(_ sender: UIButton) {
        setData("2")
    }
    
    
    @IBAction func Number3(_ sender: UIButton) {
        setData("3")
    }
    
    
    
    @IBAction func Number0(_ sender: UIButton) {
        setData("0")
    }
    
    
    @IBAction func decimalPoint(_ sender: UIButton) {
        setData(".")
    }
    
    
    
    @IBAction func percentileOperator(_ sender: Any) {
        
        let temp = calTemp(operation)
               print("temp is \(temp)")
               operation = "%"
               currNum=""
               result.text = (temp != "") ? resultFormatter(temp) : ""
                
               opChange = true
        
        
    }
    
    
    @IBAction func EqualsButton(_ sender: UIButton) {
        
        var res = ""
              switch operation {
              case "+":
                  
              if currNum != "" {
                      res = String(Double(num1)! + Double(currNum)!)
                      result.text = resultFormatter(res)
                       num2 = currNum
                  }else{
                      res = String(Double(num1)! + Double(num2)!)
                    result.text = resultFormatter(res)
                  }
                  num1 = res
                  
                  break
              case "*":
                  if currNum != "" {
                      res = String(Double(num1)! * Double(currNum)!)
                    result.text = resultFormatter(res)
                  }else{
                      res = String(Double(num1)! * Double(num2)!)
                    result.text = resultFormatter(res)
                  }
                  num1 = res
                  
                  break
              case "-":
                  if currNum != "" {
                      res = String(Double(num1)! - Double(currNum)!)
                    result.text = resultFormatter(res)
                      
                  }else{
                      res = String(Double(num1)! - Double(num2)!)
                    result.text = resultFormatter(res)
                     
                  }
                  num1 = res
                  break
              case "/":
                  if result.text == "Error"{
                      clearAll()
                  }else{
                      if currNum != "" {
                          res = String(Double(num1)! / Double(currNum)!)
                          if res == "inf"{
                            result.text! = "Error"
                              return
                          }else{
                            result.text = resultFormatter(res)
                          }
                      }else{
                          res = String(Double(num1)! / Double(num2)!)
                          if res == "inf"{
                            result.text! = "Error"
                              return
                          }else{
                            result.text = resultFormatter(res)
                          }
                      }
                      num1 = res
                  }
                  break
              case "%":
                  if currNum != "" {
                    result.text = resultFormatter(res)
                      let s1 = Double(num1)!
                      let s2 = Double(currNum)!
                      var r = s1.remainder(dividingBy: s2)
                      res = String(r)
                       num2 = currNum
                  }else{
                      let s1 = Double(num1)!
                      let s2 = Double(num2)!
                      var r = s1.remainder(dividingBy: s2)
                      res = String(r)
                    result.text = resultFormatter(res)
                  }
                  num1 = res
                  
                  break
                  
              default:
                  print("IOS")
              }
        
        
        
        
        
        
    }
    
    
    @IBAction func multiplyBy(_ sender: UIButton) {
        let temp = calTemp(operation)
              print("temp is \(temp)")
              operation = "*"
              currNum=""
              result.text = (temp != "") ? resultFormatter(temp) : ""
               
              opChange = true
        
        
    }
    
    
    @IBAction func minus(_ sender: UIButton) {
        if(num1 == ""){
                  num1 = "0"
              }
              let temp = calTemp(operation)
              print("temp is \(temp)")
              operation = "-"
              currNum=""
              result.text = (temp != "") ? resultFormatter(temp) : ""
              opChange = true
    }
    
    
    
    @IBAction func PlusButton(_ sender: UIButton) {
        let temp = calTemp(operation)
               print("temp is \(temp)")
               operation = "+"
               currNum=""
               result.text = (temp != "") ? resultFormatter(temp) : ""
               opChange = true
        
        
    }
    
    
    
    
    
    
    
    
}

