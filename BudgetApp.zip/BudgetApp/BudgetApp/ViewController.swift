//
//  ViewController.swift
//  BudgetApp
//
//  Created by Guntupalli,Mounisha on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Amountentered: UITextField!
    
    @IBOutlet weak var Discountentered: UITextField!
    
    @IBOutlet weak var displaylabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func onclicksubmit(_ sender: UIButton) {
        var amt = Amountentered.text!
        var amount = Double (amt)
        var dis = Discountentered.text!
        var discount = Double (dis)
        var res = amount! - (amount! * (discount!/100))
        
        
        displaylabel.text = "\(res)"
       
        
    }
}

