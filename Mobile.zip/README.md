npx react-native bundle --platform android --dev false --entry-file index.js --bundle-output android/app/src/main/assets/index.android.bundle --assets-dest android/app/src/main/res

./gradlew assembleDebug

Bodebeck LT Std
BodebeckLTStd-Regular
BodebeckLTStd-Italic
BodebeckLTStd-Bold
BodebeckLTStd-BoldItalic
BodebeckLTStd-ExtraBold
