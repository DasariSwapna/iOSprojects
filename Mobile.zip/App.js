import 'react-native-gesture-handler';
import React from 'react';
import Root from './src';
import {I18nextProvider} from 'react-i18next';
import i18next from 'i18next';
import {Provider as StoreProvider} from 'react-redux';
import {PersistGate} from 'redux-persist/integration/react';
import NetworkProvider from './src/contexts/NetworkContext';
import ScreenTrackContextProvider from './src/contexts/ScreenTrackContext';
import {store, persistor} from './src/store';
import {Provider} from 'react-native-paper';
import Config from 'react-native-config';

const App = () => {
  return (
    <StoreProvider store={store}>
      <I18nextProvider i18n={i18next}>
        <Provider>
          <PersistGate loading={null} persistor={persistor}>
            <NetworkProvider>
              <ScreenTrackContextProvider>
                <Root />
              </ScreenTrackContextProvider>
            </NetworkProvider>
          </PersistGate>
        </Provider>
      </I18nextProvider>
    </StoreProvider>
  );
};

export default App;
