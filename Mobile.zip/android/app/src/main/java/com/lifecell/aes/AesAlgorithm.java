package com.lifecell.aes;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
// import java.util.Base64;
import android.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class AesAlgorithm {
    private static byte[] salt = new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65,
            0x76 };

    public static String encryption(String plainText, String secretKey) {
        String strResult = null;
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            PBEKeySpec pbeKeySpec = new PBEKeySpec(secretKey.toCharArray(), salt, 1000, 384);
            byte[] derivedData = factory.generateSecret(pbeKeySpec).getEncoded();
            byte[] key = new byte[32];
            byte[] iv = new byte[16];
            System.arraycopy(derivedData, 0, key, 0, key.length);
            System.arraycopy(derivedData, key.length, iv, 0, iv.length);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivSpec);
            byte[] encrypted = cipher.doFinal(plainText.getBytes("UTF-16LE"));
            // strResult = Base64.getEncoder().encodeToString();
            strResult = Base64.encodeToString(encrypted, Base64.DEFAULT);
            return strResult;
        } catch (Exception e) {
            System.out.println("Error while encrypting: " + e.toString());
        }
        return strResult;
    }

    public static String decryption(String cipherText, String secretKey) {
        String strResult = null;
        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            PBEKeySpec pbeKeySpec = new PBEKeySpec(secretKey.toCharArray(), salt, 1000, 384);
            byte[] derivedData = factory.generateSecret(pbeKeySpec).getEncoded();
            byte[] key = new byte[32];
            byte[] iv = new byte[16];
            System.arraycopy(derivedData, 0, key, 0, key.length);
            System.arraycopy(derivedData, key.length, iv, 0, iv.length);
            IvParameterSpec ivSpec = new IvParameterSpec(iv);
            SecretKeySpec secretKeySpec = new SecretKeySpec(key, "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivSpec);
            byte[] decrypted = cipher.doFinal(Base64.decode(cipherText.getBytes("UTF-16LE"), Base64.DEFAULT));
            // String(cipher.doFinal(Base64.getDecoder().decode(cipherText.getBytes("UTF-8"))));
            strResult = new String(decrypted, "UTF-16LE");
            return strResult;
        } catch (Exception e) {
            System.out.println("Error while decrypting: " + e.toString());
        }
        return strResult;
    }

    public static String generateKey() throws IOException, GeneralSecurityException, ClassNotFoundException {
        int length = 25;
        String chars = "!@#$&*_+=.abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int index = (int) (chars.length() * Math.random());
            sb.append(chars.charAt(index));
        }
        return sb.toString();
    }

}
