// AES Algorithm Module Implementation
package com.lifecell;

import com.facebook.react.bridge.NativeModule;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Callback;
import com.facebook.react.bridge.Promise;
import java.util.Map;
import java.util.HashMap;
import android.util.Log;
import com.lifecell.aes.AesAlgorithm;

public class AesModule extends ReactContextBaseJavaModule {
    AesModule(ReactApplicationContext context) {
        super(context);
    }

    @Override
    public String getName() {
        return "AesModule";
    }

    @ReactMethod
    public void generateSecretKey(Promise promise) {
        Log.d("AesModule", "-----Key Generation-----");

        try {
            String key = AesAlgorithm.generateKey();
            promise.resolve(key);
        } catch (Exception e) {
            promise.reject(" Error", e);
        }
    }

    @ReactMethod
    public void encrypt(String plainText, String key, Promise promise) {
        Log.d("AesModule", "-----Encryption-----");
        Log.d("AesModule", "PlainText: " + plainText);
        Log.d("AesModule", "PlainText: " + key);
        String cipher = null;

        try {
            cipher = AesAlgorithm.encryption(plainText, key);
            promise.resolve(cipher);
        } catch (Exception e) {
            promise.reject(" Error", e);
        }
    }

    @ReactMethod
    public void decrypt(String cipherText, String key, Promise promise) {
        Log.d("AesModule", "-----Decryption-----");
        Log.d("AesModule", "CipherText: " + cipherText);
        Log.d("AesModule", "CipherText: " + key);
        String plain = null;
        try {
            plain = AesAlgorithm.decryption(cipherText, key);
            Log.d("AesModule", "PlainText: " + plain);
            promise.resolve(plain);
        } catch (Exception e) {
            promise.reject(" Error", e);
        }
    }

}