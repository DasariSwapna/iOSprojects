import React from 'react';
import {View, SafeAreaView} from 'react-native';
import {Button, Dialog, Paragraph, Portal} from 'react-native-paper';
import * as ImagePicker from 'react-native-image-picker';
import {getCameraPermission} from '../../services/Permissions';
// import * as ImageCropPicker from 'react-native-image-crop-picker';

export async function openCamera(
  setImageSource,
  setShowMessage,
  setMessage,
  setCameraPermission,
) {
  const result = await getCameraPermission();
  setCameraPermission(result);
  if (result == 'granted') {
    try {
      ImagePicker.launchCamera(
        {
          mediaType: 'photo',
          maxHeight: 600,
          maxWidth: 400,
          includeBase64: true,
        },
        response => {
          if (response.errorCode) {
            // console.log('Error:', response.errorCode);
            setShowMessage(true);
            setMessage(response.errorCode);
            setShowMessage(false);
          } else if (!response.didCancel) {
            // console.log('=================>Image: ', response.assets[0]);
            // alert('Image: ', response)
            // iPicker(response.assets[0]);
            setImageSource(response.assets[0]);

            // ImageCropPicker.openCropper({
            //   path: response.assets[0].uri,
            //   width: 300,
            //   height: 400,
            //   includeBase64: true
            // }).then(image => {
            //   setImageSource(image)
            //   console.log("========================================>IMGCAMERA" + JSON.stringify(image));
            // });
          }
        },
      );
    } catch (error) {
      console.log('Error:', error);
    }
  } else {
    console.log('permission denied');
  }
}

export function openImageGallery(setImageSource, setShowMessage, setMessage) {
  ImagePicker.launchImageLibrary(
    {
      mediaType: 'photo',
      includeBase64: false,
      maxHeight: 600,
      maxWidth: 400,
      includeBase64: true,
    },
    response => {
      // console.log(response);
      if (response.errorCode) {
        // console.log('Error:', response.errorCode);
        setShowMessage(true);
        setMessage(response.errorCode);
        setShowMessage(false);
      } else if (!response.didCancel) {
        // console.log(response.assets[0]);
        /// setImageSource(response.assets[0]);
        ImageCropPicker.openCropper({
          path: response.assets[0].uri,
          width: 300,
          height: 400,
          includeBase64: true,
        }).then(image => {
          setImageSource(image);
          console.log(
            '========================================>IMAGGALLERY' +
              JSON.stringify(image),
          );
        });
      }
    },
  );
}

export function CameraDialog({visible, hideDialog, takePicture, selectImage}) {
  return (
    <View>
      <Portal>
        <Dialog visible={visible} onDismiss={hideDialog}>
          <Dialog.Content>
            <Paragraph>Select your option</Paragraph>
          </Dialog.Content>
          <Dialog.Actions>
            <Button onPress={() => takePicture()}>Camera</Button>
            <Button onPress={() => selectImage()}>Image Gallery</Button>
          </Dialog.Actions>
        </Dialog>
      </Portal>
    </View>
  );
}
