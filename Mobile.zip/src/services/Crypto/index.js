import React from 'react';
import {NativeModules} from 'react-native';

var Aes = NativeModules.Aes;
// let iv = 'EB03E728620191091A207A8B865BAC3E';
let key = '923D10CDCC3696B99466694DD226A5AAD9EA90241AB5142000365B9828FE377E';

const encryptData = (data, iv) => {
  return Aes.encrypt(data, key, iv).then(cipher => ({
    cipher,
    iv,
  }));
};

const decryptData = (data, iv) => Aes.decrypt(data, key, iv);

export async function encrypt(data, iv) {
  return encryptData(data, iv)
    .then(({cipher}) => {
      return cipher;
    })
    .catch(error => {
      return error;
    });
}

export async function decrypt(data, iv) {
  return decryptData(data, iv)
    .then(text => {
      return text;
    })
    .catch(error => {
      return error;
    });
}

export async function generateIv() {
  try {
    let secret = await Aes.randomKey(16);
    return secret;
  } catch (error) {
    console.log('Iv Error');
    return error;
  }
}

export async function wrapData(data, iv) {
  console.log('Encrypt original:', data, iv);
  let wrapedData = {};
  let cipher = await encrypt(JSON.stringify(data), iv);
  wrapedData.payload = cipher;
  // console.log('wraper: ', wrapedData);
  return wrapedData;
}

export async function unwrapData(data, iv) {
  try {
    console.log('Decrypt original:', data, iv);
    let unwrapedData = {};
    if (data) {
      let plain = await decrypt(data, iv);
      unwrapedData = JSON.parse(plain);
    }
    console.log('unwraper: ', unwrapedData);
    return unwrapedData;
  } catch (error) {
    console.log('Decryption Error');
    return {};
  }
}
