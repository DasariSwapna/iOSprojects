import {PermissionsAndroid, Platform} from 'react-native';
import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoding';
import {check, request, PERMISSIONS, RESULTS} from 'react-native-permissions';

/**
 * Camera permission for both Android and IOS
 * it return permission string
 */
export async function getCameraPermission() {
  let granted;
  if (Platform.OS === 'ios') {
    granted = await check(PERMISSIONS.IOS.CAMERA);
    // console.log('Check permission:', granted);
    if (granted === RESULTS.GRANTED) return granted;
    else {
      granted = await request(PERMISSIONS.IOS.CAMERA);
      return granted;
    }
  } else {
    granted = await check(PERMISSIONS.ANDROID.CAMERA);
    if (granted === RESULTS.GRANTED) return granted;
    else {
      granted = await request(PERMISSIONS.ANDROID.CAMERA);
      return granted;
    }
  }
}

export async function getMicroPhonePermission() {
  let granted;
  if (Platform.OS === 'ios') {
    granted = await check(PERMISSIONS.IOS.MICROPHONE);
    // console.log('Check permission:', granted);
    if (granted === RESULTS.GRANTED) return granted;
    else {
      granted = await request(PERMISSIONS.IOS.MICROPHONE);
      return granted;
    }
  } else {
    granted = await check(PERMISSIONS.ANDROID.RECORD_AUDIO);
    if (granted === RESULTS.GRANTED) return granted;
    else {
      granted = await request(PERMISSIONS.ANDROID.RECORD_AUDIO);
      return granted;
    }
  }
}

export const getCurrentLocation = () =>
  new Promise((resolve, reject) => {
    Geolocation.getCurrentPosition(
      position => {
        const cords = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };
        resolve(cords);
      },
      error => {
        reject(error.message);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  });

export const locationPermission = () =>
  new Promise(async (resolve, reject) => {
    if (Platform.OS === 'ios') {
      try {
        const permissionStatus = await Geolocation.requestAuthorization(
          'whenInUse',
        );
        if (permissionStatus === 'granted') {
          return resolve('granted');
        }
        reject('Permission not granted');
      } catch (error) {
        return reject(error);
      }
    }
    return PermissionsAndroid.request(
      PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
    )
      .then(granted => {
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          resolve('granted');
        }
        return reject('Location Permission denied');
      })
      .catch(error => {
        console.log('Ask Location permission error: ', error);
        return reject(error);
      });
  });
