import axios from 'axios';
import {store} from '../../store';
import {getToken} from '../../store/Actions';

const IV_KEY = '834bebb688d53c0c4d3cc28b7a983a79';

// function retryRequest(originalRequest) {
//   // const data = {refresh: store.getState().login.refresh};
//   const data = {
//     loginUser: '9600138425',
//     password: 'TestA@123',
//   };
//   store.dispatch(getToken(data, ''));
//   const retryOriginalRequest = new Promise(resolve => {
//     originalRequest.headers.Authorization =
//       'Bearer ' + store.getState().signIn.accessToken;
//     resolve(axios(originalRequest));
//   });
//   return retryOriginalRequest;
// }

// axios.interceptors.response.use(
//   function (response) {
//     const originalRequest = response.config;
//     if (response && response.status === 401) {
//       console.log(
//         '%%%%%%%%%%%%%%%  Generate Token is Called  %%%%%%%%%%%%%%%%%%%',
//       );
//       const retry = retryRequest(originalRequest);
//       return retry;
//     }
//     return response;
//   },
//   function (error) {
//     return Promise.reject(error);
//   },
// );

const request = async options => {
  return await axios(options)
    .then(response => {
      console.log('axios response --->', response);
      return response;
    })
    .catch(error => {
      console.log('axios error --->', error);
      return error;
    });
};
const getRequest = async (url, key, token) => {
  //const getRequest = async (url, key, token) => {
  console.log('get request..', url, token);
  console.log('key--->' + JSON.stringify(key));
  console.log('token--->' + token);
  let response;
  let header = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ClientSecret: `${key}`,
  };
  if (token) {
    header.Authorization = `Bearer ${token}`;
  }
  const requestOptions = {
    url: url,
    method: 'get',
    headers: header,
    timeout: 1000 * 5,
    validateStatus: status => {
      return true;
    },
  };
  response = await request(requestOptions);
  return response;
};

const postRequest = async (url, params, key, token) => {
  console.log('post request...', url, params, token);
  console.log('key--->' + key);
  console.log('token--->' + token);

  let response;
  const header = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
    ClientSecret: `${key}`,
  };
  if (token) {
    header.Authorization = `Bearer ${token}`;
  }
  const requestOptions = {
    url: url,
    method: 'POST',
    headers: header,
    data: params,
    // timeout: 1000 * 5,
    validateStatus: status => {
      return true;
    },
  };
  console.log(requestOptions);
  response = await request(requestOptions);
  return response;
};

const putRequest = (url, params) => {
  console.log('put request...', url, params);
  let response;
  const header = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };
  const requestOptions = {
    method: 'PUT',
    headers: header,
    body: JSON.stringify(params),
  };
  response = request(url, requestOptions);
  return response;
};

const deleteRequest = url => {
  console.log('delete request...', url);
  let response;
  const header = {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };
  const requestOptions = {
    method: 'DELETE',
    headers: header,
  };
  response = request(url, requestOptions);
  return response;
};

export {getRequest, postRequest, putRequest, deleteRequest};
