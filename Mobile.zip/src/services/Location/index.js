import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoding';

export const getCoordinates = address => {
  console.log('addr:', address);
  Geocoder.from(address)
    .then(async json => {
      var location = json.results[0].geometry.location;
      console.log('Location', location);
      return {
        latitude: location.latitude,
        longitude: location.longitude,
      };
    })
    .catch(error => console.warn(error));
};

export const getAddress = coords => {
  const address = {};
  console.log('address', coords);
  return Geocoder.from(coords)
    .then(json => {
      console.log('--->', json.results);
      var location = json.results[0].formatted_address;
      var addrComponents = json.results[0].address_components;
      const [flatNo, street, area, ...address] = [...location.split(',')];
      addrComponents.map(item => {
        if (item.types.includes('administrative_area_level_2'))
          address.city = item.long_name;
        else if (item.types.includes('administrative_area_level_1'))
          address.state = item.long_name;
        else if (item.types.includes('country'))
          address.country = item.long_name;
        else if (item.types.includes('postal_code'))
          address.pincode = item.long_name;
      });
      return {
        ...address,
        //addrFirstLine: `${flatNo}, ${street}, ${area}`,
        addrFirstLine: location,
        addrSecondLine: address.toString(),
      };
    })
    .catch(error => console.warn(error));
};

export const getCurrentLocation = () =>
  new Promise((resolve, reject) => {
    Geolocation.getCurrentPosition(
      position => {
        const cords = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
        };
        resolve(cords);
      },
      error => {
        reject(error.message);
      },
      {enableHighAccuracy: true, timeout: 15000, maximumAge: 10000},
    );
  });
