import React from 'react';
import {View, Image, Dimensions, TouchableOpacity} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import SliderMenu from '../containers/manager/SliderMenu';
import {Manager} from './RouteTypes';
import Home from '../containers/manager/Home';
import Colors from '../config/Colors';
import Images from '../constants/Images';
import {Font} from '../config/Fonts';
import QuotationHome from '../containers/manager/Quotation';
import QuotationReview from '../containers/manager/QuotationReview';

import QuotationReviewStatus from '../containers/manager/QuotationReviewStatus';

import QuotationApproved from '../containers/manager/QuotationApprovedDetails';
import DiscountApproved from '../containers/manager/DiscountApprovalDetails';

import DiscountApprovedReview from '../containers/manager/DiscountApprovalReview';

const {width, height} = Dimensions.get('screen');
const drawerWidth = width * 0.74;
const backArrowSize = width * 0.04;

const Drawer = createDrawerNavigator();

const MyDrawer = () => {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      screenOptions={{
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        drawerStyle: {
          width: drawerWidth,
        },
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
        headerStyle: {
          elevation: 0,
          shadowOpacity: 0,
        },
        headerRight: () => (
          <View style={{width: 40, height: 40}}>
            <Image
              source={Images.headerLogo}
              style={{width: 36, height: 36, resizeMode: 'contain'}}
            />
          </View>
        ),
        headerRightContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}
      headerMode="screen"
      drawerContent={props => <SliderMenu {...props} />}>
      <Drawer.Screen
        name={Manager.home}
        component={Home}
        options={({navigation, route}) => ({
          titlee: 'Home',
          headerLeft: props => (
            <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
              <Ionicons
                style={{padding: 10}}
                color={Colors.primary}
                name="menu"
                size={30}
              />
            </TouchableOpacity>
          ),
        })}
      />
    </Drawer.Navigator>
  );
};

const AppStack = createStackNavigator();

export default function AppNav() {
  return (
    <AppStack.Navigator
      initialRouteName={Manager.myDrawer}
      screenOptions={{
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        headerBackTitleVisible: false,
        headerStyle: {
          shadowColor: 'transparent',
          backgroundColor: Colors.card,
        },
        headerLeftContainerStyle: {
          paddingHorizontal: 10,
        },
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
        headerRight: () => (
          <View style={{width: 40, height: 40}}>
            <Image
              source={Images.headerLogo}
              style={{width: 36, height: 36, resizeMode: 'contain'}}
            />
          </View>
        ),
        headerRightContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}>
      <AppStack.Screen
        name={Manager.myDrawer}
        component={MyDrawer}
        options={{headerShown: false}}
      />
      <AppStack.Screen
        name={Manager.quotationhome}
        component={QuotationHome}
        // options={{title: 'MOU'}}
      />
      <AppStack.Screen
        name={Manager.quotationreview}
        component={QuotationReview}
        // options={{title: 'QU06-10610'}}
      />

      <AppStack.Screen
        name={Manager.quotationreviewstatus}
        component={QuotationReviewStatus}
        //  options={{title: 'QU06-10610'}}
      />

      <AppStack.Screen
        name={Manager.quotationapproved}
        component={QuotationApproved}
        // options={{title: 'QU06-10610'}}
      />

      <AppStack.Screen
        name={Manager.discountapproved}
        component={DiscountApproved}
        // options={{title: 'QU06-10610'}}
      />

      <AppStack.Screen
        name={Manager.discountapproveddetails}
        component={DiscountApprovedReview}
        // options={{title: 'QU06-10610'}}
      />
    </AppStack.Navigator>
  );
}
