import React from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import Splash from '../containers/Splash';
import AppLanding from '../containers/Landing';
import {Auth} from './RouteTypes';

const Stack = createNativeStackNavigator();

export const InitialNavigator = () => {
  return (
    <Stack.Navigator
      initialRouteName={Auth.splash}
      screenOptions={{headerShown: false}}>
      <Stack.Screen name={Auth.splash} component={Splash} />
      <Stack.Screen name={Auth.landing} component={AppLanding} />
    </Stack.Navigator>
  );
};

export default InitialNavigator;
