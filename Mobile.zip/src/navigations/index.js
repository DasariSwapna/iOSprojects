import React, {useState, useContext, useEffect} from 'react';
import {useColorScheme} from 'react-native';
import {connect} from 'react-redux';
import {
  NavigationContainer,
  useNavigationContainerRef,
} from '@react-navigation/native';
import AuthNav from './AuthNavigation';
import AppNav from './AppNavigation';
import InitialNav from './InitialNavigation';
import {ScreenTrackContext} from '../contexts/ScreenTrackContext';
import {MyDrakTheme, MyLightTheme} from '../config/Theme';

export const routeNameRef = React.createRef();

function RootNavigation(props) {
  const scheme = useColorScheme();
  const screenContext = useContext(ScreenTrackContext);
  const navigationRef = useNavigationContainerRef();
  const [token, setToken] = useState(null);
  const [status, setStatus] = useState(null);
  const [userType, setUserType] = useState('');
  const [appLaunched, setAppLaunched] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setToken(props.accessToken);
    setUserType(props.role);
    setStatus(props.activationStatus);
    // console.log('access', props.accessToken);
  }, [props.accessToken, props.activationStatus]);

  useEffect(() => {
    setAppLaunched(props.isAppLaunched);
  }, [props.isAppLaunched]);

  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 2000);
  });

  return (
    <NavigationContainer
      ref={navigationRef}
      theme={scheme == 'dark' ? MyDrakTheme : MyLightTheme}
      onReady={() => {
        routeNameRef.current = navigationRef.getCurrentRoute()?.name;
        screenContext.setCurrentScreen(routeNameRef.current);
      }}
      onStateChange={async () => {
        const previousRouteName = routeNameRef.current;
        const currentRouteName = navigationRef.getCurrentRoute()?.name;
        if (previousRouteName !== currentRouteName) {
          console.log('--------Current Screen Name--------', currentRouteName);
        }
        // Save the current route name for later comparison
        routeNameRef.current = currentRouteName;
        screenContext.setCurrentScreen(currentRouteName);
        screenContext.setPrevScreen(currentRouteName);
      }}>
      {loading || appLaunched === false ? (
        <InitialNav />
      ) : token != null && status == true ? (
        <AppNav role={props.role} />
      ) : (
        <AuthNav status={props.activationStatus} />
      )}
    </NavigationContainer>
  );
}

const mapStateToProps = state => {
  return {
    isAppLaunched: state.common.isAppLaunched,
    accessToken: state.signIn.accessToken,
    activationStatus: state.signIn.activationStatus,
    role: state.signIn.role,
  };
};

export default connect(mapStateToProps)(RootNavigation);
