import React, {useState, useEffect} from 'react';
import {connect, useDispatch} from 'react-redux';
import ParamedicNav from './ParamedicNav';
import SalesNav from './SalesNav';
import ManagerNav from './ManagerNav';
import {View, Text, Pressable} from 'react-native';
import Colors from '../config/Colors';
import {Font, FontSize} from '../config/Fonts';

const SALES = 5; // 5; //   8;
const PARAMEDIC = 4; // 4; // 9;
const MANAGER = 7; // 7; //10;

const SALES1 = 8; // 5; //   8;
const PARAMEDIC1 = 9; // 4; // 9;
const MANAGER1 = 10; // 7; //10;

function RoleNotMatch({logoutHandler}) {
  return (
    <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
      <Text
        style={{
          fontSize: FontSize.medium,
          fontFamily: Font.bold,
        }}>
        Role Not Match
      </Text>
      <Pressable onPress={logoutHandler}>
        <Text
          style={{
            color: Colors.primary,
            fontSize: FontSize.medium,
            fontFamily: Font.bold,
          }}>
          Logout
        </Text>
      </Pressable>
    </View>
  );
}

function AppNav({role}) {
  const dispatch = useDispatch();

  return (
    <>
      {parseInt(role) == (PARAMEDIC1 || PARAMEDIC) && <ParamedicNav />}
      {parseInt(role) == (SALES1 || SALES) && <SalesNav />}
      {parseInt(role) == (MANAGER1 || MANAGER) && <ManagerNav />}
      {/* {role != (PARAMEDIC || PARAMEDIC1) &&
        role != (SALES || SALES1) &&
        role != (MANAGER1 || MANAGER) && (
          <RoleNotMatch logoutHandler={() => dispatch({type: 'LOGOUT'})} />
        )} */}
    </>
  );
}

const mapStateToProps = state => {
  return {};
};

export default connect(mapStateToProps)(AppNav);
