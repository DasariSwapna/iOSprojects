import React, {useCallback, useEffect, useState} from 'react';
import {connect, useDispatch} from 'react-redux';
import {Dimensions, View, TouchableOpacity} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {HeaderBackButton} from '@react-navigation/elements';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import SignIn from '../containers/SignIn';
import SignUp from '../containers/SignUp';
import SignUpWithOtp from '../containers/SignInWithOtp';
import ForgotPassword from '../containers/ForgotPassword';
import ResetPassword from '../containers/ResetPassword';
import ProfilePending from '../containers/ProfilePending';
import {Auth} from './RouteTypes';
import {Font, FontSize} from '../config/Fonts';
import Colors from '../config/Colors';
import {signUpBackHandle} from '../store/Actions';

const {width, height} = Dimensions.get('screen');
const backArrowSize = width * 0.04;

const AuthStack = createStackNavigator();

function AuthNav(props) {
  const dispatch = useDispatch();
  const [signBack, setSignBack] = useState(0);

  useEffect(() => {
    dispatch(signUpBackHandle({status: 0}));
  }, [dispatch]);

  useEffect(() => {
    setSignBack(props.signUpBackState);
  }, [props.signUpBackState]);

  function signUpBack() {
    console.log(props.signUpBackState);
    if (props.signUpBackState == 3) dispatch(signUpBackHandle({status: 2}));
    if (props.signUpBackState == 2) dispatch(signUpBackHandle({status: 1}));
    if (props.signUpBackState == 1) dispatch(signUpBackHandle({status: 0}));
  }

  return (
    <AuthStack.Navigator
      initialRouteName={Auth.signIn}
      screenListeners={({navigator, route}) => ({
        state: e => {
          // console.log('state changed', e.data.state.routes);
          // console.log('Route Name:==============>#########', route.name);
          if (route.name == Auth.signUp) {
            console.log('==============>', 'back--------->?', route.path);
          }
          if (route.name == Auth.profilePending) {
            console.log('==============>');
          }
        },
      })}
      screenOptions={{
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        headerBackTitleVisible: false,
        headerTitleStyle: {
          fontFamily: Font.extraBold,
          fontSize: FontSize.large,
        },
        headerStyle: {
          elevation: 0,
          shadowOpacity: 0,
          backgroundColor: Colors.background,
        },
        headerLeftContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}>
      <AuthStack.Screen
        name={Auth.signIn}
        component={SignIn}
        options={{
          title: '',
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: Colors.card,
          },
        }}
      />
      <AuthStack.Screen
        name={Auth.signUp}
        component={SignUp}
        options={({navigation}) => ({
          title: 'Create your profile',
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: Colors.background,
          },
          headerLeft: props => (
            <HeaderBackButton
              {...props}
              onPress={
                signBack == 0 || signBack > 3
                  ? () => navigation.goBack()
                  : () => signUpBack()
              }
            />
          ),
        })}
      />
      <AuthStack.Screen
        name={Auth.signUpWithOtp}
        component={SignUpWithOtp}
        options={{
          title: '',
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: Colors.card,
          },
        }}
      />
      <AuthStack.Screen
        name={Auth.forgotPassword}
        component={ForgotPassword}
        options={{
          title: '',
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: Colors.card,
          },
        }}
      />
      <AuthStack.Screen
        name={Auth.resetPassword}
        component={ResetPassword}
        options={{
          title: 'New Password',
          headerStyle: {
            elevation: 0,
            shadowOpacity: 0,
            backgroundColor: Colors.card,
          },
        }}
      />
      <AuthStack.Screen
        name={Auth.profilePending}
        component={ProfilePending}
        options={({navigation, route}) => ({
          headerTitle: '',
          headerLeft: () => <View />,
          headerRight: () => (
            <View style={{width: 40, height: 40}}>
              <TouchableOpacity
                onPress={() => navigation.navigate(Auth.signIn)}>
                <FaIcons5
                  name="arrow-right"
                  color={Colors.primary}
                  size={backArrowSize}
                />
              </TouchableOpacity>
            </View>
          ),
        })}
      />
    </AuthStack.Navigator>
  );
}

const mapStateToProps = state => {
  return {
    signUpBackState: state.signUp.signUpBackState,
  };
};

export default connect(mapStateToProps)(AuthNav);
