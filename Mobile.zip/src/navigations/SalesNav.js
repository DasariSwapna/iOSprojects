import React from 'react';
import {connect, useDispatch} from 'react-redux';
import {View, Image, Dimensions, TouchableOpacity, Text} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {HeaderBackButton} from '@react-navigation/elements';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import Ionicons from 'react-native-vector-icons/Ionicons';

import {Sales} from './RouteTypes';
import SliderMenu from '../containers/sales/SliderMenu';
import Home from '../containers/sales/Home';
import Colors from '../config/Colors';
import {Font} from '../config/Fonts';
import Images from '../constants/Images';
import CreateOrderBasicDetails from '../containers/sales/CreateOrder/CreateOrderBasicDetails';
import CreateOrderReferalDetails from '../containers/sales/CreateOrder/CreateOrderReferalDetails';
import CreateOrderAddTest from '../containers/sales/CreateOrder/CreateOrderAddTest';
import CreateOrderPickupDate from '../containers/sales/CreateOrder/CreateOrderPickupDate';
import CreateOrderSummary from '../containers/sales/CreateOrder/CreateOrderSummary';
import CashCollect_Deposit from '../containers/sales/CashCollect_Deposit';
import CashdepositCalendar from '../containers/sales/CashdepositCalendar';
import CashdepositQR from '../containers/sales/CashdepositQR';
import CreateOrderConfirmation from '../containers/sales/CreateOrder/CreateOrderConfirmation';
import PaymentCollection from '../containers/payment/PaymentCollection';
import PaymentRequest from '../containers/payment/PaymentRequest';
import PaymentStatus from '../containers/payment/PaymentStatus';

import CreateVendorBasicDetails from '../containers/sales/CreateVendor/CreateVendorBasicDetails';
import CreateVendorAddTest from '../containers/sales/CreateVendor/CreateVendorAddTest';
import CreateVendorTermsCondition from '../containers/sales/CreateVendor/CreateVendorTermsCondition';
import CreateVendorPreview from '../containers/sales/CreateVendor/CreateVendorPreview';
import CreateVendorAuthentication from '../containers/sales/CreateVendor/CreateVendorAuthentication';
import CreateVendorRetailAgreement from '../containers/sales/CreateVendor/CreateVendorRetailAgreement';
import CreateVendorQuestionsTermsCondition from '../containers/sales/CreateVendor/CreateVendorQuestionTermsCondition';

import ManagerApproval from '../containers/sales/ManagerApproval/ManagerApproval';
import ManagerApprovalStatus from '../containers/sales/ManagerApproval/MangaerApprovalStatus';
import ManagerApprovalTermsCondition from '../containers/sales/ManagerApproval/MangerApprovalTermsCondition';
import ManagerApprovalPreview from '../containers/sales/ManagerApproval/ManagerApprovalPreview';
import ManagerApprovalAuthentication from '../containers/sales/ManagerApproval/ManagerApprovalAuthentication';
import ManagerApprovalQuotation from '../containers/sales/ManagerApproval/ManagerApprovalQuotation';
import ManagerApprovalAddTest from '../containers/sales/ManagerApproval/ManagerApprovalAddTest';
import UploadCopy from '../containers/sales/UploadSignedCopy/UploadCopy';
import UploadPreview from '../containers/sales/UploadSignedCopy/UploadPreview';
import UploadCapture from '../containers/sales/UploadSignedCopy/UploadCapture';
import ReceiveCash from '../containers/sales/ReceiveCash';
import CashdepositCapture from '../containers/sales/CashdepositCapture';
import Create from '../containers/sales/Create';
import CreateOrderConfirmationPreview from '../containers/sales/CreateOrder/CreateOrderConfirmationPreview';
import SalesPaymentCollection from '../containers/sales/CreateOrder/SalesPaymentCollection';
import Address from '../containers/sales/Address';
import {storeAddress} from '../store/Actions';

const {width, height} = Dimensions.get('screen');
const drawerWidth = width * 0.74;
const backArrowSize = width * 0.04;

const Drawer = createDrawerNavigator();

const MyDrawer = () => {
  return (
    <Drawer.Navigator
      headerMode="screen"
      screenOptions={{
        presentation: 'transparentModal',
        drawerStyle: {
          width: drawerWidth,
        },
        headerStyle: {
          elevation: 0,
          shadowOpacity: 0,
        },
        headerTitleAlign: 'center',
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
        headerRight: () => (
          <View style={{width: 40, height: 40}}>
            <Image
              source={Images.headerLogo}
              style={{width: 36, height: 36, resizeMode: 'contain'}}
            />
          </View>
        ),
        headerRightContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}
      drawerContent={props => <SliderMenu {...props} />}>
      <Drawer.Screen
        name={Sales.home}
        component={Home}
        options={({navigation, route}) => ({
          titlee: 'Home',
          headerLeft: props => (
            <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
              <Ionicons
                style={{padding: 10}}
                color={Colors.primary}
                name="menu"
                size={30}
              />
            </TouchableOpacity>
          ),
        })}
      />
    </Drawer.Navigator>
  );
};

const AppStack = createStackNavigator();

export default function AppNav() {
  const dispatch = useDispatch();
  function callAddress() {
    dispatch(
      storeAddress(
        {
          addrFirstLine: '',
          addrSecondLine: '',
          city: '',
          country: '',
          latitude: '',
          longitude: '',
          pincode: '',
          state: '',
        },
        null,
      ),
    );
  }
  return (
    <AppStack.Navigator
      initialRouteName={Sales.myDrawer}
      screenListeners={({navigator, route}) => ({
        state: e => {
          console.log('state changed', e.data.state);
          console.log('Route Name:', route.name);
        },
      })}
      screenOptions={{
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        headerBackTitleVisible: false,
        headerStyle: {
          shadowColor: 'transparent',
          backgroundColor: Colors.card,
        },
        headerLeftContainerStyle: {
          paddingHorizontal: 10,
        },
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
        headerRight: () => (
          <View style={{width: 40, height: 40}}>
            <Image
              source={Images.headerLogo}
              style={{width: 36, height: 36, resizeMode: 'contain'}}
            />
          </View>
        ),
        headerRightContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}>
      <AppStack.Screen
        name={Sales.myDrawer}
        component={MyDrawer}
        options={{headerShown: false}}
      />
      <AppStack.Screen name={Sales.home} component={Home} />
      {/* Create order */}
      <AppStack.Screen
        name={Sales.createOrderBasicDetails}
        component={CreateOrderBasicDetails}
        options={({navigation, route}) => ({
          headerTitle: 'Create order',
          headerLeft: props => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                callAddress();
                navigation.goBack();
              }}
            />
          ),
        })}
      />
      <AppStack.Screen
        name={Sales.createOrderReferalDetails}
        component={CreateOrderReferalDetails}
        options={{title: 'Referral details'}}
      />
      <AppStack.Screen
        name={Sales.createOrderAddTest}
        component={CreateOrderAddTest}
        options={{title: 'Add test'}}
      />
      <AppStack.Screen
        name={Sales.createOrderPickupDate}
        component={CreateOrderPickupDate}
        options={{title: 'Pickup date & time'}}
      />
      <AppStack.Screen
        name={Sales.createOrderSummary}
        component={CreateOrderSummary}
        options={{title: 'Order summary'}}
      />
      <AppStack.Screen
        name={Sales.createOrderConfirmation}
        component={CreateOrderConfirmation}
        options={{title: 'Order confirmation'}}
      />

      {/* Payment Collection */}
      <AppStack.Screen
        name={Sales.paymentCollection}
        component={PaymentCollection}
        options={{title: 'Payment collection'}}
      />
      <AppStack.Screen
        name={Sales.cashCollect_deposit}
        component={CashCollect_Deposit}
        options={{title: 'Cash deposit'}}
      />
      <AppStack.Screen
        name={Sales.cashdepositCalendar}
        component={CashdepositCalendar}
        options={{title: 'Cash Deposit'}}
      />

      <AppStack.Screen
        name={Sales.cashdepositQR}
        component={CashdepositQR}
        options={{title: 'Cash deposit QR'}}
      />

      <AppStack.Screen
        name={Sales.paymentRequest}
        component={PaymentRequest}
        options={{title: 'Payment Collection'}}
      />
      <AppStack.Screen
        name={Sales.paymentStatus}
        component={PaymentStatus}
        options={{title: 'Payment Collection'}}
      />

      {/* Craete Vendor */}
      <AppStack.Screen
        name={Sales.createVendorBasicDetails}
        component={CreateVendorBasicDetails}
        options={{title: 'Create vendor'}}
      />
      <AppStack.Screen
        name={Sales.createVendorAddTest}
        component={CreateVendorAddTest}
        options={{title: 'Add test'}}
      />
      <AppStack.Screen
        name={Sales.createVendorTermsCondition}
        component={CreateVendorTermsCondition}
        options={({navigation, route}) => ({
          headerTitle: 'Preview',
          headerLeft: () => <View />,
        })}
      />
      <AppStack.Screen
        name={Sales.createVendorQuestionsTermsCondition}
        component={CreateVendorQuestionsTermsCondition}
        options={{title: 'Terms & Condition'}}
      />
      <AppStack.Screen
        name={Sales.createVendorPreview}
        component={CreateVendorPreview}
        options={{title: 'Preview'}}
      />
      <AppStack.Screen
        name={Sales.createVendorAuthentication}
        component={CreateVendorAuthentication}
        options={{title: 'Authentication'}}
      />

      <AppStack.Screen
        name={Sales.createVendorRetailAgreement}
        component={CreateVendorRetailAgreement}
        options={{title: 'Retail agreement'}}
      />

      {/* Manager Approval */}

      <AppStack.Screen
        name={Sales.ManagerApproval}
        component={ManagerApproval}
        options={{title: 'Manager approval'}}
      />
      <AppStack.Screen
        name={Sales.ManagerApprovalStatus}
        component={ManagerApprovalStatus}
        options={{title: 'Approval status'}}
      />
      <AppStack.Screen
        name={Sales.ManagerApprovalTermsCondition}
        component={ManagerApprovalTermsCondition}
        options={{title: 'Terms & conditions'}}
      />
      <AppStack.Screen
        name={Sales.ManagerApprovalPreview}
        component={ManagerApprovalPreview}
        options={({navigation, route}) => ({
          headerTitle: 'Preview',
          headerLeft: props => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                navigation.goBack();
              }}
            />
          ),
        })}
      />
      <AppStack.Screen
        name={Sales.ManagerApprovalAuthentication}
        component={ManagerApprovalAuthentication}
        options={{title: 'Authentication'}}
      />

      <AppStack.Screen
        name={Sales.ManagerApprovalQuotation}
        component={ManagerApprovalQuotation}
        options={{title: 'Quotation'}}
      />

      <AppStack.Screen
        name={Sales.ManagerApprovalAddTest}
        component={ManagerApprovalAddTest}
        options={{title: 'Add Test'}}
      />
      {/* Upload Signed Copy */}
      <AppStack.Screen
        name={Sales.UploadCopy}
        component={UploadCopy}
        options={{title: 'Upload signed copy'}}
      />
      <AppStack.Screen
        name={Sales.UploadPreview}
        component={UploadPreview}
        options={{title: 'Preview'}}
      />
      <AppStack.Screen
        name={Sales.UploadCapture}
        component={UploadCapture}
        options={{title: 'Upload/Capture'}}
      />
      <AppStack.Screen
        name={Sales.receiveCash}
        component={ReceiveCash}
        options={{title: 'Receive Cash'}}
      />
      <AppStack.Screen
        name={Sales.Create}
        component={Create}
        options={{title: 'Create'}}
      />

      <AppStack.Screen
        name={Sales.cashdepositCapture}
        component={CashdepositCapture}
        options={{title: 'Cash Deposit Capture'}}
      />

      <AppStack.Screen
        name={Sales.CreateOrderConfirmationPreview}
        component={CreateOrderConfirmationPreview}
        options={{title: 'Order confirmation', headerLeft: null}}
      />
      <AppStack.Screen
        name={Sales.SalesPaymentCollection}
        component={SalesPaymentCollection}
        options={{title: 'Payment collection'}}
      />
      <AppStack.Screen
        name={Sales.Address}
        component={Address}
        options={({navigation, route}) => ({
          headerTitle: 'Address',
          headerLeft: props => (
            <HeaderBackButton
              {...props}
              onPress={() => {
                callAddress();
                navigation.goBack();
              }}
            />
          ),
        })}
      />

      {/* <AppStack.Screen name={Sales.home} component={Home} /> */}
    </AppStack.Navigator>
  );
}
