/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {DrawerActions} from '@react-navigation/native';
import {connect} from 'react-redux';
import {View, Image, Dimensions, TouchableOpacity, Text} from 'react-native';
import {createStackNavigator} from '@react-navigation/stack';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {createDrawerNavigator} from '@react-navigation/drawer';
import Ionicons from 'react-native-vector-icons/Ionicons';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import {Paramedic} from './RouteTypes';
import Home from '../containers/paramedic/Home';
import MyTask from '../containers/paramedic/MyTask';
import Alert from '../containers/paramedic/Alert';
import Calender from '../containers/paramedic/Calender';
import SliderMenu from '../containers/paramedic/SliderMenu';
import MyPerformance from '../containers/paramedic/MyPerformance';
import ProfileStartDay from '../containers/paramedic/ProfileStartDay';
import BabyCord from '../containers/paramedic/BabyCord';
import BabyCordDetails from '../containers/paramedic/BabyCordDetails';
import ReportDispatch from '../containers/paramedic/ReportDispatch';
import Pns from '../containers/paramedic/PNS';
import PnsDetails from '../containers/paramedic/PNSDetails';
import PnsSelectTest from '../containers/paramedic/PNSSelectTest';
import CancelledOrReturnKit from '../containers/paramedic/CancelledOrReturnKit';
import TieUpHospital from '../containers/paramedic/TieUpHospital';
import HelpLine from '../containers/paramedic/HelpLine';
import ReportDispatchDetails from '../containers/paramedic/ReportDispatchDetails';
import Colors from '../config/Colors';
import {Font} from '../config/Fonts';
import Images from '../constants/Images';
import SamplePickUp from '../containers/paramedic/SamplePickUp';
import KitScan from '../containers/paramedic/KitScan';
import ScanTRF from '../containers/paramedic/ScanTRF';
import CancelledOrReturnKitDetails from '../containers/paramedic/CancelledOrReturnKitDetails';
import ScanTRFForPNS from '../containers/paramedic/ScanTRFForPNS';
import Shuttle from '../containers/paramedic/Shuttle';
import Deposit from '../containers/paramedic/Deposit';
import DepositQR from '../containers/paramedic/DepositQR';
import Task from '../containers/paramedic/Task';
import DepositBankCalendar from '../containers/paramedic/DepositBankCalendar';
import BarcodeScanner from '../containers/paramedic/BarcodeScanner';
import RegularBeat from '../containers/paramedic/TieupHospitalRegularBeat';
import QRScanner from '../containers/paramedic/QRScanner';
import PaymentCollection from '../containers/payment/PaymentCollection';
import PaymentRequest from '../containers/payment/PaymentRequest';
import PaymentStatus from '../containers/payment/PaymentStatus';
import Kit_SampleHandover from '../containers/paramedic/Kit_SampleHandover';
import KitSampleQR from '../containers/paramedic/KitSampleQR';
import KitSampleCenter from '../containers/paramedic/KitSampleCenter';
import kitSampleCourier from '../containers/paramedic/kitSampleCourier';
import DepositCamera from '../containers/paramedic/DepositCamera';
import KitCourierCamera from '../containers/paramedic/KitCourierCamera';
import TaskQR from '../containers/paramedic/TaskQR';
import TieupHospitalSampleType from '../containers/paramedic/TieupHospitalSampleType';
import TaskReport from '../containers/paramedic/TaskReport';
import KitSampleLab from '../containers/paramedic/KitSampleLab';

const {width, height} = Dimensions.get('screen');
const drawerWidth = width * 0.74;
const backArrowSize = width * 0.04;

const Drawer = createDrawerNavigator();

function MyDrawer() {
  return (
    <Drawer.Navigator
      initialRouteName="Home"
      screenOptions={({navigator, route}) => ({
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        drawerStyle: {
          width: drawerWidth,
        },
        headerStyle: {
          elevation: 0,
          shadowOpacity: 0,
          shadowColor: 'transparent',
          backgroundColor: Colors.card,
        },
        headerLeftContainerStyle: {
          paddingHorizontal: 10,
        },
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
      })}
      headerMode="screen"
      drawerContent={props => <SliderMenu {...props} />}>
      <Drawer.Screen
        name={Paramedic.home}
        component={Home}
        options={({navigation, route}) => ({
          titlee: 'Home',
          headerLeft: props => (
            <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
              <Ionicons
                style={{padding: 10}}
                color={Colors.primary}
                name="menu"
                size={30}
              />
            </TouchableOpacity>
          ),
        })}
      />
      <Drawer.Screen
        name={Paramedic.myPerformance}
        component={MyPerformance}
        options={({navigation, route}) => ({
          titlee: 'Home',

          headerLeft: props => (
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <FaIcons5
                name="arrow-left"
                color={Colors.primary}
                size={backArrowSize}
              />
            </TouchableOpacity>
          ),
        })}
      />
      <Drawer.Screen
        name={Paramedic.helpLine}
        component={HelpLine}
        options={({navigation, route}) => ({
          titlee: 'Home',
          headerLeft: props => (
            <TouchableOpacity onPress={() => navigation.goBack()}>
              <FaIcons5
                name="arrow-left"
                color={Colors.primary}
                size={backArrowSize}
              />
            </TouchableOpacity>
          ),
        })}
      />
    </Drawer.Navigator>
  );
}

const AppStack = createStackNavigator();
function AppNav(props) {
  return (
    <AppStack.Navigator
      initialRouteName={
        props.dayStartStatus == 1
          ? Paramedic.myDrawer
          : Paramedic.profileStartDay
      }
      screenListeners={({navigator, route}) => ({
        state: e => {
          // console.log('state changed', e.data.state.routes);
          // console.log('Route Name:==============>#########', route.name);
        },
      })}
      screenOptions={{
        presentation: 'transparentModal',
        headerTitleAlign: 'center',
        headerBackTitleVisible: false,
        headerStyle: {
          elevation: 0,
          shadowOpacity: 0,
          shadowColor: 'transparent',
          backgroundColor: Colors.card,
        },
        headerLeftContainerStyle: {
          paddingHorizontal: 10,
        },
        headerTitleStyle: {
          fontFamily: Font.extraBold,
        },
        headerRight: () => (
          <View style={{width: 40, height: 40}}>
            <Image
              source={Images.headerLogo}
              style={{width: 36, height: 36, resizeMode: 'contain'}}
            />
          </View>
        ),
        headerRightContainerStyle: {
          paddingHorizontal: 10,
        },
        headerBackImage: () => (
          <FaIcons5
            name="arrow-left"
            color={Colors.primary}
            size={backArrowSize}
          />
        ),
      }}>
      <AppStack.Screen
        name={Paramedic.myDrawer}
        component={MyDrawer}
        options={{headerShown: false}}
      />
      <AppStack.Screen
        name={Paramedic.myTask}
        component={MyTask}
        options={{title: 'My Task'}}
      />
      <AppStack.Screen
        name={Paramedic.babyCord}
        component={BabyCord}
        options={{title: 'My Task'}}
      />
      <AppStack.Screen
        name={Paramedic.reportDispatch}
        component={ReportDispatch}
        options={{title: 'Report Dispatch'}}
      />
      <AppStack.Screen
        name={Paramedic.reportDispatchDetails}
        component={ReportDispatchDetails}
        options={{title: 'Report Dispatch'}}
      />
      <AppStack.Screen
        name={Paramedic.babyCordDetails}
        component={BabyCordDetails}
        options={{title: 'Baby Cord'}}
      />
      <AppStack.Screen
        name={Paramedic.pns}
        component={Pns}
        options={{title: 'My Task'}}
      />
      <AppStack.Screen
        name={Paramedic.pnsDetails}
        component={PnsDetails}
        //options={{title: 'PNS'}}
      />
      <AppStack.Screen
        name={Paramedic.pnsSelectTest}
        component={PnsSelectTest}
        options={{title: 'Select Test'}}
      />
      <AppStack.Screen
        name={Paramedic.cancelledOrReturnKit}
        component={CancelledOrReturnKit}
        options={{title: 'My Task'}}
      />
      <AppStack.Screen
        name={Paramedic.cancelledOrReturnKitDetails}
        component={CancelledOrReturnKitDetails}
        options={{title: 'Cancelled / ReturnKit'}}
      />
      <AppStack.Screen
        name={Paramedic.tieUpHospital}
        component={TieUpHospital}
        options={{title: 'Regular Beat'}}
      />
      <AppStack.Screen
        name={Paramedic.samplePickUp}
        component={SamplePickUp}
        options={{title: 'Sample pickup'}}
      />
      <AppStack.Screen
        name={Paramedic.regularBeat}
        component={RegularBeat}
        options={{title: 'Regular Beat'}}
      />
           <AppStack.Screen
        name={Paramedic.tieupHospitalSampleType}
        component={TieupHospitalSampleType}
        options={{title: 'Regular Beat'}}
      />

      <AppStack.Screen
        name={Paramedic.kitScan}
        component={KitScan}
        // options={{ title: 'Scan kit' }}
      />

      <AppStack.Screen
        name={Paramedic.scanTRF}
        component={ScanTRF}
        options={{title: 'Scan TRF'}}
      />

      <AppStack.Screen
        name={Paramedic.scanTRFForPNS}
        component={ScanTRFForPNS}
        options={{title: 'Scan TRF'}}
      />

      <AppStack.Screen
        name={Paramedic.barcodeScanner}
        component={BarcodeScanner}
        options={{title: 'Barcode Scan'}}
      />

      <AppStack.Screen
        name={Paramedic.qrScanner}
        component={QRScanner}
        options={{title: 'QR Code Scan'}}
      />

      <AppStack.Screen
        name={Paramedic.alert}
        component={Alert}
        options={{title: 'Alert'}}
      />

      <AppStack.Screen
        name={Paramedic.calender}
        component={Calender}
        options={{title: 'Calender'}}
      />

      <AppStack.Screen
        name={Paramedic.profileStartDay}
        component={ProfileStartDay}
        options={{headerShown: false}}
      />
      <AppStack.Screen
        name={Paramedic.shuttle}
        component={Shuttle}
        options={{title: 'Shuttle Pickup'}}
      />
      <AppStack.Screen
        name={Paramedic.deposit}
        component={Deposit}
        options={{title: 'Cash deposit'}}
      />
      <AppStack.Screen
        name={Paramedic.depositQr}
        component={DepositQR}
        options={{title: 'Cash deposit'}}
      />
      <AppStack.Screen
        name={Paramedic.task}
        component={Task}
        options={{title: 'Create Tasks'}}
      />
      <AppStack.Screen
        name={Paramedic.depositBankCalendar}
        component={DepositBankCalendar}
        options={{title: 'Cash deposit'}}
      />
      <AppStack.Screen
        name={Paramedic.paymentCollection}
        component={PaymentCollection}
        options={{title: 'Payment Collection'}}
      />

      <AppStack.Screen
        name={Paramedic.paymentRequest}
        component={PaymentRequest}
        options={{title: 'Payment Collection'}}
      />
      <AppStack.Screen
        name={Paramedic.paymentStatus}
        component={PaymentStatus}
        options={{title: 'Payment Collection'}}
      />
      <AppStack.Screen
        name={Paramedic.kitSampleHandover}
        component={Kit_SampleHandover}
        options={{title: 'Kit / Sample handover'}}
      />
      <AppStack.Screen
        name={Paramedic.kitSampleCourier}
        component={kitSampleCourier}
        options={{title: 'Courier details'}}
      />

      <AppStack.Screen
        name={Paramedic.depositCamera}
        component={DepositCamera}
        options={{title: 'Deposit Camera'}}
      />

      <AppStack.Screen
        name={Paramedic.kitCourierCamera}
        component={KitCourierCamera}
        options={{title: 'Kit Courier Camera'}}
      />
      <AppStack.Screen
        name={Paramedic.kitsampleQr}
        component={KitSampleQR}
        options={{title: 'Kit / Sample handover'}}
      />

      <AppStack.Screen
        name={Paramedic.kitsampleCenter}
        component={KitSampleCenter}
        options={{title: 'Select center'}}
      />

      <AppStack.Screen
        name={Paramedic.taskqr}
        component={TaskQR}
        options={{title: 'Shuttle pickup'}}
      />
      <AppStack.Screen
        name={Paramedic.taskReports}
        component={TaskReport}
        options={{title: 'Create Tasks'}}
      />
      <AppStack.Screen
        name={Paramedic.kitsampleLab}
        component={KitSampleLab}
        options={{title: 'Select Lab'}}
      />
      {/* <AppStack.Screen
        name={Paramedic.sampleType}
        component={TieupHospitalSampleType}
        options={{title: 'Sample Type'}}
      /> */}
    </AppStack.Navigator>
  );
}
const mapStateToProps = state => {
  return {
    dayStartStatus: state.signIn.dayStartStatus,
  };
};
export default connect(mapStateToProps)(AppNav);
