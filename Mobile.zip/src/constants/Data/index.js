const stateList = [
  {
    label: 'Andhra Pradesh',
    value: 'andhra pradesh',
  },
  {
    label: 'Kerala',
    value: 'kerala',
  },
  {
    label: 'Karnataka',
    value: 'karnataka',
  },
  {
    label: 'Tamilnadu',
    value: 'tamilnadu',
  },
];

const cityList = [
  {
    label: 'Chennai',
    value: 'chennai',
  },
  {
    label: 'Cuddalore',
    value: 'cuddalore',
  },
  {
    label: 'Panruti',
    value: 'panruti',
  },
  {
    label: 'Villupuram',
    value: 'villupuram',
  },
];

const addressType = [
  {
    label: 'annanager',
    value: 'annanager',
  },
  {
    label: 'annanager',
    value: 'padi',
  },
];

const referredBy = [
  {
    label: 'No referral',
    value: 'No referral',
  },
  {
    label: 'LifeCell',
    value: 'LifeCell',
  },
  {
    label: 'Hospital',
    value: 'Hospital',
  },
  {
    label: 'Doctor',
    value: 'Doctor',
  },
];

const paymentMode = [
  {
    label: 'Cash',
    value: 'cash',
  },
  {
    label: 'Online',
    value: 'online',
  },
];

export default Data = {
  stateList,
  cityList,
  addressType,
  referredBy,
  paymentMode,
};
