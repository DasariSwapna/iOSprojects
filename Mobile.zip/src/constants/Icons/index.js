// Sales dashboard
import CreateOrder from '../../assets/icons/createOrder.png';
import ManageOrder from '../../assets/icons/manageOrder.png';
import CreateVendor from '../../assets/icons/createVendor.png';
import ManageVendor from '../../assets/icons/manageVendor.png';
import ManageApproval from '../../assets/icons/managerApproval.png';
import Referral from '../../assets/icons/referral.png';
import PlansAndTest from '../../assets/icons/plansAndTest.png';
import Cash from '../../assets/icons/cash.png';
import Invoice from '../../assets/icons/invoice.png';
import Upload from '../../assets/icons/upload.png';

import MyTaskIcon from '../../assets/icons/myTaskIcon.png';
import ReferEnrollment from '../../assets/icons/referEnrollment.png';
import Kit from '../../assets/icons/kit.png';
import Covid from '../../assets/icons/covid.png';
import Shuttle from '../../assets/icons/shuttle.png';

import BabyCord from '../../assets/icons/BabyCord.png';
import PNS from '../../assets/icons/PNS.png';
import NBS from '../../assets/icons/NBS.png';
import CancelledOrReturnKit from '../../assets/icons/CancelledOrReturnKit.png';
import AlliedOrRoutine from '../../assets/icons/AlliedOrRoutine.png';
import TieupHospital from '../../assets/icons/TieupHospital.png';

import Reports from '../../assets/icons/Reports.png';
import QrScanner from '../../assets/icons/qrScanner.png';
import Barcode from '../../assets/icons/barcode.png';
import SmallBarcode from '../../assets/icons/smallBarcode.png';
import DownloadIcon from '../../assets/icons/downloadIcon.png';
import ShareIcon from '../../assets/icons/shareIcon.png';
// payment
import QrWhite from '../../assets/icons/qrWhite.png';
import QrPink from '../../assets/icons/qrPink.png';
import LinkWhite from '../../assets/icons/linkWhite.png';
import LinkPink from '../../assets/icons/linkPink.png';
import QrImage from '../../assets/icons/qrImage.png';
import Globe from '../../assets/icons/globe.png';
import PaymentTick from '../../assets/icons/paymentTick.png';
import PaymentTime from '../../assets/icons/paymentTime.png';

import MouQuotations from '../../assets/icons/mouquotation.png';
import RetailtoInvoice from '../../assets/icons/retailtoinvoice.png';
import DiscountApprovals from '../../assets/icons/discountapprovals.png';

import Revision from '../../assets/icons/reviseicons.png';
import Approved from '../../assets/icons/approvedicons.png';

//Side and Bottom menu
import Catelog from '../../assets/icons/catelog.png';
import InvoiceBottom from '../../assets/icons/invoice-bottom.png';
import HelpLine from '../../assets/icons/helpline.png';
import Alert from '../../assets/icons/alert.png';

export default Icons = {
  createOrder: CreateOrder,
  manageOrder: ManageOrder,
  createVendor: CreateVendor,
  manageVendor: ManageVendor,
  manageApproval: ManageApproval,
  referral: Referral,
  plansAndTest: PlansAndTest,
  cash: Cash,
  invoice: Invoice,
  upload: Upload,
  myTaskIcon: MyTaskIcon,
  referEnrollment: ReferEnrollment,
  kit: Kit,
  covid: Covid,
  shuttle: Shuttle,

  babyCord: BabyCord,
  pns: PNS,
  nbs: NBS,
  alliedOrRoutine: AlliedOrRoutine,
  cancelledOrReturnKit: CancelledOrReturnKit,
  tieupHospital: TieupHospital,
  reports: Reports,
  qrScanner: QrScanner,
  barcode: Barcode,
  smallBarcode: SmallBarcode,
  downloadIcon: DownloadIcon,
  shareIcon: ShareIcon,
  qrWhite: QrWhite,
  qrPink: QrPink,
  linkWhite: LinkWhite,
  linkPink: LinkPink,
  qrImage: QrImage,
  globe: Globe,
  paymentTick: PaymentTick,
  paymentTime: PaymentTime,
  mouQuotation: MouQuotations,
  retailtoInvoice: RetailtoInvoice,
  discountApprovals: DiscountApprovals,
  revisionQuotation: Revision,
  approvalQuotation: Approved,
  invoiceBottom: InvoiceBottom,
  catelog: Catelog,
  helpline: HelpLine,
  alert: Alert,
};
