export default PageNo = {
  landing: '01', //01
  signIn: '02', //02
  signInWithOtp: '03', //03
  signInOtpModal: '04', //04
  signUp: '05', //05
  signUp2: '06', //06
  signUp3: '07', //07
  signUp4: '08', //08
  forgotPassword: '09', //09
  forgotOtpModal: '10', //10
  setPassword: '11', //11
  profilePending: '12', //12

  //sales
  sales_home: 'BD-13', // 13
  sales_create: 'BD-13A', //BD-13
  sales_createOrder: 'BD-61', //BD-61
  sales_createOrderAddTest: 'BD-62', //BD-62
  sales_createOrderReferDetails: 'BD-63', //BD-63
  sales_createOrderPickupdate: 'BD-64', //BD-64
  sales_createOrderSummary: 'BD-64', //BD-64
  sales_paymentCollection: 'BD-66', //BD-66
  sales_paymentCollectionScan: 'BD-69', //BD-69
  sales_paymentCollectionStatus: 'BD-91', //BD-91
  sales_createVendorTermsCondition: 'BD-91', //BD-91
  sales_managerApproval: 'BD-96', //BD-96
  sales_uploadSignedCopy: 'BD-96', //BD-96
  sales_manageApprovalQuotation: 'BD-99', //BD-99
  sales_manageApprovalPreview: 'BD-110', //BD-110
  sales_uploadSignedPreview: 'BD-110', //BD-110
  sales_authentication: 'BD-111', //BD-111
  sales_createVendor: 'BD-113', //BD-113
  sales_createVendorAuthentication: 'BD-118', //BD-118
  sales_createVendorOtp: 'BD-119', //BD-119
  sales_createVendorRetailAgreement: 'BD-120', //BD-120
  sales_createVendorAddTest: 'BD-122', //BD-122
  sales_createVendorPreview: 'BD-123', //BD-123
  sales_cashCollectDeposit: 'BD-14', //
  sales_cashDepositCalendar: 'BD-17', //
  sales_cashDepositCapture: 'BD-21', //
  sales_receiveCash: 'BD-24', //

  //paramedic
  paramedic_home: 'PA-15', //PA-15,
  paramedic_myTask: 'PA-16', //PA-16,
  paramedic_babyCord: 'PA-17', //PA-17,
  paramedic_babyCordDetails: 'PA-22', //PA-22,
  paramedic_babycordKitScan: 'PA-25', //PA-25,
  paramedic_captureCard: 'PA-26', //PA-26,
  paramedic_PNS: 'PA-40', //PA-40,
  paramedic_PNSDetails: 'PA-42', //PA-42,
  paramedic_PNSDetailsSamplePickup: 'PA-43', //PA-43,
  paramedic_selectTest: 'PA-44-1', //PA-44-1,
  paramedic_PNSCaptureCard: 'PA-46', //PA-46,
  paramedic_paymentCollection: 'PA-49', //PA-49,
  paramedic_paymentQrOrLink: 'PA-52', //PA-52,
  paramedic_paymentQr: 'PA-55', //PA-55,
  paramedic_paymentLink: 'PA-56', //PA-56,
  paramedic_paymentStatus: 'PA-62', //PA-62,
  paramedic_alliedOrRoutine: 'PA-A35', //PA-A35,
  paramedic_regularBeat: 'PA-101', //PA-101,
  paramedic_regularBeatSamplePickup: 'PA-103', //PA-103,
  paramedic_sampleType: 'PA-106', //PA-106,
  paramedic_regularBeatCaptureTRF: 'PA-107', //PA-107,
  paramedic_cancelledOrReturnKit: 'PA-113', //PA-113,
  paramedic_cancelledOrReturnKitDetails: 'PA-113', //PA-113,
  paramedic_cancelledOrReturnKitCapture: 'PA-122', //PA-122,
  paramedic_reportDispatch: 'PA-296', //PA-122,
  paramedic_reportDispatchDetails: 'PA-297', //PA-122,
  paramedic_deposit: 'PA-196', //PA-196
  paramedic_depositQr: 'PA-201', //PA-201
  paramedic_depositBankCalendar: 'PA-207', //PA-207
  paramedic_depositCamera: 'PA-208', //PA-208
  paramedic_kitSampleHandover: 'PA-210', //PA-210
  paramedic_task: 'PA-221', //PA-221
  paramedic_kitSampleQR: 'PA-267', //PA-267
  paramedic_kitSampleCenter: 'PA-269', //PA-269
  paramedic_kitSampleCourier: 'PA-275', //PA-275
  paramedic_kitCourierCamera: 'PA-276', //PA-276
  paramedic_shuttleQr: 'PA-278', //PA-278
  paramedic_shuttle: 'PA-281', //PA-281
  paramedic_taskReport: 'PA-292', //PA-292

  //manager
  manager_home: 'SM-03', //SM-03,
};
