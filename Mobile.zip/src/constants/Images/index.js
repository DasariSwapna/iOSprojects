/* eslint-disable no-undef */
import LoginBg from '../../assets/images/LoginBg.png';
import Logo from '../../assets/images/LifeCellLogo.png';
import IsolveLogo from '../../assets/images/IsolveLogo.png';
import VoilaLogo from '../../assets/images/VoilaLogo.png';
import ForgotPasswordBg from '../../assets/images/ForgotPasswordBg.png';
import Background from '../../assets/images/backgroundlifecell.png';
import Backgrounddaystart from '../../assets/images/backgrounddaystart.png';
// import InnerHeaderLogo from '../../assets/images/innerHeaderLogo.png';
import HeaderLogo from '../../assets/images/headerLogo.png';
import CreateOrder from '../../assets/images/c_order.png';
import ManageOrder from '../../assets/images/m_order.png';
import CreateVendor from '../../assets/images/c_vendor.png';
import MangaeVendor from '../../assets/images/m_vendor.png';
import ManageApproval from '../../assets/images/m_approval.png';
import Referral from '../../assets/images/referral.png';
import PlansTest from '../../assets/images/plansTest.png';
import Cash from '../../assets/images/cash.png';
import Invoice from '../../assets/images/invoice.png';
import Upload from '../../assets/images/upload.png';
import DrawerMenu from '../../assets/images/drawerMenu.png';
import LogoIsolve from '../../assets/images/LogoIsolve.png';
import LandingBg from '../../assets/images/LandingBg.png';
import StartDayBg from '../../assets/images/StartDayBg.png';
import Download1 from '../../assets/images/download1.png';

import Signature from '../../assets/images/signature.png';

export default Images = {
  loginBg: LoginBg,
  logo: Logo,
  iSolveLogo: IsolveLogo,
  voilaLogo: VoilaLogo,
  forgotpasswordBg: ForgotPasswordBg,
  backgroundImage: Background,
  backgroundDaystartImage: Backgrounddaystart,
  headerLogo: HeaderLogo,
  logoIsolve: LogoIsolve,
  landingBg: LandingBg,
  startDayBg: StartDayBg,
  createOrder: CreateOrder,
  manageOrder: ManageOrder,
  createVendor: CreateVendor,
  mangaeVendor: MangaeVendor,
  manageApproval: ManageApproval,
  referral: Referral,
  plansTest: PlansTest,
  cash: Cash,
  invoice: Invoice,
  upload: Upload,
  dawerMenu: DrawerMenu,
  logoIsolve: LogoIsolve,
  download1: Download1,
  signature: Signature,
};
