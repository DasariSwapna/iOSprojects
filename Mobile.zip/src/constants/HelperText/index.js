const signIn = {
  username: 'Username is empty',
  password: 'Password is empty',
};

const createOrder = {
  firstName: 'Enter valid first Name',
  lastName: 'Enter valid last name',
  primarContact: 'Enter valid Mobile No',
  email: 'Enter valid email',

  addressType: 'Select address Type',
  address: 'Enter valid address',
  state: 'Select state',
  city: 'Select city',

  pincode: 'Enter valid pincode',
  referBy: 'select referred By',
  hospital: 'select hospital',
  doctor: 'select doctor',

  remarks: 'Enter remarks',
  pickupType: 'select pickup type',

}

const validateAddressLine = {
  empty: { status: false, msg: 'hfyk' },
  minLength: { status: false, msg: 'rtyrtu' },
  maxLength: { status: false, msg: 'thtyjy' },
};

export default HelperText = {
  signIn,
  createOrder,
  validateAddressLine,
};
