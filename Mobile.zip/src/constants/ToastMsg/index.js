const kyc = {
  panSuccess: 'PAN validated successfully',
  panFailure: 'PAN No is not valid',
  aadharSuccess: 'Aadhaar validated successfully',
  aadharFailure: 'OTP Mismatch',
  aadharOtpSuccess: 'Otp sent to your register number',
  aadharOtpFailure: 'Aadhaar NO is not valid',
  kycSuccess: 'KYC submitted successfully',
  kycFailure: 'Please try again',
};

const branch = {
  baaSuccess: 'Branch and Account information submited successfully',
  baaFailure: 'Please try again',
};

const personal = {
  baaSuccess: 'Personal information submited successfully',
  baaFailure: 'Please try again',
};

const address = {
  addrSuccess: 'Address and occupation information submited successfully',
  addrFailure: 'Please try again',
  idProof: 'Please Select id Proof',
  idAddProof: 'Please Select id and address Proof'
};

const additional = {
  addSuccess: 'Additional details are submited successfully',
  addFailure: 'Please try again',
};

const preview = {
  preSuccess: 'Application details are submited successfully',
  preFailure: 'Please try again',
};

export default Toast = {
  kyc,
  branch,
  personal,
  address,
  additional,
  preview,
};
