const reg = {
  otpSuccess: '',
  otpFailure: '',
  regSuccess: '',
  regFailure: '',
};
const kyc = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};
const branch = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};
const personal = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};
const address = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};
const additional = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};
const schedule = {
  panSuccess: '',
  panFailure: '',
  aadhaarSuccess: '',
  aadhaarFailure: '',
};

export default Toast = {
  reg,
  kyc,
  branch,
  personal,
  address,
  additional,
  schedule,
};
