import Colors from '../../config/Colors';
import labelJson from '../../locale/en.json';
import localPageNos from '../../constants/PageNo';

export const delay = ms => new Promise(res => setTimeout(res, ms));

export function getObjectByKey(list = [], keyName, key) {
  if (list != null && list.length > 0) {
    const obj = list.find(item => item[keyName] == key);
    return obj;
  } else {
    return null;
  }
}

export function pageNoChangeHandler(pageNos) {
  // console.log('===============>');
  // console.log(Object.keys(localPageNos));
  // console.log(pageNos);
  Object.keys(localPageNos).map(page => {
    // console.log(pageNos[page]);
    if (pageNos && pageNos[page]) localPageNos[page] = pageNos[page];
  });
}

export function themeChangeHandler(themes) {
  Object.keys(Colors).map(colorName => {
    // console.log('--->', colorName);
    // console.log(theme[colorName]);
    if (themes[colorName]) Colors[colorName] = themes[colorName];
  });
}

export function labelChangeHandler(labels) {
  const localLabels = labelJson.translation;
  Object.keys(localLabels).map(label => {
    // console.log(label);
    Object.keys(localLabels[label]).map(innerLabel => {
      if (labels[label]) {
        // console.log(localLabels[label][innerLabel]);
        // console.log(labels[label][innerLabel]);
        localLabels[label][innerLabel] = labels[label][innerLabel];
      }
    });
  });
}
