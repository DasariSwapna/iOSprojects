import moment from 'moment';
import I18n from '../../locale/i18n';

const re =
  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

const mediumRegex = new RegExp(
  // /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*])[0-9a-zA-Z]{8,}$/,
  /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
  ///^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,28}$/,
  ///^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,28}$/
  // /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,}$/,
);

function isPassword(password) {
  return mediumRegex.test(String(password));
}

function isString(s) {
  return s.match('^[a-zA-Z()]+$');
}

function isEmail(email) {
  return re.test(String(email).toLowerCase());
}

export function validateEmpId(val) {
  if (val.trim() == '')
    return {val: false, msg: I18n.t('valitation.emp_id_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateMobileNo(mobileNo) {
  if (mobileNo.trim() == '')
    return {val: false, msg: I18n.t('valitation.mobile_empty')};
  if (mobileNo.length <= 9)
    return {val: false, msg: I18n.t('valitation.min_mobile')};
  if (mobileNo.length >= 11)
    return {val: false, msg: I18n.t('valitation.min_mobile')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateMatchMobileNo(value1, value2) {
  if (value1 == value2) return {val: false, msg: I18n.t('valitation.match_no')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateMobileNoOrEmail(val) {
  // Mobile number/ Email ID is empty
  if (val.trim() == '')
    return {val: false, msg: I18n.t('valitation.mobile_or_email_empty')};
  if (val.includes('@')) return validateEmail(val);
  else return validateMobileNo(val);
}

export function validatePrimaryContMobNo(mobileNo) {
  if (mobileNo.trim() == '')
    return {val: false, msg: I18n.t('valitation.primary_empty')};
  if (mobileNo.length <= 9)
    return {val: false, msg: I18n.t('valitation.primary_valid')};
  if (mobileNo.length >= 11)
    return {val: false, msg: I18n.t('valitation.primary_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateAltContMobNo(mobileNo) {
  if (mobileNo.trim() == '')
    return {val: false, msg: I18n.t('valitation.altenate_empty')};
  if (mobileNo.length <= 9)
    return {val: false, msg: I18n.t('valitation.altenate_valid')};
  if (mobileNo.length >= 11)
    return {val: false, msg: I18n.t('valitation.altenate_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateAmount(Amount) {
  if (Amount.trim() == '')
    return {val: false, msg: I18n.t('valitation.amount_empty')};
  if (Amount.length > 10)
    return {val: false, msg: I18n.t('valitation.amount_max')};
  return {val: true, msg: I18n.t('valitation.success')};
}

// export function validateEmpty(value) {
//   if (value.trim() == '')
//     return {val: false, msg: I18n.t('valitation.value_is_empty')};
//   return {val: true, msg: I18n.t('valitation.success')};
// }

export function firstnameEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.firtstname_is_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function lastnameEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.lastname_is_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateText(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.value_is_empty')};
  if (isString(value) == null)
    return {val: false, msg: I18n.t('valitation.valid_text')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateQualificationText(value) {
  if (value == '')
    return {val: false, msg: I18n.t('valitation.qualification_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateExperienceNumber(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.experience_empty')};
  if (isNaN(value)) return {val: false, msg: I18n.t('valitation.not_a_number')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateNumber(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.value_is_empty')};
  if (isNaN(value)) return {val: false, msg: I18n.t('valitation.not_a_number')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatePincodeNumber(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.pincode_empty')};
  if (value.startsWith('0'))
    return {val: false, msg: I18n.t('valitation.pincode_start')};
  if (value.length <= 5)
    return {val: false, msg: I18n.t('valitation.not_a_pincoder')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateOTP(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.otp_empty')};
  if (value.length <= 5) return {val: false, msg: I18n.t('valitation.min_otp')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatePasswordEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.password_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatePassword(value) {
  // console.log(mediumRegex.test(value));
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.password_empty')};

  if (isPassword(value) == false)
    return {val: false, msg: I18n.t('valitation.password_invalid')};

  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateConfirmPassword(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.confirm_password_empty')};
  //if (!mediumRegex.match(value))
  if (isPassword(value) == false)
    return {val: false, msg: I18n.t('valitation.password_invalid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatematchPassword(value1, value2) {
  if (value1 != value2)
    return {val: false, msg: I18n.t('valitation.mismatch_password')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateAddressLine(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.addr_empty')};

  if (value.length <= 9)
    return {val: false, msg: I18n.t('valitation.addr_min')};

  if (value.length >= 255)
    return {val: false, msg: I18n.t('valitation.addr_create_order_max')};

  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.mobemail_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatePincodeEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.pincode_empty')};
  if (value != '') {
    const re = /^[1-9][0-9]*$/;
    return {
      val: re.test(value),
      msg: 'Please enter valid pincode',
    };
  }
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateRemarksEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.remarks_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateRadioEmpty(value) {
  if (value == '') return {val: false, msg: I18n.t('valitation.select_value')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateUsername(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.username_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateStateDropdownEmpty(value) {
  if (value == '' || value == null)
    return {val: false, msg: I18n.t('valitation.state_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateCityDropdownEmpty(value) {
  if (value == '' || value == null)
    return {val: false, msg: I18n.t('valitation.city_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}
export function validateFirstname(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.firstName_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateLastname(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.lastName_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatedoctorFirstname(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.doctor_firstName_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validatedoctorLastname(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.doctor_lastName_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateAccountype(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.account_type_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateState(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.state_not_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateCity(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.city_not_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateSpecilityname(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.select_speciliaity')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateEmail(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.email_is_empty')};
  if (isEmail(value) == false)
    return {val: false, msg: I18n.t('valitation.emailid_is_invalid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateRoleDropdownEmpty(value) {
  if (value == '') return {val: false, msg: I18n.t('valitation.role_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateEmail1(email) {
  if (email.trim() == '')
    return {val: false, msg: I18n.t('valitation.email_empty')};
  if (email != '') {
    const re =
      /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return {
      val: re.test(String(email).toLowerCase()),
      msg: I18n.t('valitation.email_valid'),
    };
  }
}

export function validateAddressLine1(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.addr1_empty')};
  if (value.length <= 9)
    return {val: false, msg: I18n.t('valitation.addr_min')};
  if (value.length >= 49)
    return {val: false, msg: I18n.t('valitation.addr_max')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateAddressLine2(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.addr2_empty')};
  if (value.length <= 9)
    return {val: false, msg: I18n.t('valitation.addr_min')};
  if (value.length >= 255)
    return {val: false, msg: I18n.t('valitation.addr_max')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateDob(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.dob_empty')};

  const today = moment(new Date(), 'DD-MM-YYYY');
  const dob = moment(value, 'YYYY-MM-DD');
  console.log(today);
  console.log(dob);
  const diff = today.diff(dob, 'years');
  console.log('diff', diff);

  if (diff < 0) return {val: false, msg: I18n.t('valitation.dob_min')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateDate(val) {
  return moment(val, 'DD-DD-YYYY', true).isValid();
}

export function validateCenterDropdownEmpty(value) {
  if (value == '') return {val: false, msg: I18n.t('valitation.center_empty')};

  return {val: true, msg: I18n.t('valitation.success')};
}

export function barcodeValueEmpty(value) {
  if (value.trim() == '')
    return {val: false, msg: I18n.t('valitation.barcode_not_valid')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateOrderDate(value) {
  if (value == '') return {val: false, msg: I18n.t('valitation.date_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}

export function validateOrderTime(value) {
  if (value == '') return {val: false, msg: I18n.t('valitation.time_empty')};
  return {val: true, msg: I18n.t('valitation.success')};
}
