import React from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {Button, Portal, Dialog, Paragraph} from 'react-native-paper';
import {openSettings, RESULTS} from 'react-native-permissions';

export function OpenIosSettings({permission}) {
  const [visible, setVisible] = React.useState(false);

  React.useEffect(() => {
    if (permission === RESULTS.BLOCKED) showDialog();
  });

  const showDialog = () => setVisible(true);

  const hideDialog = () => setVisible(false);

  const settings = () => {
    setVisible(false);
    openSettings();
  };
  return (
    <View>
      {permission === RESULTS.BLOCKED ? (
        <Portal>
          <Dialog visible={visible} onDismiss={hideDialog}>
            <Dialog.Title>Permission Alert</Dialog.Title>
            <Dialog.Content>
              <Paragraph>
                In-App Camera requires Camera Permission to be granted. Tap here
                to open App Settings
              </Paragraph>
            </Dialog.Content>
            <Dialog.Actions>
              <Button onPress={hideDialog}>Cancel</Button>
              <Button onPress={settings}>Open Settings</Button>
            </Dialog.Actions>
          </Dialog>
        </Portal>
      ) : null}
    </View>
  );
}
