import moment from 'moment';

export function getRandomNumber() {
  return Math.floor(Math.random() * 10) + 1;
}

export function getTimeStamp() {
  let start;
  let end;
  let timeStamp = moment().valueOf().toString();
  if (timeStamp.length <= 10) {
    return timeStamp;
  } else {
    start = timeStamp.length - 10;
    end = timeStamp.length;
    return timeStamp.slice(start, end);
  }
}
