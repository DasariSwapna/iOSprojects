export function getObjectByKey(list = [], key, keyName) {
  if (list != null && list.length > 0) {
    const obj = list.find(item => item[keyName] == nullCheckForValue(key));
    return obj;
  } else {
    return null;
  }
}

export function nullCheckForValue(value) {
  if (value != null) {
    return value;
  } else {
    return '';
  }
}
