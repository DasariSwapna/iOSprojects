import {createStore, applyMiddleware} from 'redux';
import createSagaMiddleware from 'redux-saga';
import {createLogger} from 'redux-logger';
import {persistStore, persistReducer} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';
import reducer from './Reducers';
import mySaga from './Sagas';

const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
  // whitelist: ['common'],
  blacklist: [
    // 'common',
    // 'signIn',
    'signUp',
    'dayStart',
    'forgetPassword',
    'createOrder',
    'mytask',
    'kitsampleHandoverBiodata',
    'resetPassword',
    'salesmanagerapprovals',
    'uploadsignedcopydetails',
  ],
};
const persistedReducer = persistReducer(persistConfig, reducer);
// create the saga middleware
const sagaMiddleware = createSagaMiddleware();
// mount it on the Store
const middlewares = applyMiddleware(sagaMiddleware, createLogger());
export const store = createStore(persistedReducer, middlewares);

export let persistor = persistStore(store);
// then run the saga
sagaMiddleware.run(mySaga);
