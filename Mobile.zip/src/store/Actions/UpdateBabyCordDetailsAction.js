import {
    MY_TASK_UPDATE_BABY_CORD
  } from "../ActionTypes";
  
  //All action's in the form data , token
  
  export function updateBabyCordDetails(data, token) {
    return {
      type: MY_TASK_UPDATE_BABY_CORD,
      data,
      token
    };
  }
