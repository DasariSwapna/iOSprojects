import {GET_TOKEN, LOGIN, LOGOUT} from '../ActionTypes';

//All action's in the form data , token

export function getLogin(data, token) {
  return {
    type: LOGIN,
    data,
    token,
  };
}

export function getToken(data, token) {
  return {
    type: GET_TOKEN,
    data,
    token,
  };
}

export function getLogout(data, token) {
  return {
    type: LOGOUT,
    data,
    token,
  };
}
