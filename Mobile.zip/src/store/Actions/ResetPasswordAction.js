import {
    RESET_PASSWORD
  } from "../ActionTypes";
  
  //All action's in the form data , token
  
  export function getResetPassword(data, token) {
    return {
      type: RESET_PASSWORD,
      data,
      token
    };
  }

  