import {LOGIN_WITH_OTP} from '../ActionTypes';

//All action's in the form data , token

export function getLoginWithOtp(data, token) {
  return {
    type: LOGIN_WITH_OTP,
    data,
    token,
  };
}
