import {
    GETMANGERTESTAPPROVAL,DELETE_APPROVALS_DATA
  } from '../ActionTypes';
  
  //All action's in the form data , token
  export function getMangerTestApproval(data, token) {
    return {
      type: GETMANGERTESTAPPROVAL,
      data,
      token,
    };
  }


  export function deleteManagerApprovals(data, token) {
    return {
      type: DELETE_APPROVALS_DATA,
      data,
      token,
    };
  }
  
  
  
  