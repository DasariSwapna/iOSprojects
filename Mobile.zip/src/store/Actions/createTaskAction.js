import {
    CREATE_TASK,
    GET_TASK_CATEGORY,
    GET_TASK,
    GET_CRM_INFO,
    UPDATE_TASK,
    GET_TASK_TIME
  } from "../ActionTypes";
  
  //All action's in the form data , token
  
  export function createTask(data, token) {
    return {
      type: CREATE_TASK,
      data,
      token
    };
  }

  export function getTaskCategory(data, token) {
    return {
      type: GET_TASK_CATEGORY,
      data,
      token
    };
  }

  export function getTask(data, token) {
    return {
      type: GET_TASK,
      data,
      token
    };
  }

  export function getCRMInfo(data, token) {
    return {
      type: GET_CRM_INFO,
      data,
      token
    };
  }

  export function updatetask(data, token) {
    return {
      type: UPDATE_TASK,
      data,
      token
    };
  }

  export function getTaskTime(data,token) {
    return {
      type: GET_TASK_TIME,
      data,
      token
    }
  }