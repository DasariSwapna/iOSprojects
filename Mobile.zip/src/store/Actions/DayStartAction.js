import {DAY_START} from '../ActionTypes';

//All action's in the form data , token

export function dayStart(data, token) {
  return {
    type: DAY_START,
    data,
    token,
  };
}
