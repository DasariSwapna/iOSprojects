import { KITSAMPLE_HANDOVER_INSERT } from "../ActionTypes";

//All action's in the form data , token

export function kitSampleInsert(data, token) {
    return {
        type: KITSAMPLE_HANDOVER_INSERT,
        data,
        token
    };
}

