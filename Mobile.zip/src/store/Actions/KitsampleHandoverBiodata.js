import {
  KITSAMPLE_HANDOVER_BIODATA,
  GET_DROPDOWN_HANOVER_MODE,
  GET_HANOVER_CENTER,
  GET_HANOVER_LAB
} from '../ActionTypes';

//All action's in the form data , token

export function getKitsampleHanoverBiodata(data, token) {
  return {
    type: KITSAMPLE_HANDOVER_BIODATA,
    data,
    token,
  };
}

export function getDropdownMode(data, token) {
  return {
    type: GET_DROPDOWN_HANOVER_MODE,
    data,
    token,
  };
}

export function getHanoverCenter(data, token){
  return{
    type: GET_HANOVER_CENTER ,
    data,
    token,
  }
}

export function getHanoverLab(data, token){
  return{
    type: GET_HANOVER_LAB ,
    data,
    token,
  }
}
