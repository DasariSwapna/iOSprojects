import {
    INSERT_VENDOR,
    INSERT_VENDOR_TEST,
    GET_QUESTION_ANSWER,
    INSERT_QUESTION_ANSWER,
    INSERT_HOSPITAL_DOCTOR,
    CREATE_VENDOR_ADD_TEST,
    CREATE_VENDOR_BASIC_DETAIL,
    GET_VENDOR_DETAILS,
    CREATE_VENDOR_TERMS_DETAIL
} from '../ActionTypes';

//All action's in the form data , token

export function insertVendor(data, token) {
    return {
        type: INSERT_VENDOR,
        data,
        token,
    };
}

export function insertVendorTest(data, token) {
    return {
        type: INSERT_VENDOR_TEST,
        data,
        token,
    };
}
export function getTermsQuestionAnswer(data, token) {
    return {
        type: GET_QUESTION_ANSWER,
        data,
        token,
    };
}

export function insertTermsQuestionAnswer(data, token) {
    return {
        type: INSERT_QUESTION_ANSWER,
        data,
        token,
    };
}

export function insertHospitalDoctor(data) {
    return {
        type: INSERT_HOSPITAL_DOCTOR,
        data,
    };
}

export function createVendorAddTest(data) {
    return {
      type: CREATE_VENDOR_ADD_TEST,
      data
    };
  }

export function createVendorBasic(data) {
    return {
      type: CREATE_VENDOR_BASIC_DETAIL,
      data,
    };
  }

  export function createVendorTerms(data) {
    return {
      type: CREATE_VENDOR_TERMS_DETAIL,
      data,
    };
  }

  export function getVendorDetails(data, token) {
    return {
      type: GET_VENDOR_DETAILS,
      data,
      token,
    };
  }