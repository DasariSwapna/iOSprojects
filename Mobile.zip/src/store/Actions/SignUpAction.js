import {CHECK_EMAIL, SIGNUP, SIGNUP_BACK} from '../ActionTypes';

//All action's in the form data , token

export function getSignUp(data, token) {
  return {
    type: SIGNUP,
    data,
    token,
  };
}

export function signUpBackHandle(data, token) {
  return {
    type: SIGNUP_BACK,
    data,
  };
}

export function checkEmailExist(data, token) {
  return {
    type: CHECK_EMAIL,
    data,
    token,
  };
}
