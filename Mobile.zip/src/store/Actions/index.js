export {
  setLaunchApp,
  getAppConfig,
  getLanguage,
  getLebel,
  getTheme,
  getPageNo,
  getOTP,
  getState,
  // getCity,
  getAddressType,
  getReferredBy,
  getHospital,
  getPickupType,
  getDoctorName,
  getImage,
  getIcon,
  getRole,
  getCenter,
  getProductDetails,
  getProductList,
  getCity,
  geAccountType,
  getSpeciality,
  insertSignature,
  getCancelReason,
  payDetails,
  storeAddress,
} from './CommonAction';

export {getForgetPassword, verifyForgetPassword} from './ForgetPasswordAction';
export {
  getKitsampleHanoverBiodata,
  getDropdownMode,
  getHanoverCenter,
  getHanoverLab,
} from './KitsampleHandoverBiodata';

export { dayStart } from './DayStartAction';
export { getLogin, getToken, getLogout } from './SignInAction';
export { getLoginWithOtp } from './SignInWithOtp';
export { updateShuttlePickup } from './ShuttleupdateAction';
export { getResetPassword } from './ResetPasswordAction';
export { getKitsampleHandoverBiodataSelectList } from './KitsampleBiodiaHandoverSelectlist';
export { updateBabyCordDetails } from './UpdateBabyCordDetailsAction';

export { getSignUp, signUpBackHandle, checkEmailExist } from './SignUpAction';

export {
  insertOrder,
  createOrderBasic,
  createOrderRefer,
  createOrderAddTest,
  createOrderProduct,
  createOrderTest,
  userAvailability,
  getProductHospital,
  getTestHospital,
  getPatientDetails,
  createOrderPickup,
} from './CreateOrder';

export {
  getApprovalCount,
  getApprovalDetails,
  getApprovaldetailsProcess,
  updateApprovalStatus,
  updateDiscountApprovalStatus,
  getDiscountapprovaldetails,
  getDiscountapproval,
} from './ManagerAction';

export {UploadsignedCopy, uploadSignedPdfCopy} from './UploadSignedAction';

export {
  insertVendor,
  insertVendorTest,
  getTermsQuestionAnswer,
  insertTermsQuestionAnswer,
  insertHospitalDoctor,
  createVendorAddTest,
  createVendorBasic,
  getVendorDetails,
  createVendorTerms,
} from './CreateVendor';
export {
  getTaskCategory,
  getTask,
  getCRMInfo,
  updatetask,
  getTaskTime,
} from './createTaskAction';

export {
  viewMytasklist,
  viewMytasklistdetails,
  mytaskPickupStart,
  mytaskBabyCordDetailsCrmid,
  mytaskParamedicReached,
  mytaskBarcodeSelectTest,
  mytaskUpdateBarcodeTestPickup,
  mytaskGetPickedTestList,
  mytaskBarcodeRemoveSample,
  mytaskUpdatePNSWithTRF,
  mytaskUpdateCancelReason,
  mytaskGetTieupHospital,
  mytaskGetTieupHospitalVisitTime,
  mytaskGetTieupHospitalSampleType,
  updateParamedicRescduled,
  mytaskInsertOrderRegularBeat,
  mytaskInsertNoSampleRegularBeat,
  mytaskGetPickedTestListForRegularBeat,
  mytaskGetCrmidOrderidForRegularBeat,
  mytaskGetUserCancelList,
  mytaskRemoveSampleRegularBeat,
} from './MyTaskAction';
export {
  getDtByOrderId,
  getPayementMode,
  getOtpPayementMode,
  verifyOtpPayementMode,
  insertPayementMode,
  insertPaymentOnline,
} from './PayementAction';
export {
  getMangerTestApproval,
  deleteManagerApprovals,
} from './SalesMangerApproval';
export {
  getCashFromParamedic,
  updateCashFromParamedic,
} from './CashDebositSales';
export {getPostalService, getLabCenterName} from './kitHandoverCourier';
export {kitSampleInsert} from './KitInsertAction';
export {
  getDepositCash,
  getDepositCashBank,
  getDepositCashBranch,
  getDepositCashTime,
  getUpdateCashDeposit,
} from './depositCashParam';