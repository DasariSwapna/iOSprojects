import {
  GET_PAYEMENT_DETAIL_ORDERID,
  GET_PAYEMENT_MODE,
  GET_OTP_PAYEMENT_MODE,
  VERIFY_OTP_PAYEMENT_MODE,
  INSERT_PAYEMENT_MODE,
  INSERT_PAYEMENT_ONLINE_MODE,
} from '../ActionTypes';

//All action's in the form data , token
export function getDtByOrderId(data, token) {
  return {
    type: GET_PAYEMENT_DETAIL_ORDERID,
    data,
    token,
  };
}

export function getPayementMode(data, token) {
  return {
    type: GET_PAYEMENT_MODE,
    data,
    token,
  };
}

export function getOtpPayementMode(data, token) {
  return {
    type: GET_OTP_PAYEMENT_MODE,
    data,
    token,
  };
}

export function verifyOtpPayementMode(data, token) {
  return {
    type: VERIFY_OTP_PAYEMENT_MODE,
    data,
    token,
  };
}
export function insertPayementMode(data, token) {
  return {
    type: INSERT_PAYEMENT_MODE,
    data,
    token,
  };
}

export function insertPaymentOnline(data, token) {
  return {
    type: INSERT_PAYEMENT_ONLINE_MODE,
    data,
    token,
  };
}
