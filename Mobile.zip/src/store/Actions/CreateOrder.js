import {
  INSERT_ORDER,
  CREATE_ORDER_BASIC_DETAIL,
  CREATE_ORDER_REFERRAL_DETAIL,
  CREATE_ORDER_ADD_TEST,
  CREATE_ORDER_PRODUCTS,
  CREATE_ORDER_TEST,
  USER_AVAILABILITY,
  PRODUCT_HOSPITAl,
  TEST_HOSPITAL,
  GET_PATIENT_DETAILS,
  CREATE_ORDER_PICKUP
} from '../ActionTypes';

//All action's in the form data , token

export function insertOrder(data, token, pageno) {
  return {
    type: INSERT_ORDER,
    data,
    token,
    pageno
  };
}

export function createOrderBasic(data) {
  return {
    type: CREATE_ORDER_BASIC_DETAIL,
    data,
  };
}

export function createOrderRefer(data) {
  return {
    type: CREATE_ORDER_REFERRAL_DETAIL,
    data,
  };
}

export function createOrderAddTest(data) {
  return {
    type: CREATE_ORDER_ADD_TEST,
    data,
  };
}

export function createOrderProduct(data) {
  return {
    type: CREATE_ORDER_PRODUCTS,
    data,
  };
}

export function createOrderTest(data) {
  return {
    type: CREATE_ORDER_TEST,
    data,
  };
}


export function createOrderPickup(data) {
  return {
    type: CREATE_ORDER_PICKUP,
    data,
  };
}


export function userAvailability(data, token) {
  return {
    type: USER_AVAILABILITY,
    data,
    token,
  };
}

export function getProductHospital(data, token) {
  return {
    type: PRODUCT_HOSPITAl,
    data,
    token,
  };
}

export function getTestHospital(data, token) {
  return {
    type: TEST_HOSPITAL,
    data,
    token,
  };
}

export function getPatientDetails(data, token) {
  return {
    type: GET_PATIENT_DETAILS,
    data,
    token,
  };
}
