import {
  GET_OTP_FORGET_PASSWORD,
  VERIFY_FORGET_PASSWORD
} from "../ActionTypes";

//All action's in the form data , token

export function getForgetPassword(data, token) {
  return {
    type: GET_OTP_FORGET_PASSWORD,
    data,
    token
  };
}

export function verifyForgetPassword(data, token) {
  return {
    type: VERIFY_FORGET_PASSWORD,
    data,
    token
  };
}
