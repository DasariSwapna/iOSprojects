import {CASH_DEPOSIT_SALES_UPDATE} from '../ActionTypes';
import {CASH_DEPOSIT_SALES_HANDOVER_MONEY} from '../ActionTypes';

//All action's in the form data , token

export function getCashFromParamedic(data, token) {
  return {
    type: CASH_DEPOSIT_SALES_HANDOVER_MONEY,
    data,
    token,
  };
}

export function updateCashFromParamedic(data, token) {
  return {
    type: CASH_DEPOSIT_SALES_UPDATE,
    data,
    token,
  };
}
