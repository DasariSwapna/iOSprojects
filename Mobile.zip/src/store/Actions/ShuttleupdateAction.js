import { SHUTTLE_DETAIL_UPDATE } from "../ActionTypes";

//All action's in the form data , token

export function updateShuttlePickup(data, token) {
  return {
    type: SHUTTLE_DETAIL_UPDATE,
    data,
    token
  };
}
