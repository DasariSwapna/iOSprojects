import {
  GET_APPROVAL_COUNT,
  GET_APPROVAL_DETAILS,
  GET_APPROVAL_DETAILS_PROCESS,
  UPDATE_APPROVED_STATUS,
  MANAGER_DISCOUNT_APPROVAL,
  MANAGER_DISCOUNT_DETAILS_APPROVAL,
  UPDATE_DISCOUNT_DETAILS_APPROVAL,
} from '../ActionTypes';

//All action's in the form data , token

export function getApprovalCount(data, token) {
  return {
    type: GET_APPROVAL_COUNT,
    data,
    token,
  };
}

export function getApprovalDetails(data, token) {
  return {
    type: GET_APPROVAL_DETAILS,
    data,
    token,
  };
}

export function getApprovaldetailsProcess(data, token) {
  return {
    type: GET_APPROVAL_DETAILS_PROCESS,
    data,
    token,
  };
}

export function updateApprovalStatus(data, token) {
  return {
    type: UPDATE_APPROVED_STATUS,
    data,
    token,
  };
}

export function getDiscountapproval(data, token) {
  return {
    type: MANAGER_DISCOUNT_APPROVAL,
    data,
    token,
  };
}

export function getDiscountapprovaldetails(data, token) {
  return {
    type: MANAGER_DISCOUNT_DETAILS_APPROVAL,
    data,
    token,
  };
}

export function updateDiscountApprovalStatus(data, token) {
  return {
    type: UPDATE_DISCOUNT_DETAILS_APPROVAL,
    data,
    token,
  };
}
