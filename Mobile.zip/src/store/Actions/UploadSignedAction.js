import {GET_UPLOAD_SIGNED_COPY_DETAILS,GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD} from '../ActionTypes';


export function UploadsignedCopy(data,token) {
  return {
    type: GET_UPLOAD_SIGNED_COPY_DETAILS,
    data,
    token,
  };
}

export function uploadSignedPdfCopy(data,token) {
  return {
    type: GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD,
    data,
    token,
  };
}

