import { KITSAMPLE_HANDOVER_BIODATA_SELECTLIST } from "../ActionTypes";

//All action's in the form data , token

export function getKitsampleHandoverBiodataSelectList(data, token) {
  return {
    type: KITSAMPLE_HANDOVER_BIODATA_SELECTLIST,
    data,
    token
  };
}
