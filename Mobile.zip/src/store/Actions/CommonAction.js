import {
  GET_CENTER,
  GET_ICON,
  GET_APP_CONFIG,
  GET_IMAGE,
  GET_LABEL,
  GET_LANGUAGE,
  GET_OTP,
  GET_PAGE_NO,
  GET_ROLE,
  GET_THEME,
  LAUNCH_APP,
  GET_STATE,
  GET_PRODUCT_DETAILS,
  GET_PRODUCT_LIST,
  GET_CITY,
  GET_ADDRESS_TYPE,
  GET_REFERRED_BY,
  GET_HOSPITAL,
  GET_PICKUP_TYPE,
  GET_DOCTOR_NAME,
  GET_ACCOUNT_TYPE,
  GET_SPECIALITY,
  INSERT_SIGNATURE,
  GET_CANCEL_REASON,
  INSERT_PAY_DETAILS,
  GET_TASK_TIME,
  STORE_ADDRESS,
} from '../ActionTypes';

export function setLaunchApp() {
  return {
    type: LAUNCH_APP,
  };
}
export function getAppConfig(data, token) {
  return {
    type: GET_APP_CONFIG,
    data,
  };
}

export function getLebel(data, token) {
  return {
    type: GET_LABEL,
    data,
  };
}

export function getLanguage(data, token) {
  return {
    type: GET_LANGUAGE,
    data,
  };
}

export function getTheme(data, token) {
  return {
    type: GET_THEME,
    data,
  };
}

export function getPageNo(data, token) {
  return {
    type: GET_PAGE_NO,
    data,
  };
}
export function getOTP(data, token) {
  return {
    type: GET_OTP,
    data,
  };
}

export function getState(data, token) {
  return {
    type: GET_STATE,
    data,
    token,
  };
}

export function getCity(data, token) {
  return {
    type: GET_CITY,
    data,
    token,
  };
}

export function getAddressType(data, token) {
  return {
    type: GET_ADDRESS_TYPE,
    data,
    token,
  };
}

export function getReferredBy(data, token) {
  return {
    type: GET_REFERRED_BY,
    data,
    token,
  };
}

export function getHospital(data, token) {
  return {
    type: GET_HOSPITAL,
    data,
    token,
  };
}

export function getPickupType(data, token) {
  return {
    type: GET_PICKUP_TYPE,
    data,
    token,
  };
}

export function getDoctorName(data, token) {
  return {
    type: GET_DOCTOR_NAME,
    data,
    token,
  };
}

export function getImage(data, token) {
  return {
    type: GET_IMAGE,
    data,
  };
}

export function getIcon(data, token) {
  return {
    type: GET_ICON,
    data,
  };
}

export function getRole(data, token) {
  return {
    type: GET_ROLE,
    data,
  };
}

export function getCancelReason(data, token) {
  return {
    type: GET_CANCEL_REASON,
    data,
    token,
  };
}

export function getCenter(data, token) {
  console.log('Center action:', data, token);
  return {
    type: GET_CENTER,
    data,
    token,
  };
}

export function getProductDetails(data, token) {
  return {
    type: GET_PRODUCT_DETAILS,
    data,
    token,
  };
}

export function getProductList(data, token) {
  return {
    type: GET_PRODUCT_LIST,
    data,
    token,
  };
}

export function geAccountType(data, token) {
  return {
    type: GET_ACCOUNT_TYPE,
    data,
    token,
  };
}

export function getSpeciality(data, token) {
  return {
    type: GET_SPECIALITY,
    data,
    token,
  };
}

export function insertSignature(data, token) {
  return {
    type: INSERT_SIGNATURE,
    data,
    token,
  };
}

export function payDetails(data) {
  return {
    type: INSERT_PAY_DETAILS,
    data,
  };
}

export function getTaskTime(data, token) {
  return {
    type: GET_TASK_TIME,
    data,
    token,
  };
}
export function storeAddress(data, token) {
  return {
    type: STORE_ADDRESS,
    data,
    token,
  };
}
