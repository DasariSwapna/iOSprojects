import {
  DEPOSIT_CASH,
  DEPOSIT_CASH_BANK,
  DEPOSIT_CASH_BRANCH,
  DEPOSIT_CASH_TIME,
  UPDATE_DEPOSIT_CASH
} from '../ActionTypes';

//All action's in the form data , token

export function getDepositCash(data, token) {
  return {
    type: DEPOSIT_CASH,
    data,
    token,
  };
}

export function getDepositCashBank(data, token) {
  return {
    type: DEPOSIT_CASH_BANK,
    data,
    token,
  };
}

export function getDepositCashBranch(data, token) {
  return {
    type: DEPOSIT_CASH_BRANCH,
    data,
    token,
  };
}

export function getDepositCashTime(data, token) {
  return {
    type: DEPOSIT_CASH_TIME,
    data,
    token,
  }
}

export function getUpdateCashDeposit(data, token) {
  return {
    type: UPDATE_DEPOSIT_CASH,
    data,
    token,
  }
}