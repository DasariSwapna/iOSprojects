import {
  MY_TASK_TYPE_LIST_DATAS,
  MY_TASK_TYPE_LIST_DATAS_DETAILS,
  MY_TASK_PICKUP_START,
  MY_TASK_BABY_CORD_DETAILS_CRMID,
  MY_TASK_PARAMEDIC_REACHED,
  MY_TASK_BARCODE_SELECT_TEST,
  MY_TASK_UPDATE_BARCODE_TEST_PICKUP,
  MY_TASK_GET_PICKED_TEST_LIST,
  MY_TASK_BARCODE_REMOVE_SAMPLE,
  MY_TASK_UPDATE_PNS_TRF,
  MY_TASK_UPDATE_CANCEL_REASON,
  GET_TIEUP_HOSPITAL_VISIT_TIME,
  GET_TIEUP_HOSPITAL_SAMPLE_TYPE,
  GET_TIEUP_HOSPITAL,
  UPDATE_PARAMEDIC_RESCDULED,
  INSERT_ORDER_DETAILS_REGULAR_BEAT,
  GET_PICKED_TEST_LIST_REGULAR_BEAT,
  INSERT_NO_SAMPLE_REGULAR_BEAT,
  GET_ORDERID_CRMID_REGULAR_BEAT,
  MY_TASK_USER_CANCEL_LIST,
  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT
} from '../ActionTypes';

export function viewMytasklist(data, token) {
  return {
    type: MY_TASK_TYPE_LIST_DATAS,
    data,
    token,
  };
}

export function viewMytasklistdetails(data, token) {
  return {
    type: MY_TASK_TYPE_LIST_DATAS_DETAILS,
    data,
    token,
  };
}

export function getmytaskcancellistdetails(data, token) {
  return {
    type: MY_TASK_TYPE_LIST_DATAS_DETAILS,
    data,
    token,
  };
}

export function mytaskPickupStart(data, token) {
  return {
    type: MY_TASK_PICKUP_START,
    data,
    token,
  };
}

export function mytaskBabyCordDetailsCrmid(data, token) {
  return {
    type: MY_TASK_BABY_CORD_DETAILS_CRMID,
    data,
    token,
  };
}

export function mytaskParamedicReached(data, token) {
  return {
    type: MY_TASK_PARAMEDIC_REACHED,
    data,
    token,
  };
}

export function mytaskBarcodeSelectTest(data, token) {
  return {
    type: MY_TASK_BARCODE_SELECT_TEST,
    data,
    token,
  };
}

export function mytaskUpdateBarcodeTestPickup(data, token) {
  return {
    type: MY_TASK_UPDATE_BARCODE_TEST_PICKUP,
    data,
    token,
  };
}

export function mytaskGetPickedTestList(data, token) {
  return {
    type: MY_TASK_GET_PICKED_TEST_LIST,
    data,
    token,
  };
}

export function mytaskBarcodeRemoveSample(data, token) {
  return {
    type: MY_TASK_BARCODE_REMOVE_SAMPLE,
    data,
    token,
  };
}

export function mytaskUpdatePNSWithTRF(data, token) {
  return {
    type: MY_TASK_UPDATE_PNS_TRF,
    data,
    token,
  };
}

export function mytaskUpdateCancelReason(data, token) {
  return {
    type: MY_TASK_UPDATE_CANCEL_REASON,
    data,
    token,
  };
}

export function mytaskGetTieupHospital(data, token) {
  return {
    type: GET_TIEUP_HOSPITAL,
    data,
    token,
  };
}

export function updateParamedicRescduled(data, token) {
  return {
    type: UPDATE_PARAMEDIC_RESCDULED,
    data,
    token,
  };
}
export function mytaskGetTieupHospitalVisitTime(data, token) {
  return {
    type: GET_TIEUP_HOSPITAL_VISIT_TIME,
    data,
    token,
  };
}

export function mytaskGetTieupHospitalSampleType(data, token) {
  return {
    type: GET_TIEUP_HOSPITAL_SAMPLE_TYPE,
    data,
    token,
  };
}

export function mytaskInsertOrderRegularBeat(data, token) {
  return {
    type: INSERT_ORDER_DETAILS_REGULAR_BEAT,
    data,
    token,
  };
}

export function mytaskInsertNoSampleRegularBeat(data, token) {
  return {
    type: INSERT_NO_SAMPLE_REGULAR_BEAT,
    data,
    token,
  };
}

export function mytaskGetPickedTestListForRegularBeat(data, token) {
  return {
    type: GET_PICKED_TEST_LIST_REGULAR_BEAT,
    data,
    token,
  };
}

export function mytaskGetCrmidOrderidForRegularBeat(data, token) {
  return {
    type: GET_ORDERID_CRMID_REGULAR_BEAT,
    data,
    token,
  };
}
  export function mytaskGetUserCancelList(data, token) {
    return {
      type: MY_TASK_USER_CANCEL_LIST,
      data,
      token,
    };
  
}

export function mytaskRemoveSampleRegularBeat(data, token) {
  return {
    type: MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT,
    data,
    token,
  };

}







