import { GET_POSTAL, GET_LAB_CENTER_NAME } from "../ActionTypes";

//All action's in the form data , token

export function getPostalService(data, token) {
    return {
        type: GET_POSTAL,
        data,
        token
    };
}

export function getLabCenterName(data, token) {
    return {
        type: GET_LAB_CENTER_NAME,
        data,
        token
    };
}
