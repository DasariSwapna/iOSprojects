import {DAY_START,DAY_START_SUCCESS,DAY_START_FAILURE} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  daystartLoading: false,
  daystartStatus: false,
  daystartError: false,
};

export default function signInReducer(state = initState, action) {
  switch (action.type) {
    case DAY_START: {
      return {
        ...state,
        daystartLoading: true,
        daystartStatus: false,
        daystartError: false,
        message: '',
      };
    }
    case DAY_START_SUCCESS: {
      return {
        ...state,
        daystartLoading: false,
        daystartStatus: true,
        daystartError: false,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case DAY_START_FAILURE: {
      return {
        ...state,
        daystartLoading: false,
        daystartStatus: false,
        daystartError: true,
        message: action.message,
      };
    }

    default: {
      return state;
    }
  }
}
