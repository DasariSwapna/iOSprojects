import {
  GET_UPLOAD_SIGNED_COPY_DETAILS,
  GET_UPLOAD_SIGNED_COPY_DETAILS_SUCCESS,
  GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_SUCCESS,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_FAILURE
} from "../ActionTypes";

const initState = {
  message: "",
  accessToken: null,
  uploadsignedcopyDetails: null,
  uploadsignedcopyLoading: false,
  uploadsignedcopyStatus: false,
  uploadsignedcopyError: false,
  uploadsignedcopyPdfDetails: null,
  uploadsignedcopyPdfLoading: false,
  uploadsignedcopyPdfStatus: false,
  uploadsignedcopyPdfError: false,
  type: "P",
  response: ''
};

export default function uploadsignedcopyReducer(state = initState, action) {
  switch (action.type) {
    case GET_UPLOAD_SIGNED_COPY_DETAILS: {
      return {
        ...state,
        uploadsignedcopyLoading: true,
        uploadsignedcopyStatus: false,
        uploadsignedcopyError: false,
        message: ""
      };
    }
    case GET_UPLOAD_SIGNED_COPY_DETAILS_SUCCESS: {
      return {
        ...state,
        uploadsignedcopyLoading: false,
        uploadsignedcopyStatus: true,
        uploadsignedcopyError: false,
        message: action.message,
        response: action.response,
        responseall: action.responseall,
        responseretailtoinvoice: action.responseretailtoinvoice,
        responseMOU: action.responseMOU,

      };
    }
    case GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE: {
      return {
        ...state,
        uploadsignedcopyLoading: false,
        uploadsignedcopyStatus: false,
        uploadsignedcopyError: true,
        message: action.message
      };
    }
    case GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD: {
      return {
        ...state,
        uploadsignedcopyPdfLoading: true,
        uploadsignedcopyPdfStatus: false,
        uploadsignedcopyPdfError: false,
        message: ""
      };
    }
    case GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_SUCCESS: {
      return {
        ...state,
        uploadsignedcopyPdfLoading: false,
        uploadsignedcopyPdfStatus: true,
        uploadsignedcopyPdfError: false,
        message: action.message,
        uploadsignedcopyPdfDetails: action.response,
      

      };
    }
    case GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_FAILURE: {
      return {
        ...state,
        uploadsignedcopyPdfLoading: false,
        uploadsignedcopyPdfStatus: false,
        uploadsignedcopyPdfError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}