import { ActivityIndicator } from 'react-native-paper';
import {
  INSERT_ORDER,
  INSERT_ORDER_SUCCESS,
  INSERT_ORDER_FAILURE,
  CREATE_ORDER_BASIC_DETAIL,
  CREATE_ORDER_REFERRAL_DETAIL,
  CREATE_ORDER_ADD_TEST,
  CREATE_ORDER_PRODUCTS,
  CREATE_ORDER_TEST,
  USER_AVAILABILITY,
  USER_AVAILABILITY_SUCCESS,
  USER_AVAILABILITY_FAILURE,
  PRODUCT_HOSPITAl,
  PRODUCT_HOSPITAl_SUCCESS,
  PRODUCT_HOSPITAl_FAILURE,
  TEST_HOSPITAL,
  TEST_HOSPITAL_SUCCESS,
  TEST_HOSPITAL_FAILURE,
  GET_PATIENT_DETAILS,
  GET_PATIENT_DETAILS_SUCCESS,
  GET_PATIENT_DETAILS_FAILURE,
  CREATE_ORDER_PICKUP,
} from '../ActionTypes';

const initState = {
  message: '',
  insertOrderLoading: false,
  insertOrderStatus: false,
  insertOrderPayementStatus: false,
  insertOrderStatusCode: null,
  insertOrderError: false,
  insertOrderResponse: null,
  insertOrderFailureResponse: null,

  basicDetail: null,
  referDetail: null,
  addTest: null,
  createOrderProduct: null,
  createOrderTest: null,
  createOrderPickup: null,

  userAvailabilityLoading: false,
  userAvailabilityStatus: false,
  userAvailabilityError: false,
  userAvailabilityResponse: null,

  productHospiatlLoading: false,
  productHospiatlStatus: false,
  productHospiatlError: false,
  productHospiatlResponse: null,

  testHospitalLoading: false,
  testHospitalStatus: false,
  testHospitalError: false,
  testHospitalResponse: null,
  insertOrderresponsePDF: null,

  patientDetailsLoading: false,
  patientDetailsStatus: false,
  patientDetailsError: false,
  patientDetailsResponse: null,
};

export default function createOrderReducer(state = initState, action) {
  switch (action.type) {
    case INSERT_ORDER: {
      return {
        ...state,
        insertOrderLoading: true,
        insertOrderStatus: false,
        insertOrderPayementStatus: false,
        insertOrderError: false,
        message: '',
      };
    }
    case INSERT_ORDER_SUCCESS: {
      return {
        ...state,
        insertOrderResponse: action.response,
        insertOrderresponsePDF: action.responsePDF,
        insertOrderStatusCode: action.response,
        insertOrderLoading: false,
        insertOrderStatus: action.pageno == 1 ? true : false,
        insertOrderPayementStatus: action.pageno == 2 ? true : false,
        insertOrderError: false,
        message: action.message,
      };
    }
    case INSERT_ORDER_FAILURE: {
      return {
        ...state,
        insertOrderLoading: false,
        insertOrderStatus: false,
        insertOrderPayementStatus: false,
        insertOrderError: true,
        message: action.message,
        insertOrderFailureResponse: action.response,
      };
    }
    case CREATE_ORDER_BASIC_DETAIL: {
      return {
        ...state,
        basicDetail: action.data,
      };
    }
    case CREATE_ORDER_REFERRAL_DETAIL: {
      return {
        ...state,
        referDetail: action.data,
      };
    }
    case CREATE_ORDER_ADD_TEST: {
      return {
        ...state,
        addTest: action.data,
      };
    }
    case CREATE_ORDER_PRODUCTS: {
      return {
        ...state,
        createOrderProduct: action.data,
      };
    }
    case CREATE_ORDER_TEST: {
      return {
        ...state,
        createOrderTest: action.data,
      };
    }
    case CREATE_ORDER_PICKUP: {
      return {
        ...state,
        createOrderPickup: action.data,
      };
    }
    case USER_AVAILABILITY: {
      return {
        ...state,
        userAvailabilityLoading: true,
        userAvailabilityStatus: false,
        userAvailabilityError: false,
        message: '',
      };
    }
    case USER_AVAILABILITY_SUCCESS: {
      return {
        ...state,
        userAvailabilityResponse: action.response,
        userAvailabilityLoading: false,
        userAvailabilityStatus: true,
        userAvailabilityError: false,
        message: action.message,
      };
    }
    case USER_AVAILABILITY_FAILURE: {
      return {
        ...state,
        userAvailabilityLoading: false,
        userAvailabilityStatus: false,
        userAvailabilityError: true,
        message: action.message,
      };
    }

    case PRODUCT_HOSPITAl: {
      return {
        ...state,
        productHospiatlLoading: true,
        productHospiatlStatus: false,
        productHospiatlError: false,
        message: '',
      };
    }
    case PRODUCT_HOSPITAl_SUCCESS: {
      return {
        ...state,
        productHospiatlResponse: action.response,
        productHospiatlLoading: false,
        productHospiatlStatus: true,
        productHospiatlError: false,
        message: action.message,
      };
    }
    case PRODUCT_HOSPITAl_FAILURE: {
      return {
        ...state,
        productHospiatlLoading: false,
        productHospiatlStatus: false,
        productHospiatlError: true,
        message: action.message,
      };
    }

    case TEST_HOSPITAL: {
      return {
        ...state,
        testHospitalLoading: true,
        testHospitalStatus: false,
        testHospitalError: false,
        message: '',
      };
    }
    case TEST_HOSPITAL_SUCCESS: {
      return {
        ...state,
        testHospitalResponse: action.response,
        testHospitalLoading: false,
        testHospitalStatus: true,
        testHospitalError: false,
        message: action.message,
      };
    }
    case TEST_HOSPITAL_FAILURE: {
      return {
        ...state,
        testHospitalLoading: false,
        testHospitalStatus: false,
        testHospitalError: true,
        message: action.message,
      };
    }
    case GET_PATIENT_DETAILS: {
      return {
        ...state,
        patientDetailsLoading: true,
        patientDetailsStatus: false,
        patientDetailsError: false,
        message: '',
      };
    }
    case GET_PATIENT_DETAILS_SUCCESS: {
      return {
        ...state,
        patientDetailsResponse: action.response,
        patientDetailsLoading: false,
        patientDetailsStatus: true,
        patientDetailsError: false,
        message: action.message,
      };
    }
    case GET_PATIENT_DETAILS_FAILURE: {
      return {
        ...state,
        patientDetailsLoading: false,
        patientDetailsStatus: false,
        patientDetailsError: true,
        message: action.message,
      };
    }

    default: {
      return state;
    }
  }
}
