import {
  SHUTTLE_DETAIL_UPDATE,
  SHUTTLE_DETAIL_UPDATE_SUCCESS,
  SHUTTLE_DETAIL_UPDATE_FAILURE
} from "../ActionTypes";
const initState = {
  message: "",
  accessToken: null,
  shuttleUpdateLoading: false,
  shuttleUpdateStatus: false,
  shuttleUpdateError: false,
  type: "P"
};

export default function shuttledetailupdate(state = initState, action) {
  switch (action.type) {
    case SHUTTLE_DETAIL_UPDATE: {
      return {
        ...state,
        shuttleUpdateoading: true,
        shuttleUpdateStatus: false,
        shuttleUpdateError: false,
        message: ""
      };
    }
    case SHUTTLE_DETAIL_UPDATE_SUCCESS: {
      return {
        ...state,
        shuttleUpdateLoading: false,
        shuttleUpdateStatus: true,
        shuttleUpdateError: false,
        message: action.message,
        accessToken: action.accessToken
      };
    }
    case SHUTTLE_DETAIL_UPDATE_FAILURE: {
      return {
        ...state,
        shuttleUpdateLoading: false,
        shuttleUpdateStatus: false,
        shuttleUpdateError: true,
        message: action.message
      };
    }
    default: {
      return state;
    }
  }
}
