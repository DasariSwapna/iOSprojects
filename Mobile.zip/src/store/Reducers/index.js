import {combineReducers} from 'redux';
import commonReducer from './CommonReducer';
import signInReducer from './SignInReducer';
import forgetPasswordReducer from './ForgetPasswordReducer';
import kitsampleBiodataReducer from './KitsampleHandoverBiodataReducer';
import resetPasswordReducer from './ResetPasswordReducer';
import signUpReducer from './SignUpReducer';
import dayStartReducer from './DaystartReducer';
import KitsampleHandoverBiodataSelectlistReducer from './KitsampleHandoverBiodataSelectlistReducer';
import ShuttledetailUpdateReduer from './ShuttledetailUpdateReducer';
import createOrderReducer from './CreateOrderReducer';
import MyTaskReducer from './MyTaskReducer';
import ManagerReducers from './ManagerReducer';
import uploadsignedcopyReducer from './UploadsingedCopyReducer';
import SalesMangerTestApprovalReducer from './SalesMangerTestApprovalReducer';
import UpdateBabyCordDetailsReducer from './UpdateBabyCordDetailsReducer';
import createVendorReducer from './CreateVendorReducer';
import PayementModeReducer from './PayementModeReducer';
import CreateTaskReducer from './CreateTaskReducer';
import CourierReducer from './KitHandoverCourierReducer';
import KitInsertReducer from './KitSampleInsertReducer';
import CashDebositSalesReducer from './CashDebositSalesReducer';
import DepositcashParam from './DepositcashParam';

const rootReducer = combineReducers({
  common: commonReducer,
  signIn: signInReducer,
  forgetPassword: forgetPasswordReducer,
  kitsampleHandoverBiodata: kitsampleBiodataReducer,
  resetPassword: resetPasswordReducer,
  signUp: signUpReducer,
  dayStart: dayStartReducer,
  kitsampleselectlist: KitsampleHandoverBiodataSelectlistReducer,
  shuttledetailupdate: ShuttledetailUpdateReduer,
  createOrder: createOrderReducer,
  salesmanagerapprovals: ManagerReducers,
  uploadsignedcopydetails: uploadsignedcopyReducer,
  mytask: MyTaskReducer,
  updateBabyCordDetailsReducer: UpdateBabyCordDetailsReducer,
  createVendor: createVendorReducer,
  payementMode: PayementModeReducer,
  SalesMangerTestApprovalReducer: SalesMangerTestApprovalReducer,
  createtask: CreateTaskReducer,
  courier: CourierReducer,
  kitInsert: KitInsertReducer,
  CashDebositSalesReducer: CashDebositSalesReducer,
  depositCash: DepositcashParam,
});

export default rootReducer;
