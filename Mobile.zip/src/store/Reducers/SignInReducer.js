import {LOGIN, LOGIN_FAILURE, LOGIN_SUCCESS, LOGOUT} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  loginLoading: false,
  loginStatus: false,
  loginError: false,
  role: null,
  userId: null,
  username: '',
  firstName: '',
  lastName: '',
  mobileNo: '',
  email: '',
  dayStartStatus: null,
  activationStatus: null,
};

export default function signInReducer(state = initState, action) {
  switch (action.type) {
    case LOGIN: {
      return {
        ...state,
        loginLoading: true,
        loginStatus: false,
        loginError: false,
        message: '',
      };
    }
    case LOGIN_SUCCESS: {
      return {
        ...state,
        loginLoading: false,
        loginStatus: true,
        loginError: false,
        message: action.message,
        accessToken: action.accessToken,
        role: action.roles,
        userId: action.userId,
        username: action.username,
        firstName: action.firstName,
        lastName: action.lastName,
        mobileNo: action.mobileNo,
        email: action.email,
        dayStartStatus: action.dayStartStatus,
        activationStatus: action.activationStatus,
      };
    }
    case LOGIN_FAILURE: {
      return {
        ...state,
        loginLoading: false,
        loginStatus: false,
        loginError: true,
        message: action.message,
      };
    }

    case LOGOUT: {
      return {
        ...state,
        accessToken: null,
      };
    }

    default: {
      return state;
    }
  }
}
