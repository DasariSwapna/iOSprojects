import {
  GET_OTP_FORGET_PASSWORD,
  GET_OTP_FORGET_PASSWORD_SUCCESS,
  GET_OTP_FORGET_PASSWORD_FAILURE,
  VERIFY_FORGET_PASSWORD,
  VERIFY_FORGET_PASSWORD_SUCCESS,
  VERIFY_FORGET_PASSWORD_FAILURE
} from "../ActionTypes";
const initState = {
  message: "",
  accessToken: null,
  forgetPasswordLoading: false,
  forgetPasswordStatus: false,
  forgetPasswordError: false,
  type: "P",
  verifyMessage: "",
  verifyaccessToken: null,
  verifyLoading: false,
  verifyStatus: false,
  verifyError: false
};

export default function forgetpasswordReducer(state = initState, action) {
  switch (action.type) {
    case GET_OTP_FORGET_PASSWORD: {
      return {
        ...state,
        forgetPasswordLoading: true,
        forgetPasswordStatus: false,
        forgetPasswordError: false,
        message: ""
      };
    }
    case GET_OTP_FORGET_PASSWORD_SUCCESS: {
      return {
        ...state,
        forgetPasswordLoading: false,
        forgetPasswordStatus: true,
        forgetPasswordError: false,
        message: action.message,
        mobNo : action.mobileNumber,
        accessToken: action.accessToken
      };
    }
    case GET_OTP_FORGET_PASSWORD_FAILURE: {
      return {
        ...state,
        forgetPasswordLoading: false,
        forgetPasswordStatus: false,
        forgetPasswordError: true,
        message: action.message
      };
    }
    //verify password
    case VERIFY_FORGET_PASSWORD: {
      return {
        ...state,
        verifyLoading: true,
        verifyStatus: false,
        verifyError: false,
        verifyMessage: ""
      };
    }
    case VERIFY_FORGET_PASSWORD_SUCCESS: {
      return {
        ...state,
        verifyLoading: false,
        verifyStatus: true,
        verifyError: false,
        verifyMessage: action.message,
        // accessToken: action.accessToken,
        verifyaccessToken: action.accessToken
      };
    }
    case VERIFY_FORGET_PASSWORD_FAILURE: {
      return {
        ...state,
        verifyLoading: false,
        verifyStatus: false,
        verifyError: true,
        verifyMessage: action.message
        // accessToken: 'hsfkksdlfmb',
      };
    }
    default: {
      return state;
    }
  }
}
