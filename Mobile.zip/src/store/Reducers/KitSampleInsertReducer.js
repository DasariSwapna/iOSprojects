import {
    KITSAMPLE_HANDOVER_INSERT,
    KITSAMPLE_HANDOVER_INSERT_SUCCESS,
    KITSAMPLE_HANDOVER_INSERT_FAILURE,
} from "../ActionTypes";
const initState = {
    message: "",
    accessToken: null,
    kitsampleInsertLoading: false,
    kitsampleInsertStatus: false,
    kitsampleInsertError: false,
    type: "P"
};

export default function kitsampleBiodataReducer(state = initState, action) {
    switch (action.type) {
        case KITSAMPLE_HANDOVER_INSERT: {
            return {
                ...state,
                kitsampleInsertLoading: true,
                kitsampleInsertStatus: false,
                kitsampleInsertError: false,
                message: ""
            };
        }
        case KITSAMPLE_HANDOVER_INSERT_SUCCESS: {
            return {
                ...state,
                kitsampleInsertLoading: false,
                kitsampleInsertStatus: true,
                kitsampleInsertError: false,
                message: action.message,
                accessToken: action.accessToken,
                response: action.response
            };
        }
        case KITSAMPLE_HANDOVER_INSERT_FAILURE: {
            return {
                ...state,
                kitsampleInsertLoading: false,
                kitsampleInsertStatus: false,
                kitsampleInsertError: true,
                message: action.message
            };
        }
        default: {
            return state;
        }
    }
}
