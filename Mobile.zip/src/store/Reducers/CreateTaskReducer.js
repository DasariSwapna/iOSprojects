import {
  CREATE_TASK,
  CREATE_TASK_SUCCESS,
  CREATE_TASK_FAILURE,
  GET_TASK_CATEGORY,
  GET_TASK_CATEGORY_SUCCESS,
  GET_TASK_CATEGORY_FAILURE,
  GET_TASK,
  GET_TASK_SUCCESS,
  GET_TASK_FAILURE,
  GET_CRM_INFO,
  GET_CRM_INFO_SUCCESS,
  GET_CRM_INFO_FAILURE,
  UPDATE_TASK,
  UPDATE_TASK_SUCCESS,
  UPDATE_TASK_FAILURE,
  GET_TASK_TIME,
  GET_TASK_TIME_SUCCESS,
  GET_TASK_TIME_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  createTaskLoading: false,
  createTaskStatus: false,
  createTaskError: false,
  getTaskCategoryLoading: false,
  getTaskCategoryStatus: false,
  getTaskCategoryError: false,
  response: '',
  createTaskresponse: '',
  getCRMInfoLoading: false,
  getCRMInfoStatus: false,
  getCRMInfoError: false,
  CRMresponse: '',
  CRMmessage: '',
};

export default function createTaskReducer(state = initState, action) {
  switch (action.type) {
    case CREATE_TASK: {
      return {
        ...state,
        createTaskLoading: true,
        createTaskStatus: false,
        createTaskError: false,
        message: '',
      };
    }
    case CREATE_TASK_SUCCESS: {
      return {
        ...state,
        createTaskLoading: false,
        createTaskStatus: true,
        createTaskError: false,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case CREATE_TASK_FAILURE: {
      return {
        ...state,
        createTaskLoading: false,
        createTaskStatus: false,
        createTaskError: true,
        message: action.message,
      };
    }
    case GET_TASK_CATEGORY: {
      return {
        ...state,
        getTaskCategoryLoading: true,
        getTaskCategoryStatus: false,
        getTaskCategoryError: false,
        message: '',
      };
    }
    case GET_TASK_CATEGORY_SUCCESS: {
      return {
        ...state,
        getTaskCategoryLoading: false,
        getTaskCategoryStatus: true,
        getTaskCategoryError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response,
      };
    }
    case GET_TASK_CATEGORY_FAILURE: {
      return {
        ...state,
        getTaskLoading: false,
        getTaskStatus: false,
        getTaskError: true,
        message: action.message,
      };
    }
    case GET_TASK: {
      return {
        ...state,
        getTaskLoading: true,
        getTaskStatus: false,
        getTaskError: false,
        message: '',
      };
    }
    case GET_TASK_SUCCESS: {
      return {
        ...state,
        getTaskLoading: false,
        getTaskStatus: true,
        getTaskError: false,
        message: action.message,
        accessToken: action.accessToken,
        createTaskresponse: action.response,
      };
    }
    case GET_TASK_FAILURE: {
      return {
        ...state,
        getTaskLoading: false,
        getTaskStatus: false,
        getTaskError: true,
        message: action.message,
      };
    }
    case GET_CRM_INFO: {
      return {
        ...state,
        getCRMInfoLoading: true,
        getCRMInfoStatus: false,
        getCRMInfoError: false,
        CRMmessage: '',
      };
    }
    case GET_CRM_INFO_SUCCESS: {
      return {
        ...state,
        getCRMInfoLoading: false,
        getCRMInfoStatus: true,
        getCRMInfoError: false,
        CRMmessage: action.message,
        accessToken: action.accessToken,
        CRMresponse: action.response,
      };
    }
    case GET_CRM_INFO_FAILURE: {
      return {
        ...state,
        getCRMInfoLoading: false,
        getCRMInfoStatus: false,
        getCRMInfoError: true,
        CRMmessage: action.message,
      };
    }

    case UPDATE_TASK: {
      return {
        ...state,
        updateCRMLoading: true,
        updateCRMStatus: false,
        updateCRMError: false,
        message: '',
      };
    }
    case UPDATE_TASK_SUCCESS: {
      return {
        ...state,
        updateCRMLoading: false,
        updateCRMStatus: true,
        updateCRMError: false,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case UPDATE_TASK_FAILURE: {
      return {
        ...state,
        updateCRMLoading: false,
        updateCRMStatus: false,
        updateCRMError: true,
        message: action.message,
      };
    }
    case GET_TASK_TIME: {
      return {
        ...state,

        getTaskTimeLoading: true,

        getTaskTimeStatus: false,

        getTaskTimeError: false,

        taskTimemessage: '',
      };
    }

    case GET_TASK_TIME_SUCCESS: {
      return {
        ...state,

        getTaskTimeLoading: false,

        getTaskTimeStatus: true,

        getTaskTimeError: false,

        taskTimemessage: action.message,

        accessToken: action.accessToken,

        taskTimeresponse: action.response,
      };
    }

    case GET_TASK_TIME_FAILURE: {
      return {
        ...state,

        getTaskTimeLoading: false,

        getTaskTimeStatus: false,

        getTaskTimeError: true,

        taskTimemessage: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
