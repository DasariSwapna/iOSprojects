import {
  CHECK_EMAIL,
  CHECK_EMAIL_FAILURE,
  CHECK_EMAIL_SUCCESS,
  SIGNUP,
  SIGNUP_BACK,
  SIGNUP_FAILURE,
  SIGNUP_SUCCESS,
} from '../ActionTypes';
const initState = {
  message: '',
  signUpLoading: false,
  signUpStatus: false,
  signUpError: false,
  checkEmailLoading: false,
  checkEmailStatus: false,
  checkEmailError: false,
  checkEmailResponse: null,
  signUpResponse: null,
  signUpBackState: 0,
};

export default function signUpReducer(state = initState, action) {
  switch (action.type) {
    case SIGNUP: {
      return {
        ...state,
        signUpLoading: true,
        signUpStatus: false,
        signUpError: false,
        message: '',
      };
    }
    case SIGNUP_SUCCESS: {
      return {
        ...state,
        signUpLoading: false,
        signUpStatus: true,
        signUpError: false,
        message: action.message,
        signUpResponse: action.res,
      };
    }
    case SIGNUP_FAILURE: {
      return {
        ...state,
        signUpLoading: false,
        signUpStatus: false,
        signUpError: true,
        message: action.message,
      };
    }
    case CHECK_EMAIL: {
      return {
        ...state,
        checkEmailLoading: true,
        checkEmailStatus: false,
        checkEmailError: false,
        message: '',
      };
    }
    case CHECK_EMAIL_SUCCESS: {
      return {
        ...state,
        checkEmailLoading: false,
        checkEmailStatus: true,
        checkEmailError: false,
        message: action.message,
        checkEmailResponse: action.res,
      };
    }
    case CHECK_EMAIL_FAILURE: {
      return {
        ...state,
        checkEmailLoading: false,
        checkEmailStatus: false,
        checkEmailError: true,
        message: action.message,
      };
    }

    case SIGNUP_BACK: {
      return {
        ...state,
        signUpBackState: action.data
          ? action.data.status
          : state.signUpBackState,
      };
    }

    default: {
      return state;
    }
  }
}
