import {
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST,
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_SUCCESS,
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_FAILURE
} from "../ActionTypes";
const initState = {
  message: "",
  accessToken: null,
  kitsampleHandoverBiodataSelectlistLoading: false,
  kitsampleHandoverBiodataSelectlistStatus: false,
  kitsampleHandoverBiodataSelectlistError: false,
  type: "P"
};

export default function kitsampleBiodataReducer(state = initState, action) {
  switch (action.type) {
    case KITSAMPLE_HANDOVER_BIODATA_SELECTLIST: {
      return {
        ...state,
        kitsampleHandoverBiodataSelectlistLoading: true,
        kitsampleHandoverBiodataSelectlistStatus: false,
        kitsampleHandoverBiodataSelectlistError: false,
        message: ""
      };
    }
    case KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_SUCCESS: {
      return {
        ...state,
        kitsampleHandoverBiodataSelectlistLoading: false,
        kitsampleHandoverBiodataSelectlistStatus: true,
        kitsampleHandoverBiodataSelectlistError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response
      };
    }
    case KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_FAILURE: {
      return {
        ...state,
        kitsampleHandoverBiodataSelectlistLoading: false,
        kitsampleHandoverBiodataSelectlistStatus: false,
        kitsampleHandoverBiodataSelectlistError: true,
        message: action.message
      };
    }
    default: {
      return state;
    }
  }
}
