import {
  GETMANGERTESTAPPROVAL,
  GETMANGERTESTAPPROVAL_SUCCESS,
  GETMANGERTESTAPPROVAL_FAILURE,
  DELETE_APPROVALS_DATA,
  DELETE_APPROVALS_DATA_SUCCESS,
  DELETE_APPROVALS_DATA_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  salesMangerApprovelLoading: false,
  salesMangerApprovelStatus: false,
  salesMangerApprovelError: false,
  salesMangerApprovelResponse: null,
  verifyMessage: '',
  verifyaccessToken: null,
  salesMangerRevisedResponse: null,
  deletemessage: '',
  deleteapprovaldatasLoading: false,
  deleteapprovaldatasStatus: false,
  deleteapprovaldatasError: false,
};

export default function payementModeReducer(state = initState, action) {
  switch (action.type) {
    case GETMANGERTESTAPPROVAL: {
      return {
        ...state,
        salesMangerApprovelLoading: true,
        salesMangerApprovelStatus: false,
        salesMangerApprovelError: false,
        message: '',
      };
    }
    case GETMANGERTESTAPPROVAL_SUCCESS: {
      console.log('....>', action.response);
      return {
        ...state,
        salesMangerApprovelLoading: false,
        salesMangerApprovelStatus: true,
        salesMangerApprovelError: false,
        message: action.message,
        response1: action.response1,
        response2: action.response2,
        response3: action.response3,

        salesMangerApprovelResponse:
          action.kind == 1
            ? action.response
            : state.salesMangerApprovelResponse,
        salesMangerRevisedResponse:
          action.kind == 4 ? action.response : state.salesMangerRevisedResponse,
      };
    }
    case GETMANGERTESTAPPROVAL_FAILURE: {
      return {
        ...state,
        salesMangerApprovelLoading: false,
        salesMangerApprovelStatus: false,
        salesMangerApprovelError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    case DELETE_APPROVALS_DATA: {
      return {
        ...state,
        deleteapprovaldatasLoading: true,
        deleteapprovaldatasStatus: false,
        deleteapprovaldatasError: false,
        message: '',
      };
    }
    case DELETE_APPROVALS_DATA_SUCCESS: {
      return {
        ...state,
        deleteapprovaldatasLoading: false,
        deleteapprovaldatasStatus: true,
        deleteapprovaldatasError: false,
        deletemessage: action.message,
        // deleteapprovaldetailsResponse: action.response
      };
    }
    case DELETE_APPROVALS_DATA_FAILURE: {
      return {
        ...state,
        deleteapprovaldatasLoading: false,
        deleteapprovaldatasStatus: false,
        deleteapprovaldatasError: true,
        message: action.message,
      };
    }

    default: {
      return state;
    }
  }
}
