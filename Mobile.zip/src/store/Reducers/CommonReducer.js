import en from '../../locale/en.json';
import {
  GET_CENTER,
  GET_CENTER_FAILURE,
  GET_CENTER_SUCCESS,
  GET_CITY_FAILURE,
  GET_CITY_SUCCESS,
  GET_ICON,
  GET_ICON_FAILURE,
  GET_ICON_SUCCESS,
  GET_IMAGE,
  GET_IMAGE_FAILURE,
  GET_IMAGE_SUCCESS,
  GET_LABEL,
  GET_LABEL_FAILURE,
  GET_LABEL_SUCCESS,
  GET_LANGUAGE,
  GET_LANGUAGE_FAILURE,
  GET_LANGUAGE_SUCCESS,
  GET_PAGE_NO,
  GET_PAGE_NO_FAILURE,
  GET_PAGE_NO_SUCCESS,
  GET_ROLE,
  GET_ROLE_FAILURE,
  GET_ROLE_SUCCESS,
  GET_THEME,
  GET_THEME_FAILURE,
  GET_THEME_SUCCESS,
  GET_APP_CONFIG,
  GET_APP_CONFIG_SUCCESS,
  GET_APP_CONFIG_FAILURE,
  LAUNCH_APP,
  GET_OTP,
  GET_OTP_SUCCESS,
  GET_OTP_FAILURE,
  GET_STATE,
  GET_STATE_SUCCESS,
  GET_STATE_FAILURE,
  GET_PRODUCT_DETAILS,
  GET_PRODUCT_DETAILS_SUCCESS,
  GET_PRODUCT_DETAILS_FAILURE,
  GET_PRODUCT_LIST,
  GET_PRODUCT_LIST_SUCCESS,
  GET_PRODUCT_LIST_FAILURE,
  GET_ADDRESS_TYPE,
  GET_ADDRESS_TYPE_SUCCESS,
  GET_ADDRESS_TYPE_FAILURE,
  GET_CITY,
  GET_CITY_TYPE_SUCCESS,
  GET_CITY_TYPE_FAILURE,
  GET_HOSPITAL,
  GET_HOSPITAL_SUCCESS,
  GET_HOSPITAL_FAILURE,
  GET_DOCTOR_NAME,
  GET_DOCTOR_NAME_SUCCESS,
  GET_DOCTOR_NAME_FAILURE,
  GET_REFERRED_BY,
  GET_REFERRED_BY_SUCCESS,
  GET_REFERRED_BY_FAILURE,
  GET_PICKUP_TYPE,
  GET_PICKUP_TYPE_SUCCESS,
  GET_PICKUP_TYPE_FAILURE,
  GET_ACCOUNT_TYPE,
  GET_ACCOUNT_TYPE_SUCCESS,
  GET_ACCOUNT_TYPE_FAILURE,
  GET_SPECIALITY,
  GET_SPECIALITY_SUCCESS,
  GET_SPECIALITY_FAILURE,
  INSERT_SIGNATURE,
  INSERT_SIGNATURE_SUCCESS,
  INSERT_SIGNATURE_FAILURE,
  GET_CANCEL_REASON,
  GET_CANCEL_REASON_SUCCESS,
  GET_CANCEL_REASON_FAILURE,
  INSERT_PAY_DETAILS,
  STORE_ADDRESS,
} from '../ActionTypes';

const initState = {
  message: '',
  address: null,
  isAppLaunched: false,
  appConfigLoading: false,
  appConfigStatus: false,
  appConfigError: false,
  languageLoading: false,
  languageStatus: false,
  languageError: false,
  labelLoading: false,
  labelStatus: false,
  labelError: false,
  themeLoading: false,
  themeStatus: false,
  themeError: false,
  pageNoLoading: false,
  pageNoStatus: false,
  pageNoError: false,
  iconLoading: false,
  iconStatus: false,
  iconError: false,
  imageLoading: false,
  imageStatus: false,
  imageError: false,
  roleLoading: false,
  roleStatus: false,
  roleError: false,
  centerLoading: false,
  centerStatus: false,
  centerError: false,
  cityLoading: false,
  cityStatus: false,
  cityError: false,
  imageResponse: null,
  languageResponse: null,
  appConfigResponse: null,
  appConfigEnrollmentPDFResponse: null,
  themeResponse: null,
  pageNoResponse: null,
  labelResponse: null,
  getOTPLoading: false,
  getOTPStatus: false,
  getOTPError: false,
  OTPResponse: null,

  stateLoading: false,
  sateStatus: false,
  stateError: false,
  stateResponse: null,

  productDetailsLoading: false,
  productDetailsStatus: false,
  productDetailsError: false,
  productDetailsResponse: null,

  productListResponse: null,
  productListLoading: false,
  productListStatus: false,
  productListError: false,

  cityLoading: false,
  cityStatus: false,
  cityError: false,
  cityResponse: null,

  addressTypeLoading: false,
  addressTypeStatus: false,
  addressTypeError: false,
  addressTypeResponse: null,

  hospitalLoading: false,
  hospitalStatus: false,
  hospitalError: false,
  hospitalResponse: null,

  doctorNameLoading: false,
  doctorNameStatus: false,
  doctorNameError: false,
  doctorNameResponse: null,

  referredbyLoading: false,
  referredbyStatus: false,
  referredbyError: false,
  referredbyResponse: null,

  pickupTypeLoading: false,
  pickupTypeStatus: false,
  pickupTypeError: false,
  pickupTypeResponse: null,

  cancelReasonLoading: false,
  cancelReasonStatus: false,
  cancelReasonError: false,
  cancelReasonResponse: null,

  iconResponse: null,
  roles: null,
  centers: null,
  cities: null,

  accountTypeLoading: false,
  accountTypeStatus: false,
  accountTypeError: false,
  accountTypeResponse: null,

  specialityLoading: false,
  specialityStatus: false,
  specialityError: false,
  specialityResponse: null,

  insertSignatureLoading: false,
  insertSignatureStatus: false,
  insertSignatureError: false,
  insertSignatureResponse: null,

  payDetailResponse: null,
  address: null,
};

const commanReducer = (state = initState, action) => {
  switch (action.type) {
    case LAUNCH_APP: {
      return {
        ...state,
        isAppLaunched: true,
      };
    }

    case GET_APP_CONFIG: {
      return {
        ...state,
        message: '',
        appConfigLoading: true,
        appConfigStatus: false,
        appConfigError: false,
      };
    }
    case GET_APP_CONFIG_SUCCESS: {
      return {
        ...state,
        appConfigResponse: action.response,
        appConfigEnrollmentPDFResponse: action.response1,
        message: action.message,
        appConfigLoading: false,
        appConfigStatus: true,
        appConfigError: false,
      };
    }
    case GET_APP_CONFIG_FAILURE: {
      return {
        ...state,
        message: action.message,
        appConfigLoading: false,
        appConfigStatus: false,
        appConfigError: true,
      };
    }

    case GET_LANGUAGE: {
      return {
        ...state,
        message: '',
        languageLoading: true,
        languageStatus: false,
        languageError: false,
      };
    }
    case GET_LANGUAGE_SUCCESS: {
      return {
        ...state,
        languageResponse: action.response,
        message: action.message,
        languageLoading: false,
        languageStatus: true,
        languageError: false,
      };
    }
    case GET_LANGUAGE_FAILURE: {
      return {
        ...state,
        message: action.message,
        languageLoading: false,
        languageStatus: false,
        languageError: true,
      };
    }

    case GET_LABEL: {
      return {
        ...state,
        message: '',
        labelLoading: true,
        labelStatus: false,
        labelError: false,
      };
    }
    case GET_LABEL_SUCCESS: {
      // en.translation.signIn.sign_in =
      //   action.response.login[0].LC_LLM_LABLE_NAME;

      return {
        ...state,
        labelResponse: action.response,
        message: action.message,
        labelLoading: false,
        labelStatus: true,
        labelError: false,
      };
    }
    case GET_LABEL_FAILURE: {
      return {
        ...state,
        message: action.message,
        labelLoading: false,
        labelStatus: false,
        labelError: true,
      };
    }
    case GET_THEME: {
      return {
        ...state,
        message: '',
        themeLoading: true,
        themeStatus: false,
        themeError: false,
      };
    }
    case GET_THEME_SUCCESS: {
      return {
        ...state,
        themeResponse: action.response,
        message: action.message,
        themeLoading: false,
        themeStatus: true,
        themeError: false,
      };
    }
    case GET_THEME_FAILURE: {
      return {
        ...state,
        message: action.message,
        themeLoading: false,
        themeStatus: false,
        themeError: true,
      };
    }

    case GET_PAGE_NO: {
      return {
        ...state,
        message: '',
        pageNoLoading: true,
        pageNoStatus: false,
        pageNoError: false,
      };
    }
    case GET_PAGE_NO_SUCCESS: {
      return {
        ...state,
        pageNoResponse: action.response,
        message: action.message,
        pageNoLoading: false,
        pageNoStatus: true,
        pageNoError: false,
      };
    }
    case GET_PAGE_NO_FAILURE: {
      return {
        ...state,
        message: action.message,
        pageNoLoading: false,
        pageNoStatus: false,
        pageNoError: true,
      };
    }

    case GET_ADDRESS_TYPE: {
      return {
        ...state,
        message: '',
        addressTypeLoading: true,
        addressTypeStatus: false,
        addressTypeError: false,
      };
    }
    case GET_ADDRESS_TYPE_SUCCESS: {
      return {
        ...state,
        addressTypeResponse: action.response.respList,
        message: action.message,
        addressTypeLoading: false,
        addressTypeStatus: true,
        addressTypeError: false,
      };
    }
    case GET_ADDRESS_TYPE_FAILURE: {
      return {
        ...state,
        message: action.message,
        addressTypeLoading: false,
        addressTypeStatus: false,
        addressTypeError: true,
      };
    }

    case GET_STATE: {
      return {
        ...state,
        message: '',
        stateLoading: true,
        sateStatus: false,
        stateError: false,
      };
    }
    case GET_STATE_SUCCESS: {
      return {
        ...state,
        stateResponse: action.response.respList,
        message: action.message,
        stateLoading: false,
        sateStatus: true,
        stateError: false,
      };
    }
    case GET_STATE_FAILURE: {
      return {
        ...state,
        message: action.message,
        stateLoading: false,
        sateStatus: false,
        stateError: true,
      };
    }

    case GET_CANCEL_REASON: {
      return {
        ...state,
        message: '',
        cancelReasonLoading: true,
        cancelReasonStatus: false,
        cancelReasonError: false,
      };
    }
    case GET_CANCEL_REASON_SUCCESS: {
      return {
        ...state,
        cancelReasonResponse: action.response.respList,
        message: action.message,
        cancelReasonLoading: false,
        cancelReasonStatus: true,
        cancelReasonError: false,
      };
    }
    case GET_CANCEL_REASON_FAILURE: {
      return {
        ...state,
        message: action.message,
        cancelReasonLoading: false,
        cancelReasonStatus: false,
        cancelReasonError: true,
      };
    }

    // case GET_APP_CONFIG: {
    //   return {
    //     ...state,
    //     message: '',
    //     cityLoading: true,
    //     cityStatus: false,
    //     cityError: false,
    //   };
    // }
    // case GET_CITY_TYPE_SUCCESS: {
    //   return {
    //     ...state,
    //     cityResponse: action.response.respList,
    //     message: action.message,
    //     cityLoading: false,
    //     cityStatus: true,
    //     cityError: false,
    //   };
    // }
    // case GET_CITY_TYPE_FAILURE: {
    //   return {
    //     ...state,
    //     message: action.message,
    //     cityLoading: false,
    //     cityStatus: false,
    //     cityError: true,
    //   };
    // }

    case GET_HOSPITAL: {
      return {
        ...state,
        message: '',
        hospitalLoading: true,
        hospitalStatus: false,
        hospitalError: false,
      };
    }
    case GET_HOSPITAL_SUCCESS: {
      return {
        ...state,
        hospitalResponse: action.response.respList,
        message: action.message,
        hospitalLoading: false,
        hospitalStatus: true,
        hospitalError: false,
      };
    }
    case GET_HOSPITAL_FAILURE: {
      return {
        ...state,
        message: action.message,
        hospitalLoading: false,
        hospitalStatus: false,
        hospitalError: true,
      };
    }

    case GET_DOCTOR_NAME: {
      return {
        ...state,
        message: '',
        doctorNameLoading: true,
        doctorNamelStatus: false,
        doctorNameError: false,
      };
    }
    case GET_DOCTOR_NAME_SUCCESS: {
      return {
        ...state,
        doctorNameResponse: action.response,
        message: action.message,
        doctorNameLoading: false,
        doctorNameStatus: true,
        doctorNameError: false,
      };
    }
    case GET_DOCTOR_NAME_FAILURE: {
      return {
        ...state,
        message: action.message,
        doctorNameLoading: false,
        doctorNameStatus: false,
        doctorNameError: true,
      };
    }

    case GET_REFERRED_BY: {
      return {
        ...state,
        message: '',
        referredbyLoading: true,
        referredbyStatus: false,
        referredbyError: false,
      };
    }
    case GET_REFERRED_BY_SUCCESS: {
      return {
        ...state,
        referredbyResponse: action.response.respList,
        message: action.message,
        referredbyLoading: false,
        referredbyStatus: true,
        referredbyError: false,
      };
    }
    case GET_REFERRED_BY_FAILURE: {
      return {
        ...state,
        message: action.message,
        referredbyLoading: false,
        referredbyStatus: false,
        referredbyError: true,
      };
    }

    case GET_PICKUP_TYPE: {
      return {
        ...state,
        message: '',
        pickupTypeLoading: true,
        pickupTypeStatus: false,
        pickupTypeError: false,
      };
    }
    case GET_PICKUP_TYPE_SUCCESS: {
      return {
        ...state,
        pickupTypeResponse: action.response.respList,
        message: action.message,
        pickupTypeLoading: false,
        pickupTypeStatus: true,
        pickupTypeError: false,
      };
    }
    case GET_PICKUP_TYPE_FAILURE: {
      return {
        ...state,
        message: action.message,
        pickupTypeLoading: false,
        pickupTypeStatus: false,
        pickupTypeError: true,
      };
    }

    case GET_OTP: {
      return {
        ...state,
        message: '',
        getOTPLoading: true,
        getOTPStatus: false,
        getOTPError: false,
      };
    }
    case GET_OTP_SUCCESS: {
      return {
        ...state,
        OTPResponse: action.response,
        message: action.message,
        getOTPLoading: false,
        getOTPStatus: true,
        getOTPError: false,
      };
    }
    case GET_OTP_FAILURE: {
      return {
        ...state,
        message: action.message,
        getOTPLoading: false,
        getOTPStatus: false,
        getOTPError: true,
      };
    }

    case GET_IMAGE: {
      return {
        ...state,
        message: '',
        imageLoading: true,
        imageStatus: false,
        imageError: false,
      };
    }
    case GET_IMAGE_SUCCESS: {
      return {
        ...state,
        imageResponse: action.response,
        message: action.message,
        imageLoading: false,
        imageStatus: true,
        imageError: false,
      };
    }
    case GET_IMAGE_FAILURE: {
      return {
        ...state,
        message: action.message,
        imageLoading: false,
        imageStatus: false,
        imageError: true,
      };
    }

    case GET_ICON: {
      return {
        ...state,
        message: '',
        iconLoading: true,
        iconStatus: false,
        iconError: false,
      };
    }
    case GET_ICON_SUCCESS: {
      return {
        ...state,
        iconResponse: action.response,
        message: action.message,
        iconLoading: false,
        iconStatus: true,
        iconError: false,
      };
    }
    case GET_ICON_FAILURE: {
      return {
        ...state,
        message: action.message,
        iconLoading: false,
        iconStatus: false,
        iconError: true,
      };
    }

    case GET_ROLE: {
      return {
        ...state,
        message: '',
        iconLoading: true,
        iconStatus: false,
        iconError: false,
      };
    }
    case GET_ROLE_SUCCESS: {
      return {
        ...state,
        roles: action.response,
        message: action.message,
        iconLoading: false,
        iconStatus: true,
        iconError: false,
      };
    }
    case GET_ROLE_FAILURE: {
      return {
        ...state,
        message: action.message,
        iconLoading: false,
        iconStatus: false,
        iconError: true,
      };
    }

    case GET_CITY: {
      return {
        ...state,
        message: '',
        cityLoading: true,
        cityStatus: false,
        cityError: false,
      };
    }
    case GET_CITY_SUCCESS: {
      return {
        ...state,
        cities: action.response,
        cityResponse: action.response,
        message: action.message,
        cityLoading: false,
        cityStatus: true,
        cityError: false,
      };
    }
    case GET_CITY_FAILURE: {
      return {
        ...state,
        message: action.message,
        cityLoading: false,
        cityStatus: false,
        cityError: true,
      };
    }

    case GET_CENTER: {
      return {
        ...state,
        message: '',
        centerLoading: true,
        centerStatus: false,
        centerError: false,
      };
    }
    case GET_CENTER_SUCCESS: {
      return {
        ...state,
        centers: action.response,
        message: action.message,
        centerLoading: false,
        centerStatus: true,
        centerError: false,
      };
    }
    case GET_CENTER_FAILURE: {
      return {
        ...state,
        message: action.message,
        centerLoading: false,
        centerStatus: false,
        centerError: true,
      };
    }
    case GET_PRODUCT_DETAILS: {
      return {
        ...state,
        message: '',
        productDetailsLoading: true,
        productDetailsStatus: false,
        productDetailsError: false,
      };
    }
    case GET_PRODUCT_DETAILS_SUCCESS: {
      return {
        ...state,
        productDetailsResponse: action.response,
        message: action.message,
        productDetailsLoading: false,
        productDetailsStatus: true,
        productDetailsError: false,
      };
    }
    case GET_PRODUCT_DETAILS_FAILURE: {
      return {
        ...state,
        message: action.message,
        productDetailsLoading: false,
        productDetailsStatus: false,
        productDetailsError: true,
      };
    }

    case GET_PRODUCT_LIST: {
      return {
        ...state,
        message: '',
        productListLoading: true,
        productListStatus: false,
        productListError: false,
      };
    }
    case GET_PRODUCT_LIST_SUCCESS: {
      return {
        ...state,
        productListResponse: action.response,
        message: action.message,
        productListLoading: false,
        productListStatus: true,
        productDetailsError: false,
      };
    }
    case GET_PRODUCT_LIST_FAILURE: {
      return {
        ...state,
        message: action.message,
        productListLoading: false,
        productListStatus: false,
        productListError: true,
      };
    }
    case GET_ACCOUNT_TYPE: {
      return {
        ...state,
        message: '',
        accountTypeLoading: true,
        accountTypeStatus: false,
        accountTypeError: false,
      };
    }
    case GET_ACCOUNT_TYPE_SUCCESS: {
      return {
        ...state,
        accountTypeResponse: action.response,
        message: action.message,
        accountTypeLoading: false,
        accountTypeStatus: true,
        accountTypeError: false,
      };
    }
    case GET_ACCOUNT_TYPE_FAILURE: {
      return {
        ...state,
        message: action.message,
        accountTypeLoading: false,
        accountTypeStatus: false,
        accountTypeError: true,
      };
    }

    case GET_SPECIALITY: {
      return {
        ...state,
        message: '',
        specialityLoading: true,
        specialityStatus: false,
        specialityError: false,
      };
    }
    case GET_SPECIALITY_SUCCESS: {
      return {
        ...state,
        specialityResponse: action.response,
        message: action.message,
        specialityLoading: false,
        specialityStatus: true,
        specialityError: false,
      };
    }
    case GET_SPECIALITY_FAILURE: {
      return {
        ...state,
        message: action.message,
        specialityLoading: false,
        specialityStatus: false,
        specialityError: true,
      };
    }

    case INSERT_SIGNATURE: {
      return {
        ...state,
        message: '',
        insertSignatureLoading: true,
        insertSignatureStatus: false,
        insertSignatureError: false,
      };
    }
    case INSERT_SIGNATURE_SUCCESS: {
      return {
        ...state,
        insertSignatureResponse: action.response,
        message: action.message,
        insertSignatureLoading: false,
        insertSignatureStatus: true,
        insertSignatureError: false,
      };
    }
    case INSERT_SIGNATURE_FAILURE: {
      return {
        ...state,
        message: action.message,
        insertSignatureLoading: false,
        insertSignatureStatus: false,
        insertSignatureError: true,
      };
    }

    case INSERT_PAY_DETAILS: {
      return {
        ...state,
        payDetailResponse: action.data,
      };
    }
    case STORE_ADDRESS: {
      return {
        ...state,
        address: action.data,
      };
    }

    default: {
      return state;
    }
  }
};

export default commanReducer;
