import {
  LOGIN_WITH_OTP,
  LOGIN_WITH_OTP_SUCCESS,
  LOGIN_WITH_OTP_FAILURE,
} from '../ActionTypes';
const initState = {
  loginWithLoading: false,
  loginWithStatus: false,
  loginWithError: false,
};

export default function signInReducer(state = initState, action) {
  switch (action.type) {
    case LOGIN: {
      return {
        ...state,
        loginLoading: true,
        loginStatus: false,
        loginError: false,
        message: '',
      };
    }
    case LOGIN_SUCCESS: {
      return {
        ...state,
        loginLoading: false,
        loginStatus: true,
        loginError: false,
        message: action.message,
        accessToken: action.accessToken,
        role: action.roles,
        userId: action.userId,
        username: action.username,
        dayStartStatus: action.dayStartStatus,
        activationStatus: action.activationStatus,
      };
    }
    case LOGIN_FAILURE: {
      return {
        ...state,
        loginLoading: false,
        loginStatus: false,
        loginError: true,
        message: action.message,
      };
    }

    case LOGOUT: {
      return {
        ...state,
        accessToken: null,
      };
    }

    default: {
      return state;
    }
  }
}
