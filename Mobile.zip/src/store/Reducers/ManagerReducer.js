import {
  GET_APPROVAL_COUNT,
  GET_APPROVAL_COUNT_SUCCESS,
  GET_APPROVAL_COUNT_FAILURE,
  GET_APPROVAL_DETAILS,
  GET_APPROVAL_DETAILS_SUCCESS,
  GET_APPROVAL_DETAILS_FAILURE,
  GET_APPROVAL_DETAILS_PROCESS,
  GET_APPROVAL_DETAILS_PROCESS_SUCCESS,
  GET_APPROVAL_DETAILS_PROCESS_FAILURE,
  UPDATE_APPROVED_STATUS,
  UPDATE_APPROVED_STATUS_SUCCESS,
  UPDATE_APPROVED_STATUS_FAILURE,
  MANAGER_DISCOUNT_APPROVAL,
  MANAGER_DISCOUNT_APPROVAL_SUCCESS,
  MANAGER_DISCOUNT_APPROVAL_FAILURE,
  MANAGER_DISCOUNT_DETAILS_APPROVAL,
  MANAGER_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
  MANAGER_DISCOUNT_APPROVAL_DETAILS_FAILURE,
  UPDATE_DISCOUNT_DETAILS_APPROVAL,
  UPDATE_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
  UPDATE_DISCOUNT_APPROVAL_DETAILS_FAILURE,
} from '../ActionTypes';

const initState = {
  message: '',
  accessToken: null,
  approvalCountLoading: false,
  approvalCountStatus: false,
  approvalCountError: false,

  approvaldetailsLoading: false,
  apporvaldetailsStatus: false,
  approvaldetailstError: false,
  approvalDetails: null,

  approvaldetailsprocessLoading: false,
  apporvaldetailsprocessStatus: false,
  approvaldetailstprocessError: false,
  approvalDetailsprocess: null,

  approvaldetailapprovedsLoading: false,
  apporvaldetailsapprovedStatus: false,
  approvaldetailstapprovedError: false,
  approvalDetailsapproved: null,

  discountapprovaldetailsLoading: false,
  discountapporvaldetailsStatus: false,
  discountapprovaldetailstError: false,
  discountapprovalDetails: null,
  discountapprovalDetailstestTableDetails: null,

  discountapprovalLoading: false,
  discountapporvalStatus: false,
  discountapprovalError: false,
  discountapproval: null,

  updatediscountapprovaldetailsLoading: false,
  updatediscountapporvaldetailsStatus: false,
  updatediscountapprovaldetailstError: false,
  updatediscountapprovalDetailsmessage: null,

  discountapprovalpending: null,
  discountapprovalapproved: null,
  discountapprovalDetailsTest: null,

  type: 'P',
};

export default function approvalCountReducer(state = initState, action) {
  switch (action.type) {
    case GET_APPROVAL_COUNT: {
      return {
        ...state,
        approvalCountLoading: true,
        approvalCountStatus: false,
        approvalCountError: false,
        message: '',
      };
    }
    case GET_APPROVAL_COUNT_SUCCESS: {
      return {
        ...state,
        approvalCountLoading: false,
        approvalCountStatus: true,
        approvalCountError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response,
      };
    }
    case GET_APPROVAL_COUNT_FAILURE: {
      return {
        ...state,
        approvalCountLoading: false,
        approvalCountStatus: false,
        approvalCountError: true,
        message: action.message,
      };
    }

    case GET_APPROVAL_DETAILS: {
      return {
        ...state,
        approvaldetailsLoading: true,
        apporvaldetailsStatus: false,
        approvaldetailstError: false,
        message: '',
      };
    }
    case GET_APPROVAL_DETAILS_SUCCESS: {
      return {
        ...state,
        approvaldetailsLoading: false,
        apporvaldetailsStatus: true,
        approvaldetailstError: false,
        message: action.message,
        accessToken: action.accessToken,
        approvaldoctorDetails: action.response1,
        approvalproducttestDetails: action.response2,
        approvalproducttesttableDetails: action.response3,
      };
    }
    case GET_APPROVAL_DETAILS_FAILURE: {
      return {
        ...state,
        approvaldetailsLoading: false,
        apporvaldetailsStatus: false,
        approvaldetailstError: true,
        message: action.message,
      };
    }

    case GET_APPROVAL_DETAILS_PROCESS: {
      return {
        ...state,
        approvaldetailsprocessLoading: true,
        apporvaldetailsprocessStatus: false,
        approvaldetailstprocessError: false,
        message: '',
      };
    }
    case GET_APPROVAL_DETAILS_PROCESS_SUCCESS: {
      return {
        ...state,
        approvaldetailsprocessLoading: false,
        apporvaldetailsprocessStatus: true,
        approvaldetailstprocessError: false,
        // message: action.message,
        accessToken: action.accessToken,
        approvalDetailsprocess: action.response,
        approvalDetailsprocess1: action.response1,
        approvalDetailsprocess2: action.response2,
      };
    }
    case GET_APPROVAL_DETAILS_PROCESS_FAILURE: {
      return {
        ...state,
        approvaldetailsprocessLoading: false,
        apporvaldetailsprocessStatus: false,
        approvaldetailstprocessError: true,
        message: action.message,
      };
    }

    case UPDATE_APPROVED_STATUS: {
      return {
        ...state,
        approvaldetailapprovedsLoading: true,
        apporvaldetailsapprovedStatus: false,
        approvaldetailstapprovedError: false,
        message: '',
      };
    }
    case UPDATE_APPROVED_STATUS_SUCCESS: {
      return {
        ...state,
        approvaldetailapprovedsLoading: false,
        apporvaldetailsapprovedStatus: true,
        approvaldetailstapprovedError: false,
        deletemessage: action.message,
        accessToken: action.accessToken,
      };
    }
    case UPDATE_APPROVED_STATUS_FAILURE: {
      return {
        ...state,
        approvaldetailapprovedsLoading: false,
        apporvaldetailsapprovedStatus: false,
        approvaldetailstapprovedError: true,
        message: action.message,
      };
    }

    case MANAGER_DISCOUNT_APPROVAL: {
      return {
        ...state,
        discountapprovalLoading: true,
        discountapporvalStatus: false,
        discountapprovalError: false,
        message: '',
      };
    }
    case MANAGER_DISCOUNT_APPROVAL_SUCCESS: {
      return {
        ...state,
        discountapprovalLoading: false,
        discountapporvalStatus: true,
        discountapprovalError: false,
        discountapprovalpending: action.response2,
        discountapprovalapproved: action.response1,
      };
    }
    case MANAGER_DISCOUNT_APPROVAL_FAILURE: {
      return {
        ...state,
        discountapprovalLoading: false,
        discountapporvalStatus: false,
        discountapprovalError: true,
        message: action.message,
      };
    }

    case MANAGER_DISCOUNT_DETAILS_APPROVAL: {
      return {
        ...state,
        discountapprovaldetailsLoading: true,
        discountapporvaldetailsStatus: false,
        discountapprovaldetailstError: false,
        message: '',
      };
    }
    case MANAGER_DISCOUNT_APPROVAL_DETAILS_SUCCESS: {
      return {
        ...state,
        discountapprovaldetailsLoading: false,
        discountapporvaldetailsStatus: true,
        discountapprovaldetailstError: false,
        discountapprovalDetails: action.response,
        discountapprovalDetailsTest: action.response1,
        discountapprovalDetailstestTableDetails: action.response2,
      };
    }
    case MANAGER_DISCOUNT_APPROVAL_DETAILS_FAILURE: {
      return {
        ...state,
        discountapprovaldetailsLoading: false,
        discountapporvaldetailsStatus: false,
        discountapprovaldetailstError: true,
        message: action.message,
      };
    }

    case MANAGER_DISCOUNT_APPROVAL_FAILURE: {
      return {
        ...state,
        discountapprovalLoading: false,
        discountapporvalStatus: false,
        discountapprovalError: true,
        message: action.message,
      };
    }

    case UPDATE_DISCOUNT_DETAILS_APPROVAL: {
      return {
        ...state,
        updatediscountapprovaldetailsLoading: true,
        updatediscountapporvaldetailsStatus: false,
        updatediscountapprovaldetailstError: false,
        message: '',
      };
    }
    case UPDATE_DISCOUNT_APPROVAL_DETAILS_SUCCESS: {
      return {
        ...state,
        updatediscountapprovaldetailsLoading: false,
        updatediscountapporvaldetailsStatus: true,
        updatediscountapprovaldetailstError: false,
        updatediscountapprovalDetailsmessage: action.message,
      };
    }
    case UPDATE_DISCOUNT_APPROVAL_DETAILS_FAILURE: {
      return {
        ...state,
        updatediscountapprovaldetailsLoading: false,
        updatediscountapporvaldetailsStatus: false,
        updatediscountapprovaldetailstError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
