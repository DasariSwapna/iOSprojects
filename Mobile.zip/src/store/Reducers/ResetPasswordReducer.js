import {

  RESET_PASSWORD,
  RESET_PASSWORD_SUCCESS,
  RESET_PASSWORD_FAILURE
} from "../ActionTypes";
const initState = {
  message: "",
  accessToken: null,
  resetPasswordLoading: false,
  resetPasswordStatus: false,
  resetPasswordError: false,
  type: "P",
 
};

export default function forgetpasswordReducer(state = initState, action) {
  switch (action.type) {
    case RESET_PASSWORD: {
      return {
        ...state,
        resetPasswordLoading: true,
        resetPasswordStatus: false,
        resetPasswordError: false,
        message: ""
      };
    }
    case RESET_PASSWORD_SUCCESS: {
      return {
        ...state,
        resetPasswordLoading: false,
        resetPasswordStatus: true,
        resetPasswordError: false,
        message: action.message,
        // accessToken: action.accessToken,
        accessToken: "hhhhsjdlklfdjkncfnkdcv"
      };
    }
    case RESET_PASSWORD_FAILURE: {
      return {
        ...state,
        resetPasswordLoading: false,
        resetPasswordStatus: false,
        resetPasswordError: true,
        message: action.message
        // accessToken: 'hsfkksdlfmb',
      };
    }
    default: {
      return state;
    }
  }
}
