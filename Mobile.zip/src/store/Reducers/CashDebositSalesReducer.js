import {
  CASH_DEPOSIT_SALES_HANDOVER_MONEY,
  CASH_DEPOSIT_SALES_HANDOVER_MONEY_SUCCESS,
  CASH_DEPOSIT_SALES_HANDOVER_MONEY_FAILURE,
  CASH_DEPOSIT_SALES_UPDATE,
  CASH_DEPOSIT_SALES_UPDATE_SUCCESS,
  CASH_DEPOSIT_SALES_UPDATE_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  getCashDetailLoading: false,
  getCashDetailStatus: false,
  getCashDetailError: false,
  getCashDetailResponse: null,

  updateCashDetailLoading: false,
  updateCashDetailStatus: false,
  updateCashDetailError: false,
  updateCashDetailResponse: null,
  type: 'P',
};

export default function shuttledetailupdate(state = initState, action) {
  switch (action.type) {
    case CASH_DEPOSIT_SALES_HANDOVER_MONEY: {
      return {
        ...state,
        getCashDetailLoading: true,
        getCashDetailStatus: false,
        getCashDetailError: false,
        message: '',
      };
    }
    case CASH_DEPOSIT_SALES_HANDOVER_MONEY_SUCCESS: {
      return {
        ...state,
        getCashDetailLoading: false,
        getCashDetailStatus: true,
        getCashDetailError: false,
        getCashDetailResponse: action.response,
        message: action.message,
      };
    }
    case CASH_DEPOSIT_SALES_HANDOVER_MONEY_FAILURE: {
      return {
        ...state,
        getCashDetailLoading: false,
        getCashDetailStatus: false,
        getCashDetailError: true,
        message: action.message,
      };
    }

    case CASH_DEPOSIT_SALES_UPDATE: {
      return {
        ...state,
        updateCashDetailLoading: true,
        updateCashDetailStatus: false,
        updateCashDetailError: false,
        message: '',
      };
    }
    case CASH_DEPOSIT_SALES_UPDATE_SUCCESS: {
      return {
        ...state,
        updateCashDetailLoading: false,
        updateCashDetailStatus: true,
        updateCashDetailError: false,
        updateCashDetailResponse: action.response,
        message: action.message,
      };
    }
    case CASH_DEPOSIT_SALES_UPDATE_FAILURE: {
      return {
        ...state,
        updateCashDetailLoading: false,
        updateCashDetailStatus: false,
        updateCashDetailError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
