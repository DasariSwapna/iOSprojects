import {
 GET_POSTAL,
 GET_POSTAL_SUCCESS,
 GET_POSTAL_FAILURE,
 GET_LAB_CENTER_NAME,
 GET_LAB_CENTER_NAME_SUCCESS,
 GET_LAB_CENTER_NAME_FAILURE
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  getPostalLoading: false,
  getPostalStatus: false,
  getPostalError: false,
  response:'',
  type: 'P',
  getLabCenterNameLoading: false,
  getLabCenterNameStatus: false,
  getLabCenterNameError: false,
  LabCenterNameResponse: '',
};

export default function kitsampleCourirerReducer(state = initState, action) {
  switch (action.type) {

    case GET_POSTAL: {
      return {
        ...state,
        getPostalLoading: true,
        getPostalStatus: false,
        getPostalError: false,
        message: '',
      };
    }
    case GET_POSTAL_SUCCESS: {
      return {
        ...state,
        getPostalLoading: false,
        getPostalStatus: true,
        getPostalError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response,
      };
    }
    case GET_POSTAL_FAILURE: {
      return {
        ...state,
        getPostalLoading: false,
        getPostalStatus: false,
        getPostalError: true,
        message: action.message,
      };
    }

    //lab center name
    case GET_LAB_CENTER_NAME: {
      return {
        ...state,
        getLabCenterNameLoading: true,
        getLabCenterNameStatus: false,
        getLabCenterNameError: false,
        message: '',
      };
    }
    case GET_LAB_CENTER_NAME_SUCCESS: {
      return {
        ...state,
        getLabCenterNameLoading: false,
        getLabCenterNameStatus: true,
        getLabCenterNameError: false,
        message: action.message,
        accessToken: action.accessToken,
        LabCenterNameResponse: action.response,
      };
    }
    case GET_LAB_CENTER_NAME_FAILURE: {
      return {
        ...state,
        getLabCenterNameLoading: false,
        getLabCenterNameStatus: false,
        getLabCenterNameError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
