import {flatMap} from 'lodash';
import {
  DEPOSIT_CASH,
  DEPOSIT_CASH_FAILURE,
  DEPOSIT_CASH_SUCCESS,
  DEPOSIT_CASH_BANK,
  DEPOSIT_CASH_BANK_SUCCESS,
  DEPOSIT_CASH_BANK_FAILURE,
  DEPOSIT_CASH_BRANCH,
  DEPOSIT_CASH_BRANCH_SUCCESS,
  DEPOSIT_CASH_BRANCH_FAILURE,
  DEPOSIT_CASH_TIME,
  DEPOSIT_CASH_TIME_SUCCESS,
  DEPOSIT_CASH_TIME_FAILURE,
  UPDATE_DEPOSIT_CASH,
  UPDATE_DEPOSIT_CASH_SUCCESS,
  UPDATE_DEPOSIT_CASH_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  cashDepositLoading: false,
  cashDepositStatus: false,
  cashDepositError: false,
  type: 'P',
  cashDepositBankLoading: false,
  cashDepositBankStatus: false,
  cashDepositBankError: false,
  cashDepositBranchLoading: false,
  cashDepositBranchStatus: false,
  cashDepositBranchError: false,
  cashDepositTimeLoading: false,
  cashDepositTimeStatus: false,
  cashDepositTimeError: false,
  updatecashDepositLoading: false,
  updatecashDepositStatus: false,
  updatecashDepositError: false,
};

export default function depositCash(state = initState, action) {
  switch (action.type) {
    case DEPOSIT_CASH: {
      return {
        ...state,
        cashDepositLoading: true,
        cashDepositStatus: false,
        cashDepositError: false,
        message: '',
      };
    }
    case DEPOSIT_CASH_SUCCESS: {
      return {
        ...state,
        cashDepositLoading: false,
        cashDepositStatus: true,
        cashDepositError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response,
      };
    }
    case DEPOSIT_CASH_FAILURE: {
      return {
        ...state,
        cashDepositLoading: false,
        cashDepositStatus: false,
        cashDepositError: true,
        message: action.message,
      };
    }

    //bank
    case DEPOSIT_CASH_BANK: {
      return {
        ...state,
        cashDepositBankLoading: true,
        cashDepositBankStatus: false,
        cashDepositBankError: false,
        message: '',
      };
    }
    case DEPOSIT_CASH_BANK_SUCCESS: {
      return {
        ...state,
        cashDepositBankLoading: false,
        cashDepositBankStatus: true,
        cashDepositBankError: false,
        message: action.message,
        accessToken: action.accessToken,
        bankResponse: action.response,
      };
    }
    case DEPOSIT_CASH_BANK_FAILURE: {
      return {
        ...state,
        cashDepositBankLoading: false,
        cashDepositBankStatus: false,
        cashDepositBankError: true,
        message: action.message,
      };
    }
    //branch
    case DEPOSIT_CASH_BRANCH: {
      return {
        ...state,
        cashDepositBranchLoading: true,
        cashDepositBranchStatus: false,
        cashDepositBranchError: false,
        message: '',
      };
    }
    case DEPOSIT_CASH_BRANCH_SUCCESS: {
      return {
        ...state,
        cashDepositBranchLoading: false,
        cashDepositBranchStatus: true,
        cashDepositBranchError: false,
        message: action.message,
        accessToken: action.accessToken,
        branchResponse: action.response,
      };
    }
    case DEPOSIT_CASH_BRANCH_FAILURE: {
      return {
        ...state,
        cashDepositBranchLoading: false,
        cashDepositBranchStatus: false,
        cashDepositBranchError: true,
        message: action.message,
      };
    }

    //Time
    case DEPOSIT_CASH_TIME: {
      return {
        ...state,
        cashDepositTimeLoading: true,
        cashDepositTimeStatus: false,
        cashDepositTimeError: false,
        message: '',
      };
    }
    case DEPOSIT_CASH_TIME_SUCCESS: {
      return {
        ...state,
        cashDepositTimeLoading: false,
        cashDepositTimeStatus: true,
        cashDepositTimeError: false,
        message: action.message,
        accessToken: action.accessToken,
        timeResponse: action.response,
      };
    }
    case DEPOSIT_CASH_TIME_FAILURE: {
      return {
        ...state,
        cashDepositTimeLoading: false,
        cashDepositTimeStatus: false,
        cashDepositTimeError: true,
        message: action.message,
      };
    }
    //update
    case UPDATE_DEPOSIT_CASH: {
      return {
        ...state,
        updatecashDepositLoading: true,
        updatecashDepositStatus: false,
        updatecashDepositError: false,
        message: '',
      };
    }
    case UPDATE_DEPOSIT_CASH_SUCCESS: {
      return {
        ...state,
        updatecashDepositLoading: false,
        updatecashDepositStatus: true,
        updatecashDepositError: false,
        message: action.message,
        accessToken: action.accessToken,
        updateResponse: action.response,
      };
    }
    case UPDATE_DEPOSIT_CASH_FAILURE: {
      return {
        ...state,
        updatecashDepositLoading: false,
        updatecashDepositStatus: false,
        updatecashDepositError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
