import {flatMap} from 'lodash';
import {
  KITSAMPLE_HANDOVER_BIODATA,
  KITSAMPLE_HANDOVER_BIODATA_SUCCESS,
  KITSAMPLE_HANDOVER_BIODATA_FAILURE,
  GET_DROPDOWN_HANOVER_MODE,
  GET_DROPDOWN_HANOVER_MODE_SUCCESS,
  GET_DROPDOWN_HANOVER_MODE_FAILURE,
  GET_HANOVER_CENTER,
  GET_HANOVER_CENTER_SUCCESS,
  GET_HANOVER_CENTER_FAILURE,
  GET_HANOVER_LAB,
  GET_HANOVER_LAB_SUCCESS,
  GET_HANOVER_LAB_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,
  kitsampleHandoverBiodataLoading: false,
  kitsampleHandoverBiodataStatus: false,
  kitsampleHandoverBiodataError: false,
  type: 'P',
  getHandoverModeLoading: false,
  getHandoverModeStatus: false,
  getHandoverModeError: false,
  handoverModeresponse: '',
  getHandoverCenterLoading: false,
  getHandoverCenterStatus: false,
  getHandoverCenterError: false,
  centerResponse: '',
  getHandoverLabLoading: false,
  getHandoverLabStatus: false,
  getHandoverLabError: false,
  labResponse: '',
};

export default function kitsampleBiodataReducer(state = initState, action) {
  switch (action.type) {
    case KITSAMPLE_HANDOVER_BIODATA: {
      return {
        ...state,
        kitsampleHandoverBiodataLoading: true,
        kitsampleHandoverBiodataStatus: false,
        kitsampleHandoverBiodataError: false,
        message: '',
      };
    }
    case KITSAMPLE_HANDOVER_BIODATA_SUCCESS: {
      return {
        ...state,
        kitsampleHandoverBiodataLoading: false,
        kitsampleHandoverBiodataStatus: true,
        kitsampleHandoverBiodataError: false,
        //  message: action.message,
        // accessToken: action.accessToken,
        response: action.response,
        // accessToken: "hhhhsjdlklfdjkncfnkdcv"
      };
    }
    case KITSAMPLE_HANDOVER_BIODATA_FAILURE: {
      return {
        ...state,
        kitsampleHandoverBiodataLoading: false,
        kitsampleHandoverBiodataStatus: false,
        kitsampleHandoverBiodataError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    // DROPDOWN KITSAMPLE HANDOVER MODE
    case GET_DROPDOWN_HANOVER_MODE: {
      return {
        ...state,
        getHandoverModeLoading: true,
        getHandoverModeStatus: false,
        getHandoverModeError: false,
        message: '',
      };
    }
    case GET_DROPDOWN_HANOVER_MODE_SUCCESS: {
      return {
        ...state,
        getHandoverModeLoading: false,
        getHandoverModeStatus: true,
        getHandoverModeError: false,
        message: action.message,
        accessToken: action.accessToken,
        handoverModeresponse: action.response,
      };
    }
    case GET_DROPDOWN_HANOVER_MODE_FAILURE: {
      return {
        ...state,
        getHandoverModeLoading: false,
        getHandoverModeStatus: false,
        getHandoverModeError: true,
        message: action.message,
      };
    }

    //Handover mode center
    case GET_HANOVER_CENTER: {
      return {
        ...state,
        getHandoverCenterLoading: true,
        getHandoverCenterStatus: false,
        getHandoverCenterError: false,
        message: '',
      };
    }
    case GET_HANOVER_CENTER_SUCCESS: {
      return {
        ...state,
        getHandoverCenterLoading: false,
        getHandoverCenterStatus: true,
        getHandoverCenterError: false,
        message: action.message,
        accessToken: action.accessToken,
        centerResponse: action.response,
      };
    }
    case GET_HANOVER_CENTER_FAILURE: {
      return {
        ...state,
        getHandoverCenterLoading: false,
        getHandoverCenterStatus: false,
        getHandoverCenterError: true,
        message: action.message,
      };
    }
    //Handover mode center
    case GET_HANOVER_LAB: {
      return {
        ...state,
        getHandoverLabLoading: true,
        getHandoverLabStatus: false,
        getHandoverLabError: false,
        message: '',
      };
    }
    case GET_HANOVER_LAB_SUCCESS: {
      return {
        ...state,
        getHandoverLabLoading: false,
        getHandoverLabStatus: true,
        getHandoverLabError: false,
        message: action.message,
        accessToken: action.accessToken,
        labResponse: action.response,
      };
    }
    case GET_HANOVER_LAB_FAILURE: {
      return {
        ...state,
        getHandoverLabLoading: false,
        getHandoverLabStatus: false,
        getHandoverLabError: true,
        message: action.message,
      };
    }
    default: {
      return state;
    }
  }
}
