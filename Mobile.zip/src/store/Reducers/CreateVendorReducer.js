import {
    INSERT_VENDOR,
    INSERT_VENDOR_SUCCESS,
    INSERT_VENDOR_FAILURE,
    INSERT_VENDOR_TEST,
    INSERT_VENDOR_TEST_SUCCESS,
    INSERT_VENDOR_TEST_FAILURE,
    GET_QUESTION_ANSWER,
    GET_QUESTION_ANSWER_SUCCESS,
    GET_QUESTION_ANSWER_FAILURE,
    INSERT_QUESTION_ANSWER,
    INSERT_QUESTION_ANSWER_SUCCESS,
    INSERT_QUESTION_ANSWER_FAILURE,
    CREATE_VENDOR_ADD_TEST,
    CREATE_VENDOR_BASIC_DETAIL,
    INSERT_HOSPITAL_DOCTOR,
    GET_VENDOR_DETAILS,
    GET_VENDOR_DETAILS_SUCCESS,
    GET_VENDOR_DETAILS_FAILURE,
    CREATE_VENDOR_TERMS_DETAIL
    

} from '../ActionTypes';

const initState = {
    message: '',
    insertVendorLoading: false,
    insertVendorStatus: false,
    insertVendorError: false,
    insertVendorResponse: null,

    insertVendorTestLoading: false,
    insertVendorTestStatus: false,
    insertVendorTestError: false,
    insertVendorTestResponse: null,

    getQuestionAnswerLoading: false,
    getQuestionAnswerStatus: false,
    getQuestionAnswerError: false,
    getQuestionAnswerResponse: null,

    insertQuestionAnswerLoading: false,
    insertQuestionAnswerStatus: false,
    insertQuestionAnswerError: false,
    insertQuestionAnswerResponse: null,

    insertHospitalDoctorResponse: null,

    VendoraddTest : null,
    VendoraddTestProduct : null,
    VendoraddTestInvoiceAmount: null,
    VendoraddTestProductSelection:null,

    vendorDetailsResponse: null,
    vendorDetailsLoading: null,
    vendorDetailsStatus: null,
    vendorDetailsError: null,
    vendorDetailsDoctorResponse : null


};

export default function createOrderReducer(state = initState, action) {
    switch (action.type) {
        case INSERT_VENDOR: {
            return {
                ...state,
                insertVendorLoading: true,
                insertVendorStatus: false,
                insertVendorError: false,
                message: '',
            };
        }
        case INSERT_VENDOR_SUCCESS: {
            return {
                ...state,
                insertVendorResponse: action.response,
                insertVendorLoading: false,
                insertVendorStatus: true,
                insertVendorError: false,
                message: action.message,
            };
        }
        case INSERT_VENDOR_FAILURE: {
            return {
                ...state,
                insertVendorLoading: false,
                insertVendorStatus: false,
                insertVendorError: true,
                message: action.message,
            };
        }
        case INSERT_VENDOR_TEST: {
            return {
                ...state,
                insertVendorTestLoading: true,
                insertVendorTestStatus: false,
                insertVendorTestError: false,
                message: '',
            };
        }
        case INSERT_VENDOR_TEST_SUCCESS: {
            return {
                ...state,
                insertVendorTestResponse: action.response,
                insertVendorTestLoading: false,
                insertVendorTestStatus: true,
                insertVendorTestError: false,
                message: action.message,
            };
        }
        case INSERT_VENDOR_TEST_FAILURE: {
            return {
                ...state,
                insertVendorTestLoading: false,
                insertVendorTestStatus: false,
                insertVendorTestError: true,
                message: action.message,
            };
        }

        case GET_QUESTION_ANSWER: {
            return {
                ...state,
                getQuestionAnswerLoading: true,
                getQuestionAnswerStatus: false,
                getQuestionAnswerError: false,
                message: '',
            };
        }
        case GET_QUESTION_ANSWER_SUCCESS: {
            return {
                ...state,
                getQuestionAnswerLoading: false,
                getQuestionAnswerStatus: true,
                getQuestionAnswerError: false,
                getQuestionAnswerResponse: action.response,
                message: action.message,
            };
        }
        case GET_QUESTION_ANSWER_FAILURE: {
            return {
                ...state,
                getQuestionAnswerLoading: false,
                getQuestionAnswerStatus: false,
                getQuestionAnswerError: true,
                message: action.message,
            };
        }

        case INSERT_QUESTION_ANSWER: {
            return {
                ...state,
                insertQuestionAnswerLoading: true,
                insertQuestionAnswerStatus: false,
                insertQuestionAnswerError: false,
                message: '',
            };
        }
        case INSERT_QUESTION_ANSWER_SUCCESS: {
            return {
                ...state,
                insertQuestionAnswerLoading: false,
                insertQuestionAnswerStatus: true,
                insertQuestionAnswerError: false,
                insertQuestionAnswerResponse: action.response,
                message: action.message,
            };
        }
        case INSERT_QUESTION_ANSWER_FAILURE: {
            return {
                ...state,
                insertQuestionAnswerLoading: false,
                insertQuestionAnswerStatus: false,
                insertQuestionAnswerError: true,
                message: action.message,
            };
        }

        case INSERT_HOSPITAL_DOCTOR: {
            return {
                ...state,
                insertHospitalDoctorResponse: action.data
            };
        }


        case GET_VENDOR_DETAILS: {
            return {
              ...state,
              vendorDetailsLoading: true,
              vendorDetailsStatus: false,
              vendorDetailsError: false,
              message: '',
            };
          }
          case GET_VENDOR_DETAILS_SUCCESS: {
            return {
              ...state,
              vendorDetailsResponse: action.response,
              vendorDetailsDoctorResponse: action.response1,
              vendorDetailsLoading: false,
              vendorDetailsStatus: true,
              vendorDetailsError: false,
              message: action.message,
            };
          }
          case GET_VENDOR_DETAILS_FAILURE: {
            return {
              ...state,
              vendorDetailsLoading: false,
              vendorDetailsStatus: false,
              vendorDetailsError: true,
              message: action.message,
            };
          }


        case CREATE_VENDOR_ADD_TEST: {
            return {
              ...state,
              VendoraddTest: action.data.producttestDetails,
              VendoraddTestProduct: action.data.productDetails,
              VendoraddTestInvoiceAmount:action.data.invoiceAmount,
              VendoraddTestProductSelection: action.data.productSelectionindex,
              VendoraddTesttotalTestSelected: action.data.totalTestSelected,
              VendoraddTesttotalTestOutliners: action.data.totalTestOutliners,
              VendoraddTesttotalTestAutoApproved: action.data.totalTestAutoApproved,
            };
          }

          case CREATE_VENDOR_BASIC_DETAIL: {
            return {
              ...state,
              vendorbasicDetail: action.data,
            };
          }

          case CREATE_VENDOR_TERMS_DETAIL: {
            return {
              ...state,
              vendortermsDetail: action.data,
            };
          }


        default: {
            return state;
        }
    }
}