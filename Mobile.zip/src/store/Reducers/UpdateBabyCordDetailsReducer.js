import {
    MY_TASK_UPDATE_BABY_CORD,
    MY_TASK_UPDATE_BABY_CORD_SUCCESS,
    MY_TASK_UPDATE_BABY_CORD_FAILURE,
} from '../ActionTypes';

const initState = {
    message: '',
    updateBabyCordDetailsLoading: false,
    updateBabyCordDetailsStatus: false,
    updateBabyCordDetailsError: false,
    updateBabyCordDetailsResponse: null,
}

export default function updateBabyCordDetailsReducer(state = initState, action) {
    switch (action.type) {
      case MY_TASK_UPDATE_BABY_CORD: {
        return {
          ...state,
          updateBabyCordDetailsLoading: true,
          updateBabyCordDetailsStatus: false,
          updateBabyCordDetailsError: false,
          updateBabyCordDetailsResponse: null,
          message:""
        };
      }
      case MY_TASK_UPDATE_BABY_CORD_SUCCESS: {
        return {
          ...state,
          updateBabyCordDetailsLoading: false,
          updateBabyCordDetailsStatus: true,
          updateBabyCordDetailsError: false,
          updateBabyCordDetailsResponse: action.response,
          message:action.message
        };
      }
      case MY_TASK_UPDATE_BABY_CORD_FAILURE: {
        return {
          ...state,
          updateBabyCordDetailsLoading: false,
          updateBabyCordDetailsStatus: false,
          updateBabyCordDetailsError: true,
          message: action.message
        };
      }
      default: {
        return state;
      }
    }
}