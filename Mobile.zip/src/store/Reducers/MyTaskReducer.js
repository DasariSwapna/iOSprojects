import {
  MY_TASK_TYPE_LIST_DATAS,
  MY_TASK_TYPE_LIST_SUCCESS,
  MY_TASK_TYPE_LIST_FAILURE,

  MY_TASK_TYPE_LIST_DATAS_DETAILS,
  MY_TASK_TYPE_LIST_DETAILS_SUCCESS,
  MY_TASK_TYPE_LIST_DETAILS_FAILURE,

  MY_TASK_PICKUP_START,
  MY_TASK_PICKUP_START_SUCCESS,
  MY_TASK_PICKUP_START_FAILURE,

  MY_TASK_BABY_CORD_DETAILS_CRMID,
  MY_TASK_BABY_CORD_DETAILS_CRMID_SUCCESS,
  MY_TASK_BABY_CORD_DETAILS_CRMID_FAILURE,

  MY_TASK_PARAMEDIC_REACHED,
  MY_TASK_PARAMEDIC_REACHED_SUCCESS,
  MY_TASK_PARAMEDIC_REACHED_FAILURE,

  MY_TASK_BARCODE_SELECT_TEST,
  MY_TASK_BARCODE_SELECT_TEST_SUCCESS,
  MY_TASK_BARCODE_SELECT_TEST_FAILURE,

  MY_TASK_UPDATE_BARCODE_TEST_PICKUP,
  MY_TASK_UPDATE_BARCODE_TEST_PICKUP_SUCCESS,
  MY_TASK_UPDATE_BARCODE_TEST_PICKUP_FAILURE,

  MY_TASK_GET_PICKED_TEST_LIST,
  MY_TASK_GET_PICKED_TEST_LIST_SUCCESS,
  MY_TASK_GET_PICKED_TEST_LIST_FAILURE,

  MY_TASK_BARCODE_REMOVE_SAMPLE,
  MY_TASK_BARCODE_REMOVE_SAMPLE_SUCCESS,
  MY_TASK_BARCODE_REMOVE_SAMPLE_FAILURE,

  MY_TASK_UPDATE_PNS_TRF,
  MY_TASK_UPDATE_PNS_TRF_SUCCESS,
  MY_TASK_UPDATE_PNS_TRF_FAILURE,

  MY_TASK_UPDATE_CANCEL_REASON,
  MY_TASK_UPDATE_CANCEL_REASON_SUCCESS,
  MY_TASK_UPDATE_CANCEL_REASON_FAILURE,

  GET_TIEUP_HOSPITAL,
  GET_TIEUP_HOSPITAL_SUCCESS,
  GET_TIEUP_HOSPITAL_FAILURE,

  GET_TIEUP_HOSPITAL_VISIT_TIME,
  GET_TIEUP_HOSPITAL_VISIT_TIME_SUCCESS,
  GET_TIEUP_HOSPITAL_VISIT_TIME_FAILURE,

  GET_TIEUP_HOSPITAL_SAMPLE_TYPE,
  GET_TIEUP_HOSPITAL_SAMPLE_TYPE_SUCCESS,
  GET_TIEUP_HOSPITAL_SAMPLE_TYPE_FAILURE,

  INSERT_ORDER_DETAILS_REGULAR_BEAT,
  INSERT_ORDER_DETAILS_REGULAR_BEAT_SUCCESS,
  INSERT_ORDER_DETAILS_REGULAR_BEAT_FAILURE,

  GET_PICKED_TEST_LIST_REGULAR_BEAT,
  GET_PICKED_TEST_LIST_REGULAR_BEAT_SUCCESS,
  GET_PICKED_TEST_LIST_REGULAR_BEAT_FAILURE,

  INSERT_NO_SAMPLE_REGULAR_BEAT,
  INSERT_NO_SAMPLE_REGULAR_BEAT_SUCCESS,
  INSERT_NO_SAMPLE_REGULAR_BEAT_FAILURE,

  UPDATE_PARAMEDIC_RESCDULED,
  UPDATE_PARAMEDIC_RESCDULED_SUCCESS,
  UPDATE_PARAMEDIC_RESCDULED_FAILURE,

  GET_ORDERID_CRMID_REGULAR_BEAT,

  MY_TASK_USER_CANCEL_LIST,
  MY_TASK_USER_CANCEL_LIST_SUCCESS,
  MY_TASK_USER_CANCEL_LIST_FAILURE,

  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT,
  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_SUCCESS,
  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_FAILURE,


} from "../ActionTypes";

const initState = {
  message: "",
  accessToken: null,
  MytasklistLoading: false,
  MytasklistStatus: false,
  MytasklistError: false,

  MytasklistdetailsLoading: false,
  MytasklistPnsdetailsLoading: false,
  MytasklistCanceldetailsLoading: false,
  MytasklistdetailsStatus: false,
  MytasklisdetailsError: false,

  mytasklistBabyCordDetailsPending: null,
  mytasklistBabyCordDetailsCompleted: null,
  mytasklistBabyCordDetailsCansRes: null,
  type: "P",

  MytaskCancelListLoading: false,
  MytaskCancelListStatus: false,
  MytaskCancelListError: false,
  MytaskCancelListResponse: null,

  mytasklistCancelListPending: null,
  mytasklistCancelListCompleted: null,
  mytasklistCancelListCansRes: null,
  

  MytaskPickupStartedLoading: false,
  MytaskPickupStartedStatus: false,
  MytaskPickupStartedError: false,
  MytaskPickupStartedResponse: null,

  MytaskPickupBabyCordDetailsCrmidLoading: false,
  MytaskPickupBabyCordDetailsCrmidStatus: false,
  MytaskPickupBabyCordDetailsCrmidError: false,
  MytaskPickupBabyCordDetailsCrmidResponse: null,

  MytaskParamedicReachedLoading: false,
  MytaskParamedicReachedStatus: false,
  MytaskParamedicReachedError: false,
  MytaskParamedicReachedResponse: null,

  MytaskBarcodeSelectTestLoading: false,
  MytaskBarcodeSelectTestStatus: false,
  MytaskBarcodeSelectTestError: false,
  MytaskBarcodeSelectTestResponse: null,

  MytaskUpdateBarcodeTestPickupLoading: false,
  MytaskUpdateBarcodeTestPickupStatus: false,
  MytaskUpdateBarcodeTestPickupError: false,
  MytaskUpdateBarcodeTestPickupResponse: null,

  MytaskGetPickedListLoading: false,
  MytaskGetPickedListStatus: false,
  MytaskGetPickedListError: false,
  MytaskGetPickedListResponse: null,

  MytaskRemoveSamplePickupLoading: false,
  MytaskRemoveSamplePickupStatus: false,
  MytaskRemoveSamplePickupError: false,
  MytaskRemoveSamplePickupResponse: null,

  MytaskUploadPNSWithTRFLoading: false,
  MytaskUploadPNSWithTRFStatus: false,
  MytaskUploadPNSWithTRFError: false,
  MytaskUploadPNSWithTRFResponse: null,

  MytaskUpdateCancelReasonLoading: false,
  MytaskUpdateCancelReasonStatus: false,
  MytaskUpdateCancelReasonError: false,
  MytaskUpdateCancelReasonResponse: null,

  MytaskGetTieupHospitalLoading: false,
  MytaskGetTieupHospitalStatus: false,
  MytaskGetTieupHospitalError: false,
  MytaskGetTieupHospitalResponse: null,

  MytaskGetTieupHospitalVisitTimeLoading: false,
  MytaskGetTieupHospitalVisitTimeStatus: false,
  MytaskGetTieupHospitalVisitTimeError: false,
  MytaskGetTieupHospitalVisitTimeResponse: null,

  MytaskGetTieupHospitalSampleTypeLoading: false,
  MytaskGetTieupHospitalSampleTypeStatus: false,
  MytaskGetTieupHospitalSampleTypeError: false,
  MytaskGetTieupHospitalSampleTypeResponse: null,

  MytaskInsertOrderDetailsForRegularBeatLoading: false,
  MytaskInsertOrderDetailsForRegularBeatStatus: false,
  MytaskInsertOrderDetailsForRegularBeatError: false,
  MytaskInsertOrderDetailsForRegularBeatResponse: null,

  MytaskInsertNoSampleForRegularBeatLoading: false,
  MytaskInsertNoSampleForRegularBeatStatus: false,
  MytaskInsertNoSampleForRegularBeatError: false,
  MytaskInsertNoSampleForRegularBeatResponse: null,

  MytaskGetPickedTestListForRegularBeatLoading: false,
  MytaskGetPickedTestListForRegularBeatStatus: false,
  MytaskGetPickedTestListForRegularBeatError: false,
  MytaskGetPickedTestListForRegularBeatResponse: null,
  
  updateParamedicRescduledLoading: false,
  updateParamedicRescduledStatus: false,
  updateParamedicRescduledError: false,
  updateParamedicRescduledResponse: null,

  MytaskRemoveSampleRegularBeatLoading: false,
  MytaskRemoveSampleRegularBeatStatus: false,
  MytaskRemoveSampleRegularBeatError: false,
  MytaskRemoveSampleRegularBeatResponse: null,

  MytaskGetCRMIdOrderId:null
};

export default function mytasklistReducer(state = initState, action) {
  switch (action.type) {
    case MY_TASK_TYPE_LIST_DATAS: {
      return {
        ...state,
        MytasklistLoading: true,
        MytasklistStatus: false,
        MytasklistError: false,
        message: ""
      };
    }
    case MY_TASK_TYPE_LIST_SUCCESS: {
      return {
        ...state,
        MytasklistLoading: false,
        MytasklistStatus: true,
        MytasklistError: false,
        message: action.message,
        accessToken: action.accessToken,
        response: action.response
      };
    }
    case MY_TASK_TYPE_LIST_FAILURE: {
      return {
        ...state,
        MytasklistLoading: false,
        MytasklistStatus: false,
        MytasklistError: true,
        message: action.message
      };
    }

    case MY_TASK_TYPE_LIST_DATAS_DETAILS: {
      return {
        ...state,
        MytasklistdetailsLoading: true,
        MytasklistPnsdetailsLoading: true,
        MytasklistCanceldetailsLoading: true,
        MytasklistdetailsStatus: false,
        MytasklisdetailsError: false,
        message: ""
      };
    }
    case MY_TASK_TYPE_LIST_DETAILS_SUCCESS: {
      return {
        ...state,
        MytasklistdetailsLoading: false,
        MytasklistPnsdetailsLoading: false,
        MytasklistCanceldetailsLoading: false,
        MytasklistdetailsStatus: true,
        MytasklisdetailsError: false,
        message: action.message,
        accessToken: action.accessToken,
        mytasklistBabyCordDetailsPending: action.response.pending,
        mytasklistBabyCordDetailsCompleted: action.response.COMPLETED,
        mytasklistBabyCordDetailsCansRes: action.response.CANCEL_RESCHDULE,

      };
    }
    case MY_TASK_TYPE_LIST_DETAILS_FAILURE: {
      return {
        ...state,
        MytasklistdetailsLoading: false,
        MytasklistPnsdetailsLoading: false,
        MytasklistCanceldetailsLoading: false,
        MytasklistdetailsStatus: false,
        MytasklisdetailsError: true,
        message: action.message
      };
    }

    case MY_TASK_PICKUP_START: {
      return {
        ...state,
        MytaskPickupStartedLoading: true,
        MytaskPickupStartedStatus: false,
        MytaskPickupStartedError: false,
        message: ""
      };
    }
    case MY_TASK_PICKUP_START_SUCCESS: {
      return {
        ...state,
        MytaskPickupStartedLoading: false,
        MytaskPickupStartedStatus: true,
        MytaskPickupStartedError: false,
        message: action.message,
        accessToken: action.accessToken,
        MytaskPickupStartedResponse: action.response,

      };
    }
    case MY_TASK_PICKUP_START_FAILURE: {
      return {
        ...state,
        MytaskPickupStartedLoading: false,
        MytaskPickupStartedStatus: false,
        MytaskPickupStartedError: true,
        message: action.message
      };
    }
    case MY_TASK_BABY_CORD_DETAILS_CRMID: {
      return {
        ...state,
        MytaskPickupBabyCordDetailsCrmidLoading: true,
        MytaskPickupBabyCordDetailsCrmidStatus: false,
        MytaskPickupBabyCordDetailsCrmidError: false,
        MytaskPickupBabyCordDetailsCrmidResponse: "",
      };
    }
    case MY_TASK_BABY_CORD_DETAILS_CRMID_SUCCESS: {
      return {
        ...state,
        MytaskPickupBabyCordDetailsCrmidLoading: false,
        MytaskPickupBabyCordDetailsCrmidStatus: true,
        MytaskPickupBabyCordDetailsCrmidError: false,
        MytaskPickupBabyCordDetailsCrmidResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_BABY_CORD_DETAILS_CRMID_FAILURE: {
      return {
        ...state,
        MytaskPickupBabyCordDetailsCrmidLoading: false,
        MytaskPickupBabyCordDetailsCrmidStatus: false,
        MytaskPickupBabyCordDetailsCrmidError: true,
        message: action.message
      };
    }

    case MY_TASK_PARAMEDIC_REACHED: {
      return {
        ...state,
        MytaskParamedicReachedLoading: true,
        MytaskParamedicReachedStatus: false,
        MytaskParamedicReachedError: false,
        MytaskParamedicReachedResponse: "",
      };
    }
    case MY_TASK_PARAMEDIC_REACHED_SUCCESS: {
      return {
        ...state,
        MytaskParamedicReachedLoading: false,
        MytaskParamedicReachedStatus: true,
        MytaskParamedicReachedError: false,
        MytaskParamedicReachedResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_PARAMEDIC_REACHED_FAILURE: {
      return {
        ...state,
        MytaskParamedicReachedLoading: false,
        MytaskParamedicReachedStatus: false,
        MytaskParamedicReachedError: true,
        message: action.message
      };
    }


    case MY_TASK_BARCODE_SELECT_TEST: {
      return {
        ...state,
        MytaskBarcodeSelectTestLoading: true,
        MytaskBarcodeSelectTestStatus: false,
        MytaskBarcodeSelectTestError: false,
        MytaskBarcodeSelectTestResponse: "",
      };
    }
    case MY_TASK_BARCODE_SELECT_TEST_SUCCESS: {
      return {
        ...state,
        MytaskBarcodeSelectTestLoading: false,
        MytaskBarcodeSelectTestStatus: true,
        MytaskBarcodeSelectTestError: false,
        MytaskBarcodeSelectTestResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_BARCODE_SELECT_TEST_FAILURE: {
      return {
        ...state,
        MytaskBarcodeSelectTestLoading: false,
        MytaskBarcodeSelectTestStatus: false,
        MytaskBarcodeSelectTestError: true,
        message: action.message
      };
    }

    case MY_TASK_UPDATE_BARCODE_TEST_PICKUP: {
      return {
        ...state,
        MytaskUpdateBarcodeTestPickupLoading: true,
        MytaskUpdateBarcodeTestPickupStatus: false,
        MytaskUpdateBarcodeTestPickupError: false,
        MytaskUpdateBarcodeTestPickupResponse: "",
      };
    }
    case MY_TASK_UPDATE_BARCODE_TEST_PICKUP_SUCCESS: {
      return {
        ...state,
        MytaskUpdateBarcodeTestPickupLoading: false,
        MytaskUpdateBarcodeTestPickupStatus: true,
        MytaskUpdateBarcodeTestPickupError: false,
        MytaskUpdateBarcodeTestPickupResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_UPDATE_BARCODE_TEST_PICKUP_FAILURE: {
      return {
        ...state,
        MytaskUpdateBarcodeTestPickupLoading: false,
        MytaskUpdateBarcodeTestPickupStatus: false,
        MytaskUpdateBarcodeTestPickupError: true,
        message: action.message
      };
    }

    case MY_TASK_GET_PICKED_TEST_LIST: {
      return {
        ...state,
        MytaskGetPickedListLoading: true,
        MytaskGetPickedListStatus: false,
        MytaskGetPickedListError: false,
        MytaskGetPickedListResponse: "",
      };
    }
    case MY_TASK_GET_PICKED_TEST_LIST_SUCCESS: {
      return {
        ...state,
        MytaskGetPickedListLoading: false,
        MytaskGetPickedListStatus: true,
        MytaskGetPickedListError: false,
        MytaskGetPickedListResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_GET_PICKED_TEST_LIST_FAILURE: {
      return {
        ...state,
        MytaskGetPickedListLoading: false,
        MytaskGetPickedListStatus: false,
        MytaskGetPickedListError: true,
        message: action.message
      };
    }

    case MY_TASK_BARCODE_REMOVE_SAMPLE: {
      return {
        ...state,
        MytaskRemoveSamplePickupLoading: true,
        MytaskRemoveSamplePickupStatus: false,
        MytaskRemoveSamplePickupError: false,
        MytaskRemoveSamplePickupResponse: "",
      };
    }
    case MY_TASK_BARCODE_REMOVE_SAMPLE_SUCCESS: {
      return {
        ...state,
        MytaskRemoveSamplePickupLoading: false,
        MytaskRemoveSamplePickupStatus: true,
        MytaskRemoveSamplePickupError: false,
        MytaskRemoveSamplePickupResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_BARCODE_REMOVE_SAMPLE_FAILURE: {
      return {
        ...state,
        MytaskRemoveSamplePickupLoading: false,
        MytaskRemoveSamplePickupStatus: false,
        MytaskRemoveSamplePickupError: true,
        message: action.message
      };
    }

    case MY_TASK_UPDATE_PNS_TRF: {
      return {
        ...state,
        MytaskUploadPNSWithTRFLoading: true,
        MytaskUploadPNSWithTRFStatus: false,
        MytaskUploadPNSWithTRFError: false,
        MytaskUploadPNSWithTRFResponse: "",
      };
    }
    case MY_TASK_UPDATE_PNS_TRF_SUCCESS: {
      return {
        ...state,
        MytaskUploadPNSWithTRFLoading: false,
        MytaskUploadPNSWithTRFStatus: true,
        MytaskUploadPNSWithTRFError: false,
        MytaskUploadPNSWithTRFResponse: action.response,
        message: action.message,
        accessToken: action.accessToken,
      };
    }
    case MY_TASK_UPDATE_PNS_TRF_FAILURE: {
      return {
        ...state,
        MytaskUploadPNSWithTRFLoading: false,
        MytaskUploadPNSWithTRFStatus: false,
        MytaskUploadPNSWithTRFError: true,
        message: action.message
      };
    }

    case MY_TASK_UPDATE_CANCEL_REASON: {
      return {
        ...state,
        MytaskUpdateCancelReasonLoading: true,
        MytaskUpdateCancelReasonStatus: false,
        MytaskUpdateCancelReasonError: false,
        MytaskUpdateCancelReasonResponse: "",
      };
    }
    case MY_TASK_UPDATE_CANCEL_REASON_SUCCESS: {
      return {
        ...state,
        MytaskUpdateCancelReasonLoading: false,
        MytaskUpdateCancelReasonStatus: true,
        MytaskUpdateCancelReasonError: false,
        MytaskUpdateCancelReasonResponse: action.response,
        message: action.message,
      };
    }
    case MY_TASK_UPDATE_CANCEL_REASON_FAILURE: {
      return {
        ...state,
        MytaskUpdateCancelReasonLoading: false,
        MytaskUpdateCancelReasonStatus: false,
        MytaskUpdateCancelReasonError: true,
        message: action.message
      };
    }

    case GET_TIEUP_HOSPITAL: {
      return {
        ...state,
      
        MytaskGetTieupHospitalLoading: true,
        MytaskGetTieupHospitalStatus: false,
        MytaskGetTieupHospitalError: false,
        MytaskGetTieupHospitalResponse: "",
      };
    }
    case GET_TIEUP_HOSPITAL_SUCCESS: {
      return {
        ...state,
        MytaskGetTieupHospitalLoading: false,
        MytaskGetTieupHospitalStatus: true,
        MytaskGetTieupHospitalError: false,
        MytaskGetTieupHospitalResponse: action.response,
        message: action.message,
       
      };
    }
    case GET_TIEUP_HOSPITAL_FAILURE: {
      return {
        ...state,
        MytaskGetTieupHospitalLoading: false,
        MytaskGetTieupHospitalStatus: false,
        MytaskGetTieupHospitalError: true,
        message: action.message,
      };
    }

    case GET_TIEUP_HOSPITAL_VISIT_TIME: {
      return {
        ...state,
        MytaskGetTieupHospitalVisitTimeLoading: true,
        MytaskGetTieupHospitalVisitTimeStatus: false,
        MytaskGetTieupHospitalVisitTimeError: false,
        MytaskGetTieupHospitalVisitTimeResponse: "",
      };
    }
    case GET_TIEUP_HOSPITAL_VISIT_TIME_SUCCESS: {
      return {
        ...state,
        MytaskGetTieupHospitalVisitTimeLoading: false,
        MytaskGetTieupHospitalVisitTimeStatus: true,
        MytaskGetTieupHospitalVisitTimeError: false,
        MytaskGetTieupHospitalVisitTimeResponse: action.response,
        message: action.message,
       
      };
    }
    case GET_TIEUP_HOSPITAL_VISIT_TIME_FAILURE: {
      return {
        ...state,
        MytaskGetTieupHospitalVisitTimeLoading: false,
        MytaskGetTieupHospitalVisitTimeStatus: false,
        MytaskGetTieupHospitalVisitTimeError: true,
        message: action.message,
      };
    }
  

    case GET_TIEUP_HOSPITAL_SAMPLE_TYPE: {
      return {
        ...state,
        MytaskGetTieupHospitalSampleTypeLoading: true,
        MytaskGetTieupHospitalSampleTypeStatus: false,
        MytaskGetTieupHospitalSampleTypeError: false,
        MytaskGetTieupHospitalSampleTypeResponse: "",
      };
    }
    case GET_TIEUP_HOSPITAL_SAMPLE_TYPE_SUCCESS: {
      return {
        ...state,
        MytaskGetTieupHospitalSampleTypeLoading: false,
        MytaskGetTieupHospitalSampleTypeStatus: true,
        MytaskGetTieupHospitalSampleTypeError: false,
        MytaskGetTieupHospitalSampleTypeResponse: action.response,
        message: action.message,
      };
    }
    case GET_TIEUP_HOSPITAL_SAMPLE_TYPE_FAILURE: {
      return {
        ...state,
        MytaskGetTieupHospitalSampleTypeLoading: false,
        MytaskGetTieupHospitalSampleTypeStatus: false,
        MytaskGetTieupHospitalSampleTypeError: true,
        message: action.message,
      };
    }
  
    case UPDATE_PARAMEDIC_RESCDULED: {
      return {
        ...state,
        updateParamedicRescduledLoading: true,
        updateParamedicRescduledStatus: false,
        updateParamedicRescduledError: false,
        updateParamedicRescduledResponse: null,
      };
    }
    case UPDATE_PARAMEDIC_RESCDULED_SUCCESS: {
      return {
        ...state,
        updateParamedicRescduledLoading: false,
        updateParamedicRescduledStatus: true,
        updateParamedicRescduledError: false,
        updateParamedicRescduledResponse: action.response,
        message: action.message,

      };
    }
    case UPDATE_PARAMEDIC_RESCDULED_FAILURE: {
      return {
        ...state,
        updateParamedicRescduledLoading: false,
        updateParamedicRescduledStatus: false,
        updateParamedicRescduledError: true,
        message: action.message
      };
    }

    case INSERT_ORDER_DETAILS_REGULAR_BEAT: {
      return {
        ...state,
        MytaskInsertOrderDetailsForRegularBeatLoading: true,
        MytaskInsertOrderDetailsForRegularBeatStatus: false,
        MytaskInsertOrderDetailsForRegularBeatError: false,
        MytaskInsertOrderDetailsForRegularBeatResponse: null,
      };
    }
    case INSERT_ORDER_DETAILS_REGULAR_BEAT_SUCCESS: {
      return {
        ...state,
        MytaskInsertOrderDetailsForRegularBeatLoading: false,
        MytaskInsertOrderDetailsForRegularBeatStatus: true,
        MytaskInsertOrderDetailsForRegularBeatError: false,
        MytaskInsertOrderDetailsForRegularBeatResponse: action.response,
        message: action.message,

      };
    }
    case INSERT_ORDER_DETAILS_REGULAR_BEAT_FAILURE: {
      return {
        ...state,
        MytaskInsertOrderDetailsForRegularBeatLoading: false,
        MytaskInsertOrderDetailsForRegularBeatStatus: false,
        MytaskInsertOrderDetailsForRegularBeatError: true,
        message: action.message
      };
    }

    case GET_PICKED_TEST_LIST_REGULAR_BEAT: {
      return {
        ...state,
        MytaskGetPickedTestListForRegularBeatLoading: true,
        MytaskGetPickedTestListForRegularBeatStatus: false,
        MytaskGetPickedTestListForRegularBeatError: false,
        MytaskGetPickedTestListForRegularBeatResponse: null,
      };
    }
    case GET_PICKED_TEST_LIST_REGULAR_BEAT_SUCCESS: {
      return {
        ...state,
        MytaskGetPickedTestListForRegularBeatLoading: false,
        MytaskGetPickedTestListForRegularBeatStatus: true,
        MytaskGetPickedTestListForRegularBeatError: false,
        MytaskGetPickedTestListForRegularBeatResponse: action.response,
        message: action.message,
      };
    }
    case GET_PICKED_TEST_LIST_REGULAR_BEAT_FAILURE: {
      return {
        ...state,
        MytaskGetPickedTestListForRegularBeatLoading: false,
        MytaskGetPickedTestListForRegularBeatStatus: false,
        MytaskGetPickedTestListForRegularBeatError: true,
        message: action.message
      };
    }

    case INSERT_NO_SAMPLE_REGULAR_BEAT: {
      return {
        ...state,
        MytaskInsertNoSampleForRegularBeatLoading: true,
        MytaskInsertNoSampleForRegularBeatStatus: false,
        MytaskInsertNoSampleForRegularBeatError: false,
        MytaskInsertNoSampleForRegularBeatResponse: null,
      };
    }
    case INSERT_NO_SAMPLE_REGULAR_BEAT_SUCCESS: {
      return {
        ...state,
        MytaskInsertNoSampleForRegularBeatLoading: false,
        MytaskInsertNoSampleForRegularBeatStatus: true,
        MytaskInsertNoSampleForRegularBeatError: false,
        MytaskInsertNoSampleForRegularBeatResponse: action.response,
        message: action.message,
      };
    }
    case INSERT_NO_SAMPLE_REGULAR_BEAT_FAILURE: {
      return {
        ...state,
        MytaskInsertNoSampleForRegularBeatLoading: false,
        MytaskInsertNoSampleForRegularBeatStatus: false,
        MytaskInsertNoSampleForRegularBeatError: true,
        message: action.message
      };
    }

    case GET_ORDERID_CRMID_REGULAR_BEAT: {
      return {
        ...state,
        MytaskGetCRMIdOrderId: action.data,
      };
    }

    case MY_TASK_USER_CANCEL_LIST: {
      return {
        ...state,
        MytaskCancelListLoading: true,
        MytaskCancelListStatus: false,
        MytaskCancelListError: false,
        MytaskCancelListResponse: null,
      };
    }
    case MY_TASK_USER_CANCEL_LIST_SUCCESS: {
      return {
        ...state,
        MytaskCancelListLoading: false,
        MytaskCancelListStatus: true,
        MytaskCancelListError: false,
        MytaskCancelListResponse: action.response,
        message: action.message,
        mytasklistCancelListPending: action.response.Pending,
        mytasklistCancelListCompleted: action.response.Completed,
        mytasklistCancelListCansRes: action.response.CancelReschdule,
      };
    }
    case MY_TASK_USER_CANCEL_LIST_FAILURE: {
      return {
        ...state,
        MytaskCancelListLoading: false,
        MytaskCancelListStatus: false,
        MytaskCancelListError: true,
        message: action.message
      };
    }

    case MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT: {
      return {
        ...state,
        MytaskRemoveSampleRegularBeatLoading: true,
        MytaskRemoveSampleRegularBeatStatus: false,
        MytaskRemoveSampleRegularBeatError: false,
        MytaskRemoveSampleRegularBeatResponse: null,
      };
    }
    case MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_SUCCESS: {
      return {
        ...state,
        MytaskRemoveSampleRegularBeatLoading: false,
        MytaskRemoveSampleRegularBeatStatus: true,
        MytaskRemoveSampleRegularBeatError: false,
        MytaskRemoveSampleRegularBeatResponse: action.response,
        message: action.message,
      };
    }
    case MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_FAILURE: {
      return {
        ...state,
        MytaskRemoveSampleRegularBeatLoading: false,
        MytaskRemoveSampleRegularBeatStatus: false,
        MytaskRemoveSampleRegularBeatError: true,
        message: action.message
      };
    }
   
    default: {
      return state;
    }
  }
}

