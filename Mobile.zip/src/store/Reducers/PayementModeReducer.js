import {
  GET_PAYEMENT_DETAIL_ORDERID,
  GET_PAYEMENT_DETAIL_ORDERID_SUCCESS,
  GET_PAYEMENT_DETAIL_ORDERID_FAILURE,
  GET_PAYEMENT_MODE,
  GET_PAYEMENT_MODE_SUCCESS,
  GET_PAYEMENT_MODE_FAILURE,
  GET_OTP_PAYEMENT_MODE,
  GET_OTP_PAYEMENT_MODE_SUCCESS,
  GET_OTP_PAYEMENT_MODE_FAILURE,
  VERIFY_OTP_PAYEMENT_MODE,
  VERIFY_OTP_PAYEMENT_MODE_SUCCESS,
  VERIFY_OTP_PAYEMENT_MODE_FAILURE,
  INSERT_PAYEMENT_MODE,
  INSERT_PAYEMENT_MODE_SUCCESS,
  INSERT_PAYEMENT_MODE_FAILURE,
  INSERT_PAYEMENT_ONLINE_MODE,
  INSERT_PAYEMENT_ONLINE_MODE_SUCCESS,
  INSERT_PAYEMENT_ONLINE_MODE_FAILURE,
} from '../ActionTypes';
const initState = {
  message: '',
  accessToken: null,

  payementModeDtByIDLoading: false,
  payementModeDtByIDStatus: false,
  payementModeDtByIDError: false,
  payementModeDtByIDResponse: null,

  payementModeLoading: false,
  payementModeStatus: false,
  payementModeError: false,
  payementModeResponse: null,

  payementModeOtpLoading: false,
  payementModeOtpStatus: false,
  payementModeOtpError: false,
  payementModeOtpResponse: null,

  verifypayementModeOtpLoading: false,
  verifypayementModeOtpStatus: false,
  verifypayementModeOtpError: false,
  verifypayementModeOtpResponse: null,

  insertpayementModeLoading: false,
  insertpayementModeStatus: false,
  insertpayementModeError: false,
  insertpayementModeResponse: null,

  insertpayementModeOnlineLoading: false,
  insertpayementModeOnlineStatus: false,
  insertpayementModeOnlineError: false,
  insertpayementModeOnlineResponse: null,

  insertpayementModeResponsePDF : null,

  type: 'P',
  verifyMessage: '',
  verifyaccessToken: null,
};

export default function payementModeReducer(state = initState, action) {
  switch (action.type) {
    case GET_PAYEMENT_DETAIL_ORDERID: {
      return {
        ...state,
        payementModeDtByIDLoading: true,
        payementModeDtByIDStatus: false,
        payementModeDtByIDError: false,
        message: '',
      };
    }
    case GET_PAYEMENT_DETAIL_ORDERID_SUCCESS: {
      console.log("....>", action.response);
      return {
        ...state,
        payementModeDtByIDLoading: false,
        payementModeDtByIDStatus: true,
        payementModeDtByIDError: false,
        message: action.message,
        payementModeDtByIDResponse: action.response,

      };
    }
    case GET_PAYEMENT_DETAIL_ORDERID_FAILURE: {
      return {
        ...state,
        payementModeDtByIDLoading: false,
        payementModeDtByIDStatus: false,
        payementModeDtByIDError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    case GET_PAYEMENT_MODE: {
      return {
        ...state,
        payementModeLoading: true,
        payementModeStatus: false,
        payementModeError: false,
        message: '',
      };
    }
    case GET_PAYEMENT_MODE_SUCCESS: {
      return {
        ...state,
        payementModeLoading: false,
        payementModeStatus: true,
        payementModeError: false,
        message: action.message,
        payementModeResponse: action.response,
        // accessToken: action.accessToken,
        //  accessToken: action.accessToken,
      };
    }
    case GET_PAYEMENT_MODE_FAILURE: {
      return {
        ...state,
        payementModeLoading: false,
        payementModeStatus: false,
        payementModeError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    case GET_OTP_PAYEMENT_MODE: {
      return {
        ...state,
        payementModeOtpLoading: true,
        payementModeOtpStatus: false,
        payementModeOtpError: false,
        message: '',
      };
    }
    case GET_OTP_PAYEMENT_MODE_SUCCESS: {
      return {
        ...state,
        payementModeOtpLoading: false,
        payementModeOtpStatus: true,
        payementModeOtpError: false,
        message: action.message,
        payementModeOtpResponse: action.response,
        // accessToken: action.accessToken,
      };
    }
    case GET_OTP_PAYEMENT_MODE_FAILURE: {
      return {
        ...state,
        payementModeOtpLoading: false,
        payementModeOtpStatus: false,
        payementModeOtpError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }
    //verify password
    case VERIFY_OTP_PAYEMENT_MODE: {
      return {
        ...state,
        verifypayementModeOtpLoading: true,
        verifypayementModeOtpStatus: false,
        verifypayementModeOtpError: false,
        message: '',
      };
    }
    case VERIFY_OTP_PAYEMENT_MODE_SUCCESS: {
      return {
        ...state,
        verifypayementModeOtpLoading: false,
        verifypayementModeOtpStatus: true,
        verifypayementModeOtpError: false,
        message: action.message,
        //  accessToken: action.accessToken,
        verifypayementModeOtpResponse: action.response,
      };
    }
    case VERIFY_OTP_PAYEMENT_MODE_FAILURE: {
      return {
        ...state,
        verifypayementModeOtpLoading: false,
        verifypayementModeOtpStatus: false,
        verifypayementModeOtpError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    case INSERT_PAYEMENT_MODE: {
      return {
        ...state,
        insertpayementModeLoading: true,
        insertpayementModeStatus: false,
        insertpayementModeError: false,
        message: '',
      };
    }
    case INSERT_PAYEMENT_MODE_SUCCESS: {
      return {
        ...state,
        insertpayementModeLoading: false,
        insertpayementModeStatus: true,
        insertpayementModeError: false,
        insertpayementModeResponse: action.response,
        insertpayementModeResponsePDF : action.responsePDF,
        message: action.message,
        //accessToken: action.accessToken,
      };
    }
    case INSERT_PAYEMENT_MODE_FAILURE: {
      return {
        ...state,
        insertpayementModeLoading: false,
        insertpayementModeStatus: false,
        insertpayementModeError: true,
        //  insertpayementModeOnlineResponse: action.response,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    case INSERT_PAYEMENT_ONLINE_MODE: {
      return {
        ...state,
        insertpayementModeOnlineLoading: true,
        insertpayementModeOnlineStatus: false,
        insertpayementModeOnlineError: false,
        message: '',
      };
    }
    case INSERT_PAYEMENT_ONLINE_MODE_SUCCESS: {
      return {
        ...state,
        insertpayementModeOnlineLoading: false,
        insertpayementModeOnlineStatus: true,
        insertpayementModeOnlineError: false,
        message: action.message,
        insertpayementModeOnlineResponse: action.response,
        //accessToken: action.accessToken,
      };
    }
    case INSERT_PAYEMENT_ONLINE_MODE_FAILURE: {
      return {
        ...state,
        insertpayementModeOnlineLoading: false,
        insertpayementModeOnlineStatus: false,
        insertpayementModeOnlineError: true,
        message: action.message,
        // accessToken: 'hsfkksdlfmb',
      };
    }

    default: {
      return state;
    }
  }
}
