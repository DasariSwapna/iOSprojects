import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {Apis} from '../../config/Apis';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {getRequest, postRequest} from '../../services/Requests';

import {
    MY_TASK_UPDATE_BABY_CORD,
    MY_TASK_UPDATE_BABY_CORD_SUCCESS,
    MY_TASK_UPDATE_BABY_CORD_FAILURE,
} from '../ActionTypes';


function* updateBabyCordDetails(action) {
    try {
      let senderIv = yield generateIv();
      let secureData = yield wrapData(action.data, senderIv);
      const response = yield postRequest(
        Apis.updateParamedicCollected,
        secureData,
        senderIv,
        action.token,
      );
       console.log('updated Response: ', response);
  
      const receiverIv = response.headers.clientsecret;
      const responseData = yield unwrapData(
        response.data.responseData,
        receiverIv,
      );
      console.log('response Data:', responseData);
      if (responseData.statusCode == '200') {
        // if (responseData) {
        yield put({
          type: MY_TASK_UPDATE_BABY_CORD_SUCCESS,
          response: responseData,
        });
      } else {
        yield put({
          type: MY_TASK_UPDATE_BABY_CORD_FAILURE,
          message: responseData.message,
        });
      }
    } catch (error) {
      alert(error);
      yield put({
        type: MY_TASK_UPDATE_BABY_CORD_FAILURE,
        message: error,
      });
    }
  }

  export default function* mySaga() {
    yield takeEvery(MY_TASK_UPDATE_BABY_CORD, updateBabyCordDetails);
  }