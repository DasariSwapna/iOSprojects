import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  SHUTTLE_DETAIL_UPDATE,
  SHUTTLE_DETAIL_UPDATE_SUCCESS,
  SHUTTLE_DETAIL_UPDATE_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* shuttleUpdate(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log("action->", action.data);
    const response = yield postRequest(
      Apis.shuttleupate,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response--------------------------',responseData)
    if (responseData.statusCode == 200) {
      yield put({
        type: SHUTTLE_DETAIL_UPDATE_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: SHUTTLE_DETAIL_UPDATE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: SHUTTLE_DETAIL_UPDATE_FAILURE,
      message: error,
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log("response Data:", responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(SHUTTLE_DETAIL_UPDATE, shuttleUpdate);
  yield takeEvery(GET_TOKEN, generateToken);
}
