import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { getRequest, postRequest } from '../../services/Requests';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import {
  GET_PAYEMENT_DETAIL_ORDERID,
  GET_PAYEMENT_DETAIL_ORDERID_SUCCESS,
  GET_PAYEMENT_DETAIL_ORDERID_FAILURE,
  GET_PAYEMENT_MODE,
  GET_PAYEMENT_MODE_SUCCESS,
  GET_PAYEMENT_MODE_FAILURE,
  GET_OTP_PAYEMENT_MODE,
  GET_OTP_PAYEMENT_MODE_SUCCESS,
  GET_OTP_PAYEMENT_MODE_FAILURE,
  VERIFY_OTP_PAYEMENT_MODE,
  VERIFY_OTP_PAYEMENT_MODE_SUCCESS,
  VERIFY_OTP_PAYEMENT_MODE_FAILURE,
  INSERT_PAYEMENT_MODE,
  INSERT_PAYEMENT_MODE_SUCCESS,
  INSERT_PAYEMENT_MODE_FAILURE,
  INSERT_PAYEMENT_ONLINE_MODE,
  INSERT_PAYEMENT_ONLINE_MODE_SUCCESS,
  INSERT_PAYEMENT_ONLINE_MODE_FAILURE,
} from '../ActionTypes';
import { Apis } from '../../config/Apis';

function* getDtByOrderId(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.payementDtbyId,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'response Data Paymnet:------------------->',
      responseData.responseObject.object,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: GET_PAYEMENT_DETAIL_ORDERID_SUCCESS,
        message: responseData.message,
        response: responseData.responseObject.object,
      });
    } else {
      // alert('failure');
      yield put({
        type: GET_PAYEMENT_DETAIL_ORDERID_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    // alert(error);
    yield put({
      type: GET_PAYEMENT_DETAIL_ORDERID_FAILURE,
      message: error,
    });
  }
}

function* getPayementMode(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action);
    const response = yield getRequest(
      Apis.payementMode,
      senderIv,
      action.token,
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:------------------->', responseData);

    if (responseData.statusCode == 200) {
      yield put({
        type: GET_PAYEMENT_MODE_SUCCESS,
        accessToken: responseData,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      // alert('test');
      yield put({
        type: GET_PAYEMENT_MODE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    // alert(error);
    yield put({
      type: GET_PAYEMENT_MODE_FAILURE,
      message: error,
    });
  }
}

function* getOtpPayementMode(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.payementOTP,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Verify OTP ------------------->', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_OTP_PAYEMENT_MODE_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_OTP_PAYEMENT_MODE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    //alert(error);
    yield put({
      type: GET_OTP_PAYEMENT_MODE_FAILURE,
      message: error,
    });
  }
}

function* verifyOtpPayementMode(action) {
  try {
    // alert(1)

    let senderIv = yield generateIv();

    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data, action.token);
    const response = yield postRequest(
      Apis.payementVerifyOTP,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:------------------->', responseData);

    if (responseData.statusCode == 200) {
      // alert('succee')
      yield put({
        type: VERIFY_OTP_PAYEMENT_MODE_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: VERIFY_OTP_PAYEMENT_MODE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    //alert(error);
    yield put({
      type: VERIFY_OTP_PAYEMENT_MODE_FAILURE,
      message: error,
    });
  }
}

function* insertPayementMode(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.payementCash,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: INSERT_PAYEMENT_MODE_SUCCESS,
        response: responseData.responseObject,
        responsePDF: responseData.responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: INSERT_PAYEMENT_MODE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_PAYEMENT_MODE_FAILURE,
      message: error,
    });
  }
}

function* insertPaymentOnline(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.payementOnline,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: INSERT_PAYEMENT_ONLINE_MODE_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: INSERT_PAYEMENT_ONLINE_MODE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_PAYEMENT_ONLINE_MODE_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(GET_PAYEMENT_DETAIL_ORDERID, getDtByOrderId);
  yield takeEvery(GET_PAYEMENT_MODE, getPayementMode);
  yield takeEvery(GET_OTP_PAYEMENT_MODE, getOtpPayementMode);
  yield takeEvery(VERIFY_OTP_PAYEMENT_MODE, verifyOtpPayementMode);
  yield takeEvery(INSERT_PAYEMENT_MODE, insertPayementMode);
  yield takeEvery(INSERT_PAYEMENT_ONLINE_MODE, insertPaymentOnline);
}
