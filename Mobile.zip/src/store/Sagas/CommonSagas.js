import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {Apis} from '../../config/Apis';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {getRequest, postRequest} from '../../services/Requests';
import {getRole} from '../Actions';

import {
  GET_APP_CONFIG,
  GET_APP_CONFIG_SUCCESS,
  GET_APP_CONFIG_FAILURE,
  GET_LABEL,
  GET_LABEL_FAILURE,
  GET_LABEL_SUCCESS,
  GET_LANGUAGE,
  GET_THEME,
  GET_THEME_SUCCESS,
  GET_THEME_FAILURE,
  GET_PAGE_NO,
  GET_PAGE_NO_SUCCESS,
  GET_PAGE_NO_FAILURE,
  GET_LANGUAGE_SUCCESS,
  GET_LANGUAGE_FAILURE,
  GET_IMAGE,
  GET_IMAGE_SUCCESS,
  GET_IMAGE_FAILURE,
  GET_ICON_SUCCESS,
  GET_ICON_FAILURE,
  GET_ROLE,
  GET_ROLE_SUCCESS,
  GET_ROLE_FAILURE,
  GET_CITY,
  GET_CENTER,
  GET_CITY_SUCCESS,
  GET_CITY_FAILURE,
  GET_CENTER_SUCCESS,
  GET_CENTER_FAILURE,
  GET_OTP,
  GET_OTP_SUCCESS,
  GET_OTP_FAILURE,
  GET_STATE,
  GET_STATE_SUCCESS,
  GET_STATE_FAILURE,
  GET_ICON,
  GET_PRODUCT_DETAILS,
  GET_PRODUCT_DETAILS_SUCCESS,
  GET_PRODUCT_DETAILS_FAILURE,
  GET_PRODUCT_LIST_SUCCESS,
  GET_PRODUCT_LIST_FAILURE,
  GET_PRODUCT_LIST,
  GET_ADDRESS_TYPE,
  GET_ADDRESS_TYPE_SUCCESS,
  GET_ADDRESS_TYPE_FAILURE,
  GET_CITY_TYPE_SUCCESS,
  GET_CITY_TYPE_FAILURE,
  GET_HOSPITAL,
  GET_HOSPITAL_SUCCESS,
  GET_HOSPITAL_FAILURE,
  GET_DOCTOR_NAME,
  GET_DOCTOR_NAME_SUCCESS,
  GET_DOCTOR_NAME_FAILURE,
  GET_REFERRED_BY,
  GET_REFERRED_BY_SUCCESS,
  GET_REFERRED_BY_FAILURE,
  GET_PICKUP_TYPE,
  GET_PICKUP_TYPE_SUCCESS,
  GET_PICKUP_TYPE_FAILURE,
  GET_ACCOUNT_TYPE,
  GET_ACCOUNT_TYPE_SUCCESS,
  GET_ACCOUNT_TYPE_FAILURE,
  GET_SPECIALITY,
  GET_SPECIALITY_SUCCESS,
  GET_SPECIALITY_FAILURE,
  INSERT_SIGNATURE,
  INSERT_SIGNATURE_SUCCESS,
  INSERT_SIGNATURE_FAILURE,
  GET_CANCEL_REASON,
  GET_CANCEL_REASON_SUCCESS,
  GET_CANCEL_REASON_FAILURE,
} from '../ActionTypes';

function* getAppConfig(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.appConfig, secureData, senderIv);
    console.log('Appconfig New Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Appconfig response Data:', responseData);

    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_APP_CONFIG_SUCCESS,
        response: responseData,
        response1: responseData[0].lc_V_CUSTOMER_ENROLEMENT_PDF_FORM_PATH,
        //message: responseData.message,
      });
    } else {
      yield put({
        type: GET_APP_CONFIG_FAILURE,
        //message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_APP_CONFIG_FAILURE,
      message: error,
    });
  }
}

function* getLanguage(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.language, secureData, senderIv);
    console.log('Language Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Language response Data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_LANGUAGE_SUCCESS,
        response: responseData.get_LABLE_MASTER,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_LANGUAGE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_LANGUAGE_FAILURE,
      message: error,
    });
  }
}

function* getLableMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.label, secureData, senderIv);
    // console.log('Label Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    // console.log('response Data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_LABEL_SUCCESS,
        response: responseData.get_LABLE_MASTER,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_LABEL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_LABEL_FAILURE,
      message: error,
    });
  }
}

function* getThemeMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.theme, secureData, senderIv);
    // console.log('Theme Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('theme response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_THEME_SUCCESS,
        response: responseData.responseObject,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_THEME_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_THEME_FAILURE,
      message: error,
    });
  }
}

function* getPageMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.pageNo, secureData, senderIv);
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Page response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_PAGE_NO_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_PAGE_NO_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_PAGE_NO_FAILURE,
      message: error,
    });
  }
}

function* getImageMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.image,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Image response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: GET_IMAGE_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_IMAGE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_IMAGE_FAILURE,
      message: error,
    });
  }
}

function* getOTPNumber(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getOTPNumber, secureData, senderIv);
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    console.log(receiverIv);
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == 200) {
      // if (responseData) {
      yield put({
        type: GET_OTP_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_OTP_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_OTP_FAILURE,
      message: error,
    });
  }
}

function* getStateMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getState,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_STATE_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_STATE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_STATE_FAILURE,
      message: error,
    });
  }
}

function* getRoleMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);

    const response = yield postRequest(
      Apis.role,
      secureData,
      senderIv,
      action.token,
    );

    // console.log('Theme Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Rcon response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_ROLE_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_ROLE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_ROLE_FAILURE,
      message: error,
    });
  }
}

function* getCityMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.city, secureData, senderIv);
    // console.log('Theme Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Rcon response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_CITY_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_CITY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_CITY_FAILURE,
      message: error,
    });
  }
}

function* getCenterMaster(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.center,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Center Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Center response Data:', responseData);
    // if (responseData.statusCode == 200) {
    if (responseData) {
      yield put({
        type: GET_CENTER_SUCCESS,
        response: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_CENTER_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_CENTER_FAILURE,
      message: error,
    });
  }
}

function* getHospitalList(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getHospital,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: GET_HOSPITAL_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_HOSPITAL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_HOSPITAL_FAILURE,
      message: error,
    });
  }
}

function* getDoctorNameList(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getDoctor,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    // if (responseData.statusCode == '200') {
    if (responseData) {
      yield put({
        type: GET_DOCTOR_NAME_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_DOCTOR_NAME_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_DOCTOR_NAME_FAILURE,
      message: error,
    });
  }
}

function* getAddressTypeDetails(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getAddressType,
      senderIv,
      action.token,
    );

    console.log('Address Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Address response Data:', responseData);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_ADDRESS_TYPE_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_ADDRESS_TYPE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
  //  alert(error);
    yield put({
      type: GET_ADDRESS_TYPE_FAILURE,
      message: error,
    });
  }
}

function* getReferredBy(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getReferredBy,
      senderIv,
      action.token,
    );

    console.log('Address Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Referredby response Data:', responseData);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_REFERRED_BY_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_REFERRED_BY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_REFERRED_BY_FAILURE,
      message: error,
    });
  }
}

function* getCancelReason(action) {
  console.log('======================================================>');
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getCancelReason,
      senderIv,
      action.token,
    );

    console.log('cancel reason Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Referredby response Data:', responseData);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_CANCEL_REASON_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_CANCEL_REASON_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_CANCEL_REASON_FAILURE,
      message: error,
    });
  }
}

function* getPickupTypeList(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getPickupType,
      senderIv,
      action.token,
    );

    //console.log('PickupType Rew Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('PickupType response Data:', responseData);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_PICKUP_TYPE_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: GET_PICKUP_TYPE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_PICKUP_TYPE_FAILURE,
      message: error,
    });
  }
}

function* getProductsDetails(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.productDetails,
      senderIv,
      action.token,
    );
    // console.log('Theme Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Products response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_PRODUCT_DETAILS_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_PRODUCT_DETAILS_SUCCESS,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCT_DETAILS_FAILURE,
      message: error,
    });
  }
}

function* getProductList(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.productList,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Theme Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Product List response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_PRODUCT_LIST_SUCCESS,
        response: responseData.responseObject,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_PRODUCT_LIST_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_PRODUCT_LIST_FAILURE,
      message: error,
    });
  }
}

function* getAccountType(action) {
  console.log('Account Type ========>', action.token);
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getAccountType,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Account Type Raw Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Account Type Raw Response:', responseData);
    if (responseData.statusCode == 200) {
      // if (responseData) {
      yield put({
        type: GET_ACCOUNT_TYPE_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_ACCOUNT_TYPE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_ACCOUNT_TYPE_FAILURE,
      message: error,
    });
  }
}

function* getSpeciality(action) {
  console.log('speciality ========>', action.token);
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getDoctorSpeciality,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Doctor Speciality Raw Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Doctor Speciality response Data:', responseData);
    if (responseData.statusCode == 200) {
      // if (responseData) {
      yield put({
        type: GET_SPECIALITY_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_SPECIALITY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_SPECIALITY_FAILURE,
      message: error,
    });
  }
}

function* insertSignature(action) {
  console.log('SIGNATURE API CALL ========>', action.token);
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertUpdateTermsConditonSignature,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Insert Signature Raw Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Insert Signature response Data:', responseData);
    if (responseData.statusCode == 200) {
      // if (responseData) {
      yield put({
        type: INSERT_SIGNATURE_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: INSERT_SIGNATURE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_SIGNATURE_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(GET_APP_CONFIG, getAppConfig);
  yield takeEvery(GET_LANGUAGE, getLanguage);
  yield takeEvery(GET_LABEL, getLableMaster);
  yield takeEvery(GET_THEME, getThemeMaster);
  yield takeEvery(GET_PAGE_NO, getPageMaster);
  yield takeEvery(GET_IMAGE, getImageMaster);
  // yield takeEvery(GET_ICON, getIconMaster);
  yield takeEvery(GET_STATE, getStateMaster);
  yield takeEvery(GET_ROLE, getRoleMaster);
  yield takeEvery(GET_CITY, getCityMaster);
  yield takeEvery(GET_CENTER, getCenterMaster);
  yield takeEvery(GET_PRODUCT_DETAILS, getProductsDetails);
  yield takeEvery(GET_PRODUCT_LIST, getProductList);
  yield takeEvery(GET_OTP, getOTPNumber);
  yield takeEvery(GET_ADDRESS_TYPE, getAddressTypeDetails);
  yield takeEvery(GET_REFERRED_BY, getReferredBy);
  yield takeEvery(GET_HOSPITAL, getHospitalList);
  yield takeEvery(GET_PICKUP_TYPE, getPickupTypeList);
  yield takeEvery(GET_DOCTOR_NAME, getDoctorNameList);
  yield takeEvery(GET_ACCOUNT_TYPE, getAccountType);
  yield takeEvery(GET_SPECIALITY, getSpeciality);
  yield takeEvery(INSERT_SIGNATURE, insertSignature);
  yield takeEvery(GET_CANCEL_REASON, getCancelReason);
}
