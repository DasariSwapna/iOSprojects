import { put, take, takeLatest, takeEvery } from "@redux-saga/core/effects";
import { getRequest, postRequest } from "../../services/Requests";
import { generateIv, unwrapData, wrapData } from "../../services/Crypto";
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  DAY_START,
  DAY_START_SUCCESS,
  DAY_START_FAILURE
} from "../ActionTypes";
import { Apis } from "../../config/Apis";

function* dayStart(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.dayStart, secureData, senderIv,action.token);
    console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.status == 200) {
      yield put({
        type: DAY_START_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type : DAY_START_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: DAY_START_FAILURE,
      message: error
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error
    });
  }
}

export default function* mySaga() {
  yield takeEvery(DAY_START, dayStart);
  yield takeEvery(GET_TOKEN, generateToken);
}
