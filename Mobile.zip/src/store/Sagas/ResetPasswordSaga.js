import { put, take, takeLatest, takeEvery } from "@redux-saga/core/effects";
import { getRequest, postRequest } from "../../services/Requests";
import { generateIv, unwrapData, wrapData } from "../../services/Crypto";
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  RESET_PASSWORD,
  RESET_PASSWORD_SUCCESS,
  RESET_PASSWORD_FAILURE
} from "../ActionTypes";
import { Apis } from "../../config/Apis";

function* restPassword(action) {
  try {
    // alert(1)

    let senderIv = yield generateIv();

    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.resetPassword,
      secureData,
      senderIv
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );

    if (responseData.status == 200) {
      yield put({
        type: RESET_PASSWORD,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: RESET_PASSWORD_SUCCESS,
        message: responseData.message
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: RESET_PASSWORD_FAILURE,
      message: error
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );

    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error
    });
  }
}

export default function* mySaga() {
  yield takeEvery(RESET_PASSWORD, restPassword);
  yield takeEvery(GET_TOKEN, generateToken);
}
