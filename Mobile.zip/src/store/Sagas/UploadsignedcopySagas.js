import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { Apis } from '../../config/Apis';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import { getRequest, postRequest } from '../../services/Requests';
import { getRole } from '../Actions';

import {
  GET_UPLOAD_SIGNED_COPY_DETAILS,
  GET_UPLOAD_SIGNED_COPY_DETAILS_SUCCESS,
  GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_SUCCESS,
  GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_FAILURE

} from "../ActionTypes";

function* getuploadSignedcopydetails(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.uploadsignedcopydetails,
      secureData,
      senderIv,
      action.token,
    );

    console.log('Upload signed Response: ', response);


    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Upload signed Response Data:', responseData.responseObject.properties.All);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_UPLOAD_SIGNED_COPY_DETAILS_SUCCESS,
        response: responseData.responseObject.properties,
        responseall: responseData.responseObject.properties.All,
        responseretailtoinvoice: responseData.responseObject.properties.RetailtoInvoice,
        responseMOU: responseData.responseObject.properties.MOU,
      });
    } else {
      yield put({
        type: GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE,
      message: error,
    });
  }
}

function* getuploadSignedpdfcopydetails(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.uploadsignedcopypdfdetails,
      secureData,
      senderIv,
      action.token,
    );

    console.log('Upload signed Response: ', response);
    
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('upload signed PDF upload Response Data:', responseData);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_SUCCESS,
        response: responseData,
        message:responseData.message
       
      });
    } else {
      yield put({
        type: GET_UPLOAD_SIGNED_COPY_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD_FAILURE,
      message: error,
    });
  }
}



export default function* mySaga() {
  yield takeEvery(GET_UPLOAD_SIGNED_COPY_DETAILS, getuploadSignedcopydetails);
  yield takeEvery(GET_UPLOAD_SIGNED_COPY_PDF_UPLOAD, getuploadSignedpdfcopydetails);





}