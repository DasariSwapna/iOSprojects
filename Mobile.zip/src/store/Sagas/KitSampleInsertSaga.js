import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { getRequest, postRequest } from '../../services/Requests';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import {
    GET_TOKEN,
    GET_TOKEN_FAILURE,
    GET_TOKEN_SUCCESS,
    KITSAMPLE_HANDOVER_INSERT,
    KITSAMPLE_HANDOVER_INSERT_SUCCESS,
    KITSAMPLE_HANDOVER_INSERT_FAILURE,
} from '../ActionTypes';
import { Apis } from '../../config/Apis';

function* getKitsampleHanoverInsert(action) {
    try {
        let senderIv = yield generateIv();
        console.log('insertsaga->',action.data)
        let secureData = yield wrapData(action.data, senderIv);
        const response = yield postRequest(
            Apis.kitInsert,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log('kitsamplehandoverinsert', responseData);
        if (responseData.statusCode == 200) {
            yield put({
                type: KITSAMPLE_HANDOVER_INSERT_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: KITSAMPLE_HANDOVER_INSERT_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: KITSAMPLE_HANDOVER_INSERT_FAILURE,
            message: error,
        });
    }
}


function* generateToken(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        const response = yield postRequest(Apis.getToken, secureData, senderIv);

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );

        if (responseData.status == 200) {
            yield put({
                type: GET_TOKEN_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
            });
        } else {
            yield put({
                type: GET_TOKEN_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        yield put({
            type: GET_TOKEN_FAILURE,
            message: error,
        });
    }
}

export default function* mySaga() {
    yield takeEvery(KITSAMPLE_HANDOVER_INSERT, getKitsampleHanoverInsert);
    yield takeEvery(GET_TOKEN, generateToken);
}
