import { put, take, takeLatest, takeEvery } from "@redux-saga/core/effects";
import { getRequest, postRequest } from "../../services/Requests";
import { generateIv, unwrapData, wrapData } from "../../services/Crypto";
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,

  MY_TASK_TYPE_LIST_DATAS,
  MY_TASK_TYPE_LIST_SUCCESS,
  MY_TASK_TYPE_LIST_FAILURE,

  MY_TASK_TYPE_LIST_DATAS_DETAILS,
  MY_TASK_TYPE_LIST_DETAILS_SUCCESS,
  MY_TASK_TYPE_LIST_DETAILS_FAILURE,

  MY_TASK_USER_CANCEL_LIST,
  MY_TASK_USER_CANCEL_LIST_SUCCESS,
  MY_TASK_USER_CANCEL_LIST_FAILURE,

  MY_TASK_PICKUP_START,
  MY_TASK_PICKUP_START_SUCCESS,
  MY_TASK_PICKUP_START_FAILURE,

  MY_TASK_BABY_CORD_DETAILS_CRMID,
  MY_TASK_BABY_CORD_DETAILS_CRMID_SUCCESS,
  MY_TASK_BABY_CORD_DETAILS_CRMID_FAILURE,

  MY_TASK_PARAMEDIC_REACHED,
  MY_TASK_PARAMEDIC_REACHED_SUCCESS,
  MY_TASK_PARAMEDIC_REACHED_FAILURE,

  MY_TASK_BARCODE_SELECT_TEST,
  MY_TASK_BARCODE_SELECT_TEST_SUCCESS,
  MY_TASK_BARCODE_SELECT_TEST_FAILURE,

  MY_TASK_UPDATE_BARCODE_TEST_PICKUP,
  MY_TASK_UPDATE_BARCODE_TEST_PICKUP_SUCCESS,
  MY_TASK_UPDATE_BARCODE_TEST_PICKUP_FAILURE,

  MY_TASK_GET_PICKED_TEST_LIST,
  MY_TASK_GET_PICKED_TEST_LIST_SUCCESS,
  MY_TASK_GET_PICKED_TEST_LIST_FAILURE,

  MY_TASK_BARCODE_REMOVE_SAMPLE,
  MY_TASK_BARCODE_REMOVE_SAMPLE_SUCCESS,
  MY_TASK_BARCODE_REMOVE_SAMPLE_FAILURE,

  MY_TASK_UPDATE_PNS_TRF,
  MY_TASK_UPDATE_PNS_TRF_SUCCESS,
  MY_TASK_UPDATE_PNS_TRF_FAILURE,

  MY_TASK_UPDATE_CANCEL_REASON,
  MY_TASK_UPDATE_CANCEL_REASON_SUCCESS,
  MY_TASK_UPDATE_CANCEL_REASON_FAILURE,

  GET_TIEUP_HOSPITAL,
  GET_TIEUP_HOSPITAL_SUCCESS,
  GET_TIEUP_HOSPITAL_FAILURE,

  GET_TIEUP_HOSPITAL_VISIT_TIME,
  GET_TIEUP_HOSPITAL_VISIT_TIME_SUCCESS,
  GET_TIEUP_HOSPITAL_VISIT_TIME_FAILURE,

  GET_TIEUP_HOSPITAL_SAMPLE_TYPE,
  GET_TIEUP_HOSPITAL_SAMPLE_TYPE_SUCCESS,
  GET_TIEUP_HOSPITAL_SAMPLE_TYPE_FAILURE,

  UPDATE_PARAMEDIC_RESCDULED,
  UPDATE_PARAMEDIC_RESCDULED_SUCCESS,
  UPDATE_PARAMEDIC_RESCDULED_FAILURE,

  INSERT_ORDER_DETAILS_REGULAR_BEAT,
  INSERT_ORDER_DETAILS_REGULAR_BEAT_SUCCESS,
  INSERT_ORDER_DETAILS_REGULAR_BEAT_FAILURE,

  GET_PICKED_TEST_LIST_REGULAR_BEAT,
  GET_PICKED_TEST_LIST_REGULAR_BEAT_SUCCESS,
  GET_PICKED_TEST_LIST_REGULAR_BEAT_FAILURE,

  INSERT_NO_SAMPLE_REGULAR_BEAT,
  INSERT_NO_SAMPLE_REGULAR_BEAT_SUCCESS,
  INSERT_NO_SAMPLE_REGULAR_BEAT_FAILURE,

  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT,
  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_SUCCESS,
  MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_FAILURE,

} from "../ActionTypes";
import { Apis } from "../../config/Apis";

function* getMyTasklistDatas(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log("action->", action.data);
    const response = yield postRequest(
      Apis.getMyTaskListDatas,
      secureData,
      senderIv,
      action.token
    );
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data My Task:-------------------1>", responseData);
    //alert('2222--->',responseData)
    if (responseData.statusCode == 200) {
      console.log("new values223", responseData.respList)
      yield put({
        type: MY_TASK_TYPE_LIST_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList
      });
    } else {
      yield put({
        type: MY_TASK_TYPE_LIST_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
  //  alert(error);
    yield put({
      type: MY_TASK_TYPE_LIST_FAILURE,
      message: error
    });
  }
}

function* getMyTasklistdetailsDatas(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log("action->", action.data);
    const response = yield postRequest(
      Apis.getMyTaskListdetailsDatas,
      secureData,
      senderIv,
      action.token
    );
    

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data My Task:-------------------1>", responseData);
    // alert('2222--->',responseData)
    if (responseData.statusCode == 200) {
      console.log("new valuesdetails", responseData.responseObject)
      yield put({
        type: MY_TASK_TYPE_LIST_DETAILS_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject
      });
    } else {
      yield put({
        type: MY_TASK_TYPE_LIST_DETAILS_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    //alert(error);
    yield put({
      type: MY_TASK_TYPE_LIST_DETAILS_FAILURE,
      message: error
    });
  }
}

function* getMyTaskCancelList(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log("action->", action.data);
    const response = yield postRequest(
      Apis.getParamedicUserTaskCancelDetail,
      secureData,
      senderIv,
      action.token
    );
   

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data My Task:-------------------1>", responseData);
    // alert('2222--->',responseData)
    if (responseData.statusCode == 200) {
      console.log("new valuesdetails", responseData.responseObject)
      yield put({
        type: MY_TASK_USER_CANCEL_LIST_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject.properties
      });
    } else {
      yield put({
        type: MY_TASK_USER_CANCEL_LIST_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: MY_TASK_USER_CANCEL_LIST_FAILURE,
      message: error
    });
  }
}




function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error
    });
  }
}

function* mytaskPickupStart(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.updateParamedicStart, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_PICKUP_START_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.message
      });
    } else {
      yield put({
        type: MY_TASK_PICKUP_START_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_PICKUP_START_FAILURE,
      message: error
    });
  }
}

function* mytaskBabyCordDetailsCrmid(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getUserTaskProductCRMIDDetail, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_BABY_CORD_DETAILS_CRMID_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject.properties
      });
    } else {
      yield put({
        type: MY_TASK_BABY_CORD_DETAILS_CRMID_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_BABY_CORD_DETAILS_CRMID_FAILURE,
      message: error
    });
  }
}

function* mytaskParamedicReached(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.updateParamedicReached, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_PARAMEDIC_REACHED_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.response
      });
    } else {
      yield put({
        type: MY_TASK_PARAMEDIC_REACHED_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_PARAMEDIC_REACHED_FAILURE,
      message: error
    });
  }
}

function* mytaskBarcodeSelectTest(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getSelectTestForBarcode, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_BARCODE_SELECT_TEST_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList
      });
    } else {
      yield put({
        type: MY_TASK_BARCODE_SELECT_TEST_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_BARCODE_SELECT_TEST_FAILURE,
      message: error
    });
  }
}

function* mytaskUpdateBarcodeTestPickup(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.updateBarcodeTestPickup, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_UPDATE_BARCODE_TEST_PICKUP_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData
      });
    } else {
      yield put({
        type: MY_TASK_UPDATE_BARCODE_TEST_PICKUP_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_UPDATE_BARCODE_TEST_PICKUP_FAILURE,
      message: error
    });
  }
}

function* mytaskGetPickedTestList(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getPickedTestList, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_GET_PICKED_TEST_LIST_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject.properties
      });
    } else {
      yield put({
        type: MY_TASK_GET_PICKED_TEST_LIST_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_GET_PICKED_TEST_LIST_FAILURE,
      message: error
    });
  }
}

function* mytaskBarcodeRemoveSample(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.removeSamplePickup, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_BARCODE_REMOVE_SAMPLE_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData
      });
    } else {
      yield put({
        type: MY_TASK_BARCODE_REMOVE_SAMPLE_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_BARCODE_REMOVE_SAMPLE_FAILURE,
      message: error
    });
  }
}

function* updatePNSWithTRFDetails(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updateSamplePickupwithTRF,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: MY_TASK_UPDATE_PNS_TRF_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: MY_TASK_UPDATE_PNS_TRF_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: MY_TASK_UPDATE_PNS_TRF_FAILURE,
      message: error,
    });
  }
}

function* updateCancelReason(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updateParamedicCancelled,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: MY_TASK_UPDATE_CANCEL_REASON_SUCCESS,
        response: responseData,
      });
    } else {
      yield put({
        type: MY_TASK_UPDATE_CANCEL_REASON_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: MY_TASK_UPDATE_CANCEL_REASON_FAILURE,
      message: error,
    });
  }
}

function* getTieupHospital(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getTieupHospital,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response:', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: GET_TIEUP_HOSPITAL_SUCCESS,
        response: responseData.responseObject.properties.TIE_UP_HOSPITAL_RESPONSE,
      });
    } else {
      yield put({
        type: GET_TIEUP_HOSPITAL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
  //  alert(error);
    yield put({
      type: GET_TIEUP_HOSPITAL_FAILURE,
      message: error,
    });
  }
}


function* getTieupHospitalVisitTime(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getVisitTimeForRegularBeat,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response:', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: GET_TIEUP_HOSPITAL_VISIT_TIME_SUCCESS,
        response: responseData.responseObject.properties.TIE_UP_HOSPITAL_VISIT_TIME_RESPONSE,
      });
    } else {
      yield put({
        type: GET_TIEUP_HOSPITAL_VISIT_TIME_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: GET_TIEUP_HOSPITAL_VISIT_TIME_FAILURE,
      message: error,
    });
  }
}

function* getTieupHospitalSampleType(action) {
  console.log('Account Type ========>', action.token);
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getSampleTypeForRegularBeat,
      senderIv,
      action.token,
    );
    console.log('Account Type Raw Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Account Type Raw Response:', responseData);
    if (responseData.statusCode == 200) {
      // if (responseData) {
      yield put({
        type: GET_TIEUP_HOSPITAL_SAMPLE_TYPE_SUCCESS,
        response: responseData.responseObject.properties.SAMPLE_TYPE_RESPONSE,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_TIEUP_HOSPITAL_SAMPLE_TYPE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TIEUP_HOSPITAL_SAMPLE_TYPE_FAILURE,
      message: error,
    });
  }
}

function* updateParamedicRescduled(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updateParamedicRescduled,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updateParamedicRescduled : ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('updateParamedicRescduled :', responseData);
    if (responseData.status == '200') {
      // if (responseData) {
      yield put({
        type: UPDATE_PARAMEDIC_RESCDULED_SUCCESS,
        response: responseData,
      });
    } else {

      yield put({
        type: UPDATE_PARAMEDIC_RESCDULED_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
  //  alert(error);
    yield put({
      type: UPDATE_PARAMEDIC_RESCDULED_FAILURE,
      message: error,
    });
  }
}
function* getPickedTestListForRegularBeat(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getPickedTestListRegularVisit,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response:', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: GET_PICKED_TEST_LIST_REGULAR_BEAT_SUCCESS,
        response: responseData.responseObject.properties
      });
    } else {
      yield put({
        type: GET_PICKED_TEST_LIST_REGULAR_BEAT_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
  //  alert(error);
   // alert(error);
    yield put({
      type: GET_PICKED_TEST_LIST_REGULAR_BEAT_FAILURE,
      message: error,
    });
  }
}

function* getInsertOrderDetailsForRegularBeat(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertOrderDetailsRegularVisit,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response:', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: INSERT_ORDER_DETAILS_REGULAR_BEAT_SUCCESS,
        response: responseData.responseObject.properties
      });
    } else {
      yield put({
        type: INSERT_ORDER_DETAILS_REGULAR_BEAT_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    //alert(error);
   // alert(error);
    yield put({
      type: INSERT_ORDER_DETAILS_REGULAR_BEAT_FAILURE,
      message: error,
    });
  }
}

function* getInsertNoSampleForRegularBeat(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertNoSampleRegularVisit,
      secureData,
      senderIv,
      action.token,
    );
    console.log('updated Response:', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.statusCode == '200') {
      // if (responseData) {
      yield put({
        type: INSERT_NO_SAMPLE_REGULAR_BEAT_SUCCESS,
        response: responseData.responseObject.properties.NO_SAMPLES_RESPONSE
      });
    } else {
      yield put({
        type: INSERT_NO_SAMPLE_REGULAR_BEAT_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
  //  alert(error);
   // alert(error);
    yield put({
      type: INSERT_NO_SAMPLE_REGULAR_BEAT_FAILURE,
      message: error,
    });
  }
}

function* mytaskBarcodeRemoveSampleRegularBeat(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.removeRegularBeatSample, secureData, senderIv, action.token);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log("response Data:", responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData
      });
    } else {
      yield put({
        type: MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT_FAILURE,
      message: error
    });
  }
}



export default function* mySaga() {
  yield takeEvery(MY_TASK_TYPE_LIST_DATAS, getMyTasklistDatas);
  yield takeEvery(MY_TASK_TYPE_LIST_DATAS_DETAILS, getMyTasklistdetailsDatas);
  yield takeEvery(MY_TASK_USER_CANCEL_LIST, getMyTaskCancelList);
  yield takeEvery(GET_TOKEN, generateToken);
  yield takeEvery(MY_TASK_PICKUP_START, mytaskPickupStart);
  yield takeEvery(MY_TASK_BABY_CORD_DETAILS_CRMID, mytaskBabyCordDetailsCrmid);
  yield takeEvery(MY_TASK_PARAMEDIC_REACHED, mytaskParamedicReached);
  yield takeEvery(MY_TASK_BARCODE_SELECT_TEST, mytaskBarcodeSelectTest);
  yield takeEvery(MY_TASK_UPDATE_BARCODE_TEST_PICKUP, mytaskUpdateBarcodeTestPickup);
  yield takeEvery(MY_TASK_GET_PICKED_TEST_LIST, mytaskGetPickedTestList);
  yield takeEvery(MY_TASK_BARCODE_REMOVE_SAMPLE, mytaskBarcodeRemoveSample);
  yield takeEvery(MY_TASK_UPDATE_PNS_TRF, updatePNSWithTRFDetails);
  yield takeEvery(MY_TASK_UPDATE_CANCEL_REASON, updateCancelReason);
  yield takeEvery(GET_TIEUP_HOSPITAL, getTieupHospital);
  yield takeEvery(GET_TIEUP_HOSPITAL_VISIT_TIME, getTieupHospitalVisitTime);
  yield takeEvery(GET_TIEUP_HOSPITAL_SAMPLE_TYPE, getTieupHospitalSampleType);
  yield takeEvery(UPDATE_PARAMEDIC_RESCDULED, updateParamedicRescduled);
  yield takeEvery(GET_PICKED_TEST_LIST_REGULAR_BEAT, getPickedTestListForRegularBeat);
  yield takeEvery(INSERT_ORDER_DETAILS_REGULAR_BEAT, getInsertOrderDetailsForRegularBeat);
  yield takeEvery(INSERT_NO_SAMPLE_REGULAR_BEAT, getInsertNoSampleForRegularBeat);
  yield takeEvery(MY_TASK_BARCODE_REMOVE_SAMPLE_REGULAR_BEAT, mytaskBarcodeRemoveSampleRegularBeat);
}
