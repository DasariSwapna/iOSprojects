import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  LOGIN_WITH_OTP,
  LOGIN_WITH_OTP_SUCCESS,
  LOGIN_WITH_OTP_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* userLoginWithOtp(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.signIn, secureData, senderIv);
    console.log('Headers: ', response.headers.clientsecret);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    const res = responseData.responseObject.object;
    if (res.status == 200) {
      yield put({
        type: LOGIN_WITH_OTP_SUCCESS,
        roles: res.roles,
        userId: res.Technician_Id,
        username: res.Technician_Name,
        dayStartStatus: res.TECHNICIAN_STARTED,
        activationStatus: res.verified,
        accessToken: res.Token,
        message: res.message,
        firstName: res.LC_MU_USER_FIRST_NAME,
        lastName: res.LC_MU_USER_LAST_NAME,
        mobileNo: res.LC_MU_USER_PHONENO,
        email: res.LC_MU_USER_EMAILID,
      });
    } else {
      yield put({
        type: LOGIN_WITH_OTP_FAILURE,
        message: res.message,
      });
    }
  } catch (error) {
    yield put({
      type: LOGIN_WITH_OTP_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(LOGIN_WITH_OTP, userLoginWithOtp);
}
