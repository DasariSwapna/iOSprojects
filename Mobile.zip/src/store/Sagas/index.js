import {fork} from '@redux-saga/core/effects';
import signIn from './SignInSagas';
import commonSaga from './CommonSagas';
import forgetPasswordSaga from './ForgetPasswordSaga';
import kitsampleHandoverBiodataSaga from './kitsampleHandoverBiodataSaga';
import resetpasswordSaga from './ResetPasswordSaga';
import signUpSaga from './SignUpSages';
import dayStartSaga from './DaystartSaga';
import kitsampleBioDiaHandoverSelectlistSaga from './kitsampleBioDiaHandoverSelectListSaga';
import shuttledetailupdateSaga from './shuttledetailupdateSaga';
import createOrderSaga from './CreateOrderSagas';
import MyTaskSagas from './MyTaskSagas';
import ManagerSagas from './ManagerSagas';
import UploadsignedCopy from './UploadsignedcopySagas';

import SalesMangerTestApprovalSagas from './SalesMangerTestApprovalSagas';
import UpdateBabyCordDetailsSagas from './UpdateBabyCordDetailsSagas';
import createVendorSagas from './CreateVendorSagas';
import PayementModeSagas from './PayementModeSaga';
import CreateTaskSagas from './CreateTaskSaga';
import CourierSaga from './KitsampleCourierSaga';
import KitsampleInsertSaga from './KitSampleInsertSaga';
import CashDebositSalesSaga from './CashDebositSalesSaga';
import DepositCashParamSaga from './DepositCashParamsSaga';

export default function* rootSaga() {
  yield fork(signIn);
  yield fork(commonSaga);
  yield fork(forgetPasswordSaga);
  yield fork(kitsampleHandoverBiodataSaga);
  yield fork(resetpasswordSaga);
  yield fork(signUpSaga);
  yield fork(dayStartSaga);
  yield fork(kitsampleBioDiaHandoverSelectlistSaga);
  yield fork(shuttledetailupdateSaga);
  yield fork(createOrderSaga);
  yield fork(MyTaskSagas);
  yield fork(ManagerSagas);
  yield fork(UploadsignedCopy);
  yield fork(CreateTaskSagas);
  yield fork(PayementModeSagas);
  yield fork(SalesMangerTestApprovalSagas);
  yield fork(UpdateBabyCordDetailsSagas);
  yield fork(createVendorSagas);
  yield fork(CourierSaga);
  yield fork(KitsampleInsertSaga);
  yield fork(CashDebositSalesSaga);
  yield fork(DepositCashParamSaga);
}
