import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { getRequest, postRequest } from '../../services/Requests';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import {
  INSERT_ORDER,
  INSERT_ORDER_SUCCESS,
  INSERT_ORDER_FAILURE,
  USER_AVAILABILITY,
  USER_AVAILABILITY_SUCCESS,
  USER_AVAILABILITY_FAILURE,
  PRODUCT_HOSPITAl_SUCCESS,
  PRODUCT_HOSPITAl_FAILURE,
  PRODUCT_HOSPITAl,
  TEST_HOSPITAL,
  TEST_HOSPITAL_SUCCESS,
  TEST_HOSPITAL_FAILURE,
  GET_PATIENT_DETAILS,
  GET_PATIENT_DETAILS_SUCCESS,
  GET_PATIENT_DETAILS_FAILURE,
} from '../ActionTypes';
import { Apis } from '../../config/Apis';

function* insertOrder(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertOrder,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('INSERT ORDER response data:', responseData);
    if (responseData.statusCode == 200) {
      if (responseData.responseObject.orderDetailsResModel.statusCode == 200) {
        yield put({
          type: INSERT_ORDER_SUCCESS,
          response: responseData.responseObject,
          responsePDF: responseData.responseData,
          //insertOrderStatusCode:responseData
          message: responseData.message,
          pageno:action.pageno
        });
      }
      else {
        yield put({
          type: INSERT_ORDER_FAILURE,
          response: responseData.responseObject,
          message: responseData.message,
        });
      }
    } else {
      yield put({
        type: INSERT_ORDER_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_ORDER_FAILURE,
      message: error,
    });
  }
}

function* userAvailability(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getparamedicuseravailability,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('User Availability response data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: USER_AVAILABILITY_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: USER_AVAILABILITY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: USER_AVAILABILITY_FAILURE,
      message: error,
    });
  }
}

function* productHospital(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getProductDetailsforHospital,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Product Hospital response data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: PRODUCT_HOSPITAl_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: PRODUCT_HOSPITAl_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: PRODUCT_HOSPITAl_FAILURE,
      message: error,
    });
  }
}

function* testHospital(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.gettesandproductforhospital,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Test Hospital response data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: TEST_HOSPITAL_SUCCESS,
        response: responseData.respList,
        message: responseData.message,
      });
    } else {
      yield put({
        type: TEST_HOSPITAL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: TEST_HOSPITAL_FAILURE,
      message: error,
    });
  }
}


function* getPatientDetails(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getPatientDetails,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Patient Detail response data:', responseData);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_PATIENT_DETAILS_SUCCESS,
        response: responseData.responseObject.properties.PatientDetailsResponse,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_PATIENT_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_PATIENT_DETAILS_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(INSERT_ORDER, insertOrder);
  yield takeEvery(USER_AVAILABILITY, userAvailability);
  yield takeEvery(PRODUCT_HOSPITAl, productHospital);
  yield takeEvery(TEST_HOSPITAL, testHospital);
  yield takeEvery(GET_PATIENT_DETAILS, getPatientDetails);
}
