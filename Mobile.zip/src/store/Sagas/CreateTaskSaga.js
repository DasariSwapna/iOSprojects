import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  CREATE_TASK,
  CREATE_TASK_SUCCESS,
  CREATE_TASK_FAILURE,
  GET_TASK_CATEGORY,
  GET_TASK_CATEGORY_SUCCESS,
  GET_TASK_CATEGORY_FAILURE,
  GET_TASK,
  GET_TASK_SUCCESS,
  GET_TASK_FAILURE,
  GET_CRM_INFO,
  GET_CRM_INFO_SUCCESS,
  GET_CRM_INFO_FAILURE,
  UPDATE_TASK,
  UPDATE_TASK_SUCCESS,
  UPDATE_TASK_FAILURE,
  GET_TASK_TIME,
  GET_TASK_TIME_SUCCESS,
  GET_TASK_TIME_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* createTask(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.dayStart,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('createtask', responseData);
    if (responseData.status == 200) {
      yield put({
        type: CREATE_TASK_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: CREATE_TASK_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: CREATE_TASK_FAILURE,
      message: error,
    });
  }
}

function* getTskCategory(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getTaskCategory,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('getcategory', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_TASK_CATEGORY_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: GET_TASK_CATEGORY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TASK_CATEGORY_FAILURE,
      message: error,
    });
  }
}

function* getTsk(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getTask,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('getTsk', responseData);

    if (responseData.statusCode == 200) {
      yield put({
        type: GET_TASK_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: GET_TASK_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TASK_FAILURE,
      message: error,
    });
  }
}

function* getCRMInfo(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getCRMInfo,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('getCRM', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_CRM_INFO_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: GET_CRM_INFO_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_CRM_INFO_FAILURE,
      message: error,
    });
  }
}

function* updateCRM(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updatetask,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('updatecrm', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: UPDATE_TASK_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: UPDATE_TASK_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: UPDATE_TASK_FAILURE,
      message: error,
    });
  }
}

function* getTaskTime(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getTaskTime,
      secureData,
      senderIv,
      action.token,
    );
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('tasktime', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_TASK_TIME_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: GET_TASK_TIME_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TASK_TIME_FAILURE,
      message: error,
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(CREATE_TASK, createTask);
  yield takeEvery(GET_TASK_CATEGORY, getTskCategory);
  yield takeEvery(GET_TOKEN, generateToken);
  yield takeEvery(GET_TASK, getTsk);
  yield takeEvery(GET_CRM_INFO, getCRMInfo);
  yield takeEvery(UPDATE_TASK, updateCRM);
  yield takeEvery(GET_TASK_TIME, getTaskTime);
}
