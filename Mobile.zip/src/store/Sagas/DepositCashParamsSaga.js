import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { getRequest, postRequest } from '../../services/Requests';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import {
    GET_TOKEN,
    GET_TOKEN_FAILURE,
    GET_TOKEN_SUCCESS,
    DEPOSIT_CASH,
    DEPOSIT_CASH_FAILURE,
    DEPOSIT_CASH_SUCCESS,
    DEPOSIT_CASH_BANK,
    DEPOSIT_CASH_BANK_SUCCESS,
    DEPOSIT_CASH_BANK_FAILURE,
    DEPOSIT_CASH_BRANCH,
    DEPOSIT_CASH_BRANCH_SUCCESS,
    DEPOSIT_CASH_BRANCH_FAILURE,
    DEPOSIT_CASH_TIME,
    DEPOSIT_CASH_TIME_SUCCESS,
    DEPOSIT_CASH_TIME_FAILURE,
    UPDATE_DEPOSIT_CASH,
    UPDATE_DEPOSIT_CASH_SUCCESS,
    UPDATE_DEPOSIT_CASH_FAILURE
} from '../ActionTypes';
import { Apis } from '../../config/Apis';

function* getDepositCash(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        console.log("action->", action.data);
        const response = yield postRequest(
            Apis.cashDepositList,
            secureData,
            senderIv,
            action.token,
        );
        // console.log("header", response.headers);
        // console.log("Headers: ", response.headers.clientsecret);
        // console.log('Response: ', response.data);
        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log('deposit->', responseData);
        if (responseData.statusCode == 200) {
            yield put({
                type: DEPOSIT_CASH_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: DEPOSIT_CASH_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: DEPOSIT_CASH_FAILURE,
            message: error,
        });
    }
}

// bank
function* getBank(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        //need to change KITSAMPLE HANDOVER MODE API
        const response = yield postRequest(
            Apis.cashDepositBank,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log('Lab mode--->', responseData);
        if (responseData.statusCode == 200) {
            yield put({
                type: DEPOSIT_CASH_BANK_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: DEPOSIT_CASH_BANK_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: DEPOSIT_CASH_BANK_FAILURE,
            message: error,
        });
    }
}

// Bank branch
function* getBranch(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        //need to change KITSAMPLE HANDOVER MODE API
        const response = yield postRequest(
            Apis.cashDepositBranch,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log('Handover center------------------------->>>', responseData);
        if (responseData.statusCode == 200) {
            yield put({
                type: DEPOSIT_CASH_BRANCH_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: DEPOSIT_CASH_BRANCH_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: DEPOSIT_CASH_BRANCH_FAILURE,
            message: error,
        });
    }
}

//time
function* getTime(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        //need to change KITSAMPLE HANDOVER MODE API
        const response = yield postRequest(
            Apis.cashDepositTime,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        // console.log(', responseData);
        // alert(JSON.stringify(responseData))
        if (responseData.statusCode == 200) {
            yield put({
                type: DEPOSIT_CASH_TIME_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: DEPOSIT_CASH_TIME_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: DEPOSIT_CASH_TIME_FAILURE,
            message: error,
        });
    }
}


function* updatecashDeposit(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        //need to change KITSAMPLE HANDOVER MODE API
        const response = yield postRequest(
            Apis.updateCashDeposit,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        // console.log(', responseData);
        // alert(JSON.stringify(responseData))
        if (responseData.statusCode == 200) {
            yield put({
                type: UPDATE_DEPOSIT_CASH_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.responseObject,
            });
        } else {
            yield put({
                type: UPDATE_DEPOSIT_CASH_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: UPDATE_DEPOSIT_CASH_FAILURE,
            message: error,
        });
    }
}


function* generateToken(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        const response = yield postRequest(Apis.getToken, secureData, senderIv);
        // console.log('Headers: ', response.headers.clientsecret);
        // console.log('Response: ', response.data);
        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log("response Data:", responseData);
        if (responseData.status == 200) {
            yield put({
                type: GET_TOKEN_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
            });
        } else {
            yield put({
                type: GET_TOKEN_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        yield put({
            type: GET_TOKEN_FAILURE,
            message: error,
        });
    }
}

export default function* mySaga() {
    yield takeEvery(DEPOSIT_CASH, getDepositCash);
    yield takeEvery(DEPOSIT_CASH_BANK, getBank)
    yield takeEvery(DEPOSIT_CASH_BRANCH, getBranch)
    yield takeEvery(DEPOSIT_CASH_TIME, getTime);
    yield takeEvery(UPDATE_DEPOSIT_CASH, updatecashDeposit)
    yield takeEvery(GET_TOKEN, generateToken);
}
