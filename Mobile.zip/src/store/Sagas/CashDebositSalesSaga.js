import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  CASH_DEPOSIT_SALES_HANDOVER_MONEY,
  CASH_DEPOSIT_SALES_HANDOVER_MONEY_SUCCESS,
  CASH_DEPOSIT_SALES_HANDOVER_MONEY_FAILURE,
  CASH_DEPOSIT_SALES_UPDATE,
  CASH_DEPOSIT_SALES_UPDATE_SUCCESS,
  CASH_DEPOSIT_SALES_UPDATE_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';
getCashFromParamedic,
updateCashFromParamedic

function* getCashFromParamedic(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.cashHandoverSales,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response--------------------------', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: CASH_DEPOSIT_SALES_HANDOVER_MONEY_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject.properties.CASH_TASK_LIST_RESPONSE
      });
    } else {
      yield put({
        type: CASH_DEPOSIT_SALES_HANDOVER_MONEY_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: CASH_DEPOSIT_SALES_HANDOVER_MONEY_FAILURE,
      message: error,
    });
  }
}
function* updateCashFromParamedic(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.cashUpdateBySales,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response--------------------------', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: CASH_DEPOSIT_SALES_UPDATE_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData
      });
    } else {
      yield put({
        type: CASH_DEPOSIT_SALES_UPDATE_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
   // alert(error);
    yield put({
      type: CASH_DEPOSIT_SALES_UPDATE_FAILURE,
      message: error,
    });
  }
}



export default function* mySaga() {
  yield takeEvery(CASH_DEPOSIT_SALES_HANDOVER_MONEY, getCashFromParamedic);
  yield takeEvery(CASH_DEPOSIT_SALES_UPDATE, updateCashFromParamedic);
}
