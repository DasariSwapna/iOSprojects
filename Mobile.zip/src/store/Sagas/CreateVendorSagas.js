import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  INSERT_VENDOR,
  INSERT_VENDOR_SUCCESS,
  INSERT_VENDOR_FAILURE,
  INSERT_VENDOR_TEST,
  INSERT_VENDOR_TEST_SUCCESS,
  INSERT_VENDOR_TEST_FAILURE,
  GET_QUESTION_ANSWER,
  GET_QUESTION_ANSWER_SUCCESS,
  GET_QUESTION_ANSWER_FAILURE,
  INSERT_QUESTION_ANSWER,
  INSERT_QUESTION_ANSWER_SUCCESS,
  INSERT_QUESTION_ANSWER_FAILURE,
  GET_VENDOR_DETAILS,
  GET_VENDOR_DETAILS_SUCCESS,
  GET_VENDOR_DETAILS_FAILURE
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* insertVendor(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertUpdateVendorDetails,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('INSERT VENDOR response data---:', responseData);
    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: INSERT_VENDOR_SUCCESS,
        response: responseData.vendorId,
        message: responseData.message,
      });
    } else {
      yield put({
        type: INSERT_VENDOR_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_VENDOR_FAILURE,
      message: error,
    });
  }
}

function* insertVendorTest(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertProductTestMapping,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('INSERT VENDOR TEST response data:--', responseData);
    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: INSERT_VENDOR_TEST_SUCCESS,
        response: responseData.responseObject,
        message: responseData.message,
      });
    } else {
      yield put({
        type: INSERT_VENDOR_TEST_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_VENDOR_TEST_FAILURE,
      message: error,
    });
  }
}

function* getTermsQuestionAnswer(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getTermsQuestionAnswer,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    console.log('GET QUESTION ANSWER', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('GET QUESTION ANSWER response data---:', responseData);
    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: GET_QUESTION_ANSWER_SUCCESS,
        response: responseData.responseObject.properties.TermsandCondtionsResponse,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_QUESTION_ANSWER_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_VENDOR_FAILURE,
      message: error,
    });
  }
}

function* insertTermsQuestionAnswer(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.insertTermsQuestionAnswer,
      secureData,
      senderIv,
      action.token,
    );
   
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
 //   console.log('INSERT QUESTION ANSWER response data:--', responseData.responseObject.properties.TermsConditonResponse[0].Message);
    if (responseData.statusCode == 200) {

      //  if (responseData) {
        if(responseData.responseObject.properties.TermsConditonResponse == '')
        {
          yield put({
            type: INSERT_QUESTION_ANSWER_SUCCESS,
            response:[],
            message: '',
          });
        }
        else
        {
          yield put({
            type: INSERT_QUESTION_ANSWER_SUCCESS,
          
            response: responseData.responseObject.properties.TermsConditonResponse[0],
            message: responseData.message,
          });
        }
     
    } else {
      yield put({
        type: INSERT_QUESTION_ANSWER_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: INSERT_QUESTION_ANSWER_FAILURE,
      message: error,
    });
  }
}


function* getVendorDetails(action) {
  //alert('hii');
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getVendorDetails,
      secureData,
      senderIv,
      action.token,
    );
    // console.log('Page Rew Response: ', response);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Vendor Detail response data12:', responseData.responseObject.properties.DOCTER_DETAILS[0]);
    // if (responseData.status == 200) {
    if (responseData) {
      yield put({
        type: GET_VENDOR_DETAILS_SUCCESS,
        response: responseData.responseObject.properties.HOSPITAL_DETAILS[0],
        response1: responseData.responseObject.properties.DOCTER_DETAILS[0],
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_VENDOR_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_VENDOR_DETAILS_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(INSERT_VENDOR, insertVendor);
  yield takeEvery(INSERT_VENDOR_TEST, insertVendorTest);
  yield takeEvery(GET_QUESTION_ANSWER, getTermsQuestionAnswer);
  yield takeEvery(INSERT_QUESTION_ANSWER, insertTermsQuestionAnswer);
  yield takeEvery(GET_VENDOR_DETAILS, getVendorDetails);
}
