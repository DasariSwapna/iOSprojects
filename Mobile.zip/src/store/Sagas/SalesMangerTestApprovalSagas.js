import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  GETMANGERTESTAPPROVAL,
  GETMANGERTESTAPPROVAL_SUCCESS,
  GETMANGERTESTAPPROVAL_FAILURE,
  DELETE_APPROVALS_DATA,
  DELETE_APPROVALS_DATA_SUCCESS,
  DELETE_APPROVALS_DATA_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* getMangerTestApproval(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.getManagerTestApprovalSales,
      secureData,
      senderIv,
      action.token,
    );
    // console.log("header", response.headers);
    // console.log("Headers: ", response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'response ALl:------------------->',
      responseData.responseObject.properties.MOU,
    );

    console.log(
      'response Data Approval Retail to invoice :------------------->',
      responseData.responseObject.properties.RetailtoInvoice,
    );

    console.log(
      'response MOU:------------------->',
      responseData.responseObject.properties.All,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: GETMANGERTESTAPPROVAL_SUCCESS,
        message: responseData.message,
        response: responseData.responseObject.properties,
        response1: responseData.responseObject.properties.All,
        response2: responseData.responseObject.properties.RetailtoInvoice,
        response3: responseData.responseObject.properties.MOU,
        kind: action.data.statusid,
      });
    } else {
      yield put({
        type: GETMANGERTESTAPPROVAL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GETMANGERTESTAPPROVAL_FAILURE,
      message: error,
    });
  }
}

function* deleteApprovaldatas(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.deleteVendore,
      secureData,
      senderIv,
      action.token,
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'Delete Approved / Revised  response data:',
      responseData.responseObject.properties.DELETE_VENDOR_RESPONSE,
    );

    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: DELETE_APPROVALS_DATA_SUCCESS,
        // response: responseData.responseObject,
        message:
          responseData.responseObject.properties.DELETE_VENDOR_RESPONSE[0]
            .MESSAGE,
      });
    } else {
      yield put({
        type: DELETE_APPROVALS_DATA_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: DELETE_APPROVALS_DATA_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(GETMANGERTESTAPPROVAL, getMangerTestApproval);
  yield takeEvery(DELETE_APPROVALS_DATA, deleteApprovaldatas);
}
