import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {Apis} from '../../config/Apis';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {getRequest, postRequest} from '../../services/Requests';
import {getDiscountapprovaldetails, getRole} from '../Actions';

import {
  GET_APPROVAL_COUNT,
  GET_APPROVAL_COUNT_SUCCESS,
  GET_APPROVAL_COUNT_FAILURE,
  GET_APPROVAL_DETAILS,
  GET_APPROVAL_DETAILS_SUCCESS,
  GET_APPROVAL_DETAILS_FAILURE,
  GET_APPROVAL_DETAILS_PROCESS,
  GET_APPROVAL_DETAILS_PROCESS_SUCCESS,
  GET_APPROVAL_DETAILS_PROCESS_FAILURE,
  UPDATE_APPROVED_STATUS,
  UPDATE_APPROVED_STATUS_SUCCESS,
  UPDATE_APPROVED_STATUS_FAILURE,
  MANAGER_DISCOUNT_APPROVAL,
  MANAGER_DISCOUNT_APPROVAL_SUCCESS,
  MANAGER_DISCOUNT_APPROVAL_FAILURE,
  MANAGER_DISCOUNT_DETAILS_APPROVAL,
  MANAGER_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
  MANAGER_DISCOUNT_APPROVAL_DETAILS_FAILURE,
  UPDATE_DISCOUNT_DETAILS_APPROVAL,
  UPDATE_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
  UPDATE_DISCOUNT_APPROVAL_DETAILS_FAILURE,
} from '../ActionTypes';

function* getapprovalCount(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.getApprovalCount,
      senderIv,
      action.token,
    );

    console.log('Approval Count Response: ', response);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Approval Count Response Data:', responseData.respList);
    if (responseData.statusCode == '200') {
      yield put({
        type: GET_APPROVAL_COUNT_SUCCESS,
        response: responseData.respList,
      });
    } else {
      yield put({
        type: GET_APPROVAL_COUNT_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: GET_APPROVAL_COUNT_FAILURE,
      message: error,
    });
  }
}

function* getapprovalDetailsprocess(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getApprovalDetailsProcess,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Approvals details response1: ', response.data);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'response approval Details 1V:',
      responseData.responseObject.properties,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: GET_APPROVAL_DETAILS_PROCESS_SUCCESS,
        response: responseData.responseObject.properties.Pending,
        response1: responseData.responseObject.properties.Approved,
        response2: responseData.responseObject.properties.Auto_Approved,
      });
    } else {
      yield put({
        type: GET_APPROVAL_DETAILS_PROCESS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_APPROVAL_DETAILS_PROCESS_FAILURE,
      message: error,
    });
  }
}

function* getapprovalDetails(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.getApprovalDetails,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Approvals details : ', response.data);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'response approval Details:',
      responseData.responseObject.properties,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: GET_APPROVAL_DETAILS_SUCCESS,
        response1: responseData.responseObject.properties.vendorDetails,
        response3: responseData.responseObject.properties.testTableDetails,
        response2: responseData.responseObject.properties.productDetails,
      });
    } else {
      yield put({
        type: GET_APPROVAL_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_APPROVAL_DETAILS_FAILURE,
      message: error,
    });
  }
}

function* updateApprovedStatus(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updateApprovalldetails,
      secureData,
      senderIv,
      action.token,
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Update Approved / Revised  response data:', responseData);

    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: UPDATE_APPROVED_STATUS_SUCCESS,
        // response: responseData.responseObject,
        message: responseData.message,
      });
    } else {
      yield put({
        type: UPDATE_APPROVED_STATUS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: UPDATE_APPROVED_STATUS_FAILURE,
      message: error,
    });
  }
}

function* getdiscountapproval(action) {
  try {
    let senderIv = yield generateIv();
    const response = yield getRequest(
      Apis.discountApproval,
      senderIv,
      action.token,
    );
    console.log('Discount Approvals details : ', response.data);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'Discount approval Details response:',
      responseData.responseObject.properties.Approved,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: MANAGER_DISCOUNT_APPROVAL_SUCCESS,
        response1: responseData.responseObject.properties.Approved,
        response2: responseData.responseObject.properties.Pending,
      });
    } else {
      yield put({
        type: MANAGER_DISCOUNT_APPROVAL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: MANAGER_DISCOUNT_APPROVAL_FAILURE,
      message: error,
    });
  }
}

function* getdiscountapprovalDetails(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.discountApprovalDetails,
      secureData,
      senderIv,
      action.token,
    );
    console.log('Discount approval details response1: ', response.data);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'Discount response approval Details:',
      responseData.responseObject.properties,
    );

    if (responseData.statusCode == 200) {
      yield put({
        type: MANAGER_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
        response: responseData.responseObject.properties.OrderDetails,
        response1: responseData.responseObject.properties.TestDetails,
        response2: responseData.responseObject.properties.testTableDetails,
      });
    } else {
      yield put({
        type: MANAGER_DISCOUNT_APPROVAL_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: MANAGER_DISCOUNT_APPROVAL_DETAILS_FAILURE,
      message: error,
    });
  }
}

function* updateDiscountApprovedStatus(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.updatediscountApprovalDetails,
      secureData,
      senderIv,
      action.token,
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log(
      'Discount Update Approved / Revised  response data:',
      responseData.responseObject.properties.Response[0].message,
    );

    if (responseData.statusCode == 200) {
      //  if (responseData) {
      yield put({
        type: UPDATE_DISCOUNT_APPROVAL_DETAILS_SUCCESS,
        message: responseData.responseObject.properties.Response[0].message,
      });
    } else {
      yield put({
        type: UPDATE_DISCOUNT_APPROVAL_DETAILS_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: UPDATE_DISCOUNT_APPROVAL_DETAILS_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(GET_APPROVAL_COUNT, getapprovalCount);
  yield takeEvery(GET_APPROVAL_DETAILS_PROCESS, getapprovalDetailsprocess);
  yield takeEvery(GET_APPROVAL_DETAILS, getapprovalDetails);
  yield takeEvery(UPDATE_APPROVED_STATUS, updateApprovedStatus);
  yield takeEvery(MANAGER_DISCOUNT_APPROVAL, getdiscountapproval);
  yield takeEvery(
    MANAGER_DISCOUNT_DETAILS_APPROVAL,
    getdiscountapprovalDetails,
  );
  yield takeEvery(
    UPDATE_DISCOUNT_DETAILS_APPROVAL,
    updateDiscountApprovedStatus,
  );
}
