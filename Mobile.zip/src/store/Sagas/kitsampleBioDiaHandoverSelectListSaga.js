import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST,
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_SUCCESS,
  KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_FAILURE,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* getKitsampleHanoverBiodataSelectlist(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    console.log('action->', action.data);
    const response = yield postRequest(
      Apis.kitsample_handover_biodata_selectlist,
      secureData,
      senderIv,
      action.token,
    );
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('selectedlist', responseData);
    // alert(JSON.stringify(responseData));
    console.log(JSON.stringify(responseData));
    if (responseData.statusCode == 200) {
      yield put({
        type: KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        response: responseData.responseObject,
      });
    } else {
      yield put({
        type: KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: KITSAMPLE_HANDOVER_BIODATA_SELECTLIST_FAILURE,
      message: error,
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(
    KITSAMPLE_HANDOVER_BIODATA_SELECTLIST,
    getKitsampleHanoverBiodataSelectlist,
  );
  yield takeEvery(GET_TOKEN, generateToken);
}
