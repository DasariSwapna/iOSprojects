import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  LOGIN,
  LOGIN_FAILURE,
  LOGIN_SUCCESS,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* userLogin(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.signIn, secureData, senderIv);
    console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    console.log();
    const res = responseData.responseObject.object;
    if (res.status == 200) {
      yield put({
      type: LOGIN_SUCCESS,
      roles: res.roles,
      userId: res.Technician_Id,
      username: res.Technician_Name,
      dayStartStatus: res.TECHNICIAN_STARTED,
      activationStatus: res.verified,
      accessToken: res.Token,
      message: res.message,
      firstName: res.LC_MU_USER_FIRST_NAME,
      lastName: res.LC_MU_USER_LAST_NAME,
      mobileNo: res.LC_MU_USER_PHONENO,
      email: res.LC_MU_USER_EMAILID,
      });
      }
     else {
      yield put({
        type: LOGIN_FAILURE,
        message: res.message,
      });
    }
  } catch (error) {
    yield put({
      type: LOGIN_FAILURE,
      message: error,
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('response Data:', responseData);
    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(LOGIN, userLogin);
  yield takeEvery(GET_TOKEN, generateToken);
}
