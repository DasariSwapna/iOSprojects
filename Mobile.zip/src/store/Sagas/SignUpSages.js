import {put, take, takeLatest, takeEvery} from '@redux-saga/core/effects';
import {getRequest, postRequest} from '../../services/Requests';
import {generateIv, unwrapData, wrapData} from '../../services/Crypto';
import {
  CHECK_EMAIL,
  CHECK_EMAIL_FAILURE,
  CHECK_EMAIL_SUCCESS,
  SIGNUP,
  SIGNUP_FAILURE,
  SIGNUP_SUCCESS,
} from '../ActionTypes';
import {Apis} from '../../config/Apis';

function* userSignIn(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.signUp, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Sign Up response Data:', responseData);
    if (responseData.status == 200) {
      yield put({
        type: SIGNUP_SUCCESS,
        res: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: SIGNUP_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: SIGNUP_FAILURE,
      message: error,
    });
  }
}

function* checkEmailAndPhoneNo(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.checkEmail, secureData, senderIv);
    // console.log('Headers: ', response.headers.clientsecret);
    // console.log('Response: ', response.data);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv,
    );
    console.log('Sign Up Email response Data:', responseData);
    if (responseData.statusCode == 200) {
      yield put({
        type: CHECK_EMAIL_SUCCESS,
        res: responseData,
        message: responseData.message,
      });
    } else {
      yield put({
        type: CHECK_EMAIL_FAILURE,
        message: responseData.message,
      });
    }
  } catch (error) {
    yield put({
      type: CHECK_EMAIL_FAILURE,
      message: error,
    });
  }
}

export default function* mySaga() {
  yield takeEvery(SIGNUP, userSignIn);
  yield takeEvery(CHECK_EMAIL, checkEmailAndPhoneNo);
}
