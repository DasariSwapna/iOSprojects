import { put, take, takeLatest, takeEvery } from '@redux-saga/core/effects';
import { getRequest, postRequest } from '../../services/Requests';
import { generateIv, unwrapData, wrapData } from '../../services/Crypto';
import {
    GET_POSTAL,
    GET_POSTAL_SUCCESS,
    GET_POSTAL_FAILURE,
    GET_LAB_CENTER_NAME,
    GET_LAB_CENTER_NAME_SUCCESS,
    GET_LAB_CENTER_NAME_FAILURE,
    GET_TOKEN,
    GET_TOKEN_FAILURE,
    GET_TOKEN_SUCCESS,
} from '../ActionTypes';
import { Apis } from '../../config/Apis';

function* getPostalService(action) {
    try {

        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        const response = yield postRequest(
            Apis.postalService,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        if (responseData.statusCode == 200) {
            yield put({
                type: GET_POSTAL_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.respList,
            });
        } else {
            yield put({
                type: GET_POSTAL_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: GET_POSTAL_FAILURE,
            message: error,
        });
    }
}

// kitsample Handover lab center name
function* getLabCenterName(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        //need to change KITSAMPLE HANDOVER MODE API
        const response = yield postRequest(
            Apis.getHandoverLabCenterName,
            secureData,
            senderIv,
            action.token,
        );

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );
        console.log('Handover lan//////////////////////////cnter', responseData);
        if (responseData.statusCode == 200) {
            yield put({
                type: GET_LAB_CENTER_NAME_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
                response: responseData.respList,
            });
        } else {
            yield put({
                type: GET_LAB_CENTER_NAME_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        alert(error);
        yield put({
            type: GET_LAB_CENTER_NAME_FAILURE,
            message: error,
        });
    }
}


function* generateToken(action) {
    try {
        let senderIv = yield generateIv();
        let secureData = yield wrapData(action.data, senderIv);
        const response = yield postRequest(Apis.getToken, secureData, senderIv);

        const receiverIv = response.headers.clientsecret;
        const responseData = yield unwrapData(
            response.data.responseData,
            receiverIv,
        );

        if (responseData.status == 200) {
            yield put({
                type: GET_TOKEN_SUCCESS,
                accessToken: responseData.key,
                message: responseData.message,
            });
        } else {
            yield put({
                type: GET_TOKEN_FAILURE,
                message: responseData.message,
            });
        }
    } catch (error) {
        yield put({
            type: GET_TOKEN_FAILURE,
            message: error,
        });
    }
}

export default function* mySaga() {
    yield takeEvery(GET_POSTAL, getPostalService);
    yield takeEvery(GET_LAB_CENTER_NAME, getLabCenterName);
    yield takeEvery(GET_TOKEN, generateToken);
}
