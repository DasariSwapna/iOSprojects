import { put, take, takeLatest, takeEvery } from "@redux-saga/core/effects";
import { getRequest, postRequest } from "../../services/Requests";
import { generateIv, unwrapData, wrapData } from "../../services/Crypto";
import {
  GET_TOKEN,
  GET_TOKEN_FAILURE,
  GET_TOKEN_SUCCESS,
  GET_OTP_FORGET_PASSWORD,
  GET_OTP_FORGET_PASSWORD_SUCCESS,
  GET_OTP_FORGET_PASSWORD_FAILURE,
  VERIFY_FORGET_PASSWORD,
  VERIFY_FORGET_PASSWORD_SUCCESS,
  VERIFY_FORGET_PASSWORD_FAILURE
} from "../ActionTypes";
import { Apis } from "../../config/Apis";

function* getForgertPassword(action) {
  try {

    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(
      Apis.forgetPasswordOtp,
      secureData,
      senderIv
    );

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    console.log('ForgetPassord',responseData)
    if (responseData.statusCode == 200) {
      yield put({
        type: GET_OTP_FORGET_PASSWORD_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message,
        mobileNumber: responseData.mobileNumber
      });
    } else {
      yield put({
        type: GET_OTP_FORGET_PASSWORD_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: GET_OTP_FORGET_PASSWORD_FAILURE,
      message: error
    });
  }
}

function* verifyOtp(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.verifyotp, secureData, senderIv);
    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );
    if (responseData.statusCode == 200) {
      yield put({
        type: VERIFY_FORGET_PASSWORD_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: VERIFY_FORGET_PASSWORD_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    alert(error);
    yield put({
      type: VERIFY_FORGET_PASSWORD_FAILURE,
      message: error
    });
  }
}

function* generateToken(action) {
  try {
    let senderIv = yield generateIv();
    let secureData = yield wrapData(action.data, senderIv);
    const response = yield postRequest(Apis.getToken, secureData, senderIv);

    const receiverIv = response.headers.clientsecret;
    const responseData = yield unwrapData(
      response.data.responseData,
      receiverIv
    );

    if (responseData.status == 200) {
      yield put({
        type: GET_TOKEN_SUCCESS,
        accessToken: responseData.key,
        message: responseData.message
      });
    } else {
      yield put({
        type: GET_TOKEN_FAILURE,
        message: responseData.message
      });
    }
  } catch (error) {
    yield put({
      type: GET_TOKEN_FAILURE,
      message: error
    });
  }
}

export default function* mySaga() {
  yield takeEvery(GET_OTP_FORGET_PASSWORD, getForgertPassword);
  yield takeEvery(VERIFY_FORGET_PASSWORD, verifyOtp);
  yield takeEvery(GET_TOKEN, generateToken);
}
