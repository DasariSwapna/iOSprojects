import React from 'react';
import {StyleSheet} from 'react-native';
import Font from '../Fonts';
import Color from '../Colors';

const GlobalStyles = StyleSheet.create({
  mainContainer: {},
});

export default GlobalStyles;
