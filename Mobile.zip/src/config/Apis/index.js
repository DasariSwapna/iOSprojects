// const BASE_SERVICE = 'http://20.204.236.175:8086/LifeCellCommon';
// const BASE_MASTER = 'http://20.204.247.200:8087/LifeCellMobile';
// const BASE_WEB = 'http://20.204.227.15:8085/LifeCellWeb';
const BASE_SERVICE = 'https://voilalifecell.isolvedev.in/LifeCellCommon';
const BASE_MASTER = 'https://voilalifecell.isolvedev.in/LifeCellMobile';
const BASE_WEB = 'https://voilalifecell.isolvedev.in/LifeCellWeb';

export const Apis = {
  appConfig: BASE_MASTER + '/getAppConfig',
  language: BASE_MASTER + '/getLanguageMaster',
  label: BASE_MASTER + '/getLableMaster',
  theme: BASE_MASTER + '/getThemeMaster',
  pageNo: BASE_MASTER + '/getPageMaster',
  image: BASE_MASTER + '/getImagePathMaster',
  signIn: BASE_SERVICE + '/login',
  getToken: BASE_SERVICE + '/generateToken',
  resetPassword: BASE_SERVICE + '/resetPin',
  verifyotp: BASE_SERVICE + '/verifyOTP',
  checkEmail: BASE_SERVICE + '/validateEmailPhoneno',
  signUp: BASE_SERVICE + '/signup',
  role: BASE_MASTER + '/getusertype',
  city: BASE_SERVICE + '/getCityMaster',
  center: BASE_SERVICE + '/getcenter',
  dayStart: BASE_SERVICE + '/techDayStartTime',
  getAccountType: BASE_SERVICE + '/getAccountType',
  getDoctorSpeciality: BASE_MASTER + '/vendor/getDoctorSpeciality',
  insertUpdateTermsConditonSignature:
    BASE_MASTER + '/insertUpdateTermsConditonSignature',
  getparamedicuseravailability: BASE_WEB + '/getparamedicuseravailability',
  // forgetPasswordOtp : BASE_SERVICE + '/generateOTP',
  forgetPasswordOtp: BASE_SERVICE + '/generateOTPForgotPassword',
  kitsample_handover_biodata: BASE_MASTER + '/kitsample/getBioDiaHandoverList',
  getOTPNumber: BASE_SERVICE + '/generateOTP',
  getState: BASE_SERVICE + '/getStateMaster',
  getOTPNumber: BASE_SERVICE + '/generateOTP',
  signUp: BASE_SERVICE + '/signup',
  productDetails: BASE_SERVICE + '/getProductDetails',
  productList: BASE_MASTER + '/vendor/getTestListByProductId',
  insertOrder: BASE_MASTER + '/order/insertOrder',
  getAddressType: BASE_SERVICE + '/getAddressType',
  // getCityMaster: BASE_SERVICE + '/getCityMaster',
  getReferredBy: BASE_SERVICE + '/getReferType',
  getPickupType: BASE_SERVICE + '/getPickupType',
  getHospital: BASE_MASTER + '/vendor/getVendorDetails',

  dayStart: BASE_SERVICE + '/techDayStartTime',
  kitsample_handover_biodata_selectlist: BASE_MASTER + '/kitsample/getBioDiaHandoverSelectList',
  shuttleupate: BASE_MASTER + '/shuttlepickup/updateShuttleDetails',
  getDoctor: BASE_SERVICE + '/getdoctorlist',
  getMyTaskListDatas: BASE_MASTER + '/getParamedicMyTask',

  getMyTaskListdetailsDatas: BASE_MASTER + '/getUserTaskProductDetail',

  getApprovalCount: BASE_MASTER + '/getManagerApprovalCount',
  getApprovalDetails: BASE_MASTER + '/vendor/getHospitalApprovalDetails',
  getApprovalDetailsProcess: BASE_MASTER + '/vendor/getManagerTestApprovalProcess',
  updateApprovalldetails: BASE_MASTER + '/vendor/updateTestApprovalStatus',

  uploadsignedcopydetails: BASE_MASTER + '/vendor/getManagerTestApprovalSales',
  uploadsignedcopypdfdetails: BASE_MASTER + '/vendor/vendorUploadSignedCopy',
  updateParamedicStart: BASE_MASTER + '/updateParamedicStart',
  getUserTaskProductCRMIDDetail: BASE_MASTER + '/getUserTaskProductCRMIDDetail',
  updateParamedicReached: BASE_MASTER + '/updateParamedicReached',
  updateParamedicCollected: BASE_MASTER + '/updateParamedicCollected',
  updateParamedicStart: BASE_MASTER + '/updateParamedicStart',
  getUserTaskProductCRMIDDetail: BASE_MASTER + '/getUserTaskProductCRMIDDetail',

  updateParamedicCancelled: BASE_MASTER + '/updateParamedicCancelled',
  getSelectTestForBarcode: BASE_MASTER + '/order/getTestListOrderid',
  getPickedTestList: BASE_MASTER + '/order/getPickedTestListOrderid',
  removeSamplePickup: BASE_MASTER + '/order/removeSamplePickup',
  updateBarcodeTestPickup: BASE_MASTER + '/order/updateBarcodeTestPickup',
  updateSamplePickupwithTRF: BASE_MASTER + '/order/updateSamplePickupwithTRF',
  getCancelReason: BASE_SERVICE + '/getCancelReason',

  getTieupHospital: BASE_MASTER + '/kitsample/gettieuphospital',
  getVisitTimeForRegularBeat: BASE_MASTER + '/kitsample/gettieuphospitalvisittime',
  getSampleTypeForRegularBeat: BASE_MASTER + '/kitsample/getsampletype',
  insertOrderDetailsRegularVisit: BASE_MASTER + '/kitsample/insertorderdetailsregularvisit',
  insertNoSampleRegularVisit: BASE_MASTER + '/kitsample/insertnosamples',
  getPickedTestListRegularVisit: BASE_MASTER + '/kitsample/getPickedTestList',
  getParamedicUserTaskCancelDetail: BASE_MASTER + '/getParamedicUserTaskCancelDetail',
  removeRegularBeatSample: BASE_MASTER + '/kitsample/getremovesamplepickupregularvisit',

  getTieupHospital: BASE_MASTER + '/kitsample/gettieuphospital',
  getVisitTimeForRegularBeat: BASE_MASTER + '/kitsample/gettieuphospitalvisittime',
  getSampleTypeForRegularBeat: BASE_MASTER + '/kitsample/getsampletype',

  insertUpdateVendorDetails: BASE_MASTER + '/vendor/insertUpdateVendorDetails',
  insertProductTestMapping: BASE_MASTER + '/vendor/insertProductTestMapping',
  getTermsQuestionAnswer: BASE_MASTER + '/gettermsconditonquestionanswer',
  insertTermsQuestionAnswer: BASE_MASTER + '/insertUpdateTermsConditon',

  getTaskCategory: BASE_MASTER + '/getTaskCategory',
  getTask: BASE_SERVICE + '/getTaskType',
  getCRMInfo: BASE_MASTER + '/getCRMInfoScheduleTask',
  updatetask: BASE_WEB + 'updateassignparamedic',
  getTaskTime: BASE_WEB + 'getparamedicuseravailability',
  updatetask: BASE_WEB + '/updateassignparamedic',

  getProductDetailsforHospital: BASE_MASTER + '/getProductDetailsforHospital',
  gettesandproductforhospital: BASE_MASTER + '/gettesandproductforhospital',
  getTaskTime: BASE_WEB + '/getparamedicuseravailability',

  //payement mode

  payementDtbyId: BASE_MASTER + '/order/getPaymentDetOrderid',
  payementMode: BASE_SERVICE + '/getpaymenttype',
  payementOTP: BASE_SERVICE + '/generateOTPPayment',
  payementVerifyOTP: BASE_MASTER + '/paymentCashOTPVerify',
  payementCash: BASE_MASTER + '/insertPaymentCash',
  payementOnline: BASE_MASTER + '/insertPaymentInitiated',

  //sales manger approvel
  getManagerTestApprovalSales: BASE_MASTER + '/vendor/getManagerTestApprovalSales',
  getTaskTime: BASE_WEB + '/getparamedicuseravailability',
  getHandoverCenter: BASE_SERVICE + '/getcenter',
  getHandoverLab: BASE_WEB + '/getlabmaster',
  getHandoverLabCenterName: BASE_SERVICE + '/getCityMaster',
  postalService: BASE_WEB + '/getcouriermaster',
  kitInsert: BASE_MASTER + '/kitsample/updatekitsamplehandover',
  deleteVendore: BASE_MASTER + '/vendor/deletevendor',

  updateParamedicRescduled: BASE_MASTER + '/updateParamedicRescduled',

  cashGetFromUserId: BASE_MASTER + '/cashdeposit/getcashtasklist',
  cashHandoverSales: BASE_MASTER + '/cashdeposit/getcashhandovertore',
  cashUpdateBySales: BASE_MASTER + '/cashdeposit/updatecashhandover',
  cashUpdateInBank: BASE_MASTER + '/cashdeposit/updateCashDepositBank',

  cashDepositList: BASE_MASTER + '/cashdeposit/getcashtasklist',
  cashDepositBank: BASE_SERVICE + '/getBanks',
  cashDepositBranch: BASE_SERVICE + '/getBankBranch',
  cashDepositTime: BASE_SERVICE + '/getBankDepositTime',
  updateCashDeposit: BASE_MASTER + '/cashdeposit/updateCashDepositBank',

  discountApproval: BASE_MASTER + '/order/getManagerTestAppProDiscount',
  discountApprovalDetails: BASE_MASTER + '/order/getOrderApprovalDetailsDiscount',
  updatediscountApprovalDetails: BASE_MASTER + '/order/updateOrderTestApprovalStatus',

  getPatientDetails: BASE_MASTER + '/vendor/getPatientDetails',
  getVendorDetails: BASE_MASTER + '/vendor/getVendorDetailsUsingContactNo',
};

