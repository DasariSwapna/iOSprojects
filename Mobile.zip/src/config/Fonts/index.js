import {Dimensions} from 'react-native';

const {width, height} = Dimensions.get('screen');
const fontVerySmall = height * 0.011;
const fontSmall = height * 0.012;
const fontRegular = height * 0.015;
//const fontMedium = height * 0.018;
const fontMedium = height * 0.017;
const fontSemiLarge = height * 0.02;
const fontLarge = height * 0.022;
const fontExtraLarge = height * 0.024;
const fontDoubleExtra = height * 0.038;

export const Font = {
  regular: 'Magneta-Book',
  bold: 'Magneta-SemiBold',
  extraBold: 'Magneta-Bold',
};

export const FontMagneta = {
  thin: 'Magneta-Thin',
  medium: 'Magneta-Medium',
  semiBold: 'Magneta-SemiBold',
  bold: 'Magneta-Bold',
};

export const FontSize = {
  verySmall: fontVerySmall,
  small: fontSmall,
  regular: fontRegular,
  medium: fontMedium,
  semiLarge: fontSemiLarge,
  large: fontLarge,
  extraLarge: fontExtraLarge,
  doubleExtra: fontDoubleExtra,
};
