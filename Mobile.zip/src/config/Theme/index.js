import {DefaultTheme, DarkTheme} from '@react-navigation/native';

export const MyLightTheme = {
  ...DefaultTheme,
  dark: false,
  colors: {
    ...DefaultTheme.colors,
    primary: '#B455A0',
    background: '#FFFFFF',
    card: '#EFDEED',
    text: '#B455A0',
    border: '#9E2575',
    notification: 'rgb(255, 69, 58)',
    button: '#EE2C6C',
  },
};

export const MyDrakTheme = {
  ...DarkTheme,
  dark: true,
  colors: {
    ...DarkTheme.colors,
    primary: '#B455A0',
    background: '#FFFFFF',
    card: '#EFDEED',
    text: '#B455A0',
    border: '#9E2575',
    notification: 'rgb(255, 69, 58)',
    button: '#EE2C6C',
  },
};
