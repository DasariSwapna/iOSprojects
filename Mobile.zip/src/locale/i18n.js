import React from 'react';
import i18n from 'i18next';
import {useTranslation, initReactI18next} from 'react-i18next';
import {getLocales} from 'react-native-localize';
import en from './en.json';
import nb from './no.json';

// i18n
//   .use(initReactI18next) // passes i18n down to react-i18next
//   .init({
//     compatibilityJSON: 'v3',
//     resources: {
//       en: en,
//       nb: no,
//     },
//     lng: 'en',
//     fallbackLng: 'en',

//     interpolation: {
//       escapeValue: false,
//     },
//   });

i18n.use(initReactI18next).init({
  lng: getLocales()[0].languageCode,
  compatibilityJSON: 'v3',
  fallbackLng: 'en',
  resources: {
    en: en,
    nb: nb,
    // en: {
    //   translation: {
    //     Hey: 'Hey Yo Im at home',
    //   },
    // },
    // no: {
    //   translation: {
    //     Hey: 'Hey yo estoy en casa',
    //   },
    // },
  },
  interpolation: {
    escapeValue: false,
  },
});

export default i18n;
