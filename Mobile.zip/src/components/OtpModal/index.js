import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  Modal,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  Dimensions,
  KeyboardAvoidingView,
  Platform
} from 'react-native';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../config/Fonts';
import { InputField, InputField1 } from '../InputField';
import Button from '../Button';
import Ionicons from 'react-native-vector-icons/Ionicons';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import DropDownMenu from '../DropDownMenu';
import TextInputComponent from '../TextInputComponent';
import ModalSelector from '../ModalSelector';
const { width, height } = Dimensions.get('screen');
const headerHeight = height * 0.05;
const descriptionHeight = height * 0.046;
const bottomContainerHeight = height * 0.16;

export default function OtpModal({
  page,
  otp,
  isAuth,
  mobileNo,
  visible,
  isValidOtp,
  setVisible,
  otpValidationMsg,
  otpChangeHandler,
  resendOtpHandler,
  otpDismissHandler,
  otpSubmitHandler,
  showPassword,
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  console.log(isValidOtp, otpValidationMsg);

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        toggleVisible(!modalVisible);
      }}>
      <KeyboardAvoidingView
        enabled
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.centeredView}>
          <View style={styles.modalView}>
            <View style={styles.modalHeaderContainer}>
              <View style={styles.headerBackButton}>
                <TouchableOpacity onPress={() => otpDismissHandler()}>
                  <Fa5Icons
                    name="arrow-left"
                    color={Colors.primary}
                    size={headerHeight / 2.2}
                  />
                </TouchableOpacity>
              </View>
              <View style={styles.headerTitle}>
                <Text style={styles.modalHeaderText}>OTP Verification</Text>
              </View>
            </View>
            <View style={styles.descriptionContainer}>
              <Text style={styles.descriptionText}>
                Please enter the OTP received to your mobile number
              </Text>
            </View>
            <View style={styles.sendToContainer}>
              <Text style={styles.sendToText}>Sent to +91 {mobileNo}</Text>
            </View>
            <View style={{ width: '100%' }}>
              <InputField
                placeholder={'******'}
                value={otp}
                isValid={!isValidOtp}
                maxLength={6}
                validationMsg={otpValidationMsg}
                textInputContainer={styles.otpTextContainer}
                onChangeHandler={otpChangeHandler}
                resendOtpHandler={() => resendOtpHandler()}
                isNumeric={true}
                isPassword={true}
                isOtp={true}
                isAuth
              />
            </View>
            <PageNumber number={page} />
            <View style={styles.bottomContainer}>
              <Button title={'Submit'} onPress={() => otpSubmitHandler()} />
              <View style={styles.bottomTextContainer}>
                <Text style={styles.bottomText}>Didn't receive OTP?</Text>
                <Button
                  title={'Resend'}
                  isTransparent
                  buttonTextStyle={{
                    color: Colors.teal,
                    fontSize: FontSize.medium,
                  }}
                  onPress={() => resendOtpHandler()}
                />
              </View>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

OtpModal.propTypes = {
  otp: PropTypes.string.isRequired,
  mobileNo: PropTypes.string,
  visible: PropTypes.bool,
  isValidOtp: PropTypes.bool,
  setOtp: PropTypes.func,
  setVisible: PropTypes.func,
  otpSubmitHandler: PropTypes.func,
};

export function ModalConfirmNumber({
  visible,
  setVisible,
  dismissHandler,
  cancelHandler,
  okayHandler,
  title,
  message,
  mobileNumber,
  pageNumber,
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        // toggleVisible(!modalVisible);
        setModalVisible(false)
      }}>
      <View style={styles.centeredView}>
        <View style={styles.modalViewConfirm}>
          <View style={styles.modalHeaderContainer}>
            <View style={styles.headerBackButton}>
              <TouchableOpacity onPress={() => dismissHandler()}>
                <Fa5Icons name="arrow-left" color={Colors.border} size={22} />
              </TouchableOpacity>
            </View>
            <View style={styles.headerTitle}>
              <Text style={styles.modalHeaderTextConfirm}>{title}</Text>
            </View>
          </View>
          <View style={styles.messageTextConatiner}>
            <Text style={[styles.blackTextSuccess, { color: Colors.border }]}>
              {message}
            </Text>
            <Text style={styles.textConfrimNumber}>{mobileNumber}</Text>
          </View>
          <View style={styles.containerConfirm}>
            <TouchableOpacity onPress={() => cancelHandler()}>
              <View style={styles.buttonGreenConfirm}>
                <Ionicons name="close" color={Colors.white} size={24} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => okayHandler()}>
              <View style={styles.buttonPinkConfirm}>
                <Ionicons
                  name="checkmark-outline"
                  color={Colors.white}
                  size={24}
                />
              </View>
            </TouchableOpacity>
          </View>
          <PageNumber number={pageNumber} />
        </View>
      </View>
    </Modal>
  );
}

export function ModalSuccess({
  visible,
  setVisible,
  title,
  message,
  pageNumber,
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        // toggleVisible(!modalVisible);
        setModalVisible(false)
      }}>
      <View style={styles.centeredView}>
        <View style={styles.modalViewSuccess}>
          <TouchableOpacity>
            <View style={styles.circleSuccess}>
              <Ionicons
                name="checkmark-outline"
                color={Colors.white}
                size={24}
              />
            </View>
          </TouchableOpacity>
          <Text style={styles.borderTextSuccess}>{title}</Text>

          <Text style={styles.blackTextSuccess}>{message}</Text>

          <PageNumber number={pageNumber} />
        </View>
      </View>
    </Modal>
  );
}

export function OtpModalPayment({
  otp,
  mobileNo,
  visible,
  isValidOtp,
  setVisible,
  otpValidationMsg,
  otpChangeHandler,
  resendOtpHandler,
  dismissHandler,
  otpSubmitHandler,
  title,
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  console.log(isValidOtp, otpValidationMsg);

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        toggleVisible(!modalVisible);
      }}>
      <KeyboardAvoidingView
        enabled
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.centeredView}>
          <View style={styles.modalViewOtpPayment}>
            <View style={styles.modalHeaderContainer}>
              <View style={styles.headerBackButton}>
                <TouchableOpacity onPress={() => dismissHandler()}>
                  <Fa5Icons name="arrow-left" color={Colors.border} size={22} />
                </TouchableOpacity>
              </View>
              <View style={styles.headerTitle}>
                <Text style={styles.modalHeaderTextConfirm}>{title}</Text>
              </View>
            </View>
            <View>
              <InputField
                placeholder={'******'}
                value={otp}
                isValid={!isValidOtp}
                maxLength={6}
                validationMsg={otpValidationMsg}
                textInputContainer={[styles.otpTextContainer, { width: '55%' }]}
                onChangeHandler={otpChangeHandler}
                otpResentHandler={resendOtpHandler}
                isNumeric={true}
                isOtp={true}
                isPassword={true}
              />
              {/* <TouchableOpacity
              style={{flexDirection: 'row', alignSelf: 'center'}}
              onPress={() => otpDismissHandler()}>
              <Fa5Icons
                style={{alignSelf: 'center'}}
                name="redo"
                color={Colors.border}
                size={16}
              />
              <Text style={styles.resendOtpPayment}>Resend OTP</Text>
            </TouchableOpacity> */}
            </View>
            <PageNumber number={58} />
            <View style={[{ marginTop: hp('3$') }, styles.bottomContainer]}>
              <Button
                title={'Submit'}
                buttonTextStyle={{ fontSize: FontSize.medium }}
                buttonStyle={styles.buttonStyle}
                onPress={() => otpSubmitHandler()}
              />
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export function ModalCancel({
  dismissHandler,
  SubmitHandler,
  visible,
  stateHandler,
  labelKey,
  valueKey,
  listItems,
}) {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedCancelReason, setSelectedCancelReason] = useState('');
  const [selectedCancelid, setSelectedCancelid] = useState(0);
  const [cancelRemarks, setCancelRemarks] = useState('');

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };
  const remarkstxt = (text) => {
    const cleantext = text.replace(/[^a-zA-Z0-9 ,.@#$%^&*()-+=\n]/gm, '');
    setCancelRemarks(cleantext)
  }
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        //toggleVisible(!modalVisible);
        setModalVisible(false)
      }}>
      <KeyboardAvoidingView
        enabled
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={styles.centeredView}>
          <View
            style={{
              width: '100%',
              minHeight: hp('45%'),
              backgroundColor: 'white',
              padding: 12,
              alignItems: 'center',
              shadowColor: '#000',
              shadowOffset: {
                width: 0,
                height: 2,
              },
              shadowOpacity: 0.25,
              shadowRadius: 4,
              elevation: 5,
            }}>
            <View style={styles.modalHeaderContainer}>
              <View style={styles.headerBackButton}>
                <TouchableOpacity onPress={() => dismissHandler()}>
                  <Fa5Icons name="arrow-left" color={Colors.border} size={22} />
                </TouchableOpacity>
              </View>
              <View style={styles.headerTitle}>
                <Text style={styles.modalHeaderTextConfirm}>Cancel</Text>
              </View>
            </View>

            <View style={{ width: '90%', marginTop: hp('2%') }}>
              <Text
                style={{
                  color: Colors.border,
                  fontFamily: Font.bold,
                  fontSize: FontSize.medium,
                  alignSelf: 'flex-start',
                }}>
                Cancel reason
                <Text style={{ color: Colors.darkPink }}>*</Text>
              </Text>

              <ModalSelector
                id={'CancelReason'}
                data={listItems}
                initValue={'--Select--'}
                onChange={option => {
                  // stateHandler(option)
                  setSelectedCancelReason(option.lc_C_REASON);
                  setSelectedCancelid(option.lc_C_ID);
                }}
              />

              <Text
                style={{
                  color: Colors.border,
                  fontFamily: Font.bold,
                  fontSize: FontSize.medium,
                  alignSelf: 'flex-start',

                  marginTop: 20,
                }}>
                Cancel remarks
                <Text style={{ color: Colors.darkPink }}>*</Text>
              </Text>

              <TextInput
                style={[{}, styles.textColorPink]}
                placeholder="Enter remarks"
                placeholderTextColor={Colors.black}
                underlineColorAndroid="transparent"
                multiline={true}
                onChangeText={(val) => remarkstxt(val)}
                maxLength={250}
              // textAlignVertical={true}
              />
            </View>

            <PageNumber number={58} />
            <View style={styles.bottomContainer}>
              <Button
                title={'Submit'}
                buttonTextStyle={{ fontSize: FontSize.large }}
                buttonStyle={styles.buttonStyle}
                onPress={() => SubmitHandler(selectedCancelReason, cancelRemarks)}
              />
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

export function ModalReschedule({
  dismissHandler,
  SubmitHandler,
  visible,
  stateHandler,
  otpValidationMsg,
  otpChangeHandler,
  otp,
  isValidOtp,
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    setModalVisible(visible);
  }, [visible]);

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        setModalVisible(false)
        //toggleVisible(!modalVisible);
      }}>
      <View style={styles.centeredView}>
        <View
          style={{
            width: '100%',
            minHeight: hp('45%'),
            backgroundColor: 'white',
            padding: 12,
            alignItems: 'center',
            shadowColor: '#000',
            shadowOffset: {
              width: 0,
              height: 2,
            },
            shadowOpacity: 0.25,
            shadowRadius: 4,
            elevation: 5,
          }}>
          <View style={styles.modalHeaderContainer}>
            <View style={styles.headerBackButton}>
              <TouchableOpacity onPress={() => dismissHandler()}>
                <Fa5Icons name="arrow-left" color={Colors.border} size={22} />
              </TouchableOpacity>
            </View>
            <View style={styles.headerTitle}>
              <Text style={styles.modalHeaderTextConfirm}>Reschedule</Text>
            </View>
          </View>

          <View style={{ width: '90%', marginTop: hp('2%') }}>
            <Text
              style={{
                color: Colors.border,
                fontFamily: Font.bold,
                fontSize: FontSize.medium,
                alignSelf: 'flex-start',
              }}>
              Reschedule date
              <Text style={{ color: Colors.darkPink }}>*</Text>
            </Text>
            <DropDownMenu
              labelName={'--Select--'}
              labelKey={'value'}
              valueKey={'value'}
              listItems={Data.referredBy}
              valueChangeHandler={stateHandler}
              Width={'100%'}
            />

            <View style={{ marginTop: 10 }} />

            <Text
              style={{
                color: Colors.border,
                fontFamily: Font.bold,
                fontSize: FontSize.medium,
                alignSelf: 'flex-start',
              }}>
              Reschedule time
              <Text style={{ color: Colors.darkPink }}>*</Text>
            </Text>
            <DropDownMenu
              labelName={'--Select--'}
              labelKey={'value'}
              valueKey={'value'}
              listItems={Data.referredBy}
              valueChangeHandler={stateHandler}
              Width={'100%'}
            />

            <View style={{ marginTop: 10 }} />

            <Text
              style={{
                color: Colors.border,
                fontFamily: Font.bold,
                fontSize: FontSize.medium,
                alignSelf: 'flex-start',
              }}>
              Reschedule reason
              <Text style={{ color: Colors.darkPink }}>*</Text>
            </Text>
            <DropDownMenu
              labelName={'--Select--'}
              labelKey={'value'}
              valueKey={'value'}
              listItems={Data.referredBy}
              valueChangeHandler={stateHandler}
              Width={'100%'}
            />

            <View
              style={{
                width: '100%',
                height: 50,
                flexDirection: 'row',
                backgroundColor: Colors.card,
                justifyContent: 'space-between',
                borderRadius: 5,
                marginTop: 20,
              }}>
              <InputField
                placeholder={''}
                value={otp}
                isValid={!isValidOtp}
                maxLength={6}
                validationMsg={otpValidationMsg}
                onChangeHandler={otpChangeHandler}
                textInputContainer={styles.otpTextContainer1}
                isTransparent={true}
              />
              <TouchableOpacity
                style={{ flexDirection: 'row', alignSelf: 'center' }}
                onPress={() => otpDismissHandler()}>
                <Fa5Icons name="redo" color={Colors.border} size={16} />
                <Text style={styles.resendOtpPayment}>Resend OTP</Text>
              </TouchableOpacity>
            </View>
          </View>

          <PageNumber number={58} />
          <View style={styles.bottomContainer}>
            <Button
              title={'Submit'}
              buttonTextStyle={{ fontSize: FontSize.large }}
              buttonStyle={styles.buttonStyle}
              onPress={() => SubmitHandler()}
            />
          </View>
        </View>
      </View>
    </Modal>
  );
}

function PageNumber({ number }) {
  return (
    <View
      style={{
        position: 'absolute',
        right: 0,
        bottom: 0,
        margin: 10,
        fontFamily: FontMagneta.bold,
        color: Colors.greenBlue,
        fontSize: FontSize.medium,
      }}>
      <Text>{number}</Text>
    </View>
  );
}

OtpModalPayment.defaultProps = {
  title: 'Enter OTP',
};

OtpModal.defaultProps = {
  mobileNo: '987654321',
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    // alignItems: 'center',
    backgroundColor: '#00000060',
  },
  modalView: {
    width: '100%',
    minHeight: '46%',
    backgroundColor: 'white',
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeaderContainer: {
    width: '80%',
    height: headerHeight,
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 2,
  },
  headerBackButton: {
    width: '25%',
    alignItems: 'center',
  },
  headerTitle: {
    width: '80%',
    alignItems: 'center',
  },
  modalHeaderText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
  },
  descriptionContainer: {
    height: descriptionHeight,
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: 'flex-start',
    // backgroundColor: '#aaa',
  },
  descriptionText: {
    width: '80%',
    // color: Colors.text,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  sendToContainer: {
    height: descriptionHeight,
    justifyContent: 'flex-end',
    paddingHorizontal: 20,
    paddingVertical: descriptionHeight / 5,
  },
  sendToText: {
    color: Colors.text,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
  },
  otpTextContainer: {
    width: '64%',
    fontFamily: FontMagneta.medium,
    backgroundColor: Colors.card,
    // borderColor: Colors.primary,
    // shadowColor: Colors.primary,
    // shadowOffset: {
    //   width: 0,
    //   height: 2,
    // },
    // shadowOpacity: 0.25,
    // shadowRadius: 4,
  },
  otpTextContainer1: {
    height: 46,
    flex: 1,
    alignSelf: 'center',
    borderWidth: 1,
    borderRadius: 8,
    //marginVertical: 2,
    padding: 12,
    elevation: 0,
    fontFamily: FontMagneta.medium,
    shadowColor: 'transparent',
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 0,
    },
    borderColor: 'red',
    // backgroundColor: 'red',
  },
  bottomContainer: {
    height: bottomContainerHeight,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: descriptionHeight / 3,
    marginTop: hp('1%'),
    // paddingBottom: 10,
    // backgroundColor: '#aaa',
  },
  bottomTextContainer: {
    height: descriptionHeight / 1.2,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    textDecorationLine: 'underline',
    textDecorationStyle: 'double',
    textDecorationColor: Colors.primary,
    marginBottom: hp('1.5%'),
  },
  buttonStyle: {
    minWidth: hp('15%'),
    height: hp('5%'),
    borderRadius: hp('5%'),
  },
  // OtpPayment
  modalViewOtpPayment: {
    width: '100%',
    minHeight: hp('30%'),
    maxHeight: hp('30'),
    backgroundColor: 'white',
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeaderTextOtpPayment: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  boxViewOtpPayment: {
    width: '85%',
    height: 50,
    flexDirection: 'row',
    backgroundColor: Colors.card,
    justifyContent: 'space-between',
    borderRadius: 5,
    marginTop: 20,
  },
  resendOtpPayment: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    marginHorizontal: 10,
  },
  // SuccessModal
  modalViewSuccess: {
    width: '100%',
    minHeight: '30%',
    backgroundColor: 'white',
    padding: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  circleSuccess: {
    alignItems: 'center',
    height: 50,
    width: 50,
    backgroundColor: Colors.border,
    borderRadius: 25,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 10,
  },
  borderTextSuccess: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    marginVertical: 15,
  },
  blackTextSuccess: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  modalViewConfirm: {
    width: '100%',
    minHeight: hp('30%'),
    backgroundColor: 'white',
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  modalHeaderTextConfirm: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  textConfrimNumber: {
    color: Colors.border,
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.medium,
  },
  containerConfirm: {
    width: '85%',
    //minHeight: 140,
    justifyContent: 'space-between',
    // paddingTop: 30,
    alignItems: 'center',
    flexDirection: 'row',
  },
  buttonGreenConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkPink,
    borderRadius: 50,
  },
  buttonPinkConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkGreen,
    borderRadius: 50,
  },
  messageTextConatiner: {
    width: wp('80%'),
    height: hp('10%'),
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  textColorPink: {
    borderColor: Colors.card,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    width: '100%',
    height: hp('10%'),
    //elevation: 2,
    alignSelf: 'center',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    borderWidth: 1,
    textAlignVertical: 'top',
  },
});
