import React, {Component, useEffect, useState} from 'react';
import {StyleSheet, View, Modal, Text} from 'react-native';
import FaIcon5 from 'react-native-vector-icons/FontAwesome5';
import Button from '../Button';
import Colors from '../../config/Colors';
import GlobalStyles from '../../config/Styles';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

function CardConatiner({imgSrc, line, status}) {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.circleConatiner}>
        {status ? (
          <FaIcons
            name={'check-circle'}
            color={Colors.darkGreen}
            size={hp('2.8%')}
          />
        ) : (
          <View style={styles.imageConatiner} />
        )}
      </View>
      {line ? <View style={styles.lineContainer} /> : null}
    </View>
  );
}

const TimeLineContainer = ({status}) => {
  return (
    <View style={styles.timelineContainer}>
      <CardConatiner line={true} status={status > 0} />
      <CardConatiner status={status > 1} line={true} />
      <CardConatiner status={status > 2} line={true} />
      <CardConatiner status={status > 3} line={true} />
      <CardConatiner status={status > 4} line={false} />
    </View>
  );
};

const styles = StyleSheet.create({
  timelineContainer: {
    width: '95%',
    height: hp('10%'),
    paddingHorizontal: hp('2%'),
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomWidth: 1,
    borderBottomColor: Colors.eWhite,
  },
  cardContainer: {
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
  },
  circleConatiner: {
    width: hp('3.5%'),
    height: hp('3.5%'),
    borderColor: Colors.cWhite,
    borderWidth: 1,
    borderRadius: hp('3.5%'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  lineContainer: {
    width: 35,
    height: 1,
    backgroundColor: Colors.cWhite,
    alignSelf: 'center',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageConatiner: {
    width: hp('2.5%'),
    height: hp('2.5%'),
    backgroundColor: Colors.bWhite,
    borderRadius: hp('3%'),
  },
});

export default TimeLineContainer;
