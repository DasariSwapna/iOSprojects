import React from 'react';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import Colors from '../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../config/Fonts';
import Images from '../../constants/Icons';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';
export default function MyTaskHeader({ ...props }) {
  return (
    <View style={styles.rowDirection}>
      <View style={styles.imageContainer}>
        {props.image == "req" ? <Image source={props.imageSource} style={styles.imgStyle} /> :
          <Image source={{ uri: props.imageSource }} style={styles.imgStyle} />}
      </View>
      <View style={styles.nameContainer}>
        <Text style={[styles.textHeader, { color: props.textColor }]}>{props.title}</Text>
        <View style={styles.numberOfTaskContainer}>
          <Text style={styles.textTaskNumber}>{props.numberOfTask}</Text>
          <Text style={styles.textTask}>{props.textTask}</Text>
        </View>
      </View>
      {props.isQrScannerAvailable ?
        <TouchableOpacity style={styles.qrIconContainer} onPress={props.qrClickHandler}>
          <Image source={Images.qrScanner} style={styles.qrImgStyle} />
        </TouchableOpacity> :
        null
      }
      {props.value > 0 ?
        <View style={{ flex: 0.2, alignItems: 'flex-end', justifyContent: 'flex-start', height: hp('5%') }}>
          <Text style={[styles.textHeader, { color: props.textColor }]}>{props.value}</Text>
        </View> :
        null
      }
    </View>
  );
}

const styles = StyleSheet.create({
  rowDirection: {
    flexDirection: 'row',
    width: '100%',
    paddingHorizontal: wp('5%'),
    alignItems: 'center'
  },
  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10,
    flex: 0.6,
    paddingHorizontal: 10
  },
  imageContainer: {
    flex: 0.2,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 2

  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  numberOfTaskContainer: {
    flexDirection: 'row',
    marginTop: 3,
    justifyContent: 'flex-start',
    alignItems: 'center'
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black,
    paddingBottom: 2
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
    marginLeft: 8
  },
  imgStyle: {
    height: hp('6.5%'),
    width: hp('6.5%'),

  },
  qrIconContainer: {
    flex: 0.2,
    marginHorizontal: '1%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  qrImgStyle: {
    width: wp('7.5%'),
    height: wp('8%')
  }


});
