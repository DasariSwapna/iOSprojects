import React from 'react';
import {View, Text, StyleSheet, ScrollView} from 'react-native';
import {Button} from 'react-native-paper';
import Colors from '../../config/Colors';
import {Font, FontSize, FontMagneta} from '../../config/Fonts';

const data1 = [
  {
    title: 'Maternity Screening',
    amount: '5000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'QFPCR',
    amount: '8000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'Hb Pathies',
    amount: '9000/-INR',
    type: 'Blood sample',
  },
  {
    title: 'Free Testosterone',
    amount: '9000/-INR',
    type: 'Urine sample',
  },
];

function Row({column1, column2, column3, isheader, isBody}) {
  return (
    <View
      style={{
        width: '100%',
        flexDirection: 'row',
        flex: 3,
      }}>
      <View
        style={[
          styles.columnContainer1,
          isheader && styles.header,
          isBody && styles.body,
        ]}>
        <Text
          style={[
            isheader && styles.textColorBoldPink,
            isBody && styles.textColorPink,
          ]}>
          {column1}
        </Text>
      </View>
      <View
        style={[
          styles.columnContainer,
          isheader && styles.header,
          isBody && styles.body,
        ]}>
        <Text
          style={[
            isheader && styles.textColorBoldBlack,
            isBody && styles.textColorBlackMagenta,
          ]}>
          {column2}
        </Text>
      </View>
      <View
        style={[
          styles.columnContainer,
          isheader && styles.header,
          isBody && styles.body,
        ]}>
        <Text
          style={[
            isheader && styles.textColorBoldBlack,
            isBody && styles.textColorBlack,
          ]}>
          {column3}
        </Text>
      </View>
    </View>
  );
}

function Table({data = [], removeAction, accType = []}) {
  const [accountType, setAccountType] = React.useState('');

  return (
    <View style={{padding: 0}}>
      <ScrollView horizontal>
        <ScrollView>
          <Row
            isheader
            column1={'Test Panel'}
            column2={'Amount'}
            column3={'Sample Type'}
          />
          {data.map((item, index) => {
            return (
              <View key={index}>
                <Row
                  isBody
                  column1={item.title}
                  column2={item.amount}
                  column3={item.type}
                />
              </View>
            );
          })}
        </ScrollView>
      </ScrollView>
    </View>
  );
}

export default Table;

const styles = StyleSheet.create({
  columnContainer: {
    width: 100,
    // flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    // marginVertical: 1,
    paddingHorizontal: 4,
    paddingVertical: 7,
  },
  columnContainer1: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
    // marginVertical: 1,
    paddingHorizontal: 6,
    paddingVertical: 7,
  },
  header: {
    borderColor: Colors.black,
    borderTopWidth: 0.5,
    borderLeftWidth: 0.5,
    borderRightWidth: 0.5,
  },
  body: {
    backgroundborderColorColor: Colors.bgLightGray,
    borderWidth: 0.5,
  },
  textColorBoldBlack: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.regular,
    color: Colors.black,
  },
  textColorBoldPink: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.regular,
    color: Colors.border,
  },
  textColorBlack: {
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.black,
  },
  textColorPink: {
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.border,
  },
  textColorBlackMagenta: {
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.black,
  },
});
