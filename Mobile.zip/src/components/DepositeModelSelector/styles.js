"use strict";

import { StyleSheet, Dimensions } from "react-native";

const { height, width } = Dimensions.get("window");
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import Colors from "../../config/Colors";
import { Font } from "../../config/Fonts";

const PADDING = 8;
// const BORDER_RADIUS = 5;
const FONT_SIZE = 16;
const HIGHLIGHT_COLOR = "rgba(0,118,255,0.9)";
const OPTION_CONTAINER_HEIGHT = 400;

export default StyleSheet.create({
  overlayStyle: {
    width: width,
    height: height,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "rgba(0,0,0,0.7)"
  },

  optionContainer: {
    backgroundColor: Colors.white,
    justifyContent: "center",
    maxHeight: hp("90%"),
    width: wp("84%")
  },

  cancelContainer: {
    left: width * 0.1,
    top: (height - OPTION_CONTAINER_HEIGHT) / 2 + 10
  },

  selectTextStyle: {
    textAlign: "left",
    fontSize: hp("2.1%"),
    color: Colors.bgDarkGray,
    width: wp("62%"),
    marginLeft: wp("-0.5"),
    fontFamily: Font.regular
  },

  cancelStyle: {
    padding: PADDING
  },

  cancelTextStyle: {
    textAlign: "center",
    color: "#333",
    fontSize: FONT_SIZE
  },

  optionStyle: {
    padding: PADDING
  },

  optionTextStyle: {
    color: Colors.black,
    fontSize: hp("2.0%"),
    paddingVertical: wp("2%"),
    marginLeft: wp("2.9"),
    textAlign: "left",
    fontFamily: Font.regular
  },

  sectionStyle: {
    padding: PADDING * 2,
    borderBottomWidth: 1
  },

  sectionTextStyle: {
    color: Colors.black,
    fontSize: hp("2.0%"),
    marginLeft: wp("2.9%")
  }
});
