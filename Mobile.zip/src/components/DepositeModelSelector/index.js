"use strict";
import React, { PropTypes } from "react";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import Entypo from "react-native-vector-icons/Entypo";
import {
  View,
  StyleSheet,
  Dimensions,
  Modal,
  Text,
  ScrollView,
  TouchableOpacity,
  Platform,
  ActivityIndicator
} from "react-native";

import styles from "./styles";
import BaseComponent from "./BaseComponent";
import {
  heightPercentageToDP,
  widthPercentageToDP
} from "react-native-responsive-screen";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp
} from "react-native-responsive-screen";
import Colors from "../../config/Colors";

let componentIndex = 0;

const defaultProps = {
  data: [],
  onChange: () => { },
  initValue: " Please select!",
  style: {},
  selectStyle: {},
  optionStyle: {},
  optionTextStyle: {},
  sectionStyle: {},
  sectionTextStyle: {},
  cancelStyle: {},
  cancelTextStyle: {},
  overlayStyle: {},
  cancelText: "cancel"
};

export default class ModalPicker extends BaseComponent {
  constructor() {
    super();
    this._bind("onChange", "open", "close", "renderChildren");
    this.state = {
      animationType: "slide",
      modalVisible: false,
      transparent: false,
      selected: "please select"
    };
  }

  componentDidMount() {
    this.setState({ selected: this.props.initValue });
    this.setState({ cancelText: this.props.cancelText });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.initValue != this.props.initValue) {
      this.setState({ selected: nextProps.initValue });
    }
  }

  onChange(item, id) {
    console.log("ityem", item);
    this.props.onChange(item);
    id == "CancelReason" ?
      this.setState({ selected: item.lc_C_REASON })
      : id == "deposittime" ? this.setState({ selected: item.MSG_TIME }) :
        this.setState({ selected: item.msg_TIME.substring(0, 5) });

    this.close();
  }

  close() {
    this.setState({
      modalVisible: false
    });
  }

  open() {
    this.setState({
      modalVisible: true
    });
  }

  renderSection(section) {
    return (
      <View
        key={section.key}
        style={[styles.sectionStyle, this.props.sectionStyle]}
      >
        <Text style={[styles.sectionTextStyle, this.props.sectionTextStyle]}>
          {section.label}
        </Text>
      </View>
    );
  }

  renderOption(option, id) {
    return (
      <TouchableOpacity
        key={option.key}
        onPress={() => this.onChange(option, id)}
      >
        <View style={[styles.optionStyle, this.props.optionStyle]}>
          <Text style={[styles.optionTextStyle, this.props.optionTextStyle]}>
            {id == "CancelReason" ?
              option.lc_C_REASON
              : id == "deposittime" ? option.MSG_TIME :
                option.msg_TIME.substring(0, 5)}

          </Text>
        </View>
      </TouchableOpacity>
    );
  }
  renderOptionList() {
    const id = this.props.id;
    if (this.props.data != null) {
      var options = this.props.data.map(item => {
        return this.renderOption(item, id);
      });
    }

    return (
      <TouchableOpacity
        style={[styles.overlayStyle, this.props.overlayStyle]}
        key={"modalPicker" + componentIndex++}
        onPressOut={() =>
          this.setState({
            modalVisible: false
          })}
      >
        <View style={styles.optionContainer}>
          <ScrollView keyboardShouldPersistTaps="always">
            <View style={{ paddingHorizontal: 10 }}>
              {options}
            </View>
          </ScrollView>
        </View>
      </TouchableOpacity>
    );
  }

  renderChildren() {
    if (this.props.children) {
      return this.props.children;
    }
    return (
      <>
        <View style={{ width: widthPercentageToDP('80%'), flexDirection: 'row', alignItems: "center", justifyContent: 'flex-start', marginHorizontal: wp('2%') }}>
          <View style={{ width: widthPercentageToDP('77%'), }}>
            <Text style={[styles.selectTextStyle, this.props.selectTextStyle, { color: this.state.selected == "Select time" ? Colors.bgDarkGray : Colors.black }]}>
              {this.state.selected.length > 25
                ? this.state.selected.substring(0, 25) + "..."
                : this.state.selected}
            </Text>
          </View>
          <View  style={{
                marginLeft : widthPercentageToDP('-3.5%'),
                color: Colors.border
              }}>
            <Entypo
              style={{
                marginRight : widthPercentageToDP('1.5%'),
                color: Colors.border
              }}
              name="chevron-small-down"
              size={heightPercentageToDP("3.5%")}
            />
          </View>

        </View>
        <View style={{ borderBottomWidth: 1, borderBottomColor: Colors.dWhite, paddingTop: hp('1.2%') }} />
      </>
    );
  }

  render() {
    const dp = (
      <Modal
        transparent={true}
        ref="modal"
        visible={this.state.modalVisible}
        onRequestClose={this.close}
        animationType={this.state.animationType}
      >
        {this.renderOptionList()}
      </Modal>
    );
    if (this.props != null && this.props != "") {
      return (
        <View style={this.props.style}>
          {dp}
          <TouchableOpacity onPress={this.open}>
            {this.renderChildren()}
          </TouchableOpacity>
        </View>
      );
    } else {
      <ActivityIndicator />;
    }
  }
}
ModalPicker.defaultProps = defaultProps;
