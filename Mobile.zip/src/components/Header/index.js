import React from 'react';
import {
  Dimensions,
  Image,
  StyleSheet,
  StatusBar,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import AntIcons from 'react-native-vector-icons/AntDesign';
import SimpleIcons from 'react-native-vector-icons/SimpleLineIcons';
import IonIcons from 'react-native-vector-icons/Ionicons';
import Colors from '../../config/Colors';
import Images from '../../constants/Images';
import {Font, FontSize} from '../../config/Fonts';
import I18n from '../../locale/i18n';

const {width, height} = Dimensions.get('screen');
const paddingWidth = width * 0.05;
const itemWidth = (width - paddingWidth * 2) / 7;
const iconWidth = itemWidth;
const textWidth = (width - paddingWidth * 2) / 4;
const icon = width * 0.06;

const textConatinerWidth = (width - paddingWidth * 2) / 4;
const textConatinerHeight = height * 0.04;
const lineWidth = (width - (iconWidth * 4 + paddingWidth * 2)) / 3;

function Line() {
  return (
    <View>
      <View
        style={{
          left: itemWidth * 1.2,
          bottom: (itemWidth * 1.2) / 2,
          width: lineWidth * 0.8,
          height: 0.5,
          borderStyle: 'dashed',
          borderWidth: 0.5,
          borderRadius: 1,
          borderColor: Colors.primary,
        }}
      />
    </View>
  );
}

function HeaderItem({status, title, iconName}) {
  return (
    <View>
      <View
        style={[
          {
            width: itemWidth * 1.2,
            height: itemWidth * 1.2,
            alignItems: 'center',
            justifyContent: 'center',
            borderWidth: 2,
            borderRadius: (itemWidth * 1.2) / 2,
            borderColor: Colors.primary,
            backgroundColor: Colors.background,
          },
          status && {backgroundColor: Colors.primary},
        ]}>
        <View
          style={{
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {status ? (
            <IonIcons
              name={'checkmark'}
              size={icon}
              color={Colors.background}
            />
          ) : iconName == 'user' ? (
            <AntIcons name={iconName} size={icon} color={Colors.primary} />
          ) : (
            <SimpleIcons name={iconName} size={icon} color={Colors.primary} />
          )}
        </View>
      </View>
      {status && iconName != 'lock' && <Line />}
      <View
        style={{
          maxWidth: textWidth,
          height: textConatinerHeight,
          // backgroundColor: 'green',
        }}>
        <Text numberOfLines={2} style={styles.iconText}>
          {title}
        </Text>
      </View>
    </View>
  );
}

export default function Header({selected = 0, ...props}) {
  return (
    <View style={styles.headerContainer}>
      <HeaderItem
        title={I18n.t('signUp.signup_header_personal')}
        iconName={'user'}
        status={selected > 0}
      />
      <HeaderItem
        title={I18n.t('signUp.signup_header_edu')}
        iconName={'graduation'}
        status={selected > 1}
      />
      <HeaderItem
        title={I18n.t('signUp.signup_header_location')}
        iconName={'location-pin'}
        status={selected > 2}
      />
      <HeaderItem
        title={I18n.t('signUp.signup_header_passowrd')}
        iconName={'lock'}
        status={selected > 3}
        isFinished
      />
    </View>
  );
}

export function DrawerHeader({
  title,
  role,
  openDrawerHandler,
  notiHandler,
  isHome,
  isStop,
  isStart,
  count,
}) {
  return (
    <>
      <ImageBackground
        source={headerBgImg}
        style={{height: screenHeight * 0.28}}>
        <View
          style={{
            width: '100%',
            height: '35%',
            alignItems: 'center',
            paddingVertical: 10,
          }}>
          <Image source={lrhLogo} style={{width: 72, height: 72}} />
        </View>
        <View
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            padding: 20,
            justifyContent: 'space-between',
            // backgroundColor: 'yellow',
          }}>
          <View style={{flexDirection: 'row', alignItems: 'center'}}>
            <TouchableOpacity
              style={{paddingHorizontal: 4}}
              onPress={isHome || isStop ? () => openDrawerHandler() : null}>
              {!isStop ? (
                <View
                  style={[
                    {
                      width: 36,
                      height: 36,
                      alignItems: 'center',
                      justifyContent: 'center',
                      borderRadius: 18,
                      overflow: 'hidden',
                      // elevation: 2,
                    },
                    !isHome
                      ? {
                          borderWidth: 0.5,
                          borderColor: BG_BLUE1,
                          backgroundColor: BG_GRAY,
                        }
                      : {},
                  ]}>
                  {isHome ? (
                    <View style={{elevation: 2}}>
                      <EnIcons name={'menu'} size={32} color={TXT_WHITE} />
                    </View>
                  ) : (
                    <Text
                      style={{
                        color: '#7a7676',
                        fontFamily: 'Poppins-SemiBold',
                      }}>
                      {title.trim().charAt(0)}
                    </Text>
                  )}
                </View>
              ) : (
                <FaIcons name="chevron-left" color={'#fff'} size={24} solid />
              )}
            </TouchableOpacity>
            {isHome ||
              (!isStop && (
                <View>
                  <Text
                    style={{
                      color: '#fff',
                      fontSize: 18,
                      fontWeight: '600',
                      fontFamily: 'Poppins-Medium',
                      textTransform: 'capitalize',
                    }}>
                    {title}
                  </Text>
                  <Text style={{color: '#fff', textTransform: 'capitalize'}}>
                    {role}
                  </Text>
                </View>
              ))}
          </View>

          <View>
            {isHome && (
              <TouchableOpacity onPress={() => notiHandler()}>
                {count > 0 && (
                  <View
                    style={{
                      width: 16,
                      height: 16,
                      justifyContent: 'center',
                      alignItems: 'center',
                      borderRadius: 8,
                      position: 'absolute',
                      top: -2,
                      left: 8,
                      zIndex: 100,
                      backgroundColor: BG_RED1,
                    }}>
                    <Text style={{fontSize: 10, color: TXT_WHITE}}>
                      {count}
                    </Text>
                  </View>
                )}
                <View style={{zIndex: -100}}>
                  <FaIcons5
                    name="bell"
                    color={'#fff'}
                    size={24}
                    solid
                    style={{elevation: 5}}
                  />
                </View>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </ImageBackground>
    </>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: paddingWidth,
    paddingVertical: 16,
    backgroundColor: Colors.background,
  },
  itemContainer: {
    width: itemWidth,
    // alignItems: 'center',
    // justifyContent: 'flex-start',
    backgroundColor: 'gray',
  },
  iconContainer: {
    width: iconWidth,
    height: iconWidth,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderRadius: iconWidth / 2,
    margin: 6,
    borderColor: Colors.primary,
  },
  selectedContainer: {
    width: textConatinerWidth,
    height: textConatinerHeight,
    alignItems: 'center',
  },
  iconText: {
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    textAlign: 'center',
  },
});
