import React, { useRef } from 'react';
import { Text, View, StyleSheet, TouchableOpacity,Platform } from 'react-native';

import Colors from '../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { TextInput } from 'react-native-paper';

function TextInputComponent({
  labelName,
  isValid,
  validationMsg,
  onChangeHandler,
  keyboardType,
  maxLength,
  value,
  Width,
  color,
  multiline,
  editable,
  isExtra,
  iconPressed,
}) {
  return (
    <View style={{ width: Width ? Width : '85%', alignSelf: 'center' }}>
      <TextInput
        mode="flat"
        label={labelName}
        style={{ fontSize: FontSize.semiLarge }}
        underlineColor={Colors.textUnderlineColor}
        onChangeText={onChangeHandler}
        keyboardType={keyboardType}
        maxLength={maxLength}
        value={value}
        multiline={multiline}
        editable={editable}
        theme={{
          colors: {
            // placeholder: Colors.bgDarkGray,
            //selectionColor : Colors.bgDarkGray,
    
            text: Colors.black,
            primary:  color ? color : Colors.bgDarkGray,
            background: 'transparent',
            placeholder: color ? color : Colors.bgDarkGray,

          },
          fonts: {
            regular: {
              fontFamily: Font.regular,
              fontWeight: 'large',
              lineHeight:hp('3%')
            },
          },
        }}
        right={
          isExtra == true ? (
            <TextInput.Icon name="map-marker" onPress={iconPressed} color={Colors.border} />
          ) : null
        }
      />

      {isValid && (
        <Text style={styles.textValidationMsg}>
          {isValid ? validationMsg : ''}
        </Text>
      )}
    </View>
  );
}

export default TextInputComponent;

const styles = StyleSheet.create({
  textValidationMsg: {
    width: '100%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
  },
});
