import React, { useRef } from 'react';
import {
  Text,
  View,
  Image,
  StyleSheet,
  TextInput,
} from 'react-native';

import Colors from '../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

import Icon from 'react-native-vector-icons/FontAwesome';


function FilterBar({ onChangehandler, value }) {
  return (
    <View style={styles.searchSection}>
      <TextInput
        style={styles.input}
        placeholderTextColor={Colors.cWhite}
        placeholder="Search"
        underlineColorAndroid="transparent"
        onChangeText={onChangehandler}
        value={value}
      />
      <Icon style={styles.searchIcon} name="search" size={24} color={Colors.dWhite} />
    </View>
  );
}

export default FilterBar;

const styles = StyleSheet.create({
  searchSection: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: hp('7%'),
    paddingHorizontal: hp('2%')
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    flex: 1,
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.black,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
});