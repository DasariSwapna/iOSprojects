import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  Modal,
  StyleSheet,
  View,
  TouchableOpacity,
  Dimensions,
  Text,
} from 'react-native';
import FeatherIcon from 'react-native-vector-icons/Feather';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../config/Fonts';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { Calendar } from 'react-native-calendars';
import ModalSelector from '../../components/ModalSelector';
const { width, height } = Dimensions.get('screen');
const descriptionHeight = height * 0.046;
const bottomContainerHeight = height * 0.16;

export default function OtpModal({
  visible,
  isValidOtp,
  setVisible,
  otpValidationMsg,
  CallBack,
  time,
  call,
  datecall,
}) {
  const [modalVisible, setModalVisible] = useState(false);
  const [mins, setMins] = useState(new Date().getMinutes());
  const [hours, setHours] = useState(new Date().getHours());
  const [selectedDate, setSelectedDate] = useState();
  const [markedDates, setMarkedDates] = useState();
  const [timevalue, setTimevalue] = useState();
  const [timetext, setTimeText] = useState(time);
  useEffect(() => {
    setModalVisible(visible);
    console.log('timetextttt', timetext)
    if (timetext != undefined && timetext != '' && timetext != []) {
      const newData = timetext.filter(item => {
        return item.available != 'NA';
      });
      setTimeText(newData);
    }
  }, [visible]);
  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };
  console.log(isValidOtp, otpValidationMsg);
  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        toggleVisible(!modalVisible);
      }}>
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <Calendar
            markingType={'custom'}
            hideDayNames={false}
            minDate={new Date()}
            markedDates={markedDates}
            onDayPress={day => {
              setSelectedDate(day.dateString);
              let markedDates = {};
              markedDates[day.dateString] = {
                customStyles: {
                  container: {
                    backgroundColor: Colors.border,
                  },
                  text: {
                    color: Colors.white,
                    fontFamily: FontMagneta.medium,
                  },
                },
              };
              setMarkedDates(markedDates);
              datecall(day.dateString);
            }}
            style={{
              height: hp('45%'),
              backgroundColor: 'transparent',
              width: wp('100%'),
              marginBottom: hp('2%'),
            }}
            theme={{
              backgroundColor: 'transparent',
              calendarBackground: 'transparent',
              textSectionTitleColor: Colors.border,
              textSectionTitleDisabledColor: '#d9e1e8',
              selectedDayBackgroundColor: Colors.border,
              selectedDayTextColor: Colors.background,
              todayTextColor: Colors.border,
              dayTextColor: '#2d4150',
              textDisabledColor: '#d9e1e8',
              dotColor: Colors.border,
              selectedDotColor: Colors.background,
              arrowColor: Colors.border,
              disabledArrowColor: '#d9e1e8',
              monthTextColor: Colors.border,
              indicatorColor: Colors.border,
              textDayFontFamily: FontMagneta.medium,
              textMonthFontFamily: Font.extraBold,
              textDayHeaderFontFamily: Font.bold,
              textDayFontWeight: '300',
              textMonthFontWeight: 'bold',
              textDayHeaderFontWeight: '400',
              textDayFontSize: 14,
              textMonthFontSize: 14,
              textDayHeaderFontSize: 14,

              'stylesheet.calendar.header': {
                monthText: {
                  fontSize: FontSize.large,
                  fontFamily: Font.extraBold,
                  fontWeight: '500', // default is 300
                  color: Colors.border,
                  margin: 10, // default
                },
              },
            }}
          />
          <View style={{ marginVertical: hp('2%'), marginTop: hp('5%') }}>
            {timetext == [] || timetext == '' ? null : (
              <ModalSelector
                data={timetext}
                initValue={'Select time'}
                onChange={option => {
                  setTimevalue(option.msg_TIME);
                }}
              />
            )}
          </View>
          <View
            style={{
              flexDirection: 'row',
              marginBottom: 20,
              marginTop: hp('2%'),
              justifyContent: 'space-evenly',
            }}>
            <TouchableOpacity
              style={{
                width: wp('40%'),
                height: hp('5.5%'),
                marginHorizontal: 10,
                borderRadius: 40,
                backgroundColor: Colors.button,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={() => {
                setModalVisible(!modalVisible);
                CallBack();
              }}>
              <FeatherIcon name="x" size={20} color={Colors.white} />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                width: wp('40%'),
                height: hp('5.5%'),
                marginHorizontal: 10,
                borderRadius: 40,
                backgroundColor: Colors.teal,
                alignItems: 'center',
                justifyContent: 'center',
              }}
              onPress={() => {
                call(selectedDate + 'T' + timevalue);
              }}>
              <FeatherIcon name="check" size={20} color={'white'} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

OtpModal.propTypes = {
  otp: PropTypes.string.isRequired,
  mobileNo: PropTypes.string,
  visible: PropTypes.bool,
  isValidOtp: PropTypes.bool,
  setOtp: PropTypes.func,
  setVisible: PropTypes.func,
  otpSubmitHandler: PropTypes.func,
};

OtpModal.defaultProps = {
  mobileNo: '987654321',
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: '#00000060',
  },
  modalView: {
    width: wp('100%'),
    height: hp('70%'),
    backgroundColor: Colors.background,
    padding: 12,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },

  bottomContainer: {
    height: bottomContainerHeight,
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: descriptionHeight / 3,
    marginTop: hp('1%'),
  },
});
