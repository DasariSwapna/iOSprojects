import React, { useEffect, useState } from "react";
import { TouchableOpacity, Text } from "react-native";
import MaIcons from "react-native-vector-icons/MaterialCommunityIcons";

const CheckCircle = ({ length, onPress, tick, selceted }) => {
  // const select = selceted != "" ? selceted : false
  // const [selected, setSelected] = useState(select);

  return (
    <TouchableOpacity
      style={[
        {
          height: length,
          width: length,
          borderRadius: 20,
          borderWidth: 1,
          elevation: 2,
          alignSelf: "center",
          alignItems: "center",
          justifyContent: "center",
          borderColor: "#9E2575",
          backgroundColor: "#FFFFFF"
        }
      ]}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      onPress={() => {
        // setSelected(!selected);
        onPress();
      }}
      activeOpacity={0.6}
    >
      {selceted && <MaIcons name="check" color={"#9E2575"} size={tick} />}
    </TouchableOpacity>
  );
};


export const CheckCircle1 = ({ length, onPress, tick, selected }) => {
 // const [selected, setSelected] = useState(false);
  return (
    <TouchableOpacity
      style={[
        {
          height: length,
          width: length,
          borderRadius: 20,
          borderWidth: 1,
          elevation: 2,
          alignSelf: "center",
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#FFFFFF"
        }, {
          borderColor: selected ? "#9E2575" : "#AFAFAF"
        }
      ]}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      onPress={() => {
        //setSelected(!selected);
       
        onPress();
      }}
      activeOpacity={0.6}
    >
      {selected && <MaIcons name="check" color={"#9E2575"} size={tick} />}
    </TouchableOpacity>
  );
};

export default CheckCircle;
