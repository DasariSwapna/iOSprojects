import React, { useEffect, useState } from "react";
import { TouchableOpacity } from "react-native";
import MaIcons from "react-native-vector-icons/MaterialCommunityIcons";
import { BG_GREEN, BG_GREEN1 } from "../../constants/color";

const CheckBox = ({ length, checkMarkHandler }) => {
  const [selected, setSelected] = useState(false);

  useEffect(() => {
    checkMarkHandler(selected);
  }, [selected]);

  return (
    <TouchableOpacity
      style={[
        {
          height: length,
          width: length,
          borderRadius: 2,
          borderWidth: 1,
          elevation: 2,
          alignSelf: "center",
          alignItems: "center",
          justifyContent: "center",
          borderColor: selected ? BG_GREEN1 : "#29272a",
          backgroundColor: selected ? BG_GREEN1 : "#fff",
        },
      ]}
      hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
      onPress={() => setSelected(!selected)}
      activeOpacity={0.6}
    >
      {selected && <MaIcons name="check" color={"#fff"} size={20} />}
    </TouchableOpacity>
  );
};

export default CheckBox;
