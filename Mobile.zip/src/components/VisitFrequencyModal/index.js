import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { Modal, StyleSheet, View, Text, TouchableOpacity, TextInput ,FlatList} from 'react-native';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../config/Fonts';
import { InputField } from '../InputField';
import Button from '../Button';
import Ionicons from 'react-native-vector-icons/Ionicons';
import MedicalCenterNameView from '../MedicalCenterNameView';
export function VisitFrequencyModal({
    visible,
    setVisible,
    dismissHandler,
    cancelHandler,
    visitClickHandler,title,data,pageNumber,
  
  }) {
    const [modalVisible, setModalVisible] = useState(false);
  
    useEffect(() => {
      setModalVisible(visible);
    }, [visible]);
  
    const toggleVisible = val => {
      setModalVisible(val);
      setVisible(val);
    };
    function PageNumber({ number }) {
        return (
          <View style={{ position: 'absolute', right: 0, bottom: 0, margin: 10 }}>
            <Text>{number}</Text>
          </View>
        );
      }
      const renderItem = ({ item }) => (
        <TouchableOpacity style={styles.mainContainer} onPress={()=>visitClickHandler(item)}>
     <Text style={styles.nameText}>{item.VISIT_NAME} - {item.VISIT_TIME.substring(0,5)}</Text>
     <View style={styles.bottonLine}/>
    </TouchableOpacity>

      )
  
    return (
      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={() => {
          toggleVisible(!modalVisible);
        }}>
        <View style={styles.centeredView}>
          <View style={styles.modalViewConfirm}>
            <View style={styles.modalHeaderContainer}>
              <View style={styles.headerBackButton}>
                <TouchableOpacity onPress={() => dismissHandler()}>
                  <Fa5Icons name="arrow-left" color={Colors.border} size={22} />
                </TouchableOpacity>
              </View>
              <View style={styles.headerTitle}>
                <Text style={styles.modalHeaderTextConfirm}>{title}</Text>
              </View>
              
            </View>
        
            <View style={styles.flatlistContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.flatlistInnerContainer}
          />
        </View>
            < PageNumber number={pageNumber} />
          </View>
        </View>
      </Modal>
    );
  }
  const styles = StyleSheet.create({
    centeredView: {
      flex: 1,
      justifyContent: 'flex-end',
      // alignItems: 'center',
      backgroundColor: '#00000060',
    },
    modalView: {
      width: '100%',
      minHeight: '50%',
      backgroundColor: 'white',
      padding: 12,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    modalHeaderContainer: {
      width: '80%',
      height: 40,
      alignSelf: 'flex-start',
      flexDirection: 'row',
      alignItems: 'center',
      marginVertical: 2,
    },
    headerBackButton: {
      width: '25%',
      alignItems: 'center',
    },
    headerTitle: {
      width: '80%',
      alignItems: 'center',
    },
    modalHeaderText: {
      color: Colors.text,
      fontFamily: Font.extraBold,
      fontSize: FontSize.extraLarge,
    },
    descriptionContainer: {
      paddingHorizontal: 20,
      paddingVertical: 10,
      alignItems: 'flex-start',
      // backgroundColor: '#aaa',
    },
    descriptionText: {
      // color: Colors.text,
      fontFamily: Font.bold,
      fontSize: FontSize.medium,
    },
    sendToText: {
      color: Colors.text,
      fontFamily: FontMagneta.medium,
      fontSize: FontSize.regular,
    },
    otpTextContainer: {
      width: '86%',
      fontFamily: FontMagneta.medium,
      backgroundColor: Colors.card,
      // borderColor: Colors.primary,
      shadowColor: Colors.primary,
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
    },
    otpTextContainer1: {
      height: 46,
      width: '92%',
      alignSelf: 'center',
      borderWidth: 1,
      borderRadius: 8,
      marginVertical: 2,
      padding: 12,
      elevation: 0,
      fontFamily: FontMagneta.medium,
      shadowColor: 'transparent',
      shadowOpacity: 0,
      shadowRadius: 0,
      shadowOffset: {
        width: 0,
        height: 0,
      },
      borderColor: Colors.card,
      backgroundColor: Colors.card,
    },
    bottomContainer: {
      minHeight: 140,
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingTop: 30,
      paddingBottom: 10,
      // backgroundColor: '#aaa',
    },
    bottomTextContainer: {
      alignItems: 'center',
      justifyContent: 'center',
    },
    bottomText: {
      color: Colors.text,
      fontFamily: Font.extraBold,
      textDecorationLine: 'underline',
      textDecorationStyle: 'double',
      textDecorationColor: Colors.primary,
    },
    buttonStyle: {
      minWidth: 160,
      height: 45,
      borderRadius: 25,
    },
    // OtpPayment
    modalViewOtpPayment: {
      width: '100%',
      minHeight: '25%',
      backgroundColor: 'white',
      padding: 12,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    modalHeaderTextOtpPayment: {
      color: Colors.border,
      fontFamily: Font.extraBold,
      fontSize: FontSize.large,
    },
    boxViewOtpPayment: {
      width: '85%', height: 50, flexDirection: 'row', backgroundColor: Colors.card, justifyContent: 'space-between', borderRadius: 5, marginTop: 20
    },
    resendOtpPayment: {
      color: Colors.border,
      fontFamily: Font.bold,
      fontSize: FontSize.medium,
      marginHorizontal: 10
    },
    // SuccessModal
    modalViewSuccess: {
      width: '100%',
      minHeight: '30%',
      backgroundColor: 'white',
      padding: 12,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },

   blackTextSuccess: {
      color: Colors.black,
      fontFamily: Font.regular,
      fontSize: FontSize.medium,
    },
    // Confirm Mobile Number
    modalViewConfirm: {
      width: '100%',
      height: '40%',
      backgroundColor: 'white',
      padding: 12,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: {
        width: 0,
        height: 2,
      },
      shadowOpacity: 0.25,
      shadowRadius: 4,
      elevation: 5,
    },
    modalHeaderTextConfirm: {
      color: Colors.border,
      fontFamily: Font.extraBold,
      fontSize: FontSize.large,
    },
    flatlistContainer:
    { 
        width: '100%', 
        alignItems: 'center', 
        height: '80%' ,
        marginVertical:'3%',
        padding:10,
       
    },
  flatlistInnerContainer:
    { 
    flexGrow: 1,
  
  
  },
    flatList:
      {
         flex: 1, 
         width: '100%',
         paddingHorizontal: 10 
        },
        nameText: {
            fontSize: FontSize.medium,
            fontFamily: FontMagneta.semiBold,
           
            color: Colors.border,
            paddingHorizontal:30,paddingBottom:'2%'
          },
          bottonLine:
          {
              width:'100%',
              alignItems:'center',
              justifyContent:'center',
              backgroundColor:Colors.card,
              height:1,
            },
            mainContainer: {
                width:'100%',
                paddingVertical:5,
                flexDirection:'column',
                alignItems:'center',
                marginTop:'1%'
              },
  
  });
  