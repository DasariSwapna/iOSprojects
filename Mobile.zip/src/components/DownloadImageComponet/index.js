/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet, Image } from 'react-native';
import { color } from 'react-native-reanimated';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import { Font } from '../../config/Fonts';
import Images from '../../constants/Images';
import IonIcons from 'react-native-vector-icons/Ionicons';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

export function DownloadImageComponent({ onPress }) {
  return (
    <TouchableOpacity onPress={onPress}>
      <View style={{
        alignSelf: 'flex-end',
        flexDirection: 'row',
        width: wp('10%'),
        height: 40,
        alignItems: 'center',
        justifyContent: 'space-between',
        marginRight: hp('7%'),
        marginTop: hp('1%')

      }}>
        <Image
          source={Images.download1}
          style={{ width: hp('3%'), height: hp('3%'), marginRight: 8 }}
          resizeMode="cover"
        />
        <IonIcons name={'share-social'} color={Colors.border} size={hp('3%')} />
      </View>
    </TouchableOpacity>
  );
}


export default DownloadImageComponent;

const styles = StyleSheet.create({
  appButtonContainer: {
    height: 36,
    minWidth: 120,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    backgroundColor: Colors.button,
    borderRadius: 17,
    paddingVertical: 4,
    paddingHorizontal: 32,
  },

});
