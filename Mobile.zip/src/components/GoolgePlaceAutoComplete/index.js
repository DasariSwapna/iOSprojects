import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  Modal,
  SafeAreaView,
  Dimensions,
  StyleSheet,
  ScrollView,
  FlatList,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import axios from 'axios';
import Config from 'react-native-config';

const LIST_TYPE = 'LIST';
const DETAIL_TYPE = 'DETAIL';
const GOOGLE_PACES_API_BASE_URL = 'https://maps.googleapis.com/maps/api/place';

async function googlePlaceApiCallHandler(url, type) {
  return axios
    .request({
      method: 'post',
      url: url,
    })
    .then(response => {
      // console.log(response.data);
      if (type == LIST_TYPE) return response.data.predictions;
      else if (type == DETAIL_TYPE) return response.data;
      else return response.data;
    })
    .catch(e => {
      console.log(e.response);
      if (type == LIST_TYPE) return response.data.predictions;
      else return null;
    });
}

export function GooglePlacesAutoComplete({updateCoordinates, closeModal}) {
  const [search, setSearch] = useState('');
  const [places, setPlaces] = useState([]);
  const [placeId, setPlaceId] = useState('');

  useEffect(() => {
    const url = `${GOOGLE_PACES_API_BASE_URL}/autocomplete/json?key=${Config.GOOGLE_MAPS_API_KEY}&input=${search}`;
    // console.log(search, url);
    async function fetchData() {
      if (search.length > 2) {
        let res = await googlePlaceApiCallHandler(url, LIST_TYPE);
        // console.log('places ==>', res);
        setPlaces(res);
      }
    }
    fetchData();
  }, [search]);

  useEffect(() => {
    // console.log('placeId: ', placeId);
    const url = `${GOOGLE_PACES_API_BASE_URL}/details/json?key=${Config.GOOGLE_MAPS_API_KEY}&place_id=${placeId}`;
    async function fetchData() {
      if (placeId != '') {
        const res = await googlePlaceApiCallHandler(url, DETAIL_TYPE);
        // console.log('place detail ==>', res);
        if (res.result) {
          updateCoordinates(res.result.geometry.location);
          // console.log('place detail ==>', res.result.formatted_address);
          // console.log('place detail ==>', res.result.geometry.location);
          closeModal(false);
        }
      }
    }
    fetchData();
  }, [placeId]);

  function renderItem({item}) {
    // console.log(item.place_id);

    return (
      <View>
        <TouchableOpacity
          onPress={() => {
            setPlaceId(item.place_id);
          }}>
          <View
            style={{
              alignItems: 'flex-start',
              justifyContent: 'center',
              paddingHorizontal: 10,
              paddingVertical: 4,
              borderBottomWidth: 1,
              marginHorizontal: 10,
              marginVertical: 2,
              borderBottomColor: 'gray',
            }}>
            <Text>{item.description}</Text>
          </View>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View>
      <TextInput
        value={search}
        placeholder="Search Location"
        onChangeText={setSearch}
        style={{
          width: '100%',
          height: 46,
          borderWidth: 1,
          borderRadius: 5,
          paddingHorizontal: 10,
          marginVertical: 12,
        }}
      />
      <FlatList
        data={places}
        keyExtractor={item => item.place_id}
        renderItem={renderItem}
      />
    </View>
  );
}
