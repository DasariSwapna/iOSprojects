import React from 'react';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';

export default function MedicalCenterNameView({...props}) {
  return (
    <TouchableOpacity style={styles.mainContainer} onPress={props.cardClickHandler}>
     <Text style={styles.nameText}>{props.customerName}</Text>
     <View style={styles.bottonLine}/>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width:'100%',
    paddingVertical:5,
    flexDirection:'column',
    marginTop:'1%'
  },
  nameText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingHorizontal:30,paddingBottom:'2%'
  },
  bottonLine:
  {
      width:'100%',
      alignItems:'center',
      justifyContent:'center',
      backgroundColor:Colors.card,
      height:1,
    }

});
