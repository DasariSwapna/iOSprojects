import React, {useState, useEffect} from 'react';
import {Image, View, Text, TouchableOpacity} from 'react-native';
import Colors from '../../constants/Colors';
import GlobalStyles from '../../constants/Styles/index2';
import Images from '../../constants/Images';
import {Apis} from '../../constants/Apis';

export default function PhotoFrame({imageSource, setVisible, label, isUrl}) {
  console.log('image source', Apis.getImageBaseUrl + imageSource);

  return (
    <View style={{alignItems: 'center', justifyContent: 'center'}}>
      <Text style={{paddingVertical: 6, color: Colors.secondary}}>{label}</Text>
      <TouchableOpacity
        activeOpacity={0.6}
        onPress={() => setVisible(true)}
        style={{
          padding: 4,
          borderRadius: 2,
          borderWidth: 2,
          borderColor: Colors.bgMediumGray,
        }}>
        {imageSource != null ? (
          imageSource != null && isUrl ? (
            <Image
              source={{uri: Apis.getImageBaseUrl + imageSource}}
              style={{
                width: 120,
                height: 130,
                resizeMode: 'cover',
              }}
            />
          ) : (
            <Image
              //source={imageSource}
              source={{uri: imageSource.path}}
              style={{
                width: 120,
                height: 130,
                resizeMode: 'cover',
              }}
            />
          )
        ) : (
          <Image
            source={Images.avatar}
            style={{
              width: 120,
              height: 130,

              resizeMode: 'cover',
            }}
          />
        )}
      </TouchableOpacity>
    </View>
  );
}
