import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";
import {
  Modal,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  TextInput,
  FlatList
} from "react-native";
import Fa5Icons from "react-native-vector-icons/FontAwesome5";
import Colors from "../../config/Colors";
import { Font, FontMagneta, FontSize } from "../../config/Fonts";
import { InputField } from "../InputField";
import Button from "../Button";
import Ionicons from "react-native-vector-icons/Ionicons";

export default function OtpModal({
  otp,
  mobileNo,
  visible,
  isValidOtp,
  setVisible,
  otpValidationMsg,
  otpChangeHandler,
  resendOtpHandler,
  otpDismissHandler,
  otpSubmitHandler,
  title,
  data,
  callBack
}) {
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(
    () => {
      setModalVisible(visible);
    },
    [visible]
  );

  const toggleVisible = val => {
    setModalVisible(val);
    setVisible(val);
  };

  return (
    <Modal
      animationType="slide"
      transparent={true}
      visible={modalVisible}
      onRequestClose={() => {
        // toggleVisible(!modalVisible);
        setModalVisible(false)
      }}
    >
      <View style={styles.centeredView}>
        <View style={styles.modalView}>
          <View style={styles.modalHeaderContainer}>
            <View style={styles.headerBackButton}>
              <TouchableOpacity onPress={() => otpDismissHandler()}>
                <Fa5Icons name="arrow-left" color={Colors.primary} size={22} />
              </TouchableOpacity>
            </View>
            <View style={styles.headerTitle}>
              <Text style={styles.modalHeaderText}>
                {title}
              </Text>
            </View>
          </View>
          <View style={{width:'100%',}}>
          <FlatList
            data={data}
            renderItem={({ item }) =>
            <TouchableOpacity onPress={()=>callBack(item)}>
              <Text style={{alignSelf:'center',padding:15,fontFamily:Font.regular,fontSize:FontSize.large,color:Colors.border}}>
                {item.lc_TC_TASK_NAME}
              </Text>
              <View style={{borderBottomWidth:0.8,borderColor:Colors.dWhite}}></View>
              </TouchableOpacity>
              }
          />
          </View>
          <PageNumber number={"04"} />
        </View>
      </View>
    </Modal>
  );
}

function PageNumber({ number }) {
  return (
    <View style={{ position: "absolute", right: 0, bottom: 0, margin: 10 }}>
      <Text>
        {number}
      </Text>
    </View>
  );
}

OtpModal.propTypes = {
  otp: PropTypes.string.isRequired,
  mobileNo: PropTypes.string,
  visible: PropTypes.bool,
  isValidOtp: PropTypes.bool,
  setOtp: PropTypes.func,
  setVisible: PropTypes.func,
  otpSubmitHandler: PropTypes.func
};

OtpModal.defaultProps = {
  mobileNo: "987654321"
};

const styles = StyleSheet.create({
  centeredView: {
    flex: 1,
    justifyContent: "flex-end",
    // alignItems: 'center',
    backgroundColor: "#00000060"
  },
  modalView: {
    width: "100%",
    minHeight: "40%",
    backgroundColor: "white",
    padding: 12,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5
  },
  modalHeaderContainer: {
    width: "80%",
    height: 40,
    alignSelf: "flex-start",
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 2
  },
  headerBackButton: {
    width: "25%",
    alignItems: "center"
  },
  headerTitle: {
    width: "80%",
    alignItems: "center"
  },
  modalHeaderText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge
  },
  descriptionContainer: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    alignItems: "flex-start"
    // backgroundColor: '#aaa',
  },
  descriptionText: {
    // color: Colors.text,
    fontFamily: Font.bold,
    fontSize: FontSize.medium
  },
  sendToText: {
    color: Colors.text,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular
  },
  otpTextContainer: {
    width: "86%",
    fontFamily: FontMagneta.medium,
    backgroundColor: Colors.card,
    // borderColor: Colors.primary,
    shadowColor: Colors.primary,
    shadowOffset: {
      width: 0,
      height: 2
    },
    shadowOpacity: 0.25,
    shadowRadius: 4
  },
  otpTextContainer1: {
    height: 46,
    width: "92%",
    alignSelf: "center",
    borderWidth: 1,
    borderRadius: 8,
    marginVertical: 2,
    padding: 12,
    elevation: 0,
    fontFamily: FontMagneta.medium,
    shadowColor: "transparent",
    shadowOpacity: 0,
    shadowRadius: 0,
    shadowOffset: {
      width: 0,
      height: 0
    },
    borderColor: Colors.card,
    backgroundColor: Colors.card
  },
  bottomContainer: {
    minHeight: 140,
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: 30,
    paddingBottom: 10
    // backgroundColor: '#aaa',
  },
  bottomTextContainer: {
    alignItems: "center",
    justifyContent: "center"
  },
  bottomText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    textDecorationLine: "underline",
    textDecorationStyle: "double",
    textDecorationColor: Colors.primary
  },
  buttonStyle: {
    minWidth: 160,
    height: 45,
    borderRadius: 25
  }
});
