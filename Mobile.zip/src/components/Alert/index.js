import React, {Component, useEffect, useState} from 'react';
import {StyleSheet, View, Modal, Text, Dimensions} from 'react-native';
import FaIcon5 from 'react-native-vector-icons/FontAwesome5';
import Button from '../Button';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';

const {width, height} = Dimensions.get('screen');
const modelHeight = height * 0.25;
const modelWidth = width * 0.86;

const Alert = ({title, toggle, action}) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(toggle);
  }, [toggle]);

  return (
    <Modal
      transparent={true}
      animationType={'none'}
      visible={visible}
      onRequestClose={() => {
        console.log('close modal');
      }}>
      <View style={styles.modalBackground}>
        <View style={styles.wrapper}>
          <View>
            <FaIcon5
              name="question-circle"
              size={modelHeight / 4}
              color={Colors.primary}
              solid
            />
          </View>
          <Text
            style={{
              fontFamily: Font.bold,
              fontSize: FontSize.medium,
              textAlign: 'center',
              color: '#000000',
            }}>
            {title}
          </Text>
          <View style={styles.buttonContainer}>
            <View
              style={{
                paddingHorizontal: 10,
              }}>
              <Button title={'No'} onPress={() => action(false)} />
            </View>
            <View
              style={{
                paddingHorizontal: 10,
              }}>
              <Button
                title={'Yes'}
                onPress={() => action(true)}
                buttonStyle={{backgroundColor: Colors.darkGreen}}
              />
            </View>
          </View>
        </View>
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'space-around',
    backgroundColor: '#00000080',
  },
  wrapper: {
    backgroundColor: Colors.background,
    height: modelHeight,
    width: modelWidth,
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    padding: 12,
    justifyContent: 'space-around',
    opacity: 0.98,
  },
  buttonContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  yesButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 5,
    backgroundColor: Colors.primary,
  },
  noButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 5,
    backgroundColor: Colors.primary,
  },
});

export default Alert;
