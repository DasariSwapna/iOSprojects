import React, { useRef } from 'react';
import {
    Text,
    View,
    Image,
    StyleSheet,
} from 'react-native';
import Colors from '../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import { TouchableOpacity } from 'react-native-gesture-handler';


function TopContainer(props) {
    // console.log(props.image)
    return (
        <TouchableOpacity onPress={() => props.onPress()}
            style={[{ backgroundColor: props.bgColor }, styles.topContainer]}>
            <View style={{ flexDirection: 'row' }}>
                <Image
                    style={styles.topImageContainer}
                    resizeMode={'contain'}
                    source={{ uri: props.image }}
                />
                <View style={styles.topContainerLayout}>
                    <View style={{ flexDirection: 'row', height: hp('4.5%') }}>
                        <Text style={styles.topContainerTextLarge} numberOfLines={2}>
                            {props.title}
                        </Text>
                    </View>
                    <View style={styles.topInnerContainer1}>
                        <Text style={styles.topContainerTextSmall}>Total test</Text>
                        <Text style={{
                            color: Colors.black,
                            fontFamily: FontMagneta.thin,
                            fontSize: FontSize.regular,
                            marginLeft: hp('0.5%')
                        }}>{props.testCount}</Text>
                    </View>
                </View>

            </View>
            <View style={styles.topInnerContainer2}>
                <Text style={[{ marginLeft: hp('2%'), }, styles.topContainerTextSmall]}>Test added</Text>
                <Text style={{
                    color: Colors.black,
                    fontFamily: FontMagneta.thin,
                    fontSize: FontSize.regular,
                }}>{props.testAdded}</Text>
            </View>
        </TouchableOpacity>
    );
}

export default TopContainer;

const styles = StyleSheet.create({
    topContainer: {
        width: wp('35%'),
        // height: hp('11.5%'),
        borderRadius: 20,
        paddingVertical: 10,
        paddingLeft: hp('1%'),
        paddingRight: hp('2%'),
        borderWidth: hp('0.1%'),
        borderColor: Colors.border,
        marginRight: 20,
        // backgroundColor: 'red'
        // marginBottom: 20
    },
    topContainerLayout: {
        flexDirection: 'column',
        marginLeft: 10,
        //backgroundColor: 'red',
        width: wp('20%'),

    },
    topImageContainer: {
        width: hp('5%'),
        height: hp('5%')
    },
    topInnerContainer1: {
        marginTop: hp('0.5%'),
        width: '90%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        alignSelf: 'flex-start',
    },
    topInnerContainer2: {
        width: '100%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        alignSelf: 'center',
        //marginVertical: 10
        marginTop: 10,
        marginBottom: hp('0.2%'),
    },
    topContainerTextLarge: {
        color: Colors.black,
        fontFamily: Font.bold,
        fontSize: FontSize.medium,

    },
    topContainerTextSmall: {
        color: Colors.black,
        fontFamily: Font.regular,
        fontSize: FontSize.small,
        alignSelf: 'center',
    },

});
