import React from 'react';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Platform
} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontSize, FontMagneta} from '../../config/Fonts';
import AppButton from '../Button';
import {Item} from 'react-native-paper/lib/typescript/components/List/List';
import AppButtonWithIcon from '../ButtonWithIcon';
import { heightPercentageToDP as hp,widthPercentageToDP as wp } from 'react-native-responsive-screen';
import I18n from '../../locale/i18n';
export default function PendingCardView({...props}) {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.cardViewInnerMainView}>
        <View style={styles.cardNameContainer}>
          <View style={styles.cardNameContainerRow1}>
          <Text style={styles.crmText}>{props.clientNameText}</Text>
            <Text style={styles.nameText}>{props.name}</Text>
          </View>
          <View style={styles.cardNameContainerRow2}>
            <Text style={styles.crmText}>{props.crmIdText}</Text>
            <Text style={styles.crmIdText}>{props.crmid}</Text>
          </View>
        </View>
        <View style={styles.fullWidth}>
          <View style={styles.separateLine}></View>
        </View>
        <View style={styles.dateRowContainer}>
          <View style={styles.dateContainer}>
            <Text style={styles.dateText}>{props.dateText}</Text>
            <Text style={styles.dateNumber}>{props.date}</Text>
          </View>
          <View style={styles.timeRowContainer}>
            <Text style={styles.dateText}>{props.timeText}</Text>
            <Text style={styles.dateNumber}>{props.time}</Text>
          </View>
        </View>
        <View style={styles.addressContainer}>
          <Text style={styles.dateText}>{props.addressText}</Text>
          <Text style={styles.addressText} numberOfLines={3}>
            {props.address}
          </Text>
        </View>
        {props.selectedTab == '2' ? (
          <View style={styles.addressContainer}>
            <Text style={styles.dateText}>{props.deliveredTimeText}</Text>
            <Text style={styles.dateNumber} numberOfLines={2}>
              {props.deliveredTime}
            </Text>
          </View>
        ) : props.selectedTab == '3' ? (
          <View style={styles.addressContainer}>
            <Text style={styles.dateText}>{props.reasonText}</Text>
            <Text style={styles.addressLineText} numberOfLines={2}>
              {props.reason}
            </Text>
          </View>
        ) : props.selectedTab == '1' ? (
          <View style={styles.buttonContainer}>
            <View style={styles.buttonRow}>
              {props.isStarted ? (
                <AppButtonWithIcon
                  title={props.startText}
                  buttonStyle={styles.afterStartButton}
                  buttonTextStyle={styles.afterStartButtonTextStyle}
                  onPress={() => props.startCardClickHandler()}
                />
              ) : (
                <AppButton
                  title={props.startText}
                  buttonStyle={styles.beforeStartButton}
                  buttonTextStyle={styles.beforeStartButtonTextStyle}
                  onPress={() => props.startCardClickHandler()}
                />
              )}
            </View>
            <View style={styles.buttonRow}>
              <AppButton
                title={props.viewText}
                buttonStyle={styles.viewButton}
                buttonTextStyle={styles.startViewTextStyle}
                onPress={() => props.viewCardClickHandler()}
              />
            </View>
          </View>
        ) : null}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
    cardContainer: {
        borderRadius: 15,
        borderColor: Colors.border,
        borderWidth:Platform.OS=='ios'?hp('0.04%'):hp('0.1%'),
        backgroundColor: Colors.background,
        shadowColor: '#000',
        shadowOpacity: Platform.OS=='ios'?0.2: 0.5,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2.5,
        elevation: Platform.OS=='ios'?1:5,
        flexDirection: 'row',
        marginBottom: hp('3.5%'),
        alignItems: 'flex-start',
        justifyContent: 'center',
        marginHorizontal: wp('7%'),
      },
      cardViewInnerMainView:
      {
        width: '100%',
        flexDirection: 'column',
        height: '70%'
      },
      cardNameContainer:
      {
        width: '96%',
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingHorizontal: 10,
        marginTop: hp('1.5%'),
        marginHorizontal:15,
      
      },
      cardNameContainerRow1: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        
      },
      cardNameContainerRow2: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
        
      },
      nameText: {
        fontSize: FontSize.medium,
        fontFamily: Font.extraBold,
        color: Colors.border
      },
      crmText:
      {
        fontSize: FontSize.regular,
        fontFamily: Font.regular,
        color: Colors.border,
        marginVertical:hp('1%')
      },
      crmIdText: {
        fontSize: FontSize.medium,
        fontFamily: FontMagneta.bold,
        color: Colors.babyCordTextColor
      },
      fullWidth: {
         width: '100%'
      },
      separateLine: {
        height: Platform.OS=='ios'?hp('0.04%'):hp('0.1%'),
        width: '100%',
        backgroundColor: Colors.border,
        marginVertical: hp('1.5%')
      },
      dateRowContainer: {
        width: '95%',
        flexDirection: 'row',
        alignItems: 'flex-start',
        justifyContent: 'center',
        paddingHorizontal: 10,
        marginVertical: hp('0.5%'),
        marginHorizontal:15,
      },
       addressContainer:
      {
        width: '92%',
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: 'column',
        paddingHorizontal: 10,
        marginTop: hp('2%'),
        marginBottom: 15,
        marginHorizontal:15,
        maxHeight:hp('10%'),
        
      },
      dateContainer: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: 'column'
      },
      dateText: {
        fontSize: FontSize.regular,
        fontFamily: Font.regular,
        color: Colors.border
      },
      dateNumber: {
        fontSize: FontSize.medium,
        fontFamily: FontMagneta.thin,
        color: Colors.black,
        marginTop: 5
      },
      addressText:{
        fontSize: FontSize.regular,
        fontFamily: FontMagneta.thin,
        color: Colors.black,
        marginTop: 5,
        lineHeight:20
      },
      addressLineText:{
        fontSize: FontSize.medium,
        fontFamily: Font.regular,
        color: Colors.black,
        marginTop: 5,
        
      },
      buttonContainer:
      {
        width: '100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 20,
        paddingHorizontal:15,
      },
      buttonRow: {
        flex: 0.5,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column'
      },
      timeRowContainer: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'center',
        flexDirection: 'column'
      },
  
      beforeStartButton: {
        height: hp('5%'),
        width: '90%',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.babyCordTextColor,
        elevation: 2,
        borderRadius: 50,
        paddingVertical: 3,
        paddingHorizontal: 20,
        marginHorizontal: 3
      },
      afterStartButton: {
        height: hp('5%'),
        width: '90%',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.background,
        elevation: 2,
        borderRadius: 50,
        paddingVertical: 3,
        paddingHorizontal: 20,
        marginHorizontal: 3,
        borderWidth:Platform.OS=='ios'?hp('0.07%'):hp('0.1%'),
        borderColor:Colors.babyCordTextColor
      },
      viewButton: {
        height: hp('5%'),
        width: '90%',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: Colors.button,
        elevation: 2,
        borderRadius: 50,
        paddingVertical: 3,
        paddingHorizontal: 10,
        marginHorizontal: 3
      },
      beforeStartButtonTextStyle:{
        fontSize: FontSize.medium,
        fontFamily: Font.extraBold,
        color: Colors.background,
      },
      afterStartButtonTextStyle:{
        fontSize: FontSize.medium,
        fontFamily: Font.extraBold,
        color: Colors.babyCordTextColor,
      },
      startViewTextStyle:{
        fontSize: FontSize.medium,
        fontFamily: Font.extraBold,
        color: Colors.background,
      },
});
