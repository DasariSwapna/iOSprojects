import React from 'react';
import {TouchableOpacity, Text, StyleSheet,ScrollView,TouchableWithoutFeedback,View} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import { heightPercentageToDP as hp,widthPercentageToDP as wp } from 'react-native-responsive-screen';
const SearchButtonView = ({
  onPress,
  title,
  buttonStyle,
  buttonTextStyle,
  disable,
  isTransparent,
  isActive,
}) => (
  <TouchableOpacity
    disabled={disable}
    onPress={onPress}
    style={[
      styles.appButtonContainer,
      {backgroundColor: isActive?Colors.border:Colors.card},
      buttonStyle,
      isTransparent && {backgroundColor: '#00000000', elevation: 0},
    ]}>
       <View onStartShouldSetResponder={() => true}>
      <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{height:hp('2.5%')}}>
    <Text style={[styles.appButtonText, buttonTextStyle,{color:isActive?Colors.background:Colors.black}]} >{title}</Text>
    </ScrollView>
    </View>
  </TouchableOpacity>
);

export default SearchButtonView;

const styles = StyleSheet.create({
  appButtonContainer: {
    height: hp('3.5%'),
    width: wp('28%'),
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    borderRadius: 25,
    paddingVertical: 3,
    paddingHorizontal: 15,
    marginHorizontal:4,
    marginVertical:8,
  },
  appButtonText: {
    fontFamily: Font.extraBold,
    fontSize:FontSize.small,
    alignSelf: 'center',
    // textTransform: 'capitalize',
  },
});
