import React from 'react';
import {Dimensions, View, Text, Image, StyleSheet} from 'react-native';
import I18n from '../../locale/i18n';
import Images from '../../constants/Images';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';

const {width, height} = Dimensions.get('screen');
const logoSize = width * 0.1;
const minHeight = height * 0.02;

export function IconFooter() {
  return (
    <View style={styles.footerContainer}>
      <View style={{minHeight: minHeight}}>
        <Text style={styles.poweredby}>{I18n.t('signIn.powered_by')}</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={styles.iSolveLogoContainer}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={styles.voilaLogoConatiner}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

IconFooter.prototype = {};

const styles = StyleSheet.create({
  footerContainer: {
    height: height * 0.08,
    alignItems: 'center',
    justifyContent: 'flex-end',
    paddingTop: height * 0.06,
    marginBottom: 2,
    // backgroundColor: 'green',
  },
  poweredby: {
    color: Colors.blue,
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
  },
  footerLogoContainer: {
    width: '100%',
    height: logoSize * 1,
    flexDirection: 'row',
    alignItems: 'baseline',
    paddingHorizontal: 10,
    paddingVertical: 2,
    // backgroundColor: '#aaa',
  },
  seperator: {
    height: '60%',
    width: 1,
    margin: 10,
    alignSelf: 'center',
    backgroundColor: Colors.bgDarkGray,
  },
  iSolveLogoContainer: {
    width: '49%',
    alignItems: 'flex-end',
  },
  iSolveLogo: {
    width: logoSize * 3,
    height: logoSize,
    minHeight: 60,
    alignItems: 'flex-end',
    justifyContent: 'center',
    resizeMode: 'contain',
  },
  voilaLogoConatiner: {
    width: '48%',
    alignItems: 'flex-start',
    paddingBottom: 2,
  },
  voilaLogo: {
    width: logoSize * 2,
    height: logoSize,
    minHeight: 60,
    justifyContent: 'center',
    resizeMode: 'contain',
    // paddingBottom: 4,
  },
});
