import React, {useState, useEffect} from 'react';
import {
  SafeAreaView,
  StatusBar,
  StyleSheet,
  View,
  Dimensions,
  Text,
  Platform,
} from 'react-native';
import {
  Button,
  Dialog,
  Paragraph,
  Portal,
  Snackbar,
  Surface,
  Modal,
  Provider,
} from 'react-native-paper';
import {connect} from 'react-redux';
import FaIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Colors from '../../config/Colors';
import Color from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';
import NoInternet from '../NoInternet';
import Loader from '../Loader';
import {NetworkContext} from '../../contexts/NetworkContext';

const screenHeight = Dimensions.get('screen').height;
const STATUS_BAR_HEIGHT = Platform.OS === 'ios' ? 52 : StatusBar.currentHeight;

function AppStatusBar({isWhite}) {
  return (
    <View>
      {Platform.OS === 'ios' && (
        <View
          style={[
            styles.iosStatusBar,
            isWhite && {backgroundColor: Color.background},
          ]}
        />
      )}
      <StatusBar
        animated={true}
        barStyle={'dark-content'}
        backgroundColor={isWhite ? Color.background : Color.card}
      />
    </View>
  );
}

export default function RootView({
  isWhite,
  pageNo,
  isPageWhite,
  isPageCard,
  connected,
  loading,
  ...props
}) {
  const {isConnected} = React.useContext(NetworkContext);

  return (
    <View
      style={[
        styles.container,
        isPageWhite && {backgroundColor: Color.background},
        isPageCard && {backgroundColor: Color.card},
      ]}>
      <AppStatusBar isWhite={isWhite} />
      {!isConnected && <NoInternet show={!isConnected} />}
      {loading == true && <Loader show={loading} />}
      <SafeAreaView style={styles.mainConatiner}>{props.children}</SafeAreaView>
      <View style={[styles.pageNoContainer]}>
        <Text style={styles.pageText}>{pageNo}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    height: '100%',
    width: '100%',
    backgroundColor: Color.bgLightGray,
  },
  mainConatiner: {
    flex: 1,
  },
  iosStatusBar: {
    width: '100%',
    height: STATUS_BAR_HEIGHT,
    top: 0,
    left: 0,
    position: 'absolute',
    backgroundColor: Color.card,
  },
  pageNoContainer: {
    position: 'absolute',
    top: 0,
    right: 6,
    alignItems: 'flex-end',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  pageText: {
    fontFamily: FontMagneta.bold,
    color: Colors.greenBlue,
    fontSize: FontSize.medium,
  },
});
