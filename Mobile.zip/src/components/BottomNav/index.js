import React, {useRef} from 'react';
import {
  Dimensions,
  Text,
  View,
  Image,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import MaComIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';
import Icons from '../../constants/Icons';

const {width, height} = Dimensions.get('screen');
const navIconHeight = height * 0.06;

function MenuIcon({label, iconName, onPressHandler, isSales}) {
  return (
    <View>
      <TouchableOpacity
        style={styles.iconContainer}
        onPress={() => onPressHandler()}>
        {isSales == true ? (
          <Image
            source={iconName}
            style={{
              width: navIconHeight / 1.9,
              height: navIconHeight / 1.9,
              margin: 2,
            }}
          />
        ) : iconName == 'tasks' ? (
          <FaIcons
            name={iconName}
            color={Colors.primary}
            size={navIconHeight / 1.8}
          />
        ) : (
          <MaComIcons
            name={iconName}
            color={Colors.primary}
            size={navIconHeight / 1.5}
          />
        )}
        <Text style={styles.bottomMenuText}>{label}</Text>
      </TouchableOpacity>
    </View>
  );
}

MenuIcon.prototype = {
  isSales: PropTypes.bool,
  label: PropTypes.string,
  iconName: PropTypes.string,
  onPressHandler: PropTypes.func,
};

export default function BottomNav({
  menu1Handler,
  menu2Handler,
  menu3Handler,
  menu4Handler,
  centerMenuHandler,
  isSales,
}) {
  return (
    <View style={styles.bottomNavContainer}>
      <View style={styles.outerMenu}>
        <MenuIcon
          isSales={isSales}
          label={isSales ? 'Alert' : 'Home'}
          // iconName={isSales ? 'alert-circle-outline' : 'home-outline'}
          iconName={isSales ? Icons.alert : 'home-outline'}
          onPressHandler={() => menu1Handler()}
        />
      </View>
      <View style={styles.innerMenu}>
        <MenuIcon
          isSales={isSales}
          label={isSales ? 'Invoice' : 'Alert'}
          iconName={isSales ? Icons.invoiceBottom : 'alert-circle-outline'}
          onPressHandler={() => menu2Handler()}
        />
      </View>
      <View style={styles.centerMenu}>
        <TouchableOpacity
          style={styles.centerMenuIcon}
          onPress={() => centerMenuHandler()}>
          <MaComIcons
            name={'plus-thick'}
            color={Colors.background}
            size={navIconHeight / 1.6}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.innerMenu}>
        <MenuIcon
          isSales={isSales}
          label={isSales ? 'Catelog' : 'My Task'}
          iconName={isSales ? Icons.catelog : 'tasks'}
          onPressHandler={() => menu3Handler()}
        />
      </View>
      <View style={styles.outerMenu}>
        <MenuIcon
          isSales={isSales}
          label={isSales ? 'Helpline' : 'Calender'}
          iconName={isSales ? Icons.helpline : 'calendar'}
          // iconName={isSales ? 'help-circle-outline' : 'calendar'}
          onPressHandler={() => menu4Handler()}
        />
      </View>
    </View>
  );
}

BottomNav.prototype = {
  isSales: PropTypes.bool,
  homeNavHandler: PropTypes.func,
  alertNavHandler: PropTypes.func,
  createTaskNavHandler: PropTypes.func,
  myTaskNavHandler: PropTypes.func,
  calendarNavHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  bottomNavContainer: {
    flex: 1,
    position: 'absolute',
    bottom: 0,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
    borderTopWidth: 1,
    borderTopColor: Colors.card,
    backgroundColor: Colors.background,
  },
  iconContainer: {
    height: navIconHeight,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
  },
  centerMenuIcon: {
    position: 'absolute',
    top: -navIconHeight * 1.2,
    width: navIconHeight * 1.4,
    height: navIconHeight * 1.4,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: (navIconHeight * 1.4) / 2,
    backgroundColor: Colors.primary,
  },
  outerMenu: {width: '19%'},
  innerMenu: {width: '19%'},
  centerMenu: {width: '20%'},
  bottomMenuText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    color: Colors.black,
  },
});
