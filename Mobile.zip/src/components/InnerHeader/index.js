import React from 'react';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {
  Image,
  StyleSheet,
  StatusBar,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';

import Images from '../../constants/Images';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';

export default function InnerHeader({...props}) {
  return (
    <View style={styles.headerContainer}>
      <View style={styles.headerRowContainer}>
        <View
          style={{flex: 0.2, alignItems: 'center', justifyContent: 'center'}}>
          <FaIcons name={'arrow-left'} color={Colors.border} size={20} />
        </View>
        <View
          style={{flex: 0.6, alignItems: 'center', justifyContent: 'center'}}>
          <Text style={styles.headerText}>{props.headerTitle}</Text>
        </View>
        <View
          style={{flex: 0.2, alignItems: 'center', justifyContent: 'center'}}>
          <Image
            source={Images.innerHeaderLogo}
            resizeMode={'contain'}
            style={styles.imgStyle}
          />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  headerContainer: {
    width: '100%',
    height: '10%',
    backgroundColor: Colors.card,
    justifyContent: 'flex-end',
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
  },
  headerRowContainer: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    flexDirection: 'row',
    flex: 1,
    marginBottom: 20,
  },
  headerText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.border,
  },
  imgStyle: {
    width: 30,
    height: 30,
  },
});
