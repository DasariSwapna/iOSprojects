import React, {useState, useEffect, useRef} from 'react';
import {View, Text, SafeAreaView} from 'react-native';
import Geocoder from 'react-native-geocoding';
import MapView, {Marker} from 'react-native-maps';
import Config from 'react-native-config';

export default function MapLocation({
  initialCoord,
  updatedCoords,
  getCoordinates,
}) {
  const mapRef = useRef(null);
  const [region, setRegion] = useState({
    latitude: 13.0827,
    longitude: 80.2707,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  });

  useEffect(() => {
    Geocoder.init(Config.GOOGLE_MAPS_API_KEY);
  }, []);

  useEffect(() => {
    mapRef.current.animateToRegion(initialCoord);
    setRegion(initialCoord);
  }, [initialCoord]);

  useEffect(() => {
    console.log('Map coordinates updated to:', updatedCoords);
    if (updatedCoords) {
      mapRef.current.animateToRegion({
        latitude: updatedCoords.latitude,
        longitude: updatedCoords.longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      });

      setRegion({
        latitude: updatedCoords.latitude,
        longitude: updatedCoords.longitude,
        latitudeDelta: 0.0922,
        longitudeDelta: 0.0421,
      });
    }
  }, [updatedCoords]);

  function onRegionChange(region) {
    setRegion(region);
  }

  function onRegionChangeComplete(region) {
    setRegion(region);
    getCoordinates({
      latitude: region.latitude,
      longitude: region.longitude,
    });
  }

  function onMarkerChange(coords) {
    getCoordinates(coords);
  }

  return (
    <MapView
      ref={mapRef}
      onRegionChangeComplete={onRegionChangeComplete}
      onRegionChange={onRegionChange}
      style={{width: '100%', height: '100%'}}
      initialRegion={region}>
      <Marker
        draggable
        coordinate={{
          latitude: region.latitude,
          longitude: region.longitude,
        }}
        onDragEnd={e => onMarkerChange(e.nativeEvent.coordinate)}
      />
    </MapView>
  );
}
