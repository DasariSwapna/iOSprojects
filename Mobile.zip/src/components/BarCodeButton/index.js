import React from 'react';
import IonIcons from 'react-native-vector-icons/Ionicons';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
} from 'react-native';
import Colors from '../../config/Colors';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import { heightPercentageToDP as hp,widthPercentageToDP as wp } from 'react-native-responsive-screen';

export default function BarCodeButton({ ...props }) {
  return (
    <TouchableOpacity style={styles.iconConatiner} onPress={props.onPress}>
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')} />
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')}/>
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')} />
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')}/>
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')} />
        <FaIcons  name={'barcode'} color={Colors.babyCordTextColor}  size={wp('8%')} />
        
      </TouchableOpacity>
  
  );
}

const styles = StyleSheet.create({
    iconConatiner:{
    width: '90%',
    height: hp('6%'), 
    borderRadius: 50, 
    backgroundColor: Colors.vLightGreen, 
    marginTop: 44,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center'}

});
