import React, {useState, useEffect, useContext} from 'react';
import {
  StyleSheet,
  Text,
  View,
  Modal,
  ActivityIndicator,
  Image,
} from 'react-native';
import loaderImg from '../../assets/images/LoaderWithoutWhite.gif';
import Colors from '../../config/Colors';
import {routeNameRef} from '../../navigations';

const Loader = ({loading}) => {
  const [visible, setVisible] = useState(false);
  const [screen, setScreen] = useState('');

  useEffect(() => {
    setVisible(loading);
    let cleanUp = setTimeout(() => setVisible(false), 5000);
    return () => {
      clearTimeout(cleanUp);
      setVisible(false);
    };
  }, [loading]);

  useEffect(() => {
    setScreen(routeNameRef.current);
  }, [routeNameRef.current]);

  return (
    <Modal
      transparent={true}
      animationType={'none'}
      visible={visible}
      onRequestClose={() => {
        console.log('close modal');
      }}>
      <View style={styles.modalBackground}>
        <Image source={loaderImg} style={{width: 126, height: 126}} />
        {/* <Text style={{color: Colors.background}}>{screen}</Text> */}
        {/* <ActivityIndicator
          animating={visible}
          size="large"
          color={Colors.primary}
        /> */}
      </View>
    </Modal>
  );
};

const styles = StyleSheet.create({
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'space-around',
    backgroundColor: '#00000060',
  },
  activityIndicatorWrapper: {
    backgroundColor: '#FFFFFF',
    height: 80,
    width: 80,
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-around',
    opacity: 0.92,
  },
});

export default Loader;
