import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Platform
} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
const {width, height} = Dimensions.get('screen');
const barWidth = width * 0.85;
const barHeight = height * 0.09;
const imageHeight = height * 0.06;

const label1Width = width * 0.2;

function HomeType({
  imageSource,
  label,
  label1,
  label2,
  label3,
  label4,
  color,
  onPress,
  onClickListener,
}) {
  return (
    <TouchableOpacity
      onPress={() => onClickListener()}
      activeOpacity={0.6}
      style={{width: '80%', alignItems: 'center'}}>
      <View
        style={{
          width: barWidth,
          minWidth: 300,
          height: barHeight,
          flexDirection: 'column',
          // alignItems: 'center',
          marginVertical: hp('0.5%'),
          borderRadius: barHeight / 2,
          elevation: 6,
          shadowColor: Colors.bgDarkGray,
          shadowRadius: 1,
          shadowOpacity: 0.9,
          shadowOffset: {width: 1, height: 1},
          backgroundColor: Colors.background,
          marginTop: hp('1.5%'),
        }}>
        <View
          style={{
            width: barWidth,
            minWidth: 300,
            height: barHeight,
            flexDirection: 'row',
            alignItems: 'center',
            marginVertical: hp('0.5%'),
            borderRadius: barHeight / 2,
           // elevation: 6,
            shadowColor: Colors.bgDarkGray,
            shadowRadius: 1,
          //  shadowOpacity: 0.8,
            shadowOffset: {width: 1, height: 1},
            backgroundColor: Colors.background,
           // marginTop: hp('-0.5%'),
          }}>


          <View
            style={{
              width: barHeight,
              height: barHeight,
              borderRadius: barHeight / 2,
              marginTop: hp('3.5%'),
              // backgroundColor: color,
            }}>
            <Image
              source={{uri: imageSource}}
              style={{
                // width: wp('20%'),
                height: hp('20%'),
                resizeMode: 'contain',
                flex: 0.5,
                // alignSelf: 'stretch',
                //marginTop: hp('1.5%'),
                // marginHorizontal: wp('-2.5%'),
              }}
            />
          </View>





          <View
            style={{
              width: wp('20%'),
            //  marginHorizontal: wp('-2.0%'),
              flexDirection: 'row',
              height: hp('5%'),
              marginTop: hp('0.5%'),
            }}>
            <View style={{width: wp('20%')}}>
              <Text
                style={{
                  fontFamily: Font.regular,
                  color: Colors.black,
                  fontSize: FontSize.medium,
                  marginTop: hp('0.5%'),
                  //lineHeight : 30
                }}>
                {label}
              </Text>
            </View>


            <View
              style={{
                flexDirection: 'row',
                width: wp('65%'),
               // paddingBottom : hp('1.5%')

              }}>
               <View
                 style={{
                  width: wp('0.2%'),
                  height: hp('3%'),
                  flexDirection: 'row',
                  marginHorizontal: wp('1.5%'),
                  backgroundColor: Colors.primary,
                }}></View>


                <View 
                style={{
                  flexDirection: 'column',
                 // width: wp('40%'),
                }}>
                <Text
                  style={{
                    width: wp('21%'),
                    fontFamily: Font.regular,
                    color: Colors.nbsTextColor,
                    fontSize: FontSize.regular,
                  }}>
                  {label1}
                </Text>
                <Text
                  style={{
                    marginTop:  Platform.OS == 'ios' ? hp('1.0%') : null ,
                  //  marginTop: hp('0.5%'),
                    width: wp('21%'),
                    // width: wp('20%'),
                    // marginLeft: wp('1.5%'),
                    fontFamily: FontMagneta.medium,
                    color: Colors.button,
                    fontSize: FontSize.large,
                  }}>
                  {label3}
                </Text>
              </View>


              <View
                 style={{
                  width: wp('0.2%'),
                  height: hp('3%'),
                  flexDirection: 'row',
                  marginHorizontal: wp('1.5%'),
                  backgroundColor: Colors.darkGreen,
                }}></View>


                <View 
                style={{
                  flexDirection: 'column',
                 // width: wp('40%'),
                }}>
                <Text
                  style={{
                    width: wp('21%'),
                    fontFamily: Font.regular,
                    color: Colors.nbsTextColor,
                    fontSize: FontSize.regular,
                  }}>
                  {label2}
                </Text>
                <Text
                  style={{
                    marginTop:  Platform.OS == 'ios' ? hp('1.0%') : null ,
                    width: wp('21%'),
                    // width: wp('20%'),
                    // marginLeft: wp('1.5%'),
                    fontFamily: FontMagneta.medium,
                    color: Colors.button,
                    fontSize: FontSize.large,
                  }}>
                  {label4}
                </Text>
              </View>


              </View>



          </View>
        </View>
        <View style={{width: wp('88%'), flex: hp('1%')}}></View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({});

export default HomeType;
