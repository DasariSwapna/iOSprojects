import React, { useRef } from 'react';
import {
  Text,
  View,
  Image,
  StyleSheet,
  TextInput,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import Colors from '../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import CheckCircle, { CheckCircle1 } from '../../components/CheckCircle';
import { ScrollView } from 'react-native-gesture-handler';
import I18n from '../../locale/i18n';

function AddTestPayoutComponent({
  radioPress,
  title,
  minPrice,
  maxPrice,
  payoutHandler,
  sellingHandler,
  textInputsPayout,
  selected,
  dr_payout,
  selling_price,
  NO_REFERRAL,
}) {
  return (
    <View style={styles.payoutContainer}>
      <View style={styles.payoutBottomContainer}>

        <View style={{ marginTop: 10, flexDirection: 'row', justifyContent: 'space-between' }}>
          <View style={{ flexDirection: 'row' }} >
            <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
            <View style={{ width: wp('62%'), marginLeft: 10, paddingRight: 5 }}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <Text numberOfLines={1} style={styles.payoutTextContainerBold}>
                  {title}
                </Text>
              </ScrollView>
            </View>
          </View>


          <View style={{ alignSelf: 'flex-start' }}>
            <CheckCircle1
              length={20}
              onPress={() => radioPress()}
              selected={selected}
            />
          </View>
        </View>

        <View
          style={{
            marginTop: 5,
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <AddTestPayoutMinMaxComponent title={'Min'} price={minPrice} />
          <AddTestPayoutMinMaxComponent title={'Max'} price={maxPrice} />
          {NO_REFERRAL ? (
            <AddTestPayoutInputComponent
              title={'Dr.Payout'}
              value={dr_payout}
              editable={false}
              selected={selected}
              backgroundColor={'#00000029'}
              onChangeText={payoutHandler}
            />
          ) : (
            <AddTestPayoutInputComponent
              title={'Dr.Payout'}
              value={dr_payout}
              editable={selected ? true : false}
              selected={selected}
              backgroundColor={selected ? '#fff' : '#00000029'}
              onChangeText={payoutHandler}
            />
          )}
          <AddTestPayoutInputComponent
            title={'Selling price'}
            value={selling_price}
            editable={selected ? true : false}
            selected={selected}
            backgroundColor={selected ? '#fff' : '#00000029'}
            onChangeText={sellingHandler}
          />
        </View>
      </View>
    </View>
  );
}

function AddTestPayoutInputComponent({
  editable,
  title,
  value,
  backgroundColor,
  onChangeText,
}) {
  return (
    <View style={{ marginTop: hp('1%') }}>
      <Text style={styles.payoutTextContainerBlackRegular}>{title}</Text>
      <View
        style={[
          {
            flexDirection: 'row',
            width: Platform.OS === 'ios' ? hp('9.5%') : hp('11%'),
            borderWidth: hp('0.1%'),
            borderColor: Colors.border,
            borderRadius: 7,
            height: hp('5%'),
            alignItems: 'center',
            // justifyContent: 'flex-start',
            paddingLeft: 10,
          },
          { backgroundColor: backgroundColor },
        ]}>
        <Text
          style={{
            color: Colors.black,
            fontFamily: FontMagneta.thin,
            fontSize: FontSize.medium,
            marginTop: hp('-0.2%'),
          }}>
          {I18n.t('valitation.rupee')}
        </Text>
        <TextInput
          keyboardDismissMode="none"
          style={[styles.payoutTextInputContainer]}
          underlineColorAndroid="transparent"
          maxLength={8}
          onChangeText={text => {
            onChangeText(text);
          }}
          value={value}
          keyboardType={'numeric'}
          editable={editable}
          numeric
        />
      </View>
    </View>
  );
}

function AddTestPayoutMinMaxComponent({ title, price }) {
  return (
    <View style={{ marginTop: 10 }}>
      <Text style={styles.payoutTextContainerBorder}>{title}</Text>
      <Text style={styles.payoutTextContainerMagenta}>
        {I18n.t('valitation.rupee')} {price}
      </Text>
    </View>
  );
}

export default AddTestPayoutComponent;

const styles = StyleSheet.create({
  payoutContainer: {
    width: wp('92%'),
    height: Platform.OS === 'ios' ? hp('13%') : hp('15%'),
    borderWidth: hp('0.1%'),
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginTop: 15,
    marginBottom: 10,
    // paddingBottom: 20
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutTextContainerBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBold: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    // width: wp('62%'),
    // height: hp('6%'),
    marginLeft: hp('1.5%'),
    // overflow: 'visible'
    //backgroundColor: 'red'
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,
  },
  payoutBottomContainer: {
    flexDirection: 'column',
    width: '100%',
    justifyContent: 'space-between',
    paddingLeft: 15,
    paddingRight: 10,
    // backgroundColor: 'red'
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    marginTop: hp('2%'),
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: 5,
    flex: 1,
  },
});
