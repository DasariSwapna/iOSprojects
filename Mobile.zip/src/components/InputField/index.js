import React, {useState, useEffect} from 'react';
import {
  View,
  Text,
  ScrollView,
  TextInput,
  StyleSheet,
  ViewPropTypes,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import moment from 'moment';
import PropTypes from 'prop-types';
import DatePicker from 'react-native-date-picker';
import FaIcon from 'react-native-vector-icons/FontAwesome';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';

const {width, height} = Dimensions.get('screen');
const inputTextSize = height * 0.018;
const inputHeight = height * 0.065;

export function InputField({
  label,
  value,
  placeholder,
  isPassword,
  isDate,
  isValid,
  maxLength,
  validationMsg,
  inputContainerStyle,
  textInputContainer,
  onChangeHandler,
  dateChangeHandler,
  otpResentHandler,
  onBlurInput,
  isTransparent,
  isNumeric,
  isEmail,
  isOtp,
  isAuth,
}) {
  const [showPassword, setShowPassword] = useState(false);
  const [date, setDate] = useState(new Date());
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setShowPassword(isPassword);
  }, [isPassword]);

  const onChange = selectedDate => {
    dateChangeHandler(moment(selectedDate).format('YYYY-MM-DD'));
    setDate(selectedDate);
  };

  return (
    <View style={[styles.inputContainer, inputContainerStyle]}>
      {label && label != '' && (
        <Text style={styles.textLabelStyle}>{label}</Text>
      )}
      <View
        style={[
          styles.textInputContainer,
          isOtp && {backgroundColor: Colors.card},
        ]}>
        <TextInput
          blurOnSubmit={true}
          style={[
            styles.textInputStyle,
            isPassword && {width: '82%'},
            isDate && {width: '82%'},
            isOtp && {width: '62%'},
            textInputContainer,
            isTransparent && styles.transparantStyle,
          ]}
          editable={isDate == true ? false : true}
          onChangeText={onChangeHandler}
          maxLength={maxLength}
          value={value}
          placeholder={placeholder}
          numberOfLines={1}
          returnKeyType={'done'}
          secureTextEntry={showPassword == true ? true : false}
          keyboardType={
            isNumeric ? 'numeric' : isEmail ? 'email-address' : 'default'
          }
          placeholderTextColor={Colors.bgDarkGray}
          onBlur={() => (onBlurInput ? onBlurInput() : null)}
        />
        {isPassword && (
          <View
            style={{
              width: '12%',
              paddingHorizontal: 8,
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() => setShowPassword(!showPassword)}
              hitSlop={{top: 20, bottom: 20, left: 20, right: 20}}>
              <FaIcon
                name={showPassword ? 'eye-slash' : 'eye'}
                size={16}
                color={Colors.bgDarkGray}
              />
            </TouchableOpacity>
          </View>
        )}
        {isDate && (
          <View
            style={{
              width: '12%',
              paddingHorizontal: 8,
              alignItems: 'center',
            }}>
            <TouchableOpacity
              onPress={() => setOpen(true)}
              hitSlop={{top: 20, bottom: 20, left: 20, right: 20}}>
              <FaIcon name={'calendar'} size={26} color={Colors.button} />
            </TouchableOpacity>

            <DatePicker
              modal
              date={date}
              maximumDate={new Date()}
              mode="date"
              open={open}
              textColor={Colors.darkPinknew}
              format="YYYY-MM-DD"
              onConfirm={date => {
                setOpen(false);
                onChange(date);
              }}
              onCancel={() => {
                setOpen(false);
              }}
            />
          </View>
        )}
        {isOtp && isAuth != true && (
          <TouchableOpacity
            onPress={() => (otpResentHandler ? otpResentHandler() : null)}>
            <View
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
                paddingHorizontal: 10,
              }}>
              <FaIcon
                name={'rotate-right'}
                color={Colors.primary}
                size={FontSize.regular}
              />
              <Text
                style={{
                  paddingHorizontal: 2,
                  color: Colors.primary,
                  fontFamily: FontMagneta.medium,
                }}>
                Resend OTP
              </Text>
            </View>
          </TouchableOpacity>
        )}
      </View>
      {isValid == false && (
        <Text style={styles.textValidationMsg}>
          {isValid == false ? validationMsg : ''}
        </Text>
      )}
    </View>
  );
}

InputField.prototype = {
  label: PropTypes.string,
  value: PropTypes.string,
  placeholder: PropTypes.string,
  isPassword: PropTypes.bool,
  isValid: PropTypes.bool,
  maxLength: PropTypes.number,
  validationMsg: PropTypes.string,
  onChangeHandler: PropTypes.func,
  textInputContainer: ViewPropTypes.style,
};

const styles = StyleSheet.create({
  inputContainer: {
    paddingHorizontal: '1%',
    paddingVertical: '1%',
    marginVertical: '1%',
  },
  textInputContainer: {
    width: '91%',
    height: inputHeight,
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderRadius: 8,
    borderWidth: 1,
    shadowColor: Colors.bgDarkGray,
    shadowOpacity: 0.5,
    shadowRadius: 2,
    shadowOffset: {
      width: 0,
      height: -1,
    },
    paddingHorizontal: 2,
    borderColor: Colors.card,
    backgroundColor: Colors.background,
    // backgroundColor: 'green',
  },
  textLabelStyle: {
    width: '92%',
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  textValidationMsg: {
    width: '92%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingVertical: 2,
  },
  textInputStyle: {
    // height: inputHeight,
    width: '96%',
    alignSelf: 'center',
    // borderWidth: 1,
    // borderRadius: 8,
    marginVertical: 2,
    padding: 12,
    // elevation: 2,
    color: Colors.black,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.medium,
    // shadowColor: Colors.card,
    // shadowOpacity: 0.6,
    // shadowRadius: 1,
    // shadowOffset: {
    //   width: 0.5,
    //   height: 0.5,
    // },
    // borderColor: Colors.card,
    backgroundColor: Colors.background,
  },
  transparantStyle: {
    backgroundColor: 'transparent',
    elevation: 0,
    marginVertical: 0,
  },
});
