/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import { View, TouchableOpacity, Text, StyleSheet } from 'react-native';
import Colors from '../../config/Colors';
import { Font, FontSize } from '../../config/Fonts';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

const TabContainer = ({...props}) => (
  <View style={styles.tabContainer}>
    <TouchableOpacity
      style={styles.tabRowOneContainer}
      onPress={() => props.changeTab('1')}>
      <Text
        style={[
          styles.textTab,
          { color: props.selectedTab == '1' ? Colors.black : Colors.border },
        ]}>
        {props.pendingText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '1' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
    <View style={[styles.straightLine, {
            backgroundColor:
              props.selectedTab == '1' ? Colors.black : Colors.border,
          },]} />
    <TouchableOpacity
      style={styles.tabRowTwoContainer}
      onPress={() => props.changeTab('2')}>
      <Text
        style={[
          styles.textTab,
          { color: props.selectedTab == '2' ? Colors.black : Colors.border },
        ]}>
        {props.completedText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '2' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
    <View style={[styles.straightLine, {
            backgroundColor:
              props.selectedTab == '2' ? Colors.black : props.selectedTab == '3' ? Colors.black : Colors.border,
          },]} />
    <TouchableOpacity
      style={styles.tabRowThreeContainer}
      onPress={() => props.changeTab('3')}>
      <Text
        style={[
          styles.textTab,
          { color: props.selectedTab == '3' ? Colors.black : Colors.border },
        ]}>
        {props.cancelledAndRescheduleText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '3' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
  </View>
);

export const TanTwoContainer = ({ ...props }) => (
  <View
    style={{
      alignItems: 'center',
      justifyContent: "space-evenly",
      borderBottomColor: '#E8E8E8',
      borderBottomWidth: 2,
      marginHorizontal: 10,
      flexDirection: 'row',
      paddingHorizontal: 10,
      paddingVertical: 10,
      marginTop: 10,
      // backgroundColor: 'red'
    }}>
    <TouchableOpacity
      style={styles.tabtwoContainer}
      onPress={() => props.changeTab('1')}>
      <Text
        style={[
          styles.textTab,
          { color: props.selectedTab == '1' ? Colors.black : Colors.border },
        ]}>
        {props.approvedText}
      </Text>
      <View
        style={[
          {
            width: wp('10%'),
            height: 2.5,
            alignItems: 'center',
            marginTop: 10,
            orderRadius: 20,
            marginBottom: -11,
          },
          {
            backgroundColor:
              props.selectedTab == '1' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
    <View style={[styles.tabtwostraightLine,{backgroundColor:Colors.black}]} />
    <TouchableOpacity
      style={styles.tabtwoContainer}
      onPress={() => props.changeTab('2')}>
      <Text
        style={[
          styles.textTab,
          { color: props.selectedTab == '2' ? Colors.black : Colors.border },
        ]}>
        {props.rejectedText}
      </Text>
      <View
        style={[
          {
            width: wp('10%'),
            height: 2.5,
            alignItems: 'center',
            marginTop: 10,
            orderRadius: 20,
            marginBottom: -11,
          },
          {
            backgroundColor:
              props.selectedTab == '2' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
  </View>
);

export default TabContainer;

const styles = StyleSheet.create({
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomColor: '#E8E8E8',
    borderBottomWidth: 2,
    marginHorizontal: 10,
    flexDirection: 'row',
    paddingHorizontal: 10,
    marginTop: 10,
    width:wp('94%')
  },
  textTab: {
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    textAlign:"center",
   
  },
  circleShapeView: {
    marginTop: '10%',
    width: 60,
    height: 60,
    borderRadius: 60 / 2,
    backgroundColor: Colors.button,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomTabLine: {
    width: wp('11%'),
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2,
  },
  tabRowOneContainer: {
    flex: 0.19,
    justifyContent:"center",
    alignItems: 'center',
  },
  tabRowTwoContainer: {
    flex: 0.29,
    alignItems: 'center',
  },
  tabRowThreeContainer: {
    flex: 0.5,
    alignItems: 'center',
  },
  tabtwoContainer: {
    flex: 0.5,
    alignItems: 'center',
  },
  straightLine: {
    width: wp('0.25%'),
    height: '90%',
    backgroundColor: Colors.border,
    marginBottom: hp('2%'),
  },
  tabtwostraightLine: {
    width: wp('0.25%'),
    height: '90%',
    backgroundColor: Colors.border,
    marginBottom: hp('1%'),
  },
  bottomTabTwoLine: {
    width: '75%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -11,
  },
});
