import React from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';

const {width, height} = Dimensions.get('screen');
const barWidth = width * 0.72;
const barHeight = height * 0.054;

function TaskType({imageSource, label, color, onPress}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.6}
      style={{width: '80%', alignItems: 'center'}}>
      <View
        style={{
          width: barWidth,
          minWidth: 300,
          height: barHeight,
          flexDirection: 'row',
          alignItems: 'center',
          marginVertical: barHeight / 6,
          borderRadius: barHeight / 2,
          elevation: 6,
          shadowColor: Colors.bgDarkGray,
          shadowRadius: 1,
          shadowOpacity: 0.8,
          shadowOffset: {width: 1, height: 1},
          backgroundColor: Colors.background,
        }}>
        <View
          style={{
            width: barHeight,
            height: barHeight,
            borderRadius: barHeight / 2,
            // backgroundColor: color,
          }}>
          <Image
            source={imageSource}
            style={{width: barHeight, height: barHeight, resizeMode: 'contain'}}
          />
        </View>
        <View style={{paddingHorizontal: 16}}>
          <Text
            style={{
              fontFamily: Font.bold,
              color: Colors.black,
              fontSize: FontSize.medium,
            }}>
            {label}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({});

export default TaskType;
