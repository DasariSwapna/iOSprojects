import React from 'react';
import {View, Text, Image, TouchableOpacity, StyleSheet} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';

const propStyle = percent => {
  const base_degrees = -135;
  const rotateBy = base_degrees + percent * 3.6;
  return {
    transform: [{rotateZ: `${rotateBy}deg`}],
  };
};

export function CircularPrograssBar({width = 120, height = 120, percent = 20}) {
  let stylesFromProps = propStyle(percent);
  return (
    <View
      style={[
        styles.container,
        // stylesFromProps,
        {
          width: width,
          height: height,
          borderRadius: height / 2,
          borderWidth: height / 10,
        },
      ]}>
      <View
        style={[
          styles.progressLayer,
          {
            width: width,
            height: height,
            borderRadius: height / 2,
            borderWidth: height / 10,
          },
        ]}></View>
      <View style={[styles.offsetLayer, {width: width, height: height}]}></View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: 120,
    height: 120,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 16,
    borderRadius: 100,
    borderColor: 'grey',
  },
  progressLayer: {
    width: 120,
    height: 120,
    borderWidth: 16,
    borderRadius: 100,
    position: 'absolute',
    borderLeftColor: 'transparent',
    borderBottomColor: 'transparent',
    borderRightColor: '#3498db',
    borderTopColor: '#3498db',
    transform: [{rotateZ: '45deg'}],
  },
  // offsetLayer: {
  //   borderWidth: 16,
  //   // borderRadius: 100,
  //   borderLeftColor: 'transparent',
  //   borderBottomColor: 'transparent',
  //   borderRightColor: 'grey',
  //   borderTopColor: 'grey',
  //   transform: [{rotateZ: '-135deg'}],
  // },
});
