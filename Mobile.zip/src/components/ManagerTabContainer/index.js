/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, TouchableOpacity, Text, StyleSheet} from 'react-native';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

const ManagerTabContainer = ({...props}) => (
  <View style={styles.tabContainer}>
    <TouchableOpacity
      style={styles.tabRowThreeContainer}
      onPress={() => props.changeTab('1')}>
      <Text
        style={[
          styles.textTab,
          {color: props.selectedTab == '1' ? Colors.black : Colors.border},
        ]}>
        {props.pendingText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '1' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>

    <View style={styles.straightLine} />
    <TouchableOpacity
      style={styles.tabRowThreeContainer}
      onPress={() => props.changeTab('2')}>
      <Text
        style={[
          styles.textTab,
          {color: props.selectedTab == '2' ? Colors.black : Colors.border},
        ]}>
        {props.completedText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '2' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>

    <View style={styles.straightLine} />

    <TouchableOpacity
      style={styles.tabRowThreeContainer}
      onPress={() => props.changeTab('3')}>
      <Text
        style={[
          styles.textTab1,
          {color: props.selectedTab == '3' ? Colors.black : Colors.border},
        ]}>
        {props.cancelledAndRescheduleText}
      </Text>
      <View
        style={[
          styles.bottomTabLine,
          {
            backgroundColor:
              props.selectedTab == '3' ? Colors.border : 'transparent',
          },
        ]}
      />
    </TouchableOpacity>
  </View>
);

export default ManagerTabContainer;

const styles = StyleSheet.create({
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomColor: '#E8E8E8',
    borderBottomWidth: 2,
    marginHorizontal: wp('1.0%'),
    flexDirection: 'row',
    paddingHorizontal: wp('1.0%'),
    marginTop: hp('1.0%'),
    //  paddingBottom : hp('2%')
    width: wp('95%'),
  },
  textTab: {
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    //  marginHorizontal: wp('0.5%'),
    textAlign: 'center',
    // padding: hp('0.2%'),
    //paddingRight: hp('-2.5%'),
  },
  textTab1: {
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    marginLeft: wp('2.5%'),
    textAlign: 'center',
    // padding: hp('0.2%'),
    //paddingRight: hp('-2.5%'),
  },
  circleShapeView: {
    marginTop: '10%',
    width: 60,
    height: 60,
    borderRadius: 60 / 2,
    backgroundColor: Colors.button,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomTabLine: {
    width: wp('9.5%'),
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2,
  },
  tabRowOneContainer: {
    flex: 0.3,
    // width: wp('40%'),
    alignItems: 'center',
    // padding : hp('1.5%')
  },
  tabRowTwoContainer: {
    flex: 0.3,
    alignItems: 'center',
  },
  tabRowThreeContainer: {
    flex: 0.5,
    alignItems: 'center',
  },
  straightLine: {
    width: wp('0.2%'),
    height: hp('3.0%'),
    backgroundColor: Colors.border,
    marginBottom: 5,
  },
});
