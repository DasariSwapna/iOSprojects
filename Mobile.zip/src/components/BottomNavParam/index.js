import React, {useRef} from 'react';
import {
  Dimensions,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import MaComIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Colors from '../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';
import Icons from '../../constants/Icons';

const {width, height} = Dimensions.get('screen');
const navIconHeight = height * 0.06;

function MenuIcon({label, iconName, onPressHandler}) {
  return (
    <View>
      <TouchableOpacity
        style={styles.iconContainer}
        onPress={() => onPressHandler()}>
        {iconName == 'tasks' ? (
          <FaIcons
            name={iconName}
            color={Colors.primary}
            size={navIconHeight / 1.8}
          />
        ) : (
          <MaComIcons
            name={iconName}
            color={Colors.primary}
            size={navIconHeight / 1.5}
          />
        )}
        <Text style={styles.bottomMenuText}>{label}</Text>
      </TouchableOpacity>
    </View>
  );
}

MenuIcon.prototype = {
  label: PropTypes.string,
  iconName: PropTypes.string,
  onPressHandler: PropTypes.func,
};

export default function BottomNav({
  homeNavHandler,
  alertNavHandler,
  createTaskNavHandler,
  myTaskNavHandler,
  calendarNavHandler,
}) {
  return (
    <View style={styles.bottomNavContainer}>
      <View style={styles.outerMenu}>
        <MenuIcon
          label={'Home'}
          iconName={'home-outline'}
          onPressHandler={() => homeNavHandler()}
        />
      </View>
      <View style={styles.innerMenu}>
        <MenuIcon
          label={'Alert'}
          iconName={'alert-circle-outline'}
          onPressHandler={() => alertNavHandler()}
        />
      </View>
      <View style={styles.centerMenu}>
        <TouchableOpacity
          style={styles.centerMenuIcon}
          onPress={() => createTaskNavHandler()}>
          <MaComIcons
            name={'plus-thick'}
            color={Colors.background}
            size={navIconHeight / 1.6}
          />
        </TouchableOpacity>
      </View>
      <View style={styles.innerMenu}>
        <MenuIcon
          label={'My Task'}
          iconName={'tasks'}
          onPressHandler={() => myTaskNavHandler()}
        />
      </View>
      <View style={styles.outerMenu}>
        <MenuIcon
          label={'Calender'}
          iconName={'calendar'}
          onPressHandler={() => calendarNavHandler()}
        />
      </View>
    </View>
  );
}

BottomNav.prototype = {
  homeNavHandler: PropTypes.func,
  alertNavHandler: PropTypes.func,
  createTaskNavHandler: PropTypes.func,
  myTaskNavHandler: PropTypes.func,
  calendarNavHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  bottomNavContainer: {
    flex: 1,
    position: 'absolute',
    bottom: 0,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 4,
    borderTopWidth: 1,
    borderTopColor: Colors.card,
    backgroundColor: Colors.background,
  },
  iconContainer: {
    height: navIconHeight,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 2,
  },
  centerMenuIcon: {
    position: 'absolute',
    top: -navIconHeight * 1.2,
    width: navIconHeight * 1.4,
    height: navIconHeight * 1.4,
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: (navIconHeight * 1.4) / 2,
    backgroundColor: Colors.primary,
  },
  outerMenu: {width: '19%'},
  innerMenu: {width: '19%'},
  centerMenu: {width: '20%'},
  bottomMenuText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    color: Colors.black,
  },
});
