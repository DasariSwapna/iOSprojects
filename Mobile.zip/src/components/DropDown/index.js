"use strict";
import React, { PropTypes } from "react";
import FontAwesome5 from "react-native-vector-icons/FontAwesome5";
import {
  View,
  StyleSheet,
  Dimensions,
  Modal,
  Text,
  ScrollView,
  TouchableOpacity,
  Platform,
  ActivityIndicator
} from "react-native";

import styles from "./styles";
import BaseComponent from "./BaseComponent";
import { Font } from "../../config/Fonts";
import AntIcon from "react-native-vector-icons/AntDesign";
import Entypo from "react-native-vector-icons/Entypo";
import Colors from "../../config/Colors";
let componentIndex = 0;

const defaultProps = {
  data: [],
  onChange: () => { },
  initValue: " Please select!",
  style: {},
  selectStyle: {},
  optionStyle: {},
  optionTextStyle: {},
  sectionStyle: {},
  sectionTextStyle: {},
  cancelStyle: {},
  cancelTextStyle: {},
  overlayStyle: {},
  cancelText: "cancel"
};

export default class ModalPicker extends BaseComponent {
  constructor() {
    super();
    this._bind("onChange", "open", "close", "renderChildren");
    this.state = {
      animationType: "slide",
      modalVisible: false,
      transparent: false,
      selected: "please select"
    };
  }

  componentDidMount() {
    this.setState({ selected: this.props.initValue });
    this.setState({ cancelText: this.props.cancelText });
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.initValue != this.props.initValue) {
      this.setState({ selected: nextProps.initValue });
    }
  }

  onChange(item, id) {
    console.log("ityem", item);
    this.props.onChange(item);
    {
      id == "DoctorTime"
        ? this.setState({
          selected: item.lable
        })
        : null;
    }
    this.close();
  }

  close() {
    this.setState({
      modalVisible: false
    });
  }

  open() {
    this.setState({
      modalVisible: true
    });
  }

  renderSection(section) {
    return (
      <View
        key={section.key}
        style={[styles.sectionStyle, this.props.sectionStyle]}
      >
        <Text style={[styles.sectionTextStyle, this.props.sectionTextStyle]}>
          {section.label}
        </Text>
      </View>
    );
  }

  renderOption(option, id) {
    return (
      <TouchableOpacity
        key={option.key}
        onPress={() => this.onChange(option, id)}
      >
        <View style={[styles.optionStyle, this.props.optionStyle]}>
          <Text style={[styles.optionTextStyle, this.props.optionTextStyle]}>
            {option}
          </Text>
        </View>
        <View style={{ borderBottomWidth: 0.9, borderColor: Colors.dWhite, width: '90%', alignSelf: 'center' }} />

      </TouchableOpacity>
    );
  }
  renderOptionList() {
    const id = this.props.id;

    var options = this.props.data.map(item => {
      return this.renderOption(item, id);
    });

    return (
      <TouchableOpacity
        style={[styles.overlayStyle, this.props.overlayStyle]}
        key={"modalPicker" + componentIndex++}
        onPressOut={() =>
          this.setState({
            modalVisible: false
          })}
      >
        <View style={this.props.optionContainer}>
          <View style={{ flexDirection: "row" }}>
            <AntIcon name="arrowleft" size={20} style={{
              width: '20%',
              paddingHorizontal: 10,
              color: Colors.border
            }} onPress={() => this.setState({ modalVisible: false })} />
            <Text style={{ width: '80%', fontFamily: Font.extraBold, fontSize: 20, flex: 1, color: Colors.border, textAlign: 'center' }} numberOfLines={1}>
              {this.props.title}
            </Text>
            <View style={{ width: '20%' }} />
          </View>
          <View style={{ paddingHorizontal: 10 }}>
            {options}
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  renderChildren() {
    if (this.props.children) {
      return this.props.children;
    }
    return (
      <>
        <View
          style={
            (
              [styles.selectStyle, this.props.selectStyle],
              { flexDirection: "row", width: "100%", }
            )
          }
        >
          <View style={{ width: "90%", marginStart: 10 }}>
            <Text style={[styles.selectTextStyle, this.props.selectTextStyle]}>
              {this.state.selected.length > 25
                ? this.state.selected.substring(0, 25) + "..."
                : this.state.selected}
            </Text>
          </View>
          <View style={{ justifyContent: "flex-end" }}>
            <Entypo
              style={{ height: 22, color: "#A020f0" }}
              name="chevron-small-down"
              size={20}
            />
          </View>

        </View>
        <View style={{ borderBottomWidth: 1, borderColor: Colors.dWhite, marginTop: 3 }} />
      </>
    );
  }

  render() {
    const dp = (
      <Modal
        transparent={true}
        ref="modal"
        visible={this.state.modalVisible}
        onRequestClose={this.close}
        animationType={this.state.animationType}
      >
        {this.renderOptionList()}
      </Modal>
    );
    if (this.props != null && this.props != "") {
      return (
        <View style={this.props.style}>
          {dp}
          <TouchableOpacity onPress={this.open}>
            {this.renderChildren()}
          </TouchableOpacity>
        </View>
      );
    } else {
      <ActivityIndicator />;
    }
  }
}
ModalPicker.defaultProps = defaultProps;
