"use strict";

import { StyleSheet, Dimensions } from "react-native";
import Colors from "../../config/Colors";
import { Font, FontSize } from "../../config/Fonts";

const { height, width } = Dimensions.get("window");

const PADDING = 8;
// const BORDER_RADIUS = 5;
const FONT_SIZE = 16;
const HIGHLIGHT_COLOR = "rgba(0,118,255,0.9)";
const OPTION_CONTAINER_HEIGHT = 400;

export default StyleSheet.create({
  overlayStyle: {
    width: width,
    height: height,
    backgroundColor: "rgba(0,0,0,0.7)",
    alignItems: "flex-end",
    justifyContent: "flex-end"
  },

  optionContainer: {
    backgroundColor: Colors.white,
    height: "30%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 25
  },

  cancelContainer: {
    left: width * 0.1,
    top: (height - OPTION_CONTAINER_HEIGHT) / 2 + 10
  },

  selectTextStyle: {
    textAlign: "left",
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    width: "65%",
    marginLeft: "-0.5%",
    color: Colors.black
  },

  cancelStyle: {
    padding: PADDING
  },

  cancelTextStyle: {
    textAlign: "center",
    color: "#333",
    fontSize: FONT_SIZE
  },

  optionStyle: {
    padding: PADDING,
    width: width,
    alignItems: "center"
  },

  optionTextStyle: {
    paddingVertical: "2%",
    textAlign: "left",
    fontFamily: Font.regular,
    color: "#9E2575"
  },

  sectionStyle: {
    padding: PADDING * 2,
    borderBottomWidth: 1
  },

  sectionTextStyle: {
    color: "#00B39C",
    fontSize: 22,
    marginLeft: "2.9%"
  }
});
