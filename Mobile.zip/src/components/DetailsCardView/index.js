import React from 'react';
import IonIcons from 'react-native-vector-icons/Ionicons';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Platform,
  FlatList
} from 'react-native';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import Colors from '../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import AppButton from '../Button';
import AppButtonWithIcon from '../ButtonWithIcon';
import { ScrollView } from 'react-native-gesture-handler';
import I18n from '../../locale/i18n';
export default function DetailsCardView({ ...props }) {
  const renderItem = ({ item }) => (
    <View style={{ alignItems: 'flex-start', justifyContent: 'center',width:wp('70%'), 
    }}>
      <Text style={styles.flatlistTextComponment} >{item.LC_TD_TEST_NAME}</Text>
    </View>
  )
  return (
    <View style={styles.cardContainer}>
      <View style={styles.innerCardContainer}>
        <View style={styles.nameContainer}>
          <View style={styles.nameRowContainer}>
            <Text style={styles.crmIdText}>{I18n.t('paramedic.myTask.clientname_label')}</Text>
            <Text style={styles.nameText}>{props.name}</Text>
          </View>
          <View style={styles.crmRowContainer}>
            <Text style={styles.crmIdText}>{I18n.t('paramedic.myTask.crmid_label')}</Text>
            <Text style={styles.crmIdNumber}>{props.crmid}</Text>
          </View>
        </View>
        <View style={styles.seperateLine}></View>
        <View style={styles.dateContainer}>
          <View style={styles.dateRowContainer}>
            <Text style={styles.dateText}>{I18n.t('paramedic.myTask.date_label')}</Text>
            <Text style={styles.flatlistTextComponment}>{props.date}</Text>
          </View>
          <View style={styles.dateRowContainer}>
            <Text style={styles.dateText}>{I18n.t('paramedic.myTask.time_label')}</Text>
            <Text style={styles.flatlistTextComponment}>{props.time}</Text>
          </View>
        </View>
        <View style={styles.mobileNumberContainer}>
          <View style={styles.mobileNumberRowContainer}>
            <Text style={styles.dateText}>{I18n.t('paramedic.myTask.mobile_number_label')}</Text>
            <Text style={styles.flatlistTextComponment} numberOfLines={1}>{props.mobile}</Text>
          </View>
          <View style={styles.mobileNumberRowIconContainer}>
          <TouchableOpacity style={styles.callIconContainer} onPress={props.callPress}>
              <IonIcons name={'call-outline'} color={Colors.border} size={wp('4%')} />
            </TouchableOpacity>
          </View>
        </View>
        <View style={[styles.addressContainer]}>
          <View style={styles.mobileNumberRowContainer}>
            <Text style={styles.dateText}>{I18n.t('paramedic.myTask.address_label')}</Text>
            <Text style={styles.dateNumber}>{props.address}</Text>
          </View>
          <View style={styles.mobileNumberRowIconContainer}>
            <TouchableOpacity style={styles.callIconContainer} onPress={props.mapPress}>
              <IonIcons name={'location-outline'} color={Colors.border} size={wp('4%')} />
            </TouchableOpacity>
          </View>
        </View>
        {props.paidAmount ?
          <View style={styles.mobileNumberContainer}>
            <View style={styles.paymentRowContainer}>
              <Text style={styles.dateText}>{I18n.t('paramedic.myTask.payment_label')}</Text>
              <View style={styles.paymentTextContainer}>
                <Text style={styles.flatlistTextComponment} numberOfLines={1}>{props.paidAmount}</Text>
                <Text style={[styles.flatlistTextComponment, { color: props.paymentStatusColor, marginHorizontal: wp('2%') }]} numberOfLines={1}>{props.paymentStatus}</Text>
              </View>
            </View>
          </View> : null
        }
        {props.testData ?
          <View style={[styles.testContainer, { marginBottom: hp('3%') }]}>
            <View style={styles.paymentRowContainer}>
              <Text style={styles.dateText}>{I18n.t('paramedic.myTask.test_label')}</Text>
              {/* <View style={{height:hp('10%')}}> */}
              <FlatList
                showsVerticalScrollIndicator={false}
                data={props.testData}
                renderItem={renderItem}
                keyExtractor={item => item.id}
                contentContainerStyle={styles.flatListInnerContainer}
                nestedScrollEnabled={true}
              />
            </View>
            {/* </View> */}
          </View> : null
        }
        <View style={styles.buttonContainer}>
          {props.isReached ?
            <>
              {props.isPns ?
                <AppButton title={I18n.t('paramedic.myTask.next_label')}
                  buttonTextStyle={styles.buttonText}
                  buttonStyle={styles.beforeReachedButton}
                  onPress={props.nextClickHandler} /> :
                <AppButtonWithIcon title={I18n.t('paramedic.myTask.reached_label')}
                  buttonTextStyle={styles.afterReachedTextStyle}
                  buttonStyle={styles.afterReachedButton}
                />
              }
            </>
            : props.isStarted==1?
            <AppButton title={I18n.t('paramedic.myTask.reached_label')}
              buttonTextStyle={styles.buttonText}
              buttonStyle={styles.beforeReachedButton}
              onPress={props.onPress} />:
              <AppButton title={I18n.t('paramedic.myTask.reached_label')}
              buttonTextStyle={styles.buttonText}
              buttonStyle={[styles.beforeReachedButton,{backgroundColor:Colors.inActiveButton}]}
              />
          }



        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  cardContainer: {
    borderRadius: 15,
    // maxHeight: hp('65%'),
    borderColor: Colors.border,
    borderWidth: Platform.OS == 'ios' ? hp('0.04%') : hp('0.1%'),
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOpacity: Platform.OS == 'ios' ? 0.2 : 0.5,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 2.5,
    elevation: Platform.OS == 'ios' ? 1 : 5,
    flexDirection: 'row',
    marginTop: '7%',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: wp('6%'),
  },
  innerCardContainer:
  {

    width: '100%',
    flexDirection: 'column',
  },
  nameContainer:
  {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginTop: hp('1.5%'),
    marginHorizontal: wp('5%'),
  },
  nameRowContainer:
  {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'center'
  },
  nameText:
  {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border
  },
  crmRowContainer:
  {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flexDirection: 'column',
  },
  crmIdText:
  {
    fontSize: FontSize.regular,
    fontFamily: Font.regular,
    color: Colors.border,
    marginVertical: hp('1%')
  },
  crmIdNumber:
  {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.babyCordTextColor,
    paddingBottom: 2
  },
  seperateLine:
  {
    height: Platform.OS == 'ios' ? hp('0.04%') : hp('0.1%'),
    width: '100%',
    backgroundColor: Colors.border,
    marginVertical: hp('1.5%')
  },
  dateContainer:
  {

    height: hp('6%'),
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: wp('5%'),
  },
  dateRowContainer:
  {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'column'
  },
  dateText:
  {
    fontSize: FontSize.regular,
    fontFamily: Font.regular,
    color: Colors.border
  },
  dateNumber:
  {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.black,
    marginTop: 10,
    lineHeight: 20,width:wp('60%'),
    textAlign:'left'
  },
  flatlistTextComponment:
  {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.black,
    marginTop: 10,
    lineHeight:20,
    
  },
  mobileNumberContainer:
  {
    height: hp('6%'),
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'row',
    marginHorizontal: wp('5%'),
    marginTop: hp('1.5%'),
  },
  testContainer:
  {
    // height:hp('6%'),
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'row',
    marginHorizontal: wp('5%'),
    marginTop: hp('1.5%'),
  },
  addressContainer:
  {
    // maxHeight:hp('10%'),
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'row',
    marginHorizontal: wp('5%'),
    // marginTop: hp('1%'),
    paddingVertical: hp('2%')
  },
  mobileNumberRowContainer:
  {
    flexDirection: 'column',
    flex: 0.8
  },
  mobileNumberRowIconContainer:
  {
    flexDirection: 'column',
    flex: 0.2,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
  
  },
  paymentRowContainer:
  {
    flexDirection: 'column',
    flex: 1
  },
  callIconContainer:
  {
    width: wp('8%'),
    height: wp('8%'),
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 50,
    borderColor: Colors.card,
    borderWidth: 2,
  
  },
  buttonContainer:
  {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: hp('2%'),
  },
  beforeReachedButton: {
    height: hp('5%'),
    width: '48%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    
  },
  afterReachedButton: {
    height: hp('5%'),
    width: '48%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    borderWidth: Platform.OS == 'ios' ? hp('0.07%') : hp('0.1%'),
    borderColor: Colors.babyCordTextColor
  },
  afterReachedTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.babyCordTextColor
  },
  buttonText: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  },
  paymentTextContainer:
  {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  flatListInnerContainer: {
    flex: 1,
    paddingBottom: hp('2%'),
  }

});
