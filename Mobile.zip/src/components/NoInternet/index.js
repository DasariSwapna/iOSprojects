import React, {useState, useEffect} from 'react';
import {Modal, StyleSheet, TouchableOpacity, Text, View} from 'react-native';
import Icon from 'react-native-vector-icons/MaterialIcons';

const NoInternetModal = ({show}) => {
  // console.log('Internet connection==============>', show);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(show);
    return () => {
      cleanup;
    };
  }, [show]);

  return (
    <Modal
      transparent={true}
      animationType={'none'}
      visible={visible}
      onRequestClose={() => {
        console.log('close modal');
      }}>
      <View style={styles.modalBackground}>
        <View style={styles.wrapper}>
          <Icon name="signal-wifi-off" size={62} color={'skyblue'} />
          <Text style={styles.primaryText}>No Internet!</Text>
          <Text>Please check your internet connection,</Text>
          <Text>You are offline</Text>
        </View>
      </View>
    </Modal>
  );
};

export default NoInternetModal;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#00000040',
  },
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'column',
    justifyContent: 'space-around',
    backgroundColor: '#00000080',
  },
  wrapper: {
    width: 340,
    height: 260,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'gray',
    backgroundColor: 'white',
  },
  primaryText: {
    color: 'blue',
    fontSize: 20,
    textTransform: 'capitalize',
    fontFamily: 'Poppins-SemiBold',
    marginTop: 10,
    marginBottom: 20,
  },
});
