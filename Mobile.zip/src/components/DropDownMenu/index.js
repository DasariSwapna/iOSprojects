import React from 'react';
import {
  Keyboard,
  Platform,
  ScrollView,
  FlatList,
  SectionList,
  View,
  Text,
  Dimensions,
  TouchableWithoutFeedback,
} from 'react-native';
import {Divider, Card, Menu, List, TextInput} from 'react-native-paper';
import Colors from '../../config/Colors';
import {Font, FontSize, FontMagneta} from '../../config/Fonts';
import Feather from 'react-native-vector-icons/Feather';

const {width, height} = Dimensions.get('screen');
const inputHeight = height * 0.065;
const drawerHeight = height * 0.32;
const drawerWidth = width * 0.86;
const iconSize = height * 0.03;
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

export default function DropDownMenu({
  initValue,
  labelName,
  listItems,
  labelKey = 'label',
  valueKey = 'value',
  disable = false,
  valueChangeHandler,
  width,
  outline,
  color,
}) {
  const inputRef = React.useRef(null);
  const [name, setName] = React.useState('');
  const [label, setLabel] = React.useState('Label');
  const [list, setList] = React.useState([]);
  const [visible, setVisible] = React.useState(false);
  const [search, setSearch] = React.useState('');
  const [isEditable, setIsEditable] = React.useState(true);
  const [keyboardStatus, setKeyboardStatus] = React.useState(false);

  React.useEffect(() => {
    const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
      // setKeyboardStatus(true);
    });
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
      // setKeyboardStatus(false);
    });

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  React.useEffect(() => {
    setLabel(labelName);
  }, [labelName]);

  React.useEffect(() => {
    if (listItems && listItems.length > 10) setList(listItems);
    else setList(listItems);
  }, [listItems]);

  React.useEffect(() => {
    if (list && initValue) {
      // console.log('List :', list);
      // console.log('initial :', initValue);
      const initItem = list.find(item => item[valueKey] == initValue);
      if (initItem) {
        setName(initItem[labelKey]);
        valueChangeHandler(initItem[valueKey], initItem[labelKey]);
      } else {
        setName('');
      }
    } else {
      setName('');
    }
  }, [initValue, listItems, list]);

  React.useEffect(() => {
    // For Search function
    const localList = listItems;
    if (search != '') {
      const searchList = localList.filter(
        item =>
          item[labelKey].toLowerCase().indexOf(search.toLowerCase()) !== -1,
      );
      if (searchList.length !== 0) {
        setList(searchList);
      } else {
        setList([]);
      }
      console.log(searchList);
    } else {
      setList(listItems);
    }
  }, [search]);

  const openMenu = () => {
    inputRef.current.blur();
    setVisible(true);
  };

  const closeMenu = () => setVisible(false);

  const dropDownChangeHandler = item => {
    setName(item[labelKey]);
    closeMenu();
    setSearch('');
    valueChangeHandler(item[valueKey], item[labelKey]);
  };

  const renderMenu = ({item, index}) => {
    return (
      <View
        style={{width: drawerWidth}}
        pointerEvents={disable == false ? 'auto' : 'none'}>
        <List.Item
          style={{width: drawerWidth}}
          disabled={disable}
          title={item[labelKey]}
          titleStyle={{
            fontWeight: '400',
            fontSize: FontSize.medium,
            fontFamily: Font.regular,
          }}
          onPress={() => dropDownChangeHandler(item)}
        />
        {list.length - 1 != index && <Divider />}
      </View>
    );
  };

  const listEmptyComponent = () => (
    <View
      style={{
        height: '50%',
        width: drawerWidth,
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
      }}>
      <Text style={{marginTop: 10, fontFamily: Font.regular}}>
        No Results Found
      </Text>
    </View>
  );

  return (
    <View
      style={{
        width: outline == true ? '90%' : '87%',
        alignSelf: 'center',
        paddingHorizontal: 2,
        // backgroundColor: 'green',
      }}>
      <Menu
        visible={visible}
        onDismiss={closeMenu}
        style={{width: drawerWidth}}
        contentStyle={{
          marginTop:
            Platform.OS == 'ios' ? (keyboardStatus == true ? -60 : 56) : 16,
        }}
        statusBarHeight={keyboardStatus == true ? -60 : 60}
        anchor={
          <TouchableWithoutFeedback onPress={() => openMenu()}>
            <View>
              <TextInput
                mode={outline == true ? 'outlined' : 'flat'}
                //  mode={outline == true ? 'outlined' : 'outlined'}
                label={outline == true ? '' : label}
                // label={label}
                placeholder={label}
                value={name}
                ref={inputRef}
                editable={false}
                // pointerEvents={'none'}
                onChangeText={() => setVisible(true)}
                onFocus={() => openMenu()}
                onTouchStart={() => openMenu()}
                style={{
                  height: inputHeight,
                  borderColor: Colors.card,
                  backgroundColor: 'transparent',
                  fontSize:
                    outline == true ? FontSize.medium : FontSize.semiLarge,
                }}
                outlineColor={outline == true ? Colors.card : Colors.bgDarkGray}
                underlineColor={Colors.textUnderlineColor}
                theme={{
                  roundness: 8,
                  colors: {
                    placeholder: color ? color : Colors.bgDarkGray,
                    text: Colors.black,
                    primary: Colors.button,
                    secondary: Colors.teal,
                    underlineColor: 'transparent',
                    background: 'transparent',
                  },
                  fonts: {
                    regular: {
                      fontFamily: Font.regular,
                    },
                  },
                }}
                showSoftInputOnFocus={false}
                right={
                  <TextInput.Icon
                    name="chevron-down"
                    color={Colors.border}
                    size={iconSize}
                    onPress={openMenu}
                  />
                  // <Feather
                  //   name="chevron-down"
                  //   color={Colors.border}
                  //   size={32}
                  //   onPress={openMenu}
                  // />
                }
              />
            </View>
          </TouchableWithoutFeedback>
        }>
        <TextInput
          label="Search"
          value={search}
          onChangeText={setSearch}
          style={{
            width: '100%',
            shadowColor: Colors.bgDarkGray,
            shadowOpacity: 0.6,
            shadowRadius: 1,
            shadowOffset: {
              width: 1,
              height: 1,
            },
            backgroundColor: Colors.bgWhite,
            fontSize: outline == true ? FontSize.medium : FontSize.semiLarge,
          }}
          theme={{
            colors: {
              placeholder: Colors.primary,
              text: Colors.black,
              primary: Colors.primary,
              secondary: Colors.teal,
              underlineColor: 'transparent',
              background: 'transparent',
            },
            fonts: {
              regular: {
                fontFamily: Font.regular,
              },
            },
          }}
        />
        <FlatList
          // style={
          //   list &&
          //   list.length > 10 && {height: drawerHeight, width: drawerWidth}
          // }
          contentContainerStyle={{flexGrow: 1}}
          data={list}
          renderItem={renderMenu}
          keyExtractor={item => item[valueKey]}
          extraData={list}
          ListEmptyComponent={() => listEmptyComponent()}
          nestedScrollEnabled={true}
        />
      </Menu>
    </View>
  );
}
