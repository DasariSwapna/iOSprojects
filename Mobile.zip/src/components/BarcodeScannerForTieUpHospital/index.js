import React, {useState, useEffect, useRef} from 'react';
import {
  Button,
  Text,
  View,
  Alert,
  StatusBar,
  Modal,
  TouchableOpacity,
  BackHandler,
} from 'react-native';
import {RNCamera} from 'react-native-camera';
import {useRoute, useFocusEffect} from '@react-navigation/native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import BarcodeMask from 'react-native-barcode-mask';
import { Paramedic } from '../../../navigations/RouteTypes';

const BarcodeScanner = (props) => {
  
  useFocusEffect(
    React.useCallback(() => {
   // alert(props.camera)
    }, [])
  )

 
  const onBarCodeRead = (scanResult) => {
    // console.warn(scanResult.type);
    // console.warn(scanResult.data);

    if (scanResult.data != null) {
      //navigation.goBack()
     //props.onBarCodeRead(scanResult)
    // alert(scanResult.data)
     props.getBarcode(scanResult)
    //  props.navigation.navigate(Paramedic.pnsSelectTest,{barcode:scanResult.data});
    }
     return;
  };

  return (
      <View style={{height:hp('100%'),width:wp('100%')}}>
          {props.camera==true?
        <RNCamera
          defaultTouchToFocus
          captureAudio={false}
          flashMode={RNCamera.Constants.FlashMode.auto}
          mirrorImage={false}
          onBarCodeRead={onBarCodeRead.bind(this)}
          onFocusChanged={() => {}}
          onZoomChanged={() => {}}
          // permissionDialogTitle={'Permission to use RNCamera'}
          // permissionDialogMessage={'We need your permission to use your RNCamera phone'}
          style={styles.preview}
          type={RNCamera.Constants.Type.back}>
          <BarcodeMask
            width={wp('80%')}
            height={hp('20%')}
            edgeColor={'red'}
            showAnimatedLine={true}
            animatedLineColor={'red'}
            edgeBorderWidth={2}
          />
        </RNCamera>:null}
        </View>
  );
};

const styles = {
  container: {
    flex: 1,
  },
  preview: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    position: 'absolute',
    padding: 16,
    right: 0,
    left: 0,
    alignItems: 'center',
  },
  topOverlay: {
    top: 0,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomOverlay: {
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  enterBarcodeManualButton: {
    padding: 15,
    backgroundColor: 'white',
    borderRadius: 40,
  },
  scanScreenMessage: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
export default BarcodeScanner;
