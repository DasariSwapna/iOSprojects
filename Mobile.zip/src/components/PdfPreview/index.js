import React from 'react';
import {View, StyleSheet} from 'react-native';
import Pdf from 'react-native-pdf';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import Colors from '../../config/Colors';
import Images from '../../constants/Images';

function Buttons({
  uploadButtonHandler,
  downloadButtonHandler,
  shareButtonHandler,
}) {
  <View
    style={{
      alignSelf: 'flex-end',
      flexDirection: 'row',
      width: wp('10%'),
      height: 40,
      alignItems: 'center',
      justifyContent: 'space-between',
      marginRight: hp('7%'),
      marginTop: hp('1%'),
    }}>
    <TouchableOpacity onPress={uploadButtonHandler}>
      <Image
        source={Images.download1}
        style={{width: hp('3%'), height: hp('3%'), marginRight: 8}}
        resizeMode="cover"
      />
    </TouchableOpacity>
    <TouchableOpacity onPress={downloadButtonHandler}>
      <Image
        source={Images.download1}
        style={{width: hp('3%'), height: hp('3%'), marginRight: 8}}
        resizeMode="cover"
      />
    </TouchableOpacity>
    <TouchableOpacity onPress={shareButtonHandler}>
      <IonIcons name={'share-social'} color={Colors.border} size={hp('3%')} />
    </TouchableOpacity>
  </View>;
}

function PdfPreview({source}) {
  return (
    <View
      style={{
        borderColor: Colors.primary,
        backgroundColor: Colors.background,
        marginHorizontal: wp('5%'),
        marginVertical: hp('2%'),
        width: '90%',
        height: '65%',
        borderWidth: 0.25,
        borderRadius: 10,
        shadowColor: Colors.primary,
        shadowOffset: {
          width: 0,
          height: 3,
        },
        shadowOpacity: 0.29,
        shadowRadius: 4.65,
        elevation: 7,
      }}>
      <Pdf
        source={source}
        onLoadComplete={(numberOfPages, filePath) => {
          console.log(`Number of pages: ${numberOfPages}`);
        }}
        onPageChanged={(page, numberOfPages) => {
          console.log(`Current page: ${page}`);
        }}
        onError={error => {
          console.log(error);
        }}
        onPressLink={uri => {
          console.log(`Link pressed: ${uri}`);
        }}
        style={styles.pdf}
      />
    </View>
  );
}

export default PdfPreview;

const styles = StyleSheet.create({
  pdf: {
    marginVertical: wp('1%'),
    marginHorizontal: wp('1%'),
    width: '98%',
    height: '98%',
    backgroundColor: Colors.white,
  },
});
