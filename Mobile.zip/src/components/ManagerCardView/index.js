import React from 'react';
import IonIcons from 'react-native-vector-icons/Ionicons';
import {
  Image,
  StyleSheet,
  View,
  Text,
  TouchableOpacity,
  Platform,
} from 'react-native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import Colors from '../../config/Colors';
import {Font, FontSize, FontMagneta} from '../../config/Fonts';
import AppButton from '../ButtonPink';
import AppButtonWithIcon from '../ButtonWithIcon';

export default function ManagerCardView({...props}) {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.innerCardContainer}>
        <View style={styles.nameContainer}>
          <View style={styles.nameRowContainer}>
            <Text style={styles.nameText}>{props.name}</Text>
          </View>
         
        </View>
        <View style={styles.seperateLine}></View>
        <View style={styles.nameContainer}>
          <View style={styles.nameRowContainer1}>
            <Text style={styles.nameText1}>Total test</Text>
            <Text style={styles.nameText2}> {props.testCount}</Text>
          </View>
          <View style={styles.crmRowContainer}>
            {props.selectedTab == '1' ? (
              <Text style={styles.pendingText}>Pending</Text>
            ) : props.selectedTab == '2' ? (
              <Text style={styles.approvedText}>Approved</Text>
            ) : props.selectedTab == '3' ? (
              <Text style={styles.autoApprovedText}>Auto Approved</Text>
            ) : null}
          </View>
        </View>
        <View style={styles.nameContainer}>
          <View style={styles.nameRowContainer2}>
            <Text style={styles.nameText3}>Amount </Text>
            <Text style={styles.nameText4}> {props.invoiceAmount}</Text>
          </View>
          <View style={styles.buttonContainernew}>
            {props.selectedTab == '1' ? (
              <AppButton
                title={props.viewText}
                buttonStyle={styles.viewButton}
                buttonTextStyle={styles.startViewTextStyle}
                onPress={() => props.startCardClickHandler()}
              />
            ) : props.selectedTab == '2' ? (
              <AppButton
                title={props.viewText}
                buttonStyle={styles.viewButton}
                buttonTextStyle={styles.startViewTextStyle}
                onPress={() => props.startCardClickHandler()}
              />
            ) : props.selectedTab == '3' ? (
              <AppButton
                title={props.viewText}
                buttonStyle={styles.viewButton}
                buttonTextStyle={styles.startViewTextStyle}
                onPress={() => props.startCardClickHandler()}
              />
            ) : null}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  cardContainer: {
    borderRadius: 15,
    height: hp('16%'),
    borderColor: Colors.border,
    borderWidth: Platform.OS == 'ios' ? hp('0.04%') : hp('0.1%'),
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOpacity: Platform.OS == 'ios' ? 0.2 : 0.5,
    shadowOffset: {width: 0, height: 2},
    shadowRadius: 2.5,
    elevation: Platform.OS == 'ios' ? 1 : 5,
    flexDirection: 'row',
    marginTop: '7%',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: wp('7%'),
   // padding : wp('4%')
  },
  innerCardContainer: {
    width: '100%',
    flexDirection: 'column',
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: hp('1.0%'),
    marginHorizontal: wp('5%'),
  },
  nameRowContainer: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },

  nameRowContainer1: {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flexDirection: 'row',
  },
  nameRowContainer2: {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flexDirection: 'row',
  },
  nameText: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.black,
  },

  nameText1: {
    fontSize: FontSize.medium,
    fontFamily: Font.bold,
    color: Colors.black,
  },
  nameText2: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.black,
  },

  nameText3: {
    fontSize: FontSize.medium,
    fontFamily: Font.bold,
    color: Colors.darkPinknew,
  },

  nameText4: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.darkPinknew,
  },

  crmRowContainer: {
    flex: 0.5,
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    flexDirection: 'row',
  },
  crmIdText: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
  },
  pendingText: {
    marginHorizontal: hp('-1.0%'),
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.button,
  },
  approvedText: {
    marginHorizontal: hp('-1.0%'),
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.babyCordTextColor,
  },
 
  autoApprovedText: {
    marginHorizontal: hp('-1.0%'),
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.babyCordTextColor,
  },
  crmIdNumber: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.babyCordTextColor,
    paddingBottom: 2,
  },
  seperateLine: {
    height: Platform.OS == 'ios' ? hp('0.04%') : hp('0.1%'),
    width: '100%',
    backgroundColor: Colors.border,
    marginVertical: hp('1.5%'),
  },
  dateContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: 18,
    marginVertical: 10,
  },
  dateRowContainer: {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  dateText: {
    fontSize: FontSize.regular,
    fontFamily: Font.regular,
    color: Colors.border,
  },
  dateNumber: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.black,
    marginTop: 10,
  },
  mobileNumberContainer: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'row',
    marginHorizontal: 18,
    marginVertical: 10,
  },
  mobileNumberRowContainer: {
    flexDirection: 'column',
    flex: 0.8,
  },
  mobileNumberRowIconContainer: {
    flexDirection: 'column',
    flex: 0.2,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
  },
  callIconContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 25,
    borderColor: Colors.card,
    borderWidth: 2,
  },
  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: hp('4%'),
  },
  beforeReachedButton: {
    height: hp('4.5%'),
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3,
  },
  afterReachedButton: {
    height: hp('4.5%'),
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    borderWidth: Platform.OS == 'ios' ? hp('0.07%') : hp('0.1%'),
    borderColor: Colors.babyCordTextColor,
  },
  afterReachedTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.babyCordTextColor,
  },
  buttonText: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  },
  viewButton: {
    height: hp('3.5%'),
    width: wp('10%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.white,
    elevation: 2,
    borderRadius: 25,
    paddingVertical: hp('0.3%'),
    paddingHorizontal: hp('1.0'),
    marginHorizontal: hp('-1.0%'),
    borderColor: Colors.button,
    borderWidth: 0.5,
  },

  buttonContainernew: {
    flex: 0.5,
    alignItems: 'flex-end',
    justifyContent: 'flex-end',
    flexDirection: 'row',
  },
});
