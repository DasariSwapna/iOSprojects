/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {
  Dimensions,
  View,
  TouchableOpacity,
  Text,
  StyleSheet,
} from 'react-native';
import {color} from 'react-native-reanimated';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';

const {width, height} = Dimensions.get('screen');
const buttonHeight = height * 0.05;
const circularButtonHeight = height * 0.066;
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

export function CircularButton({onPress}) {
  return (
    <TouchableOpacity onPress={onPress}>
      <View style={styles.circleShapeView}>
        <Fa5Icons
          name="arrow-right"
          size={30}
          color={Colors.white}
          solid
          style={{textAlign: 'auto'}}
        />
      </View>
    </TouchableOpacity>
  );
}

const AppButton = ({
  onPress,
  title,
  buttonStyle,
  buttonTextStyle,
  disable,
  isTransparent,
}) => (
  <TouchableOpacity
    disabled={disable}
    onPress={onPress}
    activeOpacity={0.6}
    style={[
      styles.appButtonContainer,
      buttonStyle,
      isTransparent && {backgroundColor: Colors.button, elevation: 0},
    ]}>
    <Text style={[styles.appButtonText, buttonTextStyle]}>{title}</Text>
  </TouchableOpacity>
);

export default AppButton;

const styles = StyleSheet.create({
  appButtonContainer: {
    height: buttonHeight,
    minWidth: wp('22%'),
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    backgroundColor: Colors.button,
    borderRadius: buttonHeight / 2,
    paddingVertical: hp('0.4%'),
    paddingHorizontal: hp('3.2%'),
  },
  appButtonText: {
    color: Colors.button,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    alignSelf: 'center',
    // textTransform: 'capitalize',
  },
  circleShapeView: {
    marginTop: '10%',
    width: circularButtonHeight,
    height: circularButtonHeight,
    borderRadius: circularButtonHeight / 2,
    backgroundColor: Colors.black,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
