/* eslint-disable react-native/no-inline-styles */
import React from 'react';
import {View, TouchableOpacity, Text, StyleSheet} from 'react-native';
import {color} from 'react-native-reanimated';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Colors from '../../config/Colors';
import {Font} from '../../config/Fonts';
import IonIcons from 'react-native-vector-icons/Ionicons';
import { heightPercentageToDP as hp,widthPercentageToDP as wp } from 'react-native-responsive-screen';


const AppButtonWithIcon =({
  onPress,
  title,
  buttonStyle,
  buttonTextStyle,
  disable,
  isTransparent,
}) =>
(
  <TouchableOpacity
    disabled={disable}
    onPress={onPress}
    style={[
      styles.appButtonContainer,
      buttonStyle,
      isTransparent && {backgroundColor: '#00000000', elevation: 0},
    ]}>
      <View style={{flexDirection:'row'}}>
    <Text style={[styles.appButtonText, buttonTextStyle]}>{title}</Text>
    <IonIcons name={'checkmark-circle-outline'} color={Colors.babyCordTextColor} size={hp('2.5%')} style={styles.iconStyle} />
    </View>
  </TouchableOpacity>
)

export default AppButtonWithIcon;


const styles = StyleSheet.create({
  appButtonContainer: {
    height: hp('4%'),
    minWidth: 120,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 2,
    backgroundColor: Colors.button,
    borderRadius: 50,
    paddingVertical: 4,
    paddingHorizontal: 32,
  },
  appButtonText: {
    color: Colors.background,
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    // textTransform: 'capitalize',
  },
  circleShapeView: {
    marginTop: '10%',
    width: 60,
    height: 60,
    borderRadius: 60 / 2,
    backgroundColor: Colors.button,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconStyle:{
    marginLeft:5
  }
});
