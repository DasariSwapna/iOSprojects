import React, {useState, useRef, useEffect} from 'react';
import {View, StyleSheet, Animated} from 'react-native';
import {
  Text,
  Button,
  Dialog,
  Paragraph,
  Portal,
  Snackbar,
  Surface,
  Provider,
} from 'react-native-paper';
import {BTN_COLOR} from '../../constants/color';
import {delay} from '../../utils/helper';
import {Font, FontSize} from '../../config/Fonts';
import Colors from '../../config/Colors';

export const Toast = ({showToast, msg, bgColor, txtColor}) => {
  const [visible, setVisible] = React.useState(false);
  const onDismissSnackBar = () => setVisible(false);

  React.useEffect(() => {
    setVisible(showToast);
  }, [showToast]);

  const [message, setMssage] = useState('');
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (showToast == true) {
      setMssage(msg);
      fadeIn();
    }
    // if (showToast == false) fadeOut();
  }, [showToast]);

  const fadeIn = () => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();
    setTimeout(async () => await fadeOut(), 2000);
  };

  const fadeOut = () => {
    Animated.timing(fadeAnim, {
      toValue: 0,
      duration: 2000,
      useNativeDriver: true,
    }).start();
  };

  return message != '' ? (
    <Animated.View
      style={[
        styles.fadingContainer,
        {
          opacity: fadeAnim,
          backgroundColor: bgColor,
        },
      ]}>
      <Text style={[styles.fadingText, {color: txtColor}]}>{message}</Text>
    </Animated.View>
  ) : null;
  // return (
  //   // <View style={styles.container}>
  //   <Snackbar
  //     visible={visible}
  //     duration={Snackbar.DURATION_LONG}
  //     onDismiss={onDismissSnackBar}
  //     numberOfLines={2}
  //     style={{
  //       alignItems: 'center',
  //       justifyContent: 'center',
  //       textAlign: 'center',
  //       zIndex: 1000,
  //       backgroundColor: Colors.error,
  //     }}>
  //     <Text style={styles.text}>{msg}</Text>
  //   </Snackbar>
  //   // </View>
  // );
};

const styles = StyleSheet.create({
  fadingContainer: {
    zIndex: 9999,
    // bottom: 10,
    position: 'absolute',
    top: 36,
    width: '80%',
    alignSelf: 'center',
    position: 'absolute',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 16,
    borderRadius: 10,
  },
  fadingText: {
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    textAlign: 'center',
    margin: 10,
  },
  container: {
    flex: 1,
    position: 'absolute',
    top: 20,
    justifyContent: 'center',
  },
  text: {
    textAlign: 'center',
    color: Colors.background,
  },
});
