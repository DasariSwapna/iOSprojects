import React, {createContext} from 'react';
import {routeNameRef} from '../../navigations';

export const ScreenTrackContext = createContext();

class ScreenTrackContextProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentScreen: '',
      prevScreen: '',
      isLaunched: false,
      setLaunchApp: val => {
        this.setState({
          isLaunched: val,
        });
      },
    };

    this.value = {
      currentScreen: this.state.currentScreen,
      prevScreen: this.state.prevScreen,
      isLaunched: this.state.isLaunched,
      setCurrentScreen: this.setCurrentScreen,
      setPrevScreen: this.setPrevScreen,
      setLaunchApp: this.state.setLaunchApp,
    };
  }

  setCurrentScreen = val => {
    console.log('screen context:', val);
    this.setState({
      currentScreen: val,
    });
  };

  setPrevScreen = val => {
    console.log('screen context:', val);
    this.setState({
      prevScreen: val,
    });
  };

  render() {
    return (
      <ScreenTrackContext.Provider value={this.value}>
        {this.props.children}
      </ScreenTrackContext.Provider>
    );
  }
}

export default ScreenTrackContextProvider;
