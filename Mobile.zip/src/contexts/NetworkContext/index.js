import React from 'react';
import NetInfo from '@react-native-community/netinfo';

export const NetworkContext = React.createContext();

class NetworkProvider extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isConnected: true,
    };
    this.unsubscribe;
  }

  componentDidMount = () => {
    this.unsubscribe = NetInfo.addEventListener(this.handleConnectivityChange);
  };

  componentWillUnmount = () => {
    if (this.unsubscribe != null) this.unsubscribe();
  };

  handleConnectivityChange = info => {
    this.setState({isConnected: info.isConnected});
  };

  render() {
    return (
      <NetworkContext.Provider value={this.state}>
        {this.props.children}
      </NetworkContext.Provider>
    );
  }
}

export default NetworkProvider;
