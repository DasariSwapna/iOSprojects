import React from 'react';
import {View, Text} from 'react-native';
import Navigation from './navigations';
import ProfilePending from './containers/ProfilePending';
import ProfileStartDay from './containers/paramedic/ProfileStartDay';
import MangerApprovalScreen from './containers/sales/MangerApproval';
import Alert from './containers/paramedic/Alert';
import Sample from './containers/Sample';
import Pdf from './containers/sales/CreateVendor/CreateVendorTermsCondition';
import SignIn from './containers/SignIn';
export default function () {
  return <Navigation />;
}