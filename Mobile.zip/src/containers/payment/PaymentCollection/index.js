import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import {
  isValidUsername,
  isValidPassword,
  validateRadioEmpty,
  BackHandler,
} from '../../../utils/Validators';
import PaymentCollectionScreen from './Screen';
import { Routes, Sales, Paramedic } from '../../../navigations/RouteTypes';
import {
  getDtByOrderId,
  getPayementMode,
  getOtpPayementMode,
  verifyOtpPayementMode,
  insertPayementMode,
  insertPaymentOnline,
} from '../../../store/Actions';
import {
  validateAmount,
  validateEmpty,
  validateName,
  validateMobileNo,
  validateEmail1,
  validateUsername,
  validateAddressLine,
  validatePincodeEmpty,
} from '../../../utils/Validators';
import { Toast } from '../../../components/Toast';
import { delay } from '../../../utils/Helpers';

class PaymentCollection extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showToast: false,
      errorMsg: '',

      showMobileConfirmModal: false,
      showSuccessModal: false,
      showOtpPaymentModal: false,
      otpButtonEnabled: false,
      otpVerified: false,
      nextButtonEnable: false,

      paymentMode: '',
      mobileNumber: '',
      email: '',
      amount: '',
      remarks: '',

      otp: '',
      orderId: null,

      pamentModeValidMsg: '',
      amountValidMsg: '',
      emailIdValidMsg: '',
      mobileNumberValidMsg: '',
      remarksValidMsg: '',

      isValidPayementMode: false,
      isValidAmount: false,
      isValidEmail: false,
      isValidMobileNumber: false,
      isValidRemarks: false,
    };
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.paymentRequest);
    const valid1 = validateRadioEmpty(this.state.paymentMode);
    const valid2 = validateRadioEmpty(this.state.amount);
    const valid3 = validateEmail1(this.state.email);

    const valid4 = validateMobileNo(this.state.mobileNumber);
    //const valid5 = validateEmail1(this.state.remarks);

    if (
      valid1.val &&
      valid2.val &&
      valid3.val &&
      valid4.val
      //  valid5.val
    ) {
      this.setState({
        isValidPayementMode: valid1.val,
        pamentModeValidMsg: '',
        isValidAmount: valid2.val,
        amountValidMsg: '',
        isValidEmail: valid3.val,
        emailIdValidMsg: '',
        isValidMobileNumber: valid4.val,
        mobileNumberValidMsg: '',
        // isValidRemarks: valid5.val,
        // remarksValidMsg: '',
      });
      this.update();
    } else {
      this.setState({
        isValidPayementMode: valid1.val,
        pamentModeValidMsg: valid1.msg,
        isValidAmount: valid2.val,
        amountValidMsg: 'Please enter amount',
        isValidEmail: valid3.val,
        emailIdValidMsg: valid3.msg,
        isValidMobileNumber: valid4.val,
        mobileNumberValidMsg: valid4.msg,
        // isValidRemarks: valid5.val,
        // remarksValidMsg: 'Please enter remarks',
      });
    }
  };

  update = () => {
    const data = {
      crmno: this.props.payDetailResponse.crmId,
      paymentorderid: this.props.payDetailResponse.orderid,
      paymentamount: this.state.amount.toString(),
      paymentremarks: this.state.remarks,
      paymenttransid: null,
      lc_pyd_authorizationcode: null,
      flag: 1,
      createdby: this.props.UserID,
      mobileno: this.state.mobileNumber,
      paymentmodedid: this.state.paymentMode,
      email: this.state.email,
    };
    if (this.state.paymentMode === 1) {
      this.props.onInsertPayementMode(data, this.props.accessToken);
    } else {
      // this.props.navigation.navigate(Sales.paymentCollection);
      this.props.onInsertPayementModeOnline(data, this.props.accessToken);
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  cancelMobileConfirmHandler = () => {
    this.setState({
      showMobileConfirmModal: false,
      showOtpPaymentModal: false,
    });
  };

  okayMobileConfirmHandler = () => {
    const data = {
      patient_id: this.state.mobileNumber,
      sms_validtimelimit: '3',
      lang_id: 1,
    };
    this.props.onGetOtpPayementMode(data, this.props.accessToken);
  };

  enterOtpEnable = () => {
    this.setState({
      showMobileConfirmModal: false,
      showOtpPaymentModal: true,
    });
  };

  otpHandler = () => {
    if (this.state.mobileNumber.length == 10) {
      this.setState({
        showMobileConfirmModal: true,
      });
    }
  };

  otpSubmitHandler = () => {
    if (this.state.otp == '') {
      this.setState(
        {
          errorMsg: 'please enter otp',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    } else {
      const data = {
        mobileno: this.state.mobileNumber,
        otp: this.state.otp,
      };
      this.props.onVerifyOtpPayementMode(data, this.props.accessToken);
    }

    // this.setState({
    //   showOtpPaymentModal: false,
    //   showSuccessModal: true,
    // });

    // setTimeout(() => {
    //   this.setState({
    //     showSuccessModal: false,
    //   });
    //   // this.props.navigation.navigate(Sales.createOrderConfirmation);
    // }, 2000);
  };

  detailBindByOrderId = () => {
    this.setState({
      mobileNumber: this.props.payementModeDtByIDResponse.Mobile,
      email: this.props.payementModeDtByIDResponse.Email,
      amount: this.props.payementModeDtByIDResponse.Amount.toString(),
      orderId: this.props.payementModeDtByIDResponse.OrderID,
    });
  };

  paymentModeHandlerDetails = val => {
    if (val === 1) {
      this.setState({
        paymentMode: val,
        otpButtonEnabled: true,
        nextButtonEnable: false,
      });
    } else if (val === 2) {
      this.setState({
        paymentMode: val,
        otpButtonEnabled: false,
        nextButtonEnable: true,
      });
    }
  };

  amountHandlerDetail = val => {
    this.setState({
      amount: val,
    });
  };

  emailHandlerDetail = val => {
    this.setState({
      email: val,
    });
  };

  mobileNumberHandler = val => {
    this.setState({
      mobileNumber: val,
      otpVerified: false,
      otpButtonEnabled: true,
      nextButtonEnable: false
    });
  };

  remarksHandler = val => {
    this.setState({
      remarks: val,
    });
  };

  otpChangeHandler = val => {
    this.setState({ otp: val });
  };

  componentDidMount() {
    // alert(this.props.Role);
    console.log('CRMID ' + this.props.payDetailResponse.crmId);
    console.log('orderid ' + this.props.payDetailResponse.orderid);
    this.props.onGetPayementMode(null, this.props.accessToken);
    // if (this.props.payDetailResponse.crmId != null) {
    const data = {
      crmid: this.props.payDetailResponse.crmId,
      orderid: this.props.payDetailResponse.orderid,
    };
    // const data = { crmid: 'CRM_-5_20211222 154042', orderid: 45 };
    this.props.onGetDtByOrderId(data, this.props.accessToken);
    //  }
    // const data = { crmid: 'CRM_-5_20211222 154042', orderid: 45 };
  }

  // BackHandler.addEventListener("hardwareBackPress", this.backAction);
  // BackHandler.removeEventListener("hardwareBackPress", this.backAction);

  // backAction = () => {
  //    this.props.navigation.navigate('DashBoardScreen')
  //    return true;
  //  };

  componentDidUpdate = prevProps => {
    // send otp error
    if (
      prevProps.payementModeOtpError == false &&
      this.props.payementModeOtpError != prevProps.payementModeOtpError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    //send otp success
    if (
      prevProps.payementModeOtpStatus == false &&
      this.props.payementModeOtpStatus != prevProps.payementModeOtpStatus
    ) {
      this.enterOtpEnable();
    }
    // verify otp error
    if (
      prevProps.verifypayementModeOtpError == false &&
      this.props.verifypayementModeOtpError !=
      prevProps.verifypayementModeOtpError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
          otp: '',
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    //verify success
    if (
      prevProps.verifypayementModeOtpStatus == false &&
      this.props.verifypayementModeOtpStatus !=
      prevProps.verifypayementModeOtpStatus
    ) {
      this.setState({
        showOtpPaymentModal: false,
        showSuccessModal: true,
        otpVerified: true,
        otpButtonEnabled: false,
        nextButtonEnable: true,
      });
      setTimeout(() => {
        this.setState({
          showSuccessModal: false,
        });
      }, 2000);
    }
    if (
      prevProps.payementModeDtByIDStatus == false &&
      this.props.payementModeDtByIDStatus != prevProps.payementModeDtByIDStatus
    ) {
      this.detailBindByOrderId();
    }
    // insert payment cash success
    if (
      prevProps.insertpayementModeError == false &&
      this.props.insertpayementModeError != prevProps.insertpayementModeError
    ) {
      this.setState(
        {
          errorMsg: 'payment failed',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    // insert payment failure
    if (
      prevProps.insertpayementModeStatus == false &&
      this.props.insertpayementModeStatus != prevProps.insertpayementModeStatus
    ) {
      // this.props.navigation.navigate(Sales.createOrderConfirmation);
      //role {parseInt(role) == PARAMEDIC
      if (this.props.Role == '9' || this.props.Role == '4') {
        // this.props.navigation.reset({
        //   routes: [{ name: Paramedic.myTask }],
        // });
        this.props.navigation.navigate(Paramedic.myTask);
      } else {
        this.props.navigation.reset({
          routes: [{ name: Sales.createOrderConfirmation }],
        });
      }
    }
    // insert payment online success
    if (
      prevProps.insertpayementModeOnlineStatus == false &&
      this.props.insertpayementModeOnlineStatus !=
      prevProps.insertpayementModeOnlineStatus
    ) {
      if (this.props.Role == '9' || this.props.Role == '4') {
        // this.props.navigation.reset({
        //   routes: [{ name: Paramedic.myTask }],
        // });
        this.props.navigation.navigate(Paramedic.myTask);
      } else {
        this.props.navigation.reset({
          routes: [{ name: Sales.myDrawer }],
        });
      }
      // this.props.navigation.navigate(Sales.createOrderConfirmation);
    }
  };

  render() {
    return (
      <PaymentCollectionScreen
        loading={
          this.props.payementModeDtByIDLoading ||
          this.props.payementModeOtpLoading ||
          this.props.verifypayementModeOtpLoading ||
          this.props.insertpayementModeLoading ||
          this.props.insertpayementModeOnlineLoading
        }
        nextButtonHandler={this.nextButtonHandler}
        payementModeResponseList={this.props.paymentresponse}
        // paymentMode={this.props.paymentresponse}
        otpHandler={this.otpHandler}
        otpSubmitHandler={this.otpSubmitHandler}
        otpChangeHandler={this.otpChangeHandler}
        resendOtpHandler={this.okayMobileConfirmHandler}
        cancelMobileConfirmHandler={this.cancelMobileConfirmHandler}
        okayMobileConfirmHandler={this.okayMobileConfirmHandler}
        // states
        showMobileConfirmModal={this.state.showMobileConfirmModal}
        showOtpPaymentModal={this.state.showOtpPaymentModal}
        showSuccessModal={this.state.showSuccessModal}
        otpButtonEnabled={this.state.otpButtonEnabled}
        toastMsg={this.state.errorMsg}
        showToast={this.state.showToast}
        otp={this.state.otp}
        otpVerified={this.state.otpVerified}
        nextButtonEnable={this.state.nextButtonEnable}
        paymentModeHandler={this.paymentModeHandlerDetails}
        amountHandler={this.amountHandlerDetail}
        emailHandler={this.emailHandlerDetail}
        mobileNumberHandler={this.mobileNumberHandler}
        remarksHandler={this.remarksHandler}
        paymentMode={this.state.paymentMode}
        amount={this.state.amount}
        email={this.state.email}
        mobileNumber={this.state.mobileNumber}
        remarks={this.state.remarks}
        isValidPayementMode={this.state.isValidPayementMode}
        isValidAmount={this.state.isValidAmount}
        isValidEmail={this.state.isValidEmail}
        isValidMobileNumber={this.state.isValidMobileNumber}
        isValidRemarks={this.state.isValidRemarks}
        pamentModeValidMsg={this.state.pamentModeValidMsg}
        amountValidMsg={this.state.amountValidMsg}
        emailIdValidMsg={this.state.emailIdValidMsg}
        mobileNumberValidMsg={this.state.mobileNumberValidMsg}
        remarksValidMsg={this.state.remarksValidMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  // console.log("state Details:======================>", state);
  return {
    message: state.payementMode.message,
    basicDetailList: state.createOrder.basicDetail,

    payementModeDtByIDStatus: state.payementMode.payementModeDtByIDStatus,
    payementModeDtByIDResponse: state.payementMode.payementModeDtByIDResponse,
    payementModeLoading: state.payementMode.payementModeLoading,

    payementModeDtByIDLoading: state.payementMode.payementModeDtByIDLoading,

    payementModeError: state.payementMode.payementModeError,
    payementModeOtpLoading: state.payementMode.payementModeOtpLoading,
    payementModeOtpStatus: state.payementMode.payementModeOtpStatus,
    payementModeOtpError: state.payementMode.payementModeOtpError,

    verifypayementModeOtpLoading:
      state.payementMode.verifypayementModeOtpLoading,
    verifypayementModeOtpStatus: state.payementMode.verifypayementModeOtpStatus,
    verifypayementModeOtpError: state.payementMode.verifypayementModeOtpError,

    insertpayementModeLoading: state.payementMode.insertpayementModeLoading,
    insertpayementModeStatus: state.payementMode.insertpayementModeStatus,
    insertpayementModeError: state.payementMode.insertpayementModeError,

    loading: state.payementMode.loading,

    insertpayementModeOnlineStatus:
      state.payementMode.insertpayementModeOnlineStatus,
    insertpayementModeOnlineLoading:
      state.payementMode.insertpayementModeOnlineLoading,

    accessToken: state.signIn.accessToken,
    paymentresponse: state.payementMode.payementModeResponse,
    payDetailResponse: state.common.payDetailResponse,

    UserID: state.signIn.userId,
    Role: state.signIn.role,
    //  payementOtpResponseStatus: state.payementMode.payementModeOtpStatus,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetDtByOrderId: (data, token) => dispatch(getDtByOrderId(data, token)),
    onGetPayementMode: (data, token) => dispatch(getPayementMode(data, token)),
    onGetOtpPayementMode: (data, token) =>
      dispatch(getOtpPayementMode(data, token)),
    onVerifyOtpPayementMode: (data, token) =>
      dispatch(verifyOtpPayementMode(data, token)),
    onInsertPayementMode: (data, token) =>
      dispatch(insertPayementMode(data, token)),
    onInsertPayementModeOnline: (data, token) =>
      dispatch(insertPaymentOnline(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentCollection);
