import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  TouchableOpacity
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import Images from '../../../constants/Images';
import Button, { NextButton } from '../../../components/Button';
import { Font, FontSize, FontMagneta } from '../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../components/TextInputComponent';
import DropDownMenu from '../../../components/DropDownMenu';
import Data from '../../../constants/Data';
import InnerHeader from '../../../components/InnerHeader';
import Icon from 'react-native-vector-icons/FontAwesome';
import OtpModal from '../../../components/OtpModal';
import Icons from '../../../constants/Icons';
import I18n from '../../../locale/i18n';
import PageNo from '../../../constants/PageNo'



function QR() {
  return (
    <View
      style={[{ paddingTop: 20 }, styles.qrLinkContainer]}>
      <ImageText
        imgSrc={Icons.qrWhite}
        title={I18n.t('sales.paymentCollection.qr_label')}
        textStyle={styles.textColorWhite} />
      <View
        style={styles.cardContainer} />
    </View>
  )
}

function Link() {
  return (
    <View
      style={[{ paddingBottom: 20 }, styles.qrLinkContainer]}>
      <View
        style={styles.cardContainer} />
      <ImageText
        imgSrc={Icons.linkWhite}
        title={I18n.t('sales.paymentCollection.link_label')}
        textStyle={styles.textColorWhite} />
    </View>
  )
}

function ImageText({ imgSrc, title, textStyle }) {
  return (
    <View>
      <Image
        source={imgSrc}
        style={styles.imageStyle}
        resizeMode="contain"
      />
      <Text style={textStyle}>{title}</Text>
    </View>
  )
}


function PaymentRequestScreen({ addressTypeHandler,
  nextButtonHandler,
  otp,
  signUpHandler,
  qrScanHandler,
  linkScanHandler,
  QR_SCAN,
  LINK_SCAN }) {
  return (
    <RootView pageNo={PageNo.sales_paymentCollectionScan}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff'
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>
                <View
                  style={styles.bigContainer}>
                  <TouchableOpacity
                    onPress={qrScanHandler}>
                    <ImageText
                      imgSrc={Icons.qrPink}
                      title={I18n.t('sales.paymentCollection.qr_label')}
                      textStyle={styles.textColorPink} />
                  </TouchableOpacity>
                  {QR_SCAN ?
                    <View
                      style={styles.qrScan}>
                      <QR />
                    </View>
                    : null}
                  <View
                    style={styles.circleBorder} />
                  <TouchableOpacity
                    onPress={linkScanHandler}>
                    <ImageText
                      imgSrc={Icons.linkPink}
                      title={I18n.t('sales.paymentCollection.link_label')}
                      textStyle={styles.textColorPink} />
                  </TouchableOpacity>
                  {LINK_SCAN ?
                    <View style={styles.linkScan}>
                      <Link />
                    </View>
                    : null}
                </View>
              </View>
            </ScrollView>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center'
            }}>
            <View
              style={styles.buttonContainer}>
              <NextButton
                onPress={nextButtonHandler} />
            </View>
          </View>
        </View>
      </KeyboardAvoidingView >
    </RootView >
  );
}


const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  buttonContainer: {
    width: '30%',
  },
  textContainer: {
    width: '90%',
    alignSelf: 'center',
    marginTop: 5
  },
  textColorWhite: {
    color: Colors.white,
    fontFamily: Font.bold,
    fontSize: FontSize.medium_large,
    alignSelf: 'center'
  },
  textColorPink: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium_large,
    alignSelf: 'center'
  },
  qrLinkContainer: {
    height: 250,
    width: 120,
    borderRadius: 400 / 2,
    backgroundColor: Colors.border,
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  cardContainer: {
    width: 92,
    height: 92,
    borderRadius: 92 / 2,
    backgroundColor: Colors.card,
    marginBottom: 10,
  },
  imageStyle: {
    width: 50,
    height: 50,
    marginBottom: 10
  },
  bigContainer: {
    height: 400,
    width: 110,
    borderRadius: 400 / 2,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'space-evenly',
    alignSelf: 'center'
  },
  circleBorder: {
    width: 120,
    height: 120,
    borderRadius: 120 / 2,
    borderColor: Colors.border,
    borderWidth: 13
  },
  qrScan: {
    position: 'absolute',
    top: 0
  },
  linkScan: {
    position: 'absolute',
    bottom: 0,
    // backgroundColor: 'transparent'
  }

});

export default PaymentRequestScreen;
