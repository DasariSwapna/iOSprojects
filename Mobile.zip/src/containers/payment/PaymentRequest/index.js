import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../utils/Validators';
import PaymentRequestScreen from './Screen';
import Routes, { Sales } from '../../../navigations/RouteTypes';

class PaymentRequest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      QR_SCAN: false,
      LINK_SCAN: false
    };
  }

  qrScanHandler = () => {
    this.setState({
      QR_SCAN: true,
      LINK_SCAN: false
    })
  }

  linkScanHandler = () => {
    this.setState({
      QR_SCAN: false,
      LINK_SCAN: true
    })
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.paymentStatus,
      {
        QR_CODE: this.state.QR_SCAN,
        LINK_SCAN: this.state.LINK_SCAN
      });
  }


  render() {
    return <PaymentRequestScreen
      // handlers
      nextButtonHandler={this.nextButtonHandler}
      qrScanHandler={this.qrScanHandler}
      linkScanHandler={this.linkScanHandler}
      // states
      QR_SCAN={this.state.QR_SCAN}
      LINK_SCAN={this.state.LINK_SCAN}
    />
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentRequest);
