import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import Images from '../../../constants/Images';
import Button, { NextButton } from '../../../components/Button';
import { Font, FontSize, FontMagneta } from '../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../components/TextInputComponent';
import DropDownMenu from '../../../components/DropDownMenu';
import Data from '../../../constants/Data';
import InnerHeader from '../../../components/InnerHeader';
import Icon from 'react-native-vector-icons/FontAwesome';
import OtpModal from '../../../components/OtpModal';
import Icons from '../../../constants/Icons';
import I18n from '../../../locale/i18n';
import PageNo from '../../../constants/PageNo'


function QrCode() {
  return (
    <View style={{ alignItems: 'center' }}>
      <Text style={styles.textColorPink}>{I18n.t('sales.paymentCollection.scan_qr_code_label')}</Text>
      <Image
        source={Icons.qrImage}
        style={styles.imageStyle}
        resizeMode="contain"
      />
    </View>
  )
}

function LinkCode() {
  return (
    <View style={{ flex: 1, justifyContent: 'space-around' }}>
      <View style={{ alignItems: 'center' }}>
        <Image
          source={Icons.globe}
          style={{
            width: 80,
            height: 80,
          }}
          resizeMode="contain"
        />
        <Text style={{
          color: Colors.border,
          fontFamily: Font.regular,
          fontSize: FontSize.semiLarge,
          flexWrap: 'wrap',
          width: 300,
          textAlign: 'center',
          marginTop: 20
        }}>{I18n.t('sales.paymentCollection.debit_credit_label')}</Text>
        <Text style={{
          color: Colors.border,
          fontFamily: Font.regular,
          fontSize: FontSize.semiLarge,
          backgroundColor: Colors.card,
          borderRadius: 25,
          marginTop: 20,
          paddingHorizontal: 20,
          paddingVertical: 10
        }}>https://www.google.com/search?q=qr+image+</Text>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.regular,
          fontSize: FontSize.semiLarge,
          alignSelf: 'flex-end',
          marginTop: 20,
        }}>{I18n.t('sales.paymentCollection.long_press_label')}</Text>

      </View>
      <View>
        <Text style={{
          color: Colors.border,
          fontFamily: Font.regular,
          fontSize: FontSize.semiLarge,
          alignSelf: 'center',
          marginTop: 20,
        }}>{I18n.t('sales.paymentCollection.link_share_label')}
          <Text style={{
            color: Colors.border,
            fontFamily: FontMagneta.bold,
            fontSize: FontSize.medium,
          }}>   988675461</Text>
        </Text>
      </View>

    </View>

  )
}

function PaymentWaiting() {
  return (
    <View style={{ alignItems: 'center', marginTop: 100 }}>
      <Image
        source={Icons.paymentTime}
        style={{
          width: 50,
          height: 50,
        }}
        resizeMode="contain"
      />
      <Text style={{
        color: Colors.border,
        fontFamily: Font.regular,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>{I18n.t('sales.paymentCollection.waiting_payment_label')}</Text>
      <Text style={{
        color: Colors.border,
        fontFamily: FontMagneta.medium,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>3500.00</Text>
      <Text style={{
        color: Colors.border,
        fontFamily: FontMagneta.thin,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>19-11-2021 15:05</Text>
    </View>
  )
}

function PaymentReceived() {
  return (
    <View style={{ alignItems: 'center', marginTop: 100 }}>
      <Image
        source={Icons.paymentTick}
        style={{
          width: 50,
          height: 50,
        }}
        resizeMode="contain"
      />
      <Text style={{
        color: Colors.border,
        fontFamily: Font.regular,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>{I18n.t('sales.paymentCollection.payment_received_label')}</Text>
      <Text style={{
        color: Colors.border,
        fontFamily: FontMagneta.semiBold,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>3500.00</Text>
      <Text style={{
        color: Colors.border,
        fontFamily: FontMagneta.thin,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>19-11-2021 15:05</Text>

      <Text style={{
        color: Colors.border,
        fontFamily: FontMagneta.thin,
        fontSize: FontSize.medium,
        marginTop: 20
      }}>TNXR123456</Text>
    </View>
  )
}

function PageNumber({ number }) {
  return (
    <View style={{ position: 'absolute', right: 0, bottom: 0, margin: 10 }}>
      <Text>{number}</Text>
    </View>
  );
}


function PaymentStatusScreen({
  addressTypeHandler,
  nextButtonHandler,
  signUpHandler,
  QR_CODE,
  LINK_CODE,
  PAYMENT_WAITING,
  PAYMENT_RECEIVED
}) {
  return (

    <RootView pageNo={PageNo.sales_paymentCollectionStatus}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff'
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>
                {QR_CODE ?
                  <View
                    style={styles.codeContainer}>
                    <QrCode />
                    < PageNumber number={'72'} />
                  </View> : null}

                {LINK_CODE ?
                  <View
                    style={styles.codeContainer}>
                    <LinkCode />
                    < PageNumber number={'73'} />
                  </View> : null}

                {PAYMENT_WAITING ?
                  <>
                    <PaymentWaiting />
                    < PageNumber number={'77'} />
                  </>
                  : null}

                {PAYMENT_RECEIVED ?
                  <>
                    <PaymentReceived />
                    < PageNumber number={'52'} />
                  </>
                  : null}
              </View>
            </ScrollView>
          </View>
          <View
            style={{
              flex: 1,
              alignItems: 'center',
            }}>
            <View
              style={styles.buttonContainer}>
              {QR_CODE || LINK_CODE ?
                <NextButton
                  onPress={nextButtonHandler} />
                : null}
            </View>
          </View>
        </View>
      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  codeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    // width: '30%',
    // alignSelf: 'center',
    // marginBottom: 40
  },
  textContainer: {
    width: '90%',
    alignSelf: 'center',
    marginTop: 5
  },
  textColorBlack: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium_large,
  },
  textColorPink: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.large,
    flexWrap: 'wrap',
    width: '70%',
  },
  imageStyle: {
    width: 300,
    height: 300,
    marginBottom: 10,

  },

});

export default PaymentStatusScreen;
