import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../utils/Validators';
import PaymentStatusScreen from './Screen';
import Routes, { Sales } from '../../../navigations/RouteTypes';

class PaymentStatus extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      QR_CODE: this.props.route.params.QR_CODE,
      LINK_CODE: this.props.route.params.LINK_SCAN,
      PAYMENT_WAITING: false,
      PAYMENT_RECEIVED: false
    };
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Routes.createOrderAddTest);
    this.setState({
      QR_CODE: false,
      LINK_CODE: false,
    })
    this.paymentWaitingHandler();
  }

  paymentWaitingHandler = () => {
    this.setState({
      PAYMENT_WAITING: true,
    })
    setTimeout(() => {
      this.setState({
        PAYMENT_WAITING: false,
        PAYMENT_RECEIVED: true,
      })
      this.paymentReceiveHandler();
    }, 2000);
  }

  paymentReceiveHandler = () => {
    setTimeout(() => {
      //this.props.navigation.navigate(Sales.createOrderConfirmation);
    }, 2000);


  }


  render() {
    return <PaymentStatusScreen
      nextButtonHandler={this.nextButtonHandler}
      // States
      // states
      QR_CODE={this.state.QR_CODE}
      LINK_CODE={this.state.LINK_CODE}
      PAYMENT_WAITING={this.state.PAYMENT_WAITING}
      PAYMENT_RECEIVED={this.state.PAYMENT_RECEIVED}
    />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(PaymentStatus);
