import React, {useState, useEffect} from 'react';
import {
  BackHandler,
  Dimensions,
  Image,
  KeyboardAvoidingView,
  Modal,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Platform,
} from 'react-native';
import moment from 'moment';
import {Auth} from '../../navigations/RouteTypes';
import PropTypes from 'prop-types';
import RootView from '../../components/RootView';
import Header from '../../components/Header';
import Colors from '../../config/Colors';
import Button from '../../components/Button';
import {InputField} from '../../components/InputField';
import {Font, FontMagneta, FontSize} from '../../config/Fonts';
import DropDownMenu from '../../components/DropDownMenuSignup';
import {Toast} from '../../components/Toast';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import PageNo from '../../constants/PageNo';
import I18n from '../../locale/i18n';

const {width, height} = Dimensions.get('screen');
const inputFieldContainerHeight = height * 0.5;
const backArrowSize = width * 0.04;

function InfoTitle({title}) {
  return (
    <View style={{paddingHorizontal: 24, paddingVertical: 12}}>
      <Text
        style={{
          fontFamily: Font.extraBold,
          fontSize: FontSize.large,
          color: Colors.text,
        }}>
        {title}
      </Text>
    </View>
  );
}

function PersonalInfo({
  empId,
  firstName,
  lastName,
  email,
  mobileNo,
  dob,
  isValidEmpId,
  isValidFirstName,
  isValidLastName,
  isValidEmail,
  isValidMobileNo,
  isValidDob,
  empIdValidationMsg,
  firstNameValidationMsg,
  lastNameValidationMsg,
  emailValidationMsg,
  mobileNoValidationMsg,
  dobValidationMsg,
  checkEmailAndPhone,
  empIdChangeHandler,
  firstNameChangeHandler,
  lastNameChangeHandler,
  emailChangeHandler,
  mobileNoChangeHandler,
  dobChangeHandler,
  personalInfoSubmitHandler,
  validateEmpId,
  validateFirstName,
  validateLastName,
  validateEmail,
  validateMobileNo,
  validateDob,
}) {
  return (
    <View>
      <View>
        <InfoTitle title={I18n.t('signUp.personal_title')} />
      </View>
      <View style={styles.inputContainer}>
        <InputField
          placeholder={I18n.t('signUp.employee_id')} //{'First Name'}
          value={empId}
          validationMsg={empIdValidationMsg}
          isValid={isValidEmpId}
          onChangeHandler={empIdChangeHandler}
          onBlurInput={validateEmpId}
        />
        <InputField
          placeholder={I18n.t('signUp.personal_firstname')} //{'First Name'}
          value={firstName}
          validationMsg={firstNameValidationMsg}
          isValid={isValidFirstName}
          onChangeHandler={firstNameChangeHandler}
          onBlurInput={validateFirstName}
        />
        <InputField
          placeholder={I18n.t('signUp.personal_lastname')} // {'Last Name'}
          value={lastName}
          validationMsg={lastNameValidationMsg}
          isValid={isValidLastName}
          onChangeHandler={lastNameChangeHandler}
          onBlurInput={validateLastName}
        />
        <InputField
          isEmail={true}
          placeholder={I18n.t('signUp.personal_email')} //{'Email Address'}
          value={email}
          validationMsg={emailValidationMsg}
          isValid={isValidEmail}
          onChangeHandler={emailChangeHandler}
          onBlurInput={validateEmail}
        />
        <InputField
          isNumeric={true}
          placeholder={I18n.t('signUp.personal_mobile')} //{'Mobile Number'}
          value={mobileNo}
          validationMsg={mobileNoValidationMsg}
          isValid={isValidMobileNo}
          onChangeHandler={mobileNoChangeHandler}
          onBlurInput={validateMobileNo}
          maxLength={10}
        />
        <InputField
          isDate={true}
          placeholder={I18n.t('signUp.personal_dob')} //{'Date of Birth'}
          value={dob == '' ? dob : moment(dob).format('DD-MM-YYYY')}
          validationMsg={dobValidationMsg}
          isValid={isValidDob}
          dateChangeHandler={dobChangeHandler}
          onBlurInput={validateDob}
        />
      </View>
      <View
        style={{
          width: '40%',
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 16,
          paddingVertical: 32,
        }}>
        <Button
          title={I18n.t('signUp.continue_buton')} //{'Continue'}
          onPress={() => personalInfoSubmitHandler()}
        />
      </View>
    </View>
  );
}

function EducationInfo({
  qualification,
  experience,
  role,
  roleList,
  isValidQualification,
  isValidExperience,
  isValidRole,
  qualificationValidationMsg,
  experienceValidationMsg,
  qualificationChangeHandler,
  experienceChangeHandler,
  roleChangeHandler,
  educationInfoSubmitHandler,
  roleValidationMsg,
  validateQualification,
  validateExperience,
  validateRole,
}) {
  console.log('Roles =========>', roleList);
  return (
    <View>
      <View>
        <InfoTitle title={I18n.t('signUp.edu_title')} />
      </View>
      <View style={styles.inputContainer}>
        <InputField
          placeholder={I18n.t('signUp.edu_qualification')}
          value={qualification}
          validationMsg={qualificationValidationMsg}
          isValid={isValidQualification}
          onChangeHandler={qualificationChangeHandler}
          onBlurInput={validateQualification}
          maxLength={250}
        />
        <InputField
          isNumeric={true}
          placeholder={I18n.t('signUp.edu_experience')}
          value={experience}
          validationMsg={experienceValidationMsg}
          isValid={isValidExperience}
          onChangeHandler={experienceChangeHandler}
          onBlurInput={validateExperience}
          maxLength={2}
        />
        <View>
          <DropDownMenu
            // Width={200}
            labelName={I18n.t('signUp.role')}
            initValue={role}
            listItems={roleList}
            labelKey={'lc_ute_typename'}
            valueKey={'lc_ute_typeid'}
            outline={true}
            valueChangeHandler={roleChangeHandler}
            onBlurInput={validateRole}
          />

          {!isValidRole && (
            <Text style={styles.textValidationMsg}>
              {!isValidRole ? roleValidationMsg : ''}
            </Text>
          )}
        </View>
      </View>
      <View
        style={{
          width: '40%',
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 16,
          paddingVertical: 32,
        }}>
        <Button
          title={I18n.t('signUp.continue_buton')}
          onPress={() => educationInfoSubmitHandler()}
        />
      </View>
    </View>
  );
}

function LocationInfo({
  pincode,
  state,
  city,
  center,
  stateList,
  cityList,
  centerList,
  addrLine1,
  addrLine2,
  pincodeValidationMsg,
  stateValidationMsg,
  cityValidationMsg,
  centerValidationMsg,
  addrLine1ValidationMsg,
  addrLine2ValidationMsg,
  isValidPincode,
  isValidCity,
  isValidCenter,
  isValidState,
  isValidAddrLine1,
  isValidAddrLine2,
  pincodeChangeHandler,
  stateChangeHandler,
  cityChangeHandler,
  centerChangeHandler,
  addrLine1ChangeHandler,
  addrLine2ChangeHandler,
  locationInfoSubmitHandler,
  validatePincode,
  validateCity,
  validateCenter,
  validateAddrLine1,
  validateAddrLine2,
}) {
  return (
    <View>
      <View>
        <InfoTitle title={I18n.t('signUp.location_title')} />
      </View>
      <View style={styles.inputContainer}>
        <InputField
          isNumeric={true}
          placeholder={I18n.t('signUp.location_pincode')}
          value={pincode}
          validationMsg={pincodeValidationMsg}
          isValid={isValidPincode}
          onChangeHandler={pincodeChangeHandler}
          onBlurInput={validatePincode}
          maxLength={6}
        />
        <View style={{paddingBottom: 8}}>
          <DropDownMenu
            labelName={I18n.t('signUp.location_state')} //{'State'}
            initValue={state}
            listItems={stateList}
            labelKey={'lc_SM_STATE_NAME'}
            valueKey={'lc_SM_ID'}
            outline={true}
            valueChangeHandler={stateChangeHandler}
          />
          {!isValidState && (
            <Text style={styles.textValidationMsg}>
              {!isValidState ? stateValidationMsg : ''}
            </Text>
          )}
        </View>
        <View style={{paddingBottom: 8}}>
          <DropDownMenu
            labelName={I18n.t('signUp.location_city')} //{'City'}
            initValue={city}
            listItems={cityList}
            labelKey={'lc_CM_CITY_NAME'}
            valueKey={'lc_CM_ID'}
            outline={true}
            valueChangeHandler={cityChangeHandler}
            onBlurInput={validateCity}
          />
          {!isValidCity && (
            <Text style={styles.textValidationMsg}>
              {!isValidCity ? cityValidationMsg : ''}
            </Text>
          )}
        </View>

        <View style={{paddingBottom: 8}}>
          <DropDownMenu
            labelName={I18n.t('signUp.location_center')} //{'Center'}
            initValue={center}
            listItems={centerList}
            outline={true}
            labelKey={'lc_cen_m_center_name'}
            valueKey={'lc_cen_m_id'}
            valueChangeHandler={centerChangeHandler}
            onBlurInput={validateCenter}
          />
          {!isValidCenter && (
            <Text style={styles.textValidationMsg}>
              {!isValidCenter ? centerValidationMsg : ''}
            </Text>
          )}
        </View>

        {/* <InputField
          placeholder={'City'}
          value={city}
          validationMsg={cityValidationMsg}
          isValid={isValidCity}
          onChangeHandler={cityChangeHandler}
        />
        <InputField
          placeholder={'Center'}
          value={center}
          validationMsg={centerValidationMsg}
          isValid={isValidCenter}
          onChangeHandler={centerChangeHandler}
        /> */}
        <InputField
          placeholder={I18n.t('signUp.location_addr1')} //{'Address Line 1'}
          value={addrLine1}
          validationMsg={addrLine1ValidationMsg}
          isValid={isValidAddrLine1}
          onChangeHandler={addrLine1ChangeHandler}
          maxLength={50}
          onBlurInput={validateAddrLine1}
        />
        <InputField
          placeholder={I18n.t('signUp.location_addr2')} //{'Address Line 2'}
          value={addrLine2}
          validationMsg={addrLine2ValidationMsg}
          isValid={isValidAddrLine2}
          onChangeHandler={addrLine2ChangeHandler}
          maxLength={50}
          onBlurInput={validateAddrLine2}
        />
      </View>
      <View
        style={{
          width: '40%',
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 16,
          paddingVertical: 32,
        }}>
        <Button
          title={I18n.t('signUp.continue_buton')}
          onPress={() => locationInfoSubmitHandler()}
        />
      </View>
    </View>
  );
}

function PasswordInfo({
  password,
  confirmPassword,
  passwordValidationMsg,
  confirmPasswordValidationMsg,
  isValidamatchPassword,
  isValidamatchPasswordMsg,
  isValidPassword,
  isValidConfirmPassword,
  passwordChangeHandler,
  confirmPasswordChangeHandler,
  passwordInfoSubmitHandler,
  validatePassword,
  validateConfirmPassword,
}) {
  return (
    <View>
      <View>
        <InfoTitle title={I18n.t('signUp.password_title')} />
      </View>
      <View style={styles.inputContainer}>
        <InputField
          placeholder={I18n.t('signUp.password_first')} //{'Enter Password'}
          value={password}
          validationMsg={passwordValidationMsg}
          isValid={isValidPassword}
          onChangeHandler={passwordChangeHandler}
          onBlurInput={validatePassword}
          isPassword={true}
          maxLength={28}
        />
        <InputField
          placeholder={I18n.t('signUp.password_confirm')} //{'Confirm Password'}
          value={confirmPassword}
          validationMsg={confirmPasswordValidationMsg}
          isValid={isValidConfirmPassword}
          onChangeHandler={confirmPasswordChangeHandler}
          onBlurInput={validateConfirmPassword}
          isPassword={true}
          maxLength={28}
        />
        {!isValidamatchPassword && (
          <Text style={styles.textValidationMsg}>
            {!isValidamatchPassword ? isValidamatchPasswordMsg : ''}
          </Text>
        )}
      </View>
      <View
        style={{
          width: '40%',
          alignSelf: 'center',
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 16,
          paddingVertical: 32,
        }}>
        <Button
          title={I18n.t('signUp.continue_buton')} //{'Continue'}
          onPress={() => passwordInfoSubmitHandler()}
        />
      </View>
    </View>
  );
}

function SignUpScreen({
  loading,
  showToast,
  errorMsg,
  infoStatus,
  empId,
  firstName,
  lastName,
  email,
  mobileNo,
  dob,
  role,
  roleList,
  qualification,
  experience,
  pincode,
  state,
  stateList,
  city,
  cityList,
  center,
  centerList,
  addrLine1,
  addrLine2,
  password,
  confirmPassword,
  empIdValidationMsg,
  firstNameValidationMsg,
  lastNameValidationMsg,
  emailValidationMsg,
  mobileNoValidationMsg,
  dobValidationMsg,
  qualificationValidationMsg,
  experienceValidationMsg,
  roleValidationMsg,
  pincodeValidationMsg,
  stateValidationMsg,
  cityValidationMsg,
  centerValidationMsg,
  addrLine1ValidationMsg,
  addrLine2ValidationMsg,
  passwordValidationMsg,
  isValidamatchPassword,
  isValidamatchPasswordMsg,
  confirmPasswordValidationMsg,
  isValidEmpId,
  isValidFirstName,
  isValidLastName,
  isValidEmail,
  isValidMobileNo,
  isValidDob,
  isValidQualification,
  isValidExperience,
  isValidRole,
  isValidPincode,
  isValidState,
  isValidCity,
  isValidCenter,
  isValidAddrLine1,
  isValidAddrLine2,
  isValidPassword,
  isValidConfirmPassword,

  //methods
  validateEmpId,
  validateFirstName,
  validateLastName,
  validateEmail,
  validateMobileNo,
  validateDob,
  validateQualification,
  validateExperience,
  validateRole,
  validatePincode,
  validateCity,
  validateCenter,
  validateAddrLine1,
  validateAddrLine2,
  validatePassword,
  validateConfirmPassword,
  checkEmailAndPhone,
  empIdChangeHandler,
  firstNameChangeHandler,
  lastNameChangeHandler,
  emailChangeHandler,
  mobileNoChangeHandler,
  dobChangeHandler,
  personalInfoSubmitHandler,
  qualificationChangeHandler,
  experienceChangeHandler,
  roleChangeHandler,
  educationInfoSubmitHandler,
  pincodeChangeHandler,
  stateChangeHandler,
  cityChangeHandler,
  centerChangeHandler,
  addrLine1ChangeHandler,
  addrLine2ChangeHandler,
  locationInfoSubmitHandler,
  passwordChangeHandler,
  confirmPasswordChangeHandler,
  passwordInfoSubmitHandler,
  Backhandlerwithinpage,
}) {
  return (
    <RootView
      pageNo={
        infoStatus == 0
          ? PageNo.signUp
          : infoStatus == 1
          ? PageNo.signUp2
          : infoStatus == 2
          ? PageNo.signUp3
          : PageNo.signUp4
      }
      loading={loading}
      isWhite
      isPageWhite>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 70}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <Header selected={infoStatus} />
            {infoStatus == 0 && (
              <PersonalInfo
                empId={empId}
                firstName={firstName}
                lastName={lastName}
                email={email}
                mobileNo={mobileNo}
                dob={dob}
                empIdValidationMsg={empIdValidationMsg}
                firstNameValidationMsg={firstNameValidationMsg}
                lastNameValidationMsg={lastNameValidationMsg}
                emailValidationMsg={emailValidationMsg}
                mobileNoValidationMsg={mobileNoValidationMsg}
                dobValidationMsg={dobValidationMsg}
                isValidEmpId={isValidEmpId}
                isValidFirstName={isValidFirstName}
                isValidLastName={isValidLastName}
                isValidEmail={isValidEmail}
                isValidMobileNo={isValidMobileNo}
                isValidDob={isValidDob}
                checkEmailAndPhone={checkEmailAndPhone}
                empIdChangeHandler={empIdChangeHandler}
                firstNameChangeHandler={firstNameChangeHandler}
                lastNameChangeHandler={lastNameChangeHandler}
                emailChangeHandler={emailChangeHandler}
                mobileNoChangeHandler={mobileNoChangeHandler}
                dobChangeHandler={dobChangeHandler}
                personalInfoSubmitHandler={personalInfoSubmitHandler}
                validateEmpId={validateEmpId}
                validateFirstName={validateFirstName}
                validateLastName={validateLastName}
                validateEmail={validateEmail}
                validateMobileNo={validateMobileNo}
                validateDob={validateDob}
              />
            )}
            {infoStatus == 1 && (
              <EducationInfo
                role={role}
                roleList={roleList}
                qualification={qualification}
                experience={experience}
                isValidRole={isValidRole}
                isValidQualification={isValidQualification}
                isValidExperience={isValidExperience}
                roleValidationMsg={roleValidationMsg}
                qualificationValidationMsg={qualificationValidationMsg}
                experienceValidationMsg={experienceValidationMsg}
                qualificationChangeHandler={qualificationChangeHandler}
                experienceChangeHandler={experienceChangeHandler}
                roleChangeHandler={roleChangeHandler}
                educationInfoSubmitHandler={educationInfoSubmitHandler}
                validateQualification={validateQualification}
                validateExperience={validateExperience}
                validateRole={validateRole}
              />
            )}
            {infoStatus == 2 && (
              <LocationInfo
                pincode={pincode}
                state={state}
                stateList={stateList}
                city={city}
                cityList={cityList}
                center={center}
                centerList={centerList}
                addrLine1={addrLine1}
                addrLine2={addrLine2}
                pincodeValidationMsg={pincodeValidationMsg}
                stateValidationMsg={stateValidationMsg}
                cityValidationMsg={cityValidationMsg}
                centerValidationMsg={centerValidationMsg}
                addrLine1ValidationMsg={addrLine1ValidationMsg}
                addrLine2ValidationMsg={addrLine2ValidationMsg}
                isValidPincode={isValidPincode}
                isValidState={isValidState}
                isValidCity={isValidCity}
                isValidCenter={isValidCenter}
                isValidAddrLine1={isValidAddrLine1}
                isValidAddrLine2={isValidAddrLine2}
                pincodeChangeHandler={pincodeChangeHandler}
                stateChangeHandler={stateChangeHandler}
                cityChangeHandler={cityChangeHandler}
                centerChangeHandler={centerChangeHandler}
                addrLine1ChangeHandler={addrLine1ChangeHandler}
                addrLine2ChangeHandler={addrLine2ChangeHandler}
                validatePincode={validatePincode}
                validateCity={validateCity}
                validateCenter={validateCenter}
                validateAddrLine1={validateAddrLine1}
                validateAddrLine2={validateAddrLine2}
                locationInfoSubmitHandler={locationInfoSubmitHandler}
              />
            )}
            {(infoStatus == 3 || infoStatus == 4) && (
              <PasswordInfo
                password={password}
                confirmPassword={confirmPassword}
                passwordValidationMsg={passwordValidationMsg}
                confirmPasswordValidationMsg={confirmPasswordValidationMsg}
                isValidamatchPassword={isValidamatchPassword}
                isValidamatchPasswordMsg={isValidamatchPasswordMsg}
                isValidPassword={isValidPassword}
                isValidConfirmPassword={isValidConfirmPassword}
                passwordChangeHandler={passwordChangeHandler}
                confirmPasswordChangeHandler={confirmPasswordChangeHandler}
                passwordInfoSubmitHandler={passwordInfoSubmitHandler}
                validatePassword={validatePassword}
                validateConfirmPassword={validateConfirmPassword}
              />
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

export default SignUpScreen;

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    // flex: 1,
    backgroundColor: Colors.background,
  },
  inputContainer: {
    // height: inputFieldContainerHeight,
    minHeight: inputFieldContainerHeight,
    // justifyContent: 'flex-start',
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    // paddingVertical: 4,
  },
});
