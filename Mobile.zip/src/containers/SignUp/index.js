import React from 'react';
import {connect} from 'react-redux';
import {BackHandler} from 'react-native';
import SignUpScreen from './Screen';
import {
  getRole,
  getCity,
  getState,
  getSignUp,
  getCenter,
  checkEmailExist,
  signUpBackHandle,
} from '../../store/Actions';
import {Auth} from '../../navigations/RouteTypes';
import {
  validateEmpId,
  firstnameEmpty,
  lastnameEmpty,
  validateDob,
  validateEmail,
  validateEmpty,
  validateMobileNo,
  validateNumber,
  validateQualificationText,
  validateExperienceNumber,
  validateRoleDropdownEmpty,
  validateAddressLine1,
  validateAddressLine2,
  validatePincodeNumber,
  validatePassword,
  validateText,
  validateStateDropdownEmpty,
  validateCityDropdownEmpty,
  validateCenterDropdownEmpty,
  validateConfirmPassword,
  validatematchPassword,
} from '../../utils/Validators';
import {delay} from '../../utils/Helpers';

const PERSONAL_INFO_COMPLETED = 1;
const EDUCATION_INFO_COMPLETED = 2;
const LOCATION_INFO_COMPLETED = 3;
const PASSWORD_INFO_COMPLETED = 4;

class SignUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      infoStatus: 0,
      empId: '',
      firstName: '',
      lastName: '',
      email: '',
      mobileNo: '',
      dob: '',
      qualification: '',
      experience: '',
      role: '',
      roles: [],
      pincode: '',
      state: '',
      city: '',
      center: '',
      addrLine1: '',
      addrLine2: '',
      password: '',
      confirmPassword: '',
      empIdValidationMsg: '',
      firstNameValidationMsg: '',
      lastNameValidationMsg: '',
      emailValidationMsg: '',
      mobileNoValidationMsg: '',
      dobValidationMsg: '',
      qualificationValidationMsg: '',
      roleValidationMsg: '',
      experienceValidationMsg: '',
      pincodeValidationMsg: '',
      stateValidationMsg: '',
      cityValidationMsg: '',
      centerValidationMsg: '',
      addrLine1ValidationMsg: '',
      addrLine2ValidationMsg: '',
      passwordValidationMsg: '',
      confirmPasswordValidationMsg: '',
      isValidEmpId: true,
      isValidFirstName: true,
      isValidLastName: true,
      isValidEmail: true,
      isValidMobileNo: true,
      isValidDob: true,
      isValidQualification: true,
      isValidRole: true,
      isValidExperience: true,
      isValidPincode: true,
      isValidState: true,
      isValidCity: true,
      isValidCenter: true,
      isValidAddrLine1: true,
      isValidAddrLine2: true,
      isValidPassword: true,
      isValidConfirmPassword: true,
      errorMsg: '',
      showToast: false,
      isValidamatchPassword: true,
      isValidamatchPasswordMsg: '',
      isEmail: false,
      isMobile: false,
      isBack: false,
    };
  }

  empIdChangeHandler = val => {
    if (/^[ A-Za-z0-9]*$/.test(val)) {
      this.setState({
        empId: val,
      });
    }
  };

  firstNameChangeHandler = val => {
    if (!/[^a-zA-Z ]/.test(val)) {
      this.setState({
        firstName: val,
      });
    }
  };

  // validateFirstName = () => {
  //   const valid = firstnameEmpty(this.state.firstName);
  //   if (valid.val) {
  //     this.setState({
  //       isValidFirstName: valid.val,
  //       firstNameValidationMsg: '',
  //     });
  //   } else {
  //     this.setState({
  //       isValidFirstName: valid.val,
  //       firstNameValidationMsg: valid.msg,
  //     });
  //   }
  // };

  lastNameChangeHandler = val => {
    if (!/[^a-zA-Z ]/.test(val)) {
      this.setState({
        lastName: val,
      });
    }
  };

  emailChangeHandler = val => {
    if (/^[ A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        email: val,
      });
    }
  };

  validateEmail = () => {
    const valid = validateEmail(this.state.email);
    if (valid.val) {
      this.setState({
        isValidEmail: valid.val,
        emailValidationMsg: '',
        isEmail: true,
      });
      const data2 = {user_phoneno: '', user_emailid: this.state.email};
      this.props.onCheckEmailExist(data2, null);
    } else {
      this.setState({
        isValidEmail: valid.val,
        emailValidationMsg: valid.msg,
      });
    }
  };

  mobileNoChangeHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      this.setState({
        mobileNo: val,
      });
    }
  };

  validateMobileNo = () => {
    const valid = validateMobileNo(this.state.mobileNo);

    if (valid.val) {
      this.setState({
        isValidMobileNo: valid.val,
        mobileNoValidationMsg: '',
        isMobile: true,
      });
      const data2 = {user_phoneno: this.state.mobileNo, user_emailid: ''};
      this.props.onCheckEmailExist(data2, null);
    } else {
      this.setState({
        isValidMobileNo: valid.val,
        mobileNoValidationMsg: valid.msg,
      });
    }
  };

  dobChangeHaandler = val => {
    console.log(val);
    this.setState({
      dob: val,
    });
  };

  roleChangeHandler = val => {
    this.setState({
      role: val,
    });
  };

  qualificationChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        qualification: val,
      });
    }
  };

  experienceChangeHandler = val => {
    if (/^[0-9]*$/.test(val) || val === '') {
      this.setState({
        experience: val,
      });
    }
  };

  roleChangeHandler = val => {
    this.setState({
      role: val,
    });
  };

  pincodeChangeHandler = val => {
    if (/^[0-9]*$/.test(val) || val === '') {
      this.setState({
        pincode: val,
      });
    }
  };

  stateChangeHandler = val => {
    console.log('State called', this.state);
    this.setState({
      state: val,
      city: '',
      center: '',
    });
    const data = {
      stateid: val,
      search: null,
    };
    this.props.onGetCity(data, null);
  };

  cityChangeHandler = val => {
    console.log('City called======================>', this.state);
    this.setState(prevState => {
      return {
        city: val,
        center: prevState.isBack == true ? prevState.center : '',
      };
    });
    const data1 = {cityid: val};
    this.props.onGetCenter(data1, null);
  };

  centerChangeHandler = val => {
    console.log('Center called', this.state);
    this.setState({
      center: val,
    });
  };

  addressLine1ChangeHandler = val => {
    if (/^[A-Za-z0-9_@. /,#&+-]*$/.test(val)) {
      this.setState({
        addrLine1: val,
      });
    }
  };

  addressLine2ChangeHandler = val => {
    if (/^[A-Za-z0-9_@. /,#&+-]*$/.test(val)) {
      this.setState({
        addrLine2: val,
      });
    }
  };

  passwordChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        password: val,
      });
    }
  };

  confirmPasswordChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        confirmPassword: val,
      });
    }
  };

  checkEmailAndPhone = val => {
    console.log(val);
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  personalInfoSubmitHandler = () => {
    // this.setState({
    //   infoStatus: PASSWORD_INFO_COMPLETED,
    // });
    // this.props.onSignUpBackHandle({status: PASSWORD_INFO_COMPLETED}, null);
    const valid0 = validateEmpId(this.state.empId);
    const valid1 = firstnameEmpty(this.state.firstName);
    const valid2 = lastnameEmpty(this.state.lastName);
    const valid3 = validateEmail(this.state.email);
    const valid4 = validateMobileNo(this.state.mobileNo);
    const valid5 = validateDob(this.state.dob);
    // this.setState({
    //   infoStatus: PERSONAL_INFO_COMPLETED,
    // });
    // this.props.onSignUpBackHandle({status: PERSONAL_INFO_COMPLETED}, null);

    if (
      valid0.val &&
      valid1.val &&
      valid2.val &&
      valid3.val &&
      valid4.val &&
      valid5.val
    ) {
      console.log('info Completed');
      this.setState({
        isValidEmpId: valid0.val,
        isValidFirstName: valid1.val,
        isValidLastName: valid2.val,
        isValidEmail: valid3.val,
        isValidMobileNo: valid4.val,
        isValidDob: valid5.val,
        empIdValidationMsg: '',
        firstNameValidationMsg: '',
        lastNameValidationMsg: '',
        emailValidationMsg: '',
        mobileNoValidationMsg: '',
        dobValidationMsg: '',
        infoStatus: PERSONAL_INFO_COMPLETED,
      });
      this.props.onSignUpBackHandle({status: PERSONAL_INFO_COMPLETED}, null);
    } else {
      this.setState({
        isValidEmpId: valid0.val,
        isValidFirstName: valid1.val,
        isValidLastName: valid2.val,
        isValidEmail: valid3.val,
        isValidMobileNo: valid4.val,
        isValidDob: valid5.val,
        empIdValidationMsg: valid0.msg,
        firstNameValidationMsg: valid1.msg,
        lastNameValidationMsg: valid2.msg,
        emailValidationMsg: valid3.msg,
        mobileNoValidationMsg: valid4.msg,
        dobValidationMsg: valid5.msg,
      });
    }
  };

  educationInfoSubmitHandler = () => {
    const valid1 = validateQualificationText(this.state.qualification);
    const valid2 = validateExperienceNumber(this.state.experience);
    const valid3 = validateRoleDropdownEmpty(this.state.role);

    // this.setState({
    //   infoStatus: EDUCATION_INFO_COMPLETED,
    // });
    // this.props.onSignUpBackHandle({status: EDUCATION_INFO_COMPLETED}, null);

    if (valid1.val && valid2.val && valid3.val) {
      this.setState({
        isValidQualification: valid1.val,
        isValidExperience: valid2.val,
        isValidRole: valid3.val,
        qualificationValidationMsg: '',
        experienceValidationMsg: '',
        roleValidationMsg: '',
        infoStatus: EDUCATION_INFO_COMPLETED,
      });
      this.props.onSignUpBackHandle({status: EDUCATION_INFO_COMPLETED}, null);
    } else {
      this.setState({
        isValidQualification: valid1.val,
        isValidExperience: valid2.val,
        isValidRole: valid3.val,
        qualificationValidationMsg: valid1.msg,
        experienceValidationMsg: valid2.msg,
        roleValidationMsg: valid3.msg,
      });
    }
  };

  locationInfoSubmitHandler = () => {
    const valid1 = validatePincodeNumber(this.state.pincode);
    const valid2 = validateAddressLine1(this.state.addrLine1);
    const valid3 = validateAddressLine2(this.state.addrLine2);
    const valid4 = validateCityDropdownEmpty(this.state.city);
    const valid5 = validateCenterDropdownEmpty(this.state.center);
    const valid6 = validateStateDropdownEmpty(this.state.state);

    // this.setState({
    //   infoStatus: LOCATION_INFO_COMPLETED,
    // });
    // this.props.onSignUpBackHandle({status: LOCATION_INFO_COMPLETED}, null);

    if (
      valid1.val &&
      valid2.val &&
      valid3.val &&
      valid4.val &&
      valid5.val &&
      valid6.val
    ) {
      this.setState({
        isValidPincode: valid1.val,
        isValidAddrLine1: valid2.val,
        isValidAddrLine2: valid3.val,
        isValidCity: valid4.val,
        isValidCenter: valid5.val,
        isValidState: valid6.val,
        pincodeValidationMsg: '',
        addrLine1ValidationMsg: '',
        addrLine2ValidationMsg: '',
        cityValidationMsg: '',
        centerValidationMsg: '',
        stateValidationMsg: '',
        infoStatus: LOCATION_INFO_COMPLETED,
        isBack: true,
      });
      this.props.onSignUpBackHandle({status: LOCATION_INFO_COMPLETED}, null);
    } else {
      this.setState({
        isValidPincode: valid1.val,
        isValidAddrLine1: valid2.val,
        isValidAddrLine2: valid3.val,
        isValidCity: valid4.val,
        isValidCenter: valid5.val,
        isValidState: valid6.val,
        pincodeValidationMsg: valid1.msg,
        cityValidationMsg: valid4.msg,
        centerValidationMsg: valid5.msg,
        addrLine1ValidationMsg: valid2.msg,
        addrLine2ValidationMsg: valid3.msg,
        stateValidationMsg: valid6.msg,
        isBack: true,
      });
    }
  };

  passwordInfoSubmitHandler = () => {
    const valid1 = validatePassword(this.state.password);
    const valid2 = validateConfirmPassword(this.state.confirmPassword);
    const valid3 = validatematchPassword(
      this.state.password,
      this.state.confirmPassword,
    );
    // this.setState({
    //   infoStatus: PASSWORD_INFO_COMPLETED,
    // });
    // this.props.onSignUpBackHandle({status: PASSWORD_INFO_COMPLETED}, null);

    if (valid1.val && valid2.val) {
      if (valid3.val) {
        this.setState({
          isValidPassword: valid1.val,
          isValidConfirmPassword: valid2.val,
          passwordValidationMsg: '',
          confirmPasswordValidationMsg: '',
          isValidamatchPassword: '',
          isValidamatchPasswordMsg: '',
        });
        // this.props.onSignUpBackHandle({status: PASSWORD_INFO_COMPLETED}, null);
        this.props.onGetSignUp(this.getData(), null);
      } else {
        this.setState({
          isValidPassword: valid1.val,
          isValidConfirmPassword: valid2.val,
          passwordValidationMsg: valid1.msg,
          confirmPasswordValidationMsg: valid2.msg,
          isValidamatchPassword: valid3.val,
          isValidamatchPasswordMsg: valid3.msg,
        });
      }
    } else {
      this.setState({
        isValidPassword: valid1.val,
        isValidConfirmPassword: valid2.val,
        passwordValidationMsg: valid1.msg,
        confirmPasswordValidationMsg: valid2.msg,
        isValidamatchPassword: valid3.val,
        isValidamatchPasswordMsg: valid3.msg,
      });
    }
  };

  getData = () => {
    const data = {
      userid: -1,
      user_first_name: this.state.firstName,
      user_last_name: this.state.lastName,
      user_phoneno: this.state.mobileNo,
      user_emailid: this.state.email,
      user_dob: this.state.dob,
      user_address_line1: this.state.addrLine1,
      user_address_line2: this.state.addrLine2,
      user_roleid: this.state.role,
      user_password: this.state.password,
      qualification: this.state.qualification,
      exp_in_years: this.state.experience,
      pincode: this.state.pincode,
      cityid: this.state.city,
      branch_id: this.state.center,
      stateid: this.state.state,
      employeeid : this.state.empId
    };
    return data;
  };

  backHandler = () => {
    if (this.state.infoStatus == 3) {
      this.setState({
        infoStatus: 2,
      });
      this.props.onSignUpBackHandle({status: 2}, null);
      return true;
    } else if (this.state.infoStatus == 2) {
      this.setState({
        infoStatus: 1,
      });
      this.props.onSignUpBackHandle({status: 1}, null);
      return true;
    } else if (this.state.infoStatus == 1) {
      this.setState({
        infoStatus: 0,
      });
      this.props.onSignUpBackHandle({status: 0}, null);
      return true;
    } else if (this.state.infoStatus == 0) {
      this.props.navigation.goBack(null);
      return true;
    }
  };

  componentDidMount = () => {
    const data0 = {
      flag: 0,
    };
    const data = {
      stateid: 1,
      search: null,
    };
    const data1 = {
      cityid: null,
    };
    this.props.onGetRole(data0);
    this.props.onGetState({}, null);
    this.props.onGetCity(data, null);
    this.props.onGetCenter(data1, null);

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.roleStatus != this.props.roleStatus &&
      this.props.roleStatus == true
    ) {
      this.setState({
        roles: this.props.roles,
      });
    }

    // if (
    //   prevProps.statesStatus != this.props.statesStatus &&
    //   this.props.statesStatus == true
    // ) {
    //   const data = {
    //     stateid: this.state.state,
    //     search: null,
    //   };
    //   const data1 = {cityid: this.state.city};
    //   this.props.onGetCenter(data1, null);
    //   this.props.onGetCity(data, null);
    // }

    // if (
    //   prevProps.citiesStatus != this.props.citiesStatus &&
    //   this.props.citiesStatus == true
    // ) {
    //   const data1 = {cityid: this.state.city};
    //   this.props.onGetCenter(data1, null);
    //   this.setState({
    //     center: '',
    //   });
    // }

    if (
      prevProps.signUpStatus != this.props.signUpStatus &&
      this.props.signUpStatus == true
    ) {
      this.setState({
        infoStatus: PASSWORD_INFO_COMPLETED,
      });
      this.props.navigation.navigate(Auth.profilePending);
    }

    if (
      prevProps.signUpError != this.props.signUpError &&
      this.props.signUpError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.signUpBackState != this.props.signUpBackState &&
      this.state.infoStatus != this.props.signUpBackState
    ) {
      this.setState({
        infoStatus: this.props.signUpBackState,
      });
    }

    if (
      prevProps.checkEmailError != this.props.checkEmailError &&
      this.props.checkEmailError == true
    ) {
      console.log(this.state);
      console.log(this.props.checkEmailError);
      if (this.state.isEmail == true)
        this.setState({
          isValidEmail: false,
          emailValidationMsg: this.props.message,
          isEmail: false,
        });
      if (this.state.isMobile == true)
        this.setState({
          isValidMobileNo: false,
          mobileNoValidationMsg: this.props.message,
          isMobile: false,
        });
    }
    if (
      prevProps.checkEmailStatus != this.props.checkEmailStatus &&
      this.props.checkEmailStatus == true
    ) {
      if (this.state.isEmail == true)
        this.setState({
          isValidEmail: true,
          emailValidationMsg: '',
          isEmail: false,
        });
      if (this.state.isMobile == true)
        this.setState({
          isValidMobileNo: true,
          mobileNoValidationMsg: '',
          isMobile: false,
        });
    }
  };

  componentWillUnmount() {
    this.back.remove();
  }

  render() {
    return (
      <SignUpScreen
        loading={this.props.checkEmailLoading}
        showToast={this.state.showToast}
        errorMsg={this.props.message}
        infoStatus={this.state.infoStatus}
        empId={this.state.empId}
        firstName={this.state.firstName}
        lastName={this.state.lastName}
        email={this.state.email}
        mobileNo={this.state.mobileNo}
        dob={this.state.dob}
        qualification={this.state.qualification}
        experience={this.state.experience}
        role={this.state.role}
        roleList={this.props.roles}
        pincode={this.state.pincode}
        state={this.state.state}
        stateList={this.props.states}
        city={this.state.city}
        cityList={this.state.state != '' ? this.props.cities : []}
        center={this.state.center}
        centerList={this.state.city != '' ? this.props.centers : []}
        addrLine1={this.state.addrLine1}
        addrLine2={this.state.addrLine2}
        password={this.state.password}
        confirmPassword={this.state.confirmPassword}
        empIdValidationMsg={this.state.empIdValidationMsg}
        firstNameValidationMsg={this.state.firstNameValidationMsg}
        lastNameValidationMsg={this.state.lastNameValidationMsg}
        emailValidationMsg={this.state.emailValidationMsg}
        mobileNoValidationMsg={this.state.mobileNoValidationMsg}
        dobValidationMsg={this.state.dobValidationMsg}
        qualificationValidationMsg={this.state.qualificationValidationMsg}
        roleValidationMsg={this.state.roleValidationMsg}
        experienceValidationMsg={this.state.experienceValidationMsg}
        pincodeValidationMsg={this.state.pincodeValidationMsg}
        stateValidationMsg={this.state.stateValidationMsg}
        cityValidationMsg={this.state.cityValidationMsg}
        centerValidationMsg={this.state.centerValidationMsg}
        addrLine1ValidationMsg={this.state.addrLine1ValidationMsg}
        addrLine2ValidationMsg={this.state.addrLine2ValidationMsg}
        passwordValidationMsg={this.state.passwordValidationMsg}
        confirmPasswordValidationMsg={this.state.confirmPasswordValidationMsg}
        isValidamatchPasswordMsg={this.state.isValidamatchPasswordMsg}
        isValidamatchPassword={this.state.isValidamatchPassword}
        isValidEmpId={this.state.isValidEmpId}
        isValidFirstName={this.state.isValidFirstName}
        isValidLastName={this.state.isValidLastName}
        isValidEmail={this.state.isValidEmail}
        isValidMobileNo={this.state.isValidMobileNo}
        isValidDob={this.state.isValidDob}
        isValidQualification={this.state.isValidQualification}
        isValidExperience={this.state.isValidExperience}
        isValidRole={this.state.isValidRole}
        isValidPincode={this.state.isValidPincode}
        isValidCity={this.state.isValidCity}
        isValidCenter={this.state.isValidCenter}
        isValidState={this.state.isValidState}
        isValidAddrLine1={this.state.isValidAddrLine1}
        isValidAddrLine2={this.state.isValidAddrLine2}
        isValidPassword={this.state.isValidPassword}
        isValidConfirmPassword={this.state.isValidConfirmPassword}
        //methods
        validateEmpId={this.validateEmpId}
        validateFirstName={this.validateFirstName}
        validateLastName={this.validateLastName}
        validateEmail={this.validateEmail}
        validateMobileNo={this.validateMobileNo}
        validateDob={this.validateDob}
        validateQualification={this.validateQualification}
        validateExperience={this.validateExperience}
        validateRole={this.validateRole}
        validatePincode={this.validatePincode}
        validateCity={this.validateCity}
        validateCenter={this.validateCenter}
        validateAddrLine1={this.validateAddrLine1}
        validateAddrLine2={this.validateAddrLine2}
        validatePassword={this.validatePassword}
        validateConfirmPassword={this.validateConfirmPassword}
        checkEmailAndPhone={this.checkEmailAndPhone}
        empIdChangeHandler={this.empIdChangeHandler}
        firstNameChangeHandler={this.firstNameChangeHandler}
        lastNameChangeHandler={this.lastNameChangeHandler}
        emailChangeHandler={this.emailChangeHandler}
        mobileNoChangeHandler={this.mobileNoChangeHandler}
        dobChangeHandler={this.dobChangeHaandler}
        qualificationChangeHandler={this.qualificationChangeHandler}
        experienceChangeHandler={this.experienceChangeHandler}
        roleChangeHandler={this.roleChangeHandler}
        pincodeChangeHandler={this.pincodeChangeHandler}
        stateChangeHandler={this.stateChangeHandler}
        cityChangeHandler={this.cityChangeHandler}
        centerChangeHandler={this.centerChangeHandler}
        addrLine1ChangeHandler={this.addressLine1ChangeHandler}
        addrLine2ChangeHandler={this.addressLine2ChangeHandler}
        passwordChangeHandler={this.passwordChangeHandler}
        confirmPasswordChangeHandler={this.confirmPasswordChangeHandler}
        personalInfoSubmitHandler={this.personalInfoSubmitHandler}
        educationInfoSubmitHandler={this.educationInfoSubmitHandler}
        locationInfoSubmitHandler={this.locationInfoSubmitHandler}
        passwordInfoSubmitHandler={this.passwordInfoSubmitHandler}
        // Backhandlerwithinpage={this.Backhandlerwithinpage}
      />
    );
  }
}
SignUp.navigationOptions = {
  title: 'Hello!',
};

function mapStateToProps(state) {
  return {
    roles: state.common.roles,
    cities: state.common.cities,
    citiesError: state.common.cityError,
    citiesLoading: state.common.cityLoading,
    citiesStatus: state.common.cityStatus,
    centerStatus: state.common.centerStatus,
    centers: state.common.centers,
    centersError: state.common.centerError,
    centersLoading: state.common.centerLoading,
    statesLoading: state.common.stateLoading,
    statesError: state.common.stateError,
    statesStatus: state.common.sateStatus,
    states: state.common.stateResponse,
    signUpLoading: state.signUp.signUpLoading,
    signUpStatus: state.signUp.signUpStatus,
    signUpError: state.signUp.signUpError,
    message: state.signUp.message,
    accessToken: state.signIn.accessToken,
    signUpBackState: state.signUp.signUpBackState,
    checkEmailLoading: state.signUp.checkEmailLoading,
    checkEmailStatus: state.signUp.checkEmailStatus,
    checkEmailError: state.signUp.checkEmailError,
  };
}

function mapDispatchToProps(dispatch) {
  return {
    onGetRole: (data, token) => dispatch(getRole(data, token)),
    onGetState: (data, token) => dispatch(getState(data, token)),
    onGetCity: (data, token) => dispatch(getCity(data, token)),
    onGetCenter: (data, token) => dispatch(getCenter(data, token)),
    onCheckEmailExist: (data, token) => dispatch(checkEmailExist(data, token)),
    onGetSignUp: (data, token) => dispatch(getSignUp(data, token)),
    onSignUpBackHandle: (data, token) =>
      dispatch(signUpBackHandle(data, token)),
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(SignUp);
