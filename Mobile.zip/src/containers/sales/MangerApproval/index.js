import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import MangerApprovalScreen from './Screen';

class Alert extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  render() {
    return <MangerApprovalScreen />;
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(Alert);
