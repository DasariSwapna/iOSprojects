import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../components/RootView';

//import SearchBar from '../../../components/Searchbar';

function MangerApprovalScreen() {
  const [searchQuery, setSearchQuery] = React.useState('');

  const onChangeSearch = query => setSearchQuery(query);
  return (
    <RootView pageNo={'P-299'}>
      <Text>Aathi</Text>
    </RootView>
  );
}

export default MangerApprovalScreen;
