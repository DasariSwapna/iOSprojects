import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  FlatList,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import {ModalCancel} from '../../../../components/OtpModal';
import {Toast} from '../../../../components/Toast';
import I18n from '../../../../locale/i18n';

function PayoutSctionContainer({
  revised,
  title,
  minPrice,
  requestedPrice,
  suggestedPrice,
  status,
  statusText,
}) {
  return (
    <View style={styles.payoutContainer}>
      {/* <View style={styles.payoutInnerContainer}>
        <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
        <Text style={styles.payoutTextContainerBold}>Vitamin D</Text>
      </View> */}
      <View style={styles.payoutBottomContainer}>
        <View style={{marginTop: hp('1.0%'), flexDirection: 'row'}}>
          <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
          <View style={{width: wp('62%'), marginLeft: 10, paddingRight: 5}}>
            <ScrollView horizontal>
              <Text numberOfLines={1} style={styles.payoutTextContainerBold}>
                {title}
              </Text>
            </ScrollView>
          </View>
        </View>

        <View
          style={{
            marginTop: hp('1.0%'),
            flexDirection: 'row',
            justifyContent: 'space-between',
          }}>
          <View style={{flexDirection: 'column'}}>
            <Text style={styles.payoutTextContainerBorder}>Min</Text>
            <Text style={styles.payoutTextContainerMagenta}>
              {I18n.t('valitation.rupee')} {minPrice}
            </Text>
          </View>
          <View style={{flexDirection: 'column'}}>
            <Text style={styles.payoutTextContainerBorder}>Requested</Text>
            <Text style={styles.payoutTextContainerMagenta}>
              {I18n.t('valitation.rupee')} {requestedPrice}
            </Text>
          </View>
          <View style={{flexDirection: 'column'}}>
            <Text style={styles.payoutTextContainerBorder}>
              {status == 'Revised' ? 'Suggetsed' : ''}
            </Text>
            <Text style={styles.payoutTextContainerMagenta}>
              {status == 'Revised'
                ? I18n.t('valitation.rupee') + suggestedPrice
                : ''}
            </Text>
          </View>

          <Text
            style={[
              {
                fontFamily: Font.regular,
                color: Colors.darkGreen,
                fontSize: FontSize.medium,
                alignSelf: 'flex-end',
              },
              {color: !revised ? Colors.darkGreen : Colors.darkPink},
            ]}>
            {status}
          </Text>
        </View>
      </View>
    </View>
  );
}

const renderNodata = () => {
  return (
    <>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          marginVertical: hp('35%'),
        }}>
        <Text style={{fontFamily: FontMagneta.bold}}>No data found</Text>
      </View>
    </>
  );
};

function ManagerApprovalStatusScreen({
  addressTypeHandler,
  nextButtonHandler,
  reinitiateHandler,
  dismissHandler,
  SubmitHandler,
  cancelHandler,
  // states
  rejected,
  showModalCancel,
  approvalTestdatas,
  loading,
  showToast,
  errorMsg,
}) {
  const renderPayoutContainer = ({item, index}) => {
    return (
      <PayoutSctionContainer
        title={item.LC_TD_TEST_NAME}
        minPrice={item.Min_Price}
        requestedPrice={item.Selling_Price}
        suggestedPrice={item.Suggested_Price}
        status={item.LC_AS_APPROVE_STATUS}
      />
    );
  };

  return (
    <RootView pageNo={'96-1'} loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      {showModalCancel === true && (
        <ModalCancel
          pageNumber={117}
          visible={showModalCancel}
          dismissHandler={dismissHandler}
          SubmitHandler={SubmitHandler}
        />
      )}
      <KeyboardAvoidingView style={{flex: 1}}>
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            backgroundColor: '#fff',
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <View
              style={{
                alignSelf: 'center',
                alignContent: 'flex-start',
                width: hp('88%'),
                flex: 1,
                marginTop: hp('1.5%'),
                //backgroundColor: 'red'
              }}>
              <FlatList
                data={approvalTestdatas}
                keyExtractor={(item, index) => item.key}
                renderItem={renderPayoutContainer}
                ListEmptyComponent={renderNodata}
                contentContainerStyle={styles.flatListInnerContainer}
                showsVerticalScrollIndicator={false}
              />
            </View>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
              backgroundColor: '#fff',
            }}>
            {rejected ? (
              <View style={styles.buttonPayContainer}>
                <View
                  style={{
                    width: '100%',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-evenly',
                  }}>
                  <Button
                    title="Cancel"
                    buttonStyle={{
                      width: '40%',
                      paddingHorizontal: 2,
                      borderRadius: hp('5%'),
                      backgroundColor: '#fff',
                      borderColor: Colors.darkPink,
                      borderWidth: 1,
                    }}
                    buttonTextStyle={styles.buttonTextStylePink}
                    onPress={cancelHandler}
                  />
                  <Button
                    title="Re-initiate"
                    buttonStyle={{
                      width: '40%',
                      paddingHorizontal: 2,
                      borderRadius: hp('5%'),
                    }}
                    buttonTextStyle={styles.buttonStyleWhite}
                    onPress={reinitiateHandler}
                  />
                </View>
              </View>
            ) : approvalTestdatas == '' ? null : (
              <View style={styles.buttonContainer}>
                <Button
                  title="Next"
                  buttonTextStyle={{fontSize: FontSize.large}}
                  onPress={nextButtonHandler}
                />
              </View>
            )}
          </View>
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  head: {
    height: 40,
    backgroundColor: '#fff',
    color: Colors.border,
  },
  text: {
    margin: 4,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.black,
  },
  textBorder: {
    margin: 4,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.border,
  },
  textStyleBold: {
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.black,
    marginTop: 30,
  },
  textStyleHeader: {
    flex: 1,
    paddingLeft: 25,
    paddingVertical: 5,
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  ////Payout Section Container
  payoutContainer: {
    width: wp('85%'),
    height: Platform.OS === 'ios' ? hp('12%') : hp('14%'),
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginVertical: hp('1.5%'),
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: '80%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutTextContainerBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBold: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,
  },
  payoutBottomContainer: {
    flexDirection: 'column',
    //  width: wp('100%'),
    justifyContent: 'space-between',
    paddingHorizontal: wp('2.5%'),
    marginTop: hp('1.0%'),
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    marginTop: hp('2%'),
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    //  width: 90,
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 7,
    height: 40,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: 10,
  },
  ////Buttons Style
  buttonPayContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    //  width: '100%',
    alignSelf: 'center',
  },
  buttonWithBorder: {
    minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: '#fff',
    borderColor: Colors.darkPink,
    borderWidth: 1,
  },
  buttonWithoutBorder: {
    minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
  },
  buttonTextStylePink: {
    fontSize: FontSize.large,
    color: Colors.darkPink,
  },
  buttonStyleWhite: {
    fontSize: FontSize.large,
  },
});

export default ManagerApprovalStatusScreen;
