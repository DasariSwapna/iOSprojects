import React from 'react';
import {connect} from 'react-redux';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import ManagerApprovalStatusScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import {
  getApprovalDetails,
  updateApprovalStatus,
} from '../../../../store/Actions';
import {delay} from '../../../../utils/Helpers';
import {
  getTermsQuestionAnswer,
  insertTermsQuestionAnswer,
} from '../../../../store/Actions';
import I18n from '../../../../locale/i18n';

class ManagerApprovalStatus extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      rejected: this.props.route.params.rejected,
      showModalCancel: false,
      vendorID: this.props.route.params.vendorId,
      approvalTestdatas: '',
      typeID: this.props.route.params.typeID,
      errorMsg: '',
      showToast: false,
    };
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.ManagerApprovalTermsCondition);

    const data = {
      hostpital_id: this.state.vendorID,
      types_id: this.state.typeID,
      terms: [],
      name_of_signing: '',
      designation: '',
      contact_number: '',
      email_id: '',
      address: '',
      user_id: this.props.userId,
    };

    this.props.onInsertTermsQuestionAnswer(data, this.props.accessToken);
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  navigationNextpage = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalPreview, {
      URL: this.props.insertQuestionAnswerResponse.Message,
      Hospitalname: this.props.insertQuestionAnswerResponse.LC_VD_HOSPITALNAME,
      vendorID: this.props.insertQuestionAnswerResponse.LC_VD_VENID,
    });
  };

  reinitiateHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  cancelHandler = () => {
    this.setState({
      showModalCancel: true,
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  dismissHandler = () => {
    this.setState({
      showModalCancel: false,
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  SubmitHandler = () => {
    this.setState({
      showModalCancel: false,
    });
    this.props.navigation.navigate(Sales.ManagerApproval);
  };
  componentDidMount() {
    const data = {
      hospitalid: this.state.vendorID,
    };
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalDetails(data, this.props.accessToken);
    });
    //  this.props.onGetMangerTestApproval(data, this.props.accessToken);
  }
  componentDidUpdate = prevProps => {
    if (
      prevProps.managerapprovaldetailsStatus == false &&
      this.props.managerapprovaldetailsStatus !=
        prevProps.managerapprovaldetailsStatus
    ) {
      approvalTestdatas = this.props.managerapprovalproducttestDetails;
    }

    if (
      prevProps.insertQuestionAnswerStatus == false &&
      this.props.insertQuestionAnswerStatus !=
        prevProps.insertQuestionAnswerStatus
    ) {
      if (this.props.insertQuestionAnswerResponse == '') {
        this.setState(
          {
            errorMsg: I18n.t('valitation.PDF_not_available'),
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
      } else {
        this.navigationNextpage();
      }
    }
  };

  render() {
    return (
      <ManagerApprovalStatusScreen
        nextButtonHandler={this.nextButtonHandler}
        reinitiateHandler={this.reinitiateHandler}
        cancelHandler={this.cancelHandler}
        dismissHandler={this.dismissHandler}
        SubmitHandler={this.SubmitHandler}
        typeID={this.state.typeID}
        vendorID={this.state.vendorID}
        // states
        rejected={this.state.rejected}
        showModalCancel={this.state.showModalCancel}
        approvalTestdatas={this.props.managerapprovalproducttestDetails}
        loading={this.props.managerapprovaldetailsLoading}
        hospitaldetails={this.props.managerapprovaldoctorDetails}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    userId: state.signIn.userId,
    loading: state.SalesMangerTestApprovalReducer.salesMangerApprovelLoading,
    managerapprovalproducttestDetails:
      state.salesmanagerapprovals.approvalproducttestDetails,
    managerapprovaldetailsError:
      state.salesmanagerapprovals.approvaldetailstError,
    managerapprovaldetailsStatus:
      state.salesmanagerapprovals.apporvaldetailsStatus,
    managerapprovaldetailsLoading:
      state.salesmanagerapprovals.approvaldetailsLoading,
    managerapprovaldoctorDetails:
      state.salesmanagerapprovals.approvaldoctorDetails,

    insertQuestionAnswerLoading: state.createVendor.insertQuestionAnswerLoading,
    insertQuestionAnswerStatus: state.createVendor.insertQuestionAnswerStatus,
    insertQuestionAnswerError: state.createVendor.insertQuestionAnswerError,
    insertQuestionAnswerResponse:
      state.createVendor.insertQuestionAnswerResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getApprovalDetails(data, token)),
    onInsertTermsQuestionAnswer: (data, token) =>
      dispatch(insertTermsQuestionAnswer(data, token)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(ManagerApprovalStatus);
