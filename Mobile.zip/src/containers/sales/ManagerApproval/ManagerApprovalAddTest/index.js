import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import MangerApprovalAddTestScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import Colors from '../../../../config/Colors';

const Data = [
  { id: 1, name: 'PNS', totalId: '05', testId: '02', image: Icons.nbs, color: Colors.card },
  { id: 2, name: 'NbS', totalId: '08', testId: '01', image: Icons.pns, color: Colors.white },
  { id: 3, name: 'Allied', totalId: '02', testId: '04', image: Icons.nbs, color: Colors.white },
  { id: 4, name: 'Allied', totalId: '02', testId: '04', image: Icons.nbs, color: Colors.white },
]

class MangerApprovalAddTest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      data: [],
      radio: false
    };
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalTermsCondition);
  }

  componentDidMount() {
    this.setState({ data: Data })
  }

  radioPress = () => {
    this.setState({
      radio: true
    })
  };

  render() {
    return <MangerApprovalAddTestScreen
      nextButtonHandler={this.nextButtonHandler}
      radioPress={this.radioPress}
      // 
      data={this.state.data} />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(MangerApprovalAddTest);
