import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import AddTestTopComponet from '../../../../components/AddTestTopComponent'
// import SearchBar from '../../../../components/SearchBar'
import AddTestPayoutComponent from '../../../../components/AddTestPayoutContainer'
import CheckCircle from "../../../../components/CheckCircle";
import PageNo from '../../../../constants/PageNo'




const renderTopContainer = ({ item }) => (
  <AddTestTopComponet
    image={'item.image'}
    color={item.color}
  />
)

function PayoutSctionContainer({ radioPress }) {
  return (
    <View style={styles.payoutContainer}>
      {/* <View style={styles.payoutInnerContainer}>
        <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
        <Text style={styles.payoutTextContainerBold}>Vitamin D</Text>
        <Text style={styles.payoutCircleContainer}></Text>
      </View> */}

      <View style={styles.payoutBottomContainer}>
        <View style={{ marginTop: 10 }}>
          <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
          <Text style={styles.payoutTextContainerBorder}>Min</Text>
          <Text style={styles.payoutTextContainerMagenta}>₹ 600</Text>
        </View>

        <View style={{ marginTop: 10 }}>
          <Text style={styles.payoutTextContainerBold}>Vitamin D</Text>
          <Text style={styles.payoutTextContainerBorder}>Max</Text>
          <Text style={styles.payoutTextContainerMagenta}>₹ 1200</Text>
        </View>


        <View style={{ marginTop: 10 }}>
          <Text style={styles.payoutTextContainerBorder}></Text>
          <Text style={styles.payoutTextContainerMagenta}></Text>
        </View>

        <View style={{ flexDirection: 'column', marginTop: 10 }}>
          <Text style={styles.payoutTextContainerBlackRegular}>Enter Price</Text>
          <TextInput
            style={styles.payoutTextInputContainer}
            placeholder="₹    100"
            placeholderTextColor={Colors.black}
            underlineColorAndroid="transparent"
          />
        </View>

      </View>

      <View style={{ position: 'absolute', right: 0, margin: hp('1%') }}>
        <CheckCircle length={20} onPress={() => radioPress()} />
      </View>

    </View>
  );
}

function Footer() {
  return (
    <View style={{ width: '90%', justifyContent: 'space-between', flexDirection: 'row', alignSelf: 'center', marginVertical: 20 }}>
      <View style={{ width: hp('14%'), justifyContent: 'center', alignItems: 'center', borderRadius: hp('10%'), backgroundColor: "#F0F6D8", paddingVertical: 4 }}>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.regular,
          fontSize: FontSize.regular,
        }}>Total Test</Text>
        <Text>5</Text>
      </View>
      <View style={{ width: hp('14%'), justifyContent: 'center', alignItems: 'center', borderRadius: hp('10%'), backgroundColor: Colors.card, paddingVertical: 4 }}>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.regular,
          fontSize: FontSize.regular,
        }}>outliners</Text>
        <Text>1</Text>
      </View>
      <View style={{ width: hp('14%'), justifyContent: 'center', alignItems: 'center', borderRadius: hp('10%'), backgroundColor: "#CCEAE5", paddingVertical: 4 }}>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.regular,
          fontSize: FontSize.regular,
        }}>Auto approved</Text>
        <Text>1</Text>
      </View>
    </View>
  );
}


function MangerApprovalAddTestScreen({
  addressTypeHandler,
  nextButtonHandler,
  data,
  radioPress }) {
  return (
    <RootView pageNo={PageNo.sales_createVendorTermsCondition}>
      <KeyboardAvoidingView style={{ flex: 1 }}>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            {/* Top Conatiner */}
            <View
              style={styles.TopViewContainer} >
              <FlatList
                horizontal
                showsHorizontalScrollIndicator={false}
                data={data}
                keyExtractor={(item) => item.id}
                renderItem={renderTopContainer}
              />
            </View>
            {/* Serach Section */}
            <View
              style={styles.searchOuterContainer}>
              <View
                style={{ width: '70%' }}>
                {/* <SearchBar /> */}
              </View>
              <Text
                style={styles.textStyle}>₹7,700</Text>
            </View>
            {/* Payout Section */}
            <PayoutSctionContainer radioPress={radioPress} />
            <PayoutSctionContainer radioPress={radioPress} />
            <PayoutSctionContainer radioPress={radioPress} />

            <View style={styles.lineLargeContainer} />

            <Footer />





            <View style={styles.buttonContainer}>
              <Button title="Next"
                buttonTextStyle={{ fontSize: FontSize.large }}
                onPress={nextButtonHandler} />
            </View>


          </View>
        </ScrollView>
      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff'
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff'
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
    marginTop: 30
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
    marginTop: 30
  },
  //////Top Container start
  topContainer: {
    width: 170,
    height: 90,
    borderRadius: 20,
    padding: 10,
    borderWidth: 0.5,
    borderColor: Colors.border,
    marginRight: 20,

  },
  topContainerLayout: {
    flexDirection: 'column',
    marginLeft: 10
  },
  topImageContainer: {
    width: 40,
    height: 40
  },
  topInnerContainer1: {
    width: '70%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'flex-start'
  },
  topInnerContainer2: {
    width: '90%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'center',
    marginTop: 10
  },
  topContainerTextLarge: {
    color: Colors.black,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  topContainerTextSmall: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100
  },
  /////////Serach Section
  searchSection: {
    width: '70%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  /////Search outer Style
  searchOuterContainer: {
    width: '85%',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    paddingVertical: 20
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center'
  },
  ////Payout Section Container
  payoutContainer: {
    width: '85%',
    height: hp('12%'),
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginVertical: 15
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,

  },
  payoutTextContainerBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBold: {

    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,

  },
  payoutBottomContainer: {
    flexDirection: 'row',
    width: '90%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    paddingVertical: 10
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    marginTop: hp('1%')
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    width: hp('14%'),
    borderWidth: hp('0.1%'),
    borderColor: Colors.border,
    borderRadius: 7,
    height: hp('5%'),
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: 10
  },
  TopViewContainer: {
    height: hp('12%'),
    marginTop: 20,
    width: '95%',
    marginLeft: '5%',
    alignSelf: 'center',
  },

});

export default MangerApprovalAddTestScreen;
