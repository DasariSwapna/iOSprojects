import React, { useRef, createRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  TouchableOpacity
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { NextButton } from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import SignatureCapture from 'react-native-signature-capture';
import IonIcons from 'react-native-vector-icons/Ionicons';
import OtpModal, { ModalConfirmNumber, OtpModalPayment, ModalSuccess } from '../../../../components/OtpModal';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo'




function ManagerApprovalAuthenticationScreen({
  addressTypeHandler,
  nextButtonHandler,
  otpHandler,
  otpSubmitHandler,
  cancelMobileConfirmHandler,
  quotationHandler,
  // states
  showOtpPaymentModal,
}) {

  const sign = createRef();

  const saveSign = () => {
    sign.current.saveImage();
  };

  const resetSign = () => {
    sign.current.resetImage();
  };

  const _onSaveEvent = result => {
    //result.encoded - for the base64 encoded png
    //result.pathName - for the file path name
    alert('Signature Captured Successfully');
    console.log(result.encoded);
  };
  const _onDragEvent = () => {
    // This callback will be called when the user enters signature
    console.log('dragged');
  };

  return (
    <RootView pageNo={PageNo.sales_authentication}>
      {showOtpPaymentModal === true && (
        <OtpModalPayment
          visible={showOtpPaymentModal}
          dismissHandler={cancelMobileConfirmHandler}
          otpSubmitHandler={otpSubmitHandler}
          title={I18n.t('sales.paymentCollection.enter_otp_placeholder')}
        />
      )}
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff'
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View
                style={styles.mainContainer}>
                <View
                  style={styles.container}>
                  <Text
                    style={styles.titleStyle}>{I18n.t('sales.authentication.sign_inside_label')}
                  </Text>
                  <View
                    style={styles.signatureContainer}>
                    <SignatureCapture
                      style={styles.signature}
                      ref={sign}
                      onSaveEvent={_onSaveEvent}
                      onDragEvent={_onDragEvent}
                      showNativeButtons={false}
                      showTitleLabel={false}
                      viewMode={'portrait'}
                      showBorder={false}
                    />
                    <TouchableOpacity
                      style={styles.refreshButtonStyle}
                      onPress={() => {
                        resetSign();
                      }}>
                      <IonIcons
                        name={'md-refresh'}
                        color={Colors.primary}
                        size={25}
                        style={styles.refreshIconStyle}
                      />
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity onPress={quotationHandler}>
                    <Text style={styles.skiptitleStyle}>{I18n.t('sales.authentication.skip_auth_label')}</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </ScrollView>
          </View>

          <View
            style={{
              flex: 1,
              justifyContent: 'flex-start',
              alignItems: 'center',
              // backgroundColor: 'red'
            }}>
            <NextButton
              onPress={nextButtonHandler}
            />

          </View>
        </View>
      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff'
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff'
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center'
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'flex-start'
  },
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  titleStyle: {
    fontSize: FontSize.extraLarge,
    fontFamily: Font.bold,
    color: Colors.border,
    textAlign: 'center',
    marginVertical: hp('2%'),
  },
  signatureContainer: {
    width: wp('90%'), //340
    height: hp('50%'),
    borderColor: Colors.border,
    borderWidth: 1,
    marginHorizontal: wp('5%'),
    marginVertical: '2%',
  },
  refreshButtonStyle: {
    alignItems: 'flex-start',
  },
  refreshIconStyle: {
    padding: wp('5%'),
  },
  skiptitleStyle: {
    fontSize: FontSize.extraLarge,
    fontFamily: Font.bold,
    color: Colors.border,
    textAlign: 'right',
    marginHorizontal: wp('5%'),
    marginTop: hp('5%'),
  },
  signature: {
    flex: 1,
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
    marginTop: hp('2%'),
  },
  buttonStyle: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    height: 50,
    backgroundColor: '#eeeeee',
    margin: 10,
  },


});

export default ManagerApprovalAuthenticationScreen;
