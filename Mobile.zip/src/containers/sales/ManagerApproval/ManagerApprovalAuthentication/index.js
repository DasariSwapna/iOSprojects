import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import ManagerApprovalAuthenticationScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';

class ManagerApprovalAuthentication extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      showOtpPaymentModal: false,
    };
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createVendorRetailAgreement);
    this.setState({
      showOtpPaymentModal: true,

    })
  }

  otpSubmitHandler = () => {
    this.setState({
      showOtpPaymentModal: false,

    })
    this.props.navigation.navigate(Sales.ManagerApprovalQuotation);
  }

  quotationHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalQuotation);
  }


  render() {
    return <ManagerApprovalAuthenticationScreen
      nextButtonHandler={this.nextButtonHandler}
      otpSubmitHandler={this.otpSubmitHandler}
      showOtpPaymentModal={this.state.showOtpPaymentModal}
      quotationHandler={this.quotationHandler} />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ManagerApprovalAuthentication);
