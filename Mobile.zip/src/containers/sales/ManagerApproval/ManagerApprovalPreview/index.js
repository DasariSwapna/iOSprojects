import React from 'react';
import {connect} from 'react-redux';
import {Share, PermissionsAndroid, Platform} from 'react-native';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import CreateVendorPreviewScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import RNFetchBlob from 'rn-fetch-blob';
import {delay} from '../../../../utils/Helpers';
import I18n from '../../../../locale/i18n';

const data1 = [
  {
    title: 'Maternity Screening',
    amount: '5000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'QFPCR',
    amount: '8000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'Hb Pathies',
    amount: '9000/-INR',
    type: 'Blood sample',
  },
  {
    title: 'Free Testosterone',
    amount: '9000/-INR',
    type: 'Urine sample',
  },
];

class CreateVendorPreview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      isValidated: false,
      tableHead: ['Test Panel', 'Amount', 'Sample Type'],
      tableData: [
        ['Maternity Screening', '5000/- INR', 'Heel Prick'],
        ['QFPCR', '8000/- INR', 'Heel Prick'],
        ['Hb Pathies', '9000/- INR', 'Blood sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
      ],
      data: data1,
      errorMsg: '',
      showToast: false,
      source: {
        uri: this.props.route.params.URL,
        cache: false,
      },
    };
  }

  actualDownloadiOS = () => {
    try {
      const {config, fs} = RNFetchBlob;
      let dirs = fs.dirs;
      let options = {
        fileCache: false,
        appendExt: 'pdf',
        path:
          dirs.DocumentDir +
          '/' +
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID +
          '.pdf',
      };
      config(options)
        .fetch('GET', this.props.route.params.URL)
        .then(res => {
          // do some magic here
          // RNFetchBlob.ios.openDocument();
          this.setState(
            {
              errorMsg: I18n.t('valitation.iOS_download_path_msg'),
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );

          //  Downloding: On My iPhone =>Lifecell
          //  toastMsg(this.state.downloadtext);
          console.log('File download', res.path());
        });
    } catch (error) {
      console.log('File download error', error);
    }
  };

  async downloadFile() {
    console.log('plato', Platform.OS);

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload();
      } else {
        alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  actualDownload = () => {
    RNFetchBlob.fs
      .mkdir(RNFetchBlob.fs.dirs.SDCardDir + '/LifeCell')

      .then(() => {
        alert('created');
      })

      .catch(err => {
        console.log(err);
      });

    RNFetchBlob.fs
      .ls(RNFetchBlob.fs.dirs.SDCardDir)

      // files will an array contains filenames

      .then(files => {
        console.log(files);
      });

    const {dirs} = RNFetchBlob.fs;

    console.log(dirs);

    RNFetchBlob.config({
      fileCache: true,

      addAndroidDownloads: {
        useDownloadManager: true,

        notification: true,

        mediaScannable: true,

        title:
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID,

        path:
          dirs.DownloadDir +
          '/' +
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID +
          '.pdf',

        //  +''+this.state.PDF_name+".pdf"`,

        // path: `${dirs.DownloadDir}/this.state.PDF_name.pdf,
      },
    })

      .fetch('GET', this.props.route.params.URL, {})

      .then(res => {
        // toastMsg(this.state.downloadtext1);

        console.log('The file saved to ', res.path());
      })

      .catch(e => {
        console.log(e);
      });
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  downloadButtonHandler = async () => {
    {
      Platform.OS == 'ios' ? this.actualDownloadiOS() : this.downloadFile();
    }
  };

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApproval);
  };

  shareButtonHandler = async () => {
    const result = await Share.share({
      message: this.state.source.uri,
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
        // shared with activity type of result.activityType
      } else {
        // shared
      }
    } else if (result.action === Share.dismissedAction) {
      // dismissed
    }
  };

  render() {
    return (
      <CreateVendorPreviewScreen
        nextButtonHandler={this.nextButtonHandler}
        shareButtonHandler={this.shareButtonHandler}
        downloadButtonHandler={this.downloadButtonHandler}
        source={this.state.source}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateVendorPreview);
