import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  TouchableOpacity,
  Share,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { HomeButton } from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import { Table, Row, Rows, TableWrapper, Cell, Col, Cols } from 'react-native-table-component';
//import Table from '../../../../components/Table';
import PageNo from '../../../../constants/PageNo';
import Pdf from 'react-native-pdf';
import IonIcons from 'react-native-vector-icons/Ionicons';
import {Toast} from '../../../../components/Toast';

function TextConatiner({
  leftText,
  rightText,
 
}) {
  return (
    <View style={{ width: '100%', flexDirection: 'row' }}>
      <Text
        style={{
          flex: 1,
          paddingLeft: 25,
          paddingVertical: 5,
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>{leftText}</Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: 5,
          color: Colors.black,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>{rightText}</Text>
    </View>
  )
}


function CreateVendorPreviewScreen({
  addressTypeHandler,
  nextButtonHandler,
  tableHead,
  tableData,
  tableTitle,
  tableColumnData,
  data,
  shareButtonHandler,
  downloadButtonHandler,
  showToast,
  errorMsg,
  source,
}) {
  return (
    <RootView pageNo={PageNo.sales_createVendorTermsCondition}>
        <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
      <View style={styles.mainContainer}>
      <View style={styles.lineLargeContainer} />
      <View
        style={{
          borderColor: Colors.primary,
          backgroundColor: Colors.background,
          marginHorizontal: wp('5%'),
          marginVertical: hp('2%'),
          marginTop : hp('5%'),
          width: '90%',
          height: '65%',
          borderWidth: Platform.OS == 'ios' ? 0.2 : 0.6,
          borderRadius: 10,
          shadowColor: Colors.primary,
          shadowOffset: {
            width: 0,
            height: 3,
          },
          shadowOpacity: 0.29,
          shadowRadius: 4.65,
        //  elevation: 7,
        }}>
        <Pdf
          source={source}
          onLoadComplete={(numberOfPages, filePath) => {
            console.log(`Number of pages: ${numberOfPages}`);
          }}
          onPageChanged={(page, numberOfPages) => {
            console.log(`Current page: ${page}`);
          }}
          onError={error => {
            console.log(error);
          }}
          onPressLink={uri => {
            console.log(`Link pressed: ${uri}`);
          }}
          style={styles.pdf}
        />
      </View>

      <View
        style={{
          alignSelf: 'flex-end',
          flexDirection: 'row',
          width: wp('10%'),
          height: 40,
          alignItems: 'center',
          justifyContent: 'space-between',
          marginRight: hp('7%'),
          marginTop: hp('1%'),
        }}>
        <TouchableOpacity onPress={downloadButtonHandler}>
          <Image
            source={Images.download1}
            style={{ width: hp('3%'), height: hp('3%'), marginRight: 8 }}
            resizeMode="cover"
          />
        </TouchableOpacity>
        <TouchableOpacity onPress={shareButtonHandler}>
          <IonIcons
            name={'share-social'}
            color={Colors.border}
            size={hp('3%')}
          />
        </TouchableOpacity>
      </View>

      <View
        style={{
        //  flex: 1,
          flexDirection: 'column',
          alignItems: 'center',
          backgroundColor: Colors.white,
          marginTop : hp('5%')
        }}>
        <View style={styles.buttonContainer}>
          <HomeButton onPress={nextButtonHandler} />
        </View>
        </View>
      </View>
     
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex : 1,
    width: '100%',
    height: '100%',
    // overflow: 'hidden',
    backgroundColor : Colors.white
  },
  pdf: {
    marginVertical: wp('1%'),
    marginHorizontal: wp('1%'),
    width: '98%',
    height: '98%',
    backgroundColor: Colors.white,
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
    backgroundColor: Colors.white,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  textStyleRegular: {
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    color: Colors.termsTextColor,
    marginTop: 30,
  },
});

export default CreateVendorPreviewScreen;
