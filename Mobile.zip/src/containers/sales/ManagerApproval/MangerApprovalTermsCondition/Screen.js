import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { NextButton } from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import PageNo from '../../../../constants/PageNo'


function ManagerApprovalTermsConditionScreen({ addressTypeHandler,
  nextButtonHandler }) {
  return (
    <RootView pageNo={PageNo.sales_createVendorTermsCondition}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff'
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>
                <View
                  style={{
                    width: '85%',
                    alignSelf: 'center'
                  }}>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                </View>
              </View>
            </ScrollView>
          </View>

          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center'
            }}>
            <View
              style={styles.buttonContainer}>
              <NextButton
                onPress={nextButtonHandler} />
            </View>
          </View>

        </View>

      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center'
  },
  buttonContainer: {
    width: '30%',

  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center'
  },
  textStyleRegular: {
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    color: Colors.termsTextColor,
    marginTop: 30
  }

});

export default ManagerApprovalTermsConditionScreen;
