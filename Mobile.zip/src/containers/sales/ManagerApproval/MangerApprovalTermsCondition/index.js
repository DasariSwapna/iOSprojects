import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import ManagerApprovalTermsConditionScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';

class ManagerApprovalTermsCondition extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalPreview);
  }

  render() {
    return <ManagerApprovalTermsConditionScreen
      nextButtonHandler={this.nextButtonHandler} />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ManagerApprovalTermsCondition);
