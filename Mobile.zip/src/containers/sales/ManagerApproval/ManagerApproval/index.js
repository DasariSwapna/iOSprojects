import React from 'react';
import {connect} from 'react-redux';
import I18n from '../../../../locale/i18n';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import ManagerApprovalScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import {
  getMangerTestApproval,
  deleteManagerApprovals,
} from '../../../../store/Actions';
import Alert from '../../../../components/Alert';
import {delay} from '../../../../utils/Helpers';
import {
  getTermsQuestionAnswer,
  insertTermsQuestionAnswer,
} from '../../../../store/Actions';

// const searchData = [
//   {id: 1, name: 'All'},
//   {id: 2, name: 'Retail to invoice'},
//   {id: 3, name: 'MOU'},
// ];

class ManagerApproval extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      selectedTab: 1,
      data: [],
      selectedSearchId: 1,
      approved: true,
      rejected: false,
      salesMangerApprovelStatus: false,
      salesMangerResponse: [],
      salesMangerRevisedResponse: [],
      errorMsg: '',
      showToast: false,
      searchData : [
        {id: 1, name: 'All'},
        {id: 2, name: 'Retail to invoice'},
        {id: 3, name: 'MOU'},
      ],
      actionValue : ''

    };
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalTermsCondition);
  };

  approveHandler = (id, type) => {
    // this.props.navigation.navigate(Sales.ManagerApprovalTermsCondition);
    const data = {
      hostpital_id: id,
      types_id: type,
      terms: [],
      name_of_signing: '',
      designation: '',
      contact_number: '',
      email_id: '',
      address: '',
      user_id: this.props.userId,
    };

    this.props.onInsertTermsQuestionAnswer(data, this.props.accessToken);
  };

  revisedHandler = (id, type) => {
    this.props.navigation.navigate(Sales.ManagerApprovalStatus, {
      vendorId: id,
      rejected: false,
      typeID: type,
    });
  };

  rejectedHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalStatus, {
      rejected: true,
    });
  };

  changeTab = id => {
    this.setState({selectedTab: id});
    this.fetchData(id);
  };



  fetchData(id) {
    if (id == '1') {
      this.setState({
        approved: true,
        rejected: false,
      });
    } else if (id == '2') {
      this.setState({
        rejected: true,
        approved: false,
      });
    }
  }

  searchClickHandler = (id) => {
   // alert(id)
    this.setState(prevState => {
      const temp = prevState.selectedSearchId == id ? id : id;
      return {
        selectedSearchId: temp,
      };
    });
  };

  nextClickHandler = id => {
    const data = {
      vendorid: id,
      userid: this.props.userId,
    };
    this.props.onDeleteTestApproval(data, this.props.accessToken);
  };

  revisedClickHandler = id => {
    const data = {
      vendorid: id,
      userid: this.props.userId,
    };
    this.props.onDeleteTestApproval(data, this.props.accessToken);
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  actionSearch = text => {
    var listSelected = '';
    if (this.state.selectedTab == '1') {
      listSelected = this.props.salesMangerApprovelResponse.All;
    } else if (this.state.selectedTab == '2') {
      listSelected = this.props.salesMangerApprovelResponse.All;
    } 
    var filterdata = listSelected;
   // alert(filterdata)
   console.log('Filter data',JSON.stringify(filterdata))

    var arraydata = filterdata.filter(function (x) {
      return (
        x.Hospital_Name.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1
      );
    });

    this.setState({
      salesMangerResponse: arraydata,
      actionValue: text,
    });
    console.log('Array data',JSON.stringify(arraydata))
  };



  navigationNextpage = () => {
    this.props.navigation.navigate(Sales.ManagerApprovalPreview, {
      URL: this.props.insertQuestionAnswerResponse.Message,
      Hospitalname: this.props.insertQuestionAnswerResponse.LC_VD_HOSPITALNAME,
      vendorID: this.props.insertQuestionAnswerResponse.LC_VD_VENID,
    });
  };

  componentDidMount() {
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      const data = {
        statusid: 1,
        userid: this.props.userId,
      };
      this.props.onGetMangerTestApproval(data, this.props.accessToken);
      const data1 = {
        statusid: 4,
        userid: this.props.userId,
      };
      this.props.onGetMangerTestApproval(data1, this.props.accessToken);
    });
  }
  componentDidUpdate = prevProps => {
    if (
      prevProps.salesMangerApprovelStatus == false &&
      this.props.salesMangerApprovelStatus !=
        prevProps.salesMangerApprovelStatus
    ) {
    }

    if (
      prevProps.deleteapprovalDetailsStatus == false &&
      this.props.deleteapprovalDetailsStatus !=
        prevProps.deleteapprovalDetailsStatus
    ) {
      this.setState(
        {
          errorMsg: this.props.deleteapprovalDetailsmessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );

      const data = {
        statusid: 1,
        userid: this.props.userId,
      };
      this.props.onGetMangerTestApproval(data, this.props.accessToken);
      const data1 = {
        statusid: 4,
        userid: this.props.userId,
      };
      this.props.onGetMangerTestApproval(data1, this.props.accessToken);

      this.setState({
        approved: true,
        rejected: false,
      });
    }
    if (
      prevProps.insertQuestionAnswerStatus == false &&
      this.props.insertQuestionAnswerStatus !=
        prevProps.insertQuestionAnswerStatus
    ) {
      if (this.props.insertQuestionAnswerResponse == '') {
        this.setState(
          {
            errorMsg: I18n.t('valitation.PDF_not_available'),
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
      } else {
        this.navigationNextpage();
      }
    }
  };

  componentWillUnmount() {
    this._unsubscribe();
  }

  render() {
    console.log('sales res', this.props.salesMangerApprovelResponse);
    return (
      <ManagerApprovalScreen
        nextButtonHandler={this.nextButtonHandler}
        changeTab={this.changeTab}
        selectedTab={this.state.selectedTab}
        searchClickHandler={this.searchClickHandler}
        selectedSearchId={this.state.selectedSearchId}
        approveHandler={this.approveHandler}
        rejectedHandler={this.rejectedHandler}
        revisedHandler={this.revisedHandler}
        // states
        data={this.state.data}
        approved={this.state.approved}
        rejected={this.state.rejected}
        searchData={this.state.searchData}
        salesMangerApprovelStatus={this.props.salesMangerApprovelStatus}
        salesMangerResponse={this.props.salesMangerApprovelResponse}
        salesMangerRevisedResponse={this.props.salesMangerRevisedResponse}
        loading={this.props.loading || this.props.deleteapprovalDetailsLoading}
        nextClickHandler={this.nextClickHandler}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        revisedClickHandler={this.revisedClickHandler}
        actionSearch={this.actionSearch}
        actionValue={this.state.actionValue}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    userId: state.signIn.userId,
    loading: state.SalesMangerTestApprovalReducer.salesMangerApprovelLoading,
    accessToken: state.signIn.accessToken,
    salesMangerApprovelStatus:
      state.SalesMangerTestApprovalReducer.salesMangerApprovelStatus,
    salesMangerApprovelError:
      state.SalesMangerTestApprovalReducer.salesMangerApprovelError,
    salesMangerApprovelResponse:
      state.SalesMangerTestApprovalReducer.salesMangerApprovelResponse,
    salesMangerRevisedResponse:
      state.SalesMangerTestApprovalReducer.salesMangerRevisedResponse,
    deleteapprovalDetailsLoading:
      state.SalesMangerTestApprovalReducer.deleteapprovaldatasLoading,
    deleteapprovalDetailsStatus:
      state.SalesMangerTestApprovalReducer.deleteapprovaldatasStatus,
    deleteapprovalDetailsError:
      state.SalesMangerTestApprovalReducer.deleteapprovaldatasError,
    deleteapprovalDetailsmessage:
      state.SalesMangerTestApprovalReducer.deletemessage,

   /*    salesMangerApprovelResponseAll:
      state.SalesMangerTestApprovalReducer.response1,
      salesMangerApprovelResponseRetailtoinvoice:
      state.SalesMangerTestApprovalReducer.response2,
      salesMangerApprovelResponseMOUT:
      state.SalesMangerTestApprovalReducer.response3, */

    insertQuestionAnswerLoading: state.createVendor.insertQuestionAnswerLoading,
    insertQuestionAnswerStatus: state.createVendor.insertQuestionAnswerStatus,
    insertQuestionAnswerError: state.createVendor.insertQuestionAnswerError,
    insertQuestionAnswerResponse:
      state.createVendor.insertQuestionAnswerResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetMangerTestApproval: (data, token) =>
      dispatch(getMangerTestApproval(data, token)),
    onDeleteTestApproval: (data, token) =>
      dispatch(deleteManagerApprovals(data, token)),
    onInsertTermsQuestionAnswer: (data, token) =>
      dispatch(insertTermsQuestionAnswer(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ManagerApproval);
