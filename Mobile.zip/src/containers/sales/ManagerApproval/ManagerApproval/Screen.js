import React, {useRef, useState} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import Ionicons from 'react-native-vector-icons/Ionicons';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import {TanTwoContainer} from '../../../../components/TabContainer';
import SearchButtonView from '../../../../components/SearchButtonView';
import SearchBar from '../../../../components/SearchBar';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import PropTypes from 'prop-types';
import Alert from '../../../../components/Alert';
import {Toast} from '../../../../components/Toast';

function Approved({
  nextButtonHandler,
  nextClickHandler,
  rejected,
  approveText,
  data,
}) {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.cardHeaderConatiner}>
        <View style={styles.cardHeaderDirection}>
          <Text style={styles.cardHeaderText}>Quote ID</Text>
          <Text style={styles.cardHeaderIdText}>{data.QUOTATION_ID}</Text>
        </View>
        <TouchableOpacity
          onPress={() =>
            nextClickHandler(data.VENDOR_ID, data.LC_VD_ACCOUNT_TYPE_ID)
          }>
          <View>
            <Icon name="trash" size={wp('5%')} color={Colors.darkPink} />
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.cardHeaderUnderline}></View>

      <View style={styles.cardSubHeaderContainer}>
        <Text style={styles.hospitalText}>Hospital</Text>
        <Text
          style={[
            styles.statusText,
            {
              color:
                data.Approved_Status == 'Pending'
                  ? Colors.darkPink
                  : data.Approved_Status == 'Revised'
                  ? Colors.darkPink
                  : Colors.darkGreen,
            },
          ]}>
          {data.Approved_Status}
        </Text>
      </View>

      <View style={styles.cardFootercontainerOverall}>
        <Text style={styles.doctorNameText}>{data.Hospital_Name}</Text>
      </View>

      <View style={styles.cardFooterContainer}>
        <View style={styles.cardFooterDirection}>
          <Text style={styles.totalText}>Total test</Text>
          <Text style={styles.totalTextNumber}>{data.Tests}</Text>
        </View>
        <Button
          title="Continue quotation"
          buttonStyle={styles.buttonWithoutBorder}
          buttonTextStyle={styles.buttonStyleWhite}
          onPress={nextButtonHandler}
        />
      </View>
    </View>
  );
}

function Revised({
  nextButtonHandler,
  revisedClickHandler,
  rejected,
  approveText,
  data,
}) {
  return (
    <View style={styles.cardContainer}>
      <View style={styles.cardHeaderConatiner}>
        <View style={styles.cardHeaderDirection}>
          <Text style={styles.cardHeaderText}>Quote ID</Text>
          <Text style={styles.cardHeaderIdText}>{data.QUOTATION_ID}</Text>
        </View>
        <TouchableOpacity
          onPress={() =>
            revisedClickHandler(data.VENDOR_ID, data.LC_VD_ACCOUNT_TYPE_ID)
          }>
          <View>
            <Icon name="trash" size={wp('5%')} color={Colors.darkPink} />
          </View>
        </TouchableOpacity>
      </View>
      <View style={styles.cardHeaderUnderline}></View>

      <View style={styles.cardSubHeaderContainer}>
        <Text style={styles.hospitalText}>Hospital</Text>
        <Text
          style={[
            styles.statusText,
            {
              color:
                data.Approved_Status == 'Pending'
                  ? Colors.darkPink
                  : data.Approved_Status == 'Revised'
                  ? Colors.darkPink
                  : Colors.darkGreen,
            },
          ]}>
          {data.Approved_Status}
        </Text>
      </View>

      <View style={styles.cardFootercontainerOverall}>
        <Text style={styles.doctorNameText}>{data.Hospital_Name}</Text>
      </View>

      <View style={styles.cardFooterContainer}>
        <View style={styles.cardFooterDirection}>
          <Text style={styles.totalText}>Total test</Text>
          <Text style={styles.totalTextNumber}>{data.Tests}</Text>
        </View>
        <Button
          title="Continue quotation"
          buttonStyle={styles.buttonWithoutBorder}
          buttonTextStyle={styles.buttonStyleWhite}
          onPress={nextButtonHandler}
        />
      </View>
    </View>
  );
}
const renderNodata = () => {
  return (
    <>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: hp('30%'),
        }}>
        <Text style={{fontFamily: FontMagneta.bold, fontSize: FontSize.large}}>
          No data found
        </Text>
      </View>
        
    </>
  );
};

function ManagerApprovalScreen({
  addressTypeHandler,
  nextButtonHandler,
  approveHandler,
  rejectedHandler,
  revisedHandler,
  changeTab,
  selectedTab,
  searchData,
  selectedSearchId,
  searchClickHandler,
  nextClickHandler,
  approved,
  rejected,
  salesMangerApprovelStatus,
  salesMangerResponse,
  salesMangerRevisedResponse,
  loading,
  alertHandler,
  showToast,
  errorMsg,
  revisedClickHandler,
  actionSearch,
  actionValue,
}) {
  const renderSearchItem = ({item}) => (
    <SearchButtonView
      title={item.name}
      onPress={() => searchClickHandler(item.id)}
      isActive={selectedSearchId == item.id}
    />
  );

  const [alertToggle, setAlertToggle] = useState(false);

 /* alertActionHandler = val => {
    setAlertToggle(false);
    if (val == true) alertHandler();
  }; */

  return (
    <RootView pageNo={PageNo.sales_managerApproval} loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView style={{flex: 1}}>
        <View style={styles.mainContainer}>
          <TanTwoContainer
            approvedText={I18n.t('sales.managerApproval.approved_label')}
            rejectedText={I18n.t('sales.managerApproval.revised_label')}
            selectedTab={selectedTab}
            changeTab={changeTab}
          />
          <View style={styles.topSearchContainer}>
            <FlatList
              contentContainerStyle={styles.topcontentContainerStyle}
              columnWrapperStyle={{justifyContent: 'space-between'}}
              data={searchData}
              extraData={searchData}
              keyExtractor={item => item.id}
              numColumns={3}
              renderItem={renderSearchItem}
            />
          </View>
          <View style={{width: '80%', alignSelf: 'center', height: hp('6%')}}>
          <SearchBar onChangehandler={actionSearch} value={actionValue} />
          </View>

          {approved && salesMangerResponse ? (
            <FlatList
            contentContainerStyle={styles.flatListInnerContainer}
              data={
                selectedSearchId == 1
                  ? salesMangerResponse.All
                  : selectedSearchId == 2
                  ? salesMangerResponse.RetailtoInvoice
                  : salesMangerResponse.MOU
              }
              keyExtractor={item => item.VENDOR_ID}
              extraData={salesMangerResponse}
              renderItem={({item}) => (
                <Approved
                  nextButtonHandler={() =>
                    approveHandler(item.VENDOR_ID, item.LC_VD_ACCOUNT_TYPE_ID)
                  }
                  rejected={rejected}
                  approveText={'Approved'}
                  data={item}
                  nextClickHandler={nextClickHandler}
                />
              )}
            />
          ) : null}
          {rejected && salesMangerRevisedResponse ? (
            <FlatList
            contentContainerStyle={styles.flatListInnerContainer}
              data={
                selectedSearchId == 1
                  ? salesMangerRevisedResponse.All
                  : selectedSearchId == 2
                  ? salesMangerRevisedResponse.RetailtoInvoice
                  : salesMangerRevisedResponse.MOU
              }
              keyExtractor={item => item.VENDOR_ID}
              extraData={salesMangerRevisedResponse}
              renderItem={({item}) => (
                <Revised
                  nextButtonHandler={() =>
                    revisedHandler(item.VENDOR_ID, item.LC_VD_ACCOUNT_TYPE_ID)
                  }
                  rejected={rejected}
                  approveText={'Revised'}
                  data={item}
                  revisedClickHandler={revisedClickHandler}
                />
              )}
            />
          ) : null}
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: hp('100%'),
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
  },
  flatList: {flex: 1,
    //   paddingBottom : hp('5%')
    
     },
  topcontentContainerStyle: {
    padding: 2,
    width: '90%',
    alignSelf: 'center',
    marginVertical: 10,
   flexGrow: 1,
 // paddingBottom: hp('20%'),
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: hp('20%'),
  },

  searchOuterContainer: {
    width: '90%',
    alignSelf: 'center',
    marginBottom: 20,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  /////////Serach Section
  searchSection: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
    alignSelf: 'center',
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  buttonWithoutBorder: {
    minWidth: wp('16%'),
    paddingHorizontal: hp('1.5%'),
    marginHorizontal: wp('-1.5%'),
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
    alignSelf: 'center',
    marginBottom: 5,
  },
  buttonStyleWhite: {
    fontSize: FontSize.regular,
  },
  topSearchContainer: {
    width: wp('100%'),
    alignItems: 'center',
    justifyContent: 'space-between',
    overflow: 'scroll',
  },
  cardContainer: {
    width: wp('90%'),
    backgroundColor: '#fff',
    borderWidth: Platform.OS == 'ios' ? 0.3 : 0.7,
    borderColor: Colors.border,
    borderRadius: Platform.OS == 'ios' ? 15 : 12,
    marginTop: wp('5%'),
    alignSelf: 'center',
    //elevation: 5,
  },
  cardHeaderConatiner: {
    flexDirection: 'row',
    paddingHorizontal: wp('7%'),
    paddingVertical: hp('1%'),
    justifyContent: 'space-between',
  },
  cardHeaderDirection: {
    flexDirection: 'row',
  },
  cardHeaderText: {
    fontFamily: Font.bold,
    color: Colors.border,
    fontSize: FontSize.medium,
    alignSelf: 'center',
  },
  cardHeaderIdText: {
    fontFamily: Font.regular,
    color: Colors.black,
    fontSize: FontSize.medium,
    alignSelf: 'center',
    marginLeft: 10,
  },
  cardHeaderUnderline: {
    width: '100%',
    height: hp('0.1%'),
    backgroundColor: Colors.border,
  },
  cardSubHeaderContainer: {
    flexDirection: 'row',
    paddingHorizontal: wp('7%'),
    paddingVertical: hp('1%'),
    justifyContent: 'space-between',
    marginTop: 5,
  },
  hospitalText: {
    fontFamily: Font.regular,
    color: Colors.border,
    fontSize: FontSize.medium,
    alignSelf: 'center',
  },
  statusText: {
    fontFamily: Font.regular,
    color: Colors.darkGreen,
    fontSize: FontSize.regular,
    alignSelf: 'center',
  },
  cardFootercontainerOverall: {
    flexDirection: 'row',
    paddingHorizontal: wp('7%'),

    justifyContent: 'space-between',
  },
  doctorNameText: {
    fontFamily: Font.regular,
    color: Colors.black,
    fontSize: FontSize.medium,
    alignSelf: 'center',
  },

  cardFooterContainer: {
    flexDirection: 'row',
    paddingHorizontal: wp('7%'),
    justifyContent: 'space-between',
    paddingBottom: hp('1%'),
  },
  cardFooterDirection: {
    flexDirection: 'row',
  },
  totalText: {
    fontFamily: Font.bold,
    color: Colors.black,
    fontSize: FontSize.regular,
    alignSelf: 'center',
  },
  totalTextNumber: {
    fontFamily: FontMagneta.thin,
    color: Colors.black,
    fontSize: FontSize.regular,
    alignSelf: 'center',
    marginLeft: wp('2%'),
  },
});

export default ManagerApprovalScreen;
