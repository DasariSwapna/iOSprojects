// import React from "react";
// import { connect } from "react-redux";
// import I18n from "i18next";
// import PropTypes from "prop-types";
// import ReceiveCashScreen from "./Screen";
// import { Paramedic, Sales } from "../../../navigations/RouteTypes";
// import Modal from "../../../components/ModalCalendar";
// import { floor } from "react-native-reanimated";
// class Shuttle extends React.Component {
//   static propTypes = {
//     // ...prop type definitions here
//   };

//   constructor(props) {
//     super(props);
//     this.state = {
//       modalVisible: false,
//       showSuccessModal: false
//     };
//   }

//   componentDidMount = () => {};

//   componentDidUpdate = () => {};

//   nextButton = () => {
//     this.setState({ modalVisible: true });
//   };
//   SuccessModal = () => {
//     this.setState({ showSuccessModal: true });
//     setTimeout(() => {
//       this.setState({ showSuccessModal: false });
//       this.props.navigation.navigate(Sales.cashCollect_deposit);
//     }, 2000);
//   };
//   render() {
//     return (
//       <ReceiveCashScreen
//         nextButton={this.nextButton}
//         modalVisible={this.state.modalVisible}
//         showSuccessModal={this.state.showSuccessModal}
//         SuccessModal={this.SuccessModal}
//       />
//     );
//   }
// }

// const mapStateToProps = state => {
//   return {};
// };

// const mapDispatchToProps = dispatch => {
//   return {};
// };

// export default connect(mapStateToProps, mapDispatchToProps)(Shuttle);
import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import ShuttleScreen from './Screen';
import {Paramedic, Sales} from '../../../navigations/RouteTypes';
import Modal from '../../../components/ModalCalendar';
import {floor} from 'react-native-reanimated';
import {
  // updateShuttlePickup,
  // getKitsampleHandoverBiodataSelectList,
  getCashFromParamedic,
  updateCashFromParamedic,
} from '../../../store/Actions';
import {} from '../../../store/Actions';
import {data} from 'browserslist';
class Shuttle extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      showSuccessModal: false,
    };
  }

  componentDidMount = () => {
    const data = {
      // userid: this.props.userId,
      paramedicid: this.props.route.params.userId,
      orderids: this.props.route.params.shuttledata,
      // userid: 81
      // paramedicid: 7,
      // orderids: [{id: 2}, {id: 10}],
    };
    this.props.GetSelectList(data, this.props.accessToken);
  };

  componentDidUpdate = prevProps => {
    if (
     
      prevProps.updateCashDetailStatus == false &&
      this.props.updateCashDetailStatus != prevProps.updateCashDetailStatus
    ) {
      try {
        this.setState({showSuccessModal: true});
        this.setState({modalVisible: false});
        setTimeout(() => {
          this.setState({showSuccessModal: false});
          this.props.navigation.navigate(Sales.home);
        }, 2000);
      } catch (error) {}
    }
  };

  // nextButton = () => {
  //   this.setState({modalVisible: true});
  // };
  SuccessModal = () => {
    const data = {
      userid: this.props.userId,
      fromuserid: this.props.route.params.userId,
      orderdetails: this.props.route.params.shuttledata,
    };

    this.props.shuttlepickup(data, this.props.accessToken);
    // this.setState({showSuccessModal: true});
    // this.setState({modalVisible: false});
    // setTimeout(() => {
    //   this.setState({showSuccessModal: false});
    //   this.props.navigation.navigate(Paramedic.home);
    // }, 2000);
  };
  cancelButton = () => {
    this.setState({modalVisible: false});
  };
  render() {
    console.log('response--->', this.props.getCashDetailResponse);
    return (
      <ShuttleScreen
        nextButton={this.nextButton}
        modalVisible={this.state.modalVisible}
        showSuccessModal={this.state.showSuccessModal}
        SuccessModal={this.SuccessModal}
        cancelButton={this.cancelButton}
        response={this.props.getCashDetailResponse}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    // message: state.kitsampleHandoverBiodata.message,
    // accessToken: state.signIn.accessToken,
    // shuttleUpdateLoading: state.shuttledetailupdate.shuttleUpdateLoading,
    // shuttleUpdateStatus: state.shuttledetailupdate.shuttleUpdateStatus,
    // shuttleUpdateError: state.shuttledetailupdate.shuttleUpdateError,
    // response: state.kitsampleselectlist.response,
    message: state.CashDebositSalesReducer.message,
    accessToken: state.signIn.accessToken,
    getCashDetailLoading: state.CashDebositSalesReducer.getCashDetailLoading,
    getCashDetailStatus: state.CashDebositSalesReducer.getCashDetailStatus,
    getCashDetailError: state.CashDebositSalesReducer.getCashDetailError,
    getCashDetailResponse: state.CashDebositSalesReducer.getCashDetailResponse,

    updateCashDetailLoading:
      state.CashDebositSalesReducer.updateCashDetailLoading,
    updateCashDetailStatus:
      state.CashDebositSalesReducer.updateCashDetailStatus,
    updateCashDetailError: state.CashDebositSalesReducer.updateCashDetailError,
    updateCashDetailResponse:
      state.CashDebositSalesReducer.updateCashDetailResponse,
    userId: state.signIn.userId,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    shuttlepickup: (data, token) =>
      dispatch(updateCashFromParamedic(data, token)),
    GetSelectList: (data, token) => dispatch(getCashFromParamedic(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Shuttle);
