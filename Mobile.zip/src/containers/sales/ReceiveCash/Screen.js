// import { placeholder } from "@babel/types";
// import React, { useRef } from "react";
// import {
//   ImageBackground,
//   Image,
//   Text,
//   TextInput,
//   View,
//   StyleSheet,
//   ScrollView,
//   Platform,
//   KeyboardAvoidingView,
//   TouchableOpacity,
//   FlatList
// } from "react-native";
// import PropTypes from "prop-types";
// import I18n from "../../../locale/i18n";
// import Button from "../../../components/Button";
// import RootView from "../../../components/RootView";
// import Colors from "../../../config/Colors";
// import { Font, FontSize, FontMagneta } from "../../../config/Fonts";
// import Images from "../../../constants/Images";
// import InnerHeader from "../../../components/InnerHeader";
// import DropDown from "../../../components/DropDown";
// import CheckCircle from "../../../components/CheckCircle";
// import { ModalConfirmNumber, ModalSuccess } from "../../../components/OtpModal";
// function Footer() {
//   return (
//     <View style={styles.footerContainer}>
//       <View>
//         <Text style={styles.poweredby}>Powered by</Text>
//       </View>
//       <View style={styles.footerLogoContainer}>
//         <View style={{ width: "48%", alignItems: "flex-end" }}>
//           <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
//         </View>
//         <View style={styles.seperator} />
//         <View style={{ width: "48%", alignItems: "flex-start" }}>
//           <Image source={Images.voilaLogo} style={styles.voilaLogo} />
//         </View>
//       </View>
//     </View>
//   );
// }

// Footer.prototype = {};
// function renderItem({ item }) {
//   return (
//     <View key={item.key} style={styles.cardContainer}>
//       <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
//         <View
//           style={{
//             flexDirection: "row",
//             flex: 1,
//             justifyContent: "space-between"
//           }}
//         >
//           <Text style={styles.cardTitle}>
//             {item.title}
//           </Text>
//           <CheckCircle length={20} />
//         </View>
//         <View
//           style={{
//             borderBottomColor: "#dcdcdc",
//             borderBottomWidth: 0.6,
//             marginVertical: 5
//           }}
//         />
//         <View style={{ flexDirection: "row" }}>
//           <View style={{ flex: 1 }}>
//             <Text style={styles.cardText}>CRM ID :</Text>
//             <Text style={styles.numberTxt}>
//               {item.crmID}
//             </Text>
//           </View>
//           <View style={{ flex: 1 }}>
//             <Text style={styles.cardText}>Amount :</Text>
//             <Text style={styles.numberTxt}>
//               {item.amount}
//             </Text>
//           </View>
//         </View>
//       </View>
//     </View>
//   );
// }
// function ReceiveCashScreen({
//   nextButton,
//   modalVisible,
//   showSuccessModal,
//   SuccessModal
// }) {
//   return (
//     <RootView pageNo={"02"}>
//       <KeyboardAvoidingView style={styles.container}>
//         <FlatList
//           data={[
//             {
//               id: "1",
//               title: "SRM Hospital",
//               crmID: "12345",
//               amount: "1555.00",
//               crmcount: "1",
//               date: "15.11.2021",
//               time: "12:55",
//               person: "RE/BDO: Ramesh kumar"
//             },
//             {
//               id: "2",
//               title: "Dr.Varma Hospital",
//               crmID: "56789",
//               amount: "1200.00",
//               crmcount: "1",
//               date: "15.11.2021",
//               time: "12:55",
//               person: "RE/BDO: Ramesh kumar"
//             },
//             {
//               id: "3",
//               title: "PK Hospital",
//               crmID: "24680",
//               amount: "3488.00",
//               crmcount: "1",
//               date: "15.11.2021",
//               time: "12:55",
//               person: "RE/BDO: Ramesh kumar"
//             }
//           ]}
//           renderItem={renderItem}
//           keyExtractor={item => item.id}
//         />
//         <TouchableOpacity style={styles.nextButton} onPress={SuccessModal}>
//           <Text style={styles.btnText}>Next</Text>
//         </TouchableOpacity>
//         <ModalSuccess
//           visible={showSuccessModal}
//           title={"Success"}
//           message={"Cash Received confirm from paramedic"}
//           pageNumber={"209"}
//         />
//       </KeyboardAvoidingView>
//     </RootView>
//   );
// }

// ReceiveCashScreen.prototype = {
//   nextButton: PropTypes.func
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: Colors.white,
//     width: "100%"
//   },
//   btnText: {
//     fontFamily: Font.regular,
//     color: Colors.white,
//     fontSize: FontSize.large
//   },
//   txt: {
//     alignSelf: "center",
//     color: Colors.border,
//     fontFamily: Font.regular,
//     fontSize: FontSize.medium
//   },
//   containerView: {
//     flex: 1,
//     justifyContent: "center"
//   },
//   cardText: {
//     fontSize: FontSize.medium,
//     fontFamily: Font.regular,
//     color: Colors.border,
//     paddingVertical: 5
//   },

//   amountText: {
//     color: Colors.black
//   },
//   nextButton: {
//     backgroundColor: Colors.darkPink,
//     width: "40%",
//     height: "8%",
//     alignSelf: "center",
//     position: "absolute",
//     bottom: 15,
//     borderRadius: 40,
//     alignItems: "center",
//     justifyContent: "center"
//   },
//   cardContainer: {
//     borderRadius: 10,
//     marginHorizontal: 20,
//     marginTop: 20,
//     minHeight: 120,
//     justifyContent: "center",
//     backgroundColor: Colors.background,
//     shadowColor: Colors.black,
//     shadowOffset: { width: 1, height: 1 },
//     shadowOpacity: 0.4,
//     shadowRadius: 3,
//     elevation: 5,
//     width: "85%",
//     alignSelf: "center",
//     marginBottom: "2%"
//   },
//   cardTitle: {
//     fontSize: FontSize.medium,
//     fontFamily: Font.extraBold,
//     color: Colors.border,
//     paddingVertical: 5
//   },
//   numberTxt: { fontFamily: FontMagneta.medium, color: Colors.black }
// });

// export default ReceiveCashScreen;
import { placeholder } from '@babel/types';
import React, { useRef } from 'react';
import {
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import Button from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import InnerHeader from '../../../components/InnerHeader';
import DropDown from '../../../components/DropDown';
import CheckCircle from '../../../components/CheckCircle';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import PageNo from '../../../constants/PageNo';
import AppButton from '../../../components/Button';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';

function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};
function renderItem({ item }) {
  return (
    <View key={item.key} style={styles.cardContainer}>
      <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
          }}>
          <Text style={styles.cardTitle}>{item.LC_VD_HOSPITALNAME}</Text>
          <CheckCircle
            length={20}
            selceted={true}
            onPress={() => {
              console.log('No Action');
            }}
          />
        </View>
        <View
          style={{
            borderBottomColor: '#dcdcdc',
            borderBottomWidth: 0.6,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row' }}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.LC_PYD_CRMID}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardText}>Amount :</Text>
            <Text style={styles.numberTxt}>{item.LC_PYD_AMOUNT}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function ReceiveCashScreen({
  nextButton,
  modalVisible,
  showSuccessModal,
  SuccessModal,
  cancelButton,
  response,
}) {
  return (
    <RootView pageNo={PageNo.paramedic_shuttle}>
      <KeyboardAvoidingView style={styles.container}>
        {response && (
          <FlatList
            data={response}
            renderItem={renderItem}
            keyExtractor={item => item.id}
          />
        )}
        {/* <TouchableOpacity style={styles.nextButton} onPress={SuccessModal}>
          <Text style={styles.btnText}>Next</Text>
        </TouchableOpacity> */}
        <AppButton
          title={'Next'}
          buttonStyle={styles.reachedButton}
          onPress={SuccessModal} />
        {/* <ModalConfirmNumber
          visible={modalVisible}
          title={I18n.t('paramedic.shuttle.shuttle_pickup')}
          message={I18n.t('paramedic.shuttle.shuttle_pickuped')}
          okayHandler={SuccessModal}
          cancelHandler={cancelButton}
        /> */}
        <ModalSuccess
          visible={showSuccessModal}
          title={'Success'}
          message={"Cash received from paramedic"}
          pageNumber={'209'}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

ReceiveCashScreen.prototype = {
  nextButton: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    width: '100%',
  },
  btnText: {
    fontFamily: Font.regular,
    color: Colors.white,
    fontSize: FontSize.large,
  },
  txt: {
    alignSelf: 'center',
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  containerView: {
    flex: 1,
    justifyContent: 'center',
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingVertical: 5,
  },

  amountText: {
    color: Colors.black,
  },
  nextButton: {
    backgroundColor: Colors.darkPink,
    width: '40%',
    height: '8%',
    alignSelf: 'center',
    position: 'absolute',
    bottom: 15,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardContainer: {
    borderRadius: 10,
    marginHorizontal: 20,
    marginTop: 20,
    minHeight: 120,
    justifyContent: 'center',
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: '85%',
    alignSelf: 'center',
    marginBottom: '2%',
  },
  cardTitle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: 5,
  },
  numberTxt: { fontFamily: FontMagneta.medium, color: Colors.black },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.darkPink,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('1%'),
    position: 'absolute',
    borderRadius: 40,
  },
});

export default ReceiveCashScreen;
