import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../utils/Validators';
import HomeScreen from './Screen';
import { Paramedic, Sales } from '../../../navigations/RouteTypes';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  createHandler = () => {
    this.props.navigation.navigate(Sales.Create);
  }

  createOrderHandler = () => {
    this.props.navigation.navigate(Sales.createOrderBasicDetails);
  }
  cashCollectNavHandler = () => {
    this.props.navigation.navigate(Sales.cashCollect_deposit);
  }
  createVendorNavHandler = () => {
    this.props.navigation.navigate(Sales.createVendorBasicDetails);
  }

  managerApprovalHandler = () => {
    this.props.navigation.navigate(Sales.ManagerApproval);
  }

  UploadCopyHandler = () => {
    this.props.navigation.navigate(Sales.UploadCopy);
  }
  
  render() {
    return <HomeScreen
      createOrderHandler={this.createOrderHandler}
      cashCollectNavHandler={this.cashCollectNavHandler}
      createVendorNavHandler={this.createVendorNavHandler}
      managerApprovalHandler={this.managerApprovalHandler}
      UploadCopyHandler={this.UploadCopyHandler}
      createHandler={this.createHandler}

    />;
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
