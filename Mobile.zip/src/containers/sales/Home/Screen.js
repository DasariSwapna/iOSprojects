import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import MaComIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import Icons from '../../../constants/Icons';
import TaskType from '../../../components/TaskType';
import BottomNav from '../../../components/BottomNav';
import CashCollect_Deposit from '../CashCollect_Deposit';

const {width, height} = Dimensions.get('screen');
const boardHeight = height * 0.2;

function MenuIcon({label, iconName, onPressHandler}) {
  return (
    <View>
      <TouchableOpacity
        style={styles.iconContainer}
        onPress={() => onPressHandler()}>
        {iconName == 'tasks' ? (
          <FaIcons name={iconName} color={Colors.primary} size={22} />
        ) : (
          <MaComIcons name={iconName} color={Colors.primary} size={28} />
        )}
        <Text>{label}</Text>
      </TouchableOpacity>
    </View>
  );
}

MenuIcon.prototype = {
  label: PropTypes.string,
  iconName: PropTypes.string,
  onPressHandler: PropTypes.func,
};

function BoardItem({title, value}) {
  return (
    <View style={{flexDirection: 'row', alignItems: 'center'}}>
      <View style={{width: '80%', justifyContent: 'center', paddingLeft: 5}}>
        <Text
          style={{
            color: Colors.text,
            fontFamily: Font.extraBold,
            fontSize: FontSize.medium,
          }}>
          {title}
        </Text>
      </View>
      <View
        style={{
          width: '20%',
          alignItems: 'flex-end',
          justifyContent: 'center',
          paddingRight: 2,
          paddingBottom: 6,
        }}>
        <Text
          style={{fontFamily: FontMagneta.semiBold, fontSize: FontSize.medium}}>
          {value}
        </Text>
      </View>
    </View>
  );
}

function Board({}) {
  return (
    <View
      style={{
        width: '76%',
        height: boardHeight,
        minWidth: 320,
        alignSelf: 'center',
        justifyContent: 'space-between',
        marginTop: boardHeight / 8,
        paddingHorizontal: boardHeight / 12,
        paddingVertical: boardHeight / 10,
        borderRadius: 20,
        backgroundColor: Colors.background,
      }}>
      <BoardItem title={'Order Value (MTD)'} value={20000} />
      <View
        style={{width: '100%', height: 1, backgroundColor: Colors.bgDarkGray}}
      />
      <BoardItem title={'Order count (MTD)'} value={26} />
      <View
        style={{width: '100%', height: 1, backgroundColor: Colors.bgDarkGray}}
      />
      <BoardItem title={'New MOU Conversions (MTD)'} value={12} />
    </View>
  );
}

function HomeScreen({
  homeNavHandler,
  alertNavHandler,
  createTaskNavHandler,
  myTaskNavHandler,
  calendarNavHandler,
  createOrderHandler,
  cashCollectNavHandler,
  createVendorNavHandler,
  managerApprovalHandler,
  UploadCopyHandler,
  createHandler,
}) {
  return (
    <RootView pageNo={'5'} isPageWhite>
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View
              style={{
                width: '100%',
                height: boardHeight / 1.2,
                borderBottomLeftRadius: 15,
                borderBottomRightRadius: 15,
                backgroundColor: Colors.card,
              }}>
              <View>
                <Board />
              </View>
            </View>
            <View
              style={{
                alignItems: 'center',
                justifyContent: 'center',
                paddingTop: boardHeight / 2.6,
                paddingBottom: boardHeight / 4,
              }}>
              {/* <TaskType
                imageSource={Icons.createOrder}
                color={Colors.teal}
                label={'Create order'}
                onPress={createOrderHandler}
              /> */}
              <TaskType
                imageSource={Icons.manageOrder}
                color={Colors.border}
                label={'Manage order'}
              />
              {/* <TaskType
                imageSource={Icons.createVendor}
                color={Colors.lightGreen}
                label={'Create vendor'}
                onPress={createVendorNavHandler}
              /> */}
              <TaskType
                imageSource={Icons.manageVendor}
                color={Colors.button}
                label={'Manage vendor'}
              />
              <TaskType
                imageSource={Icons.manageApproval}
                color={Colors.darkBlue}
                label={'Manager approval'}
                onPress={managerApprovalHandler}
              />

              {/* <TaskType
                imageSource={Icons.plansAndTest}
                color={Colors.teal}
                label={'Plan and test catalog with price'}
              /> */}
              <TaskType
                imageSource={Icons.cash}
                color={Colors.darkBlue}
                label={'Cash collection / deposit'}
                onPress={cashCollectNavHandler}
              />
              {/* <TaskType
                imageSource={Icons.invoice}
                color={Colors.border}
                label={'Invoice payment'}
              /> */}
              <TaskType
                imageSource={Icons.upload}
                color={Colors.greenBlue}
                label={'Upload signed copy '}
                onPress={UploadCopyHandler}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <View style={styles.bottomContainer}>
        <BottomNav
          isSales={true}
          menu1Handler={homeNavHandler}
          menu2Handler={alertNavHandler}
          centerMenuHandler={createHandler}
          menu3Handler={myTaskNavHandler}
          menu4Handler={calendarNavHandler}
        />
      </View>
    </RootView>
  );
}

HomeScreen.prototype = {
  homeNavHandler: PropTypes.func,
  alertNavHandler: PropTypes.func,
  createTaskNavHandler: PropTypes.func,
  myTaskNavHandler: PropTypes.func,
  calendarNavHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    flex: 1,
    width: '100%',
    paddingBottom: 62,
    backgroundColor: Colors.bgLightGray,
  },
  bottomContainer: {
    // flex: 1,
    alignItems: 'center',
  },
  bottomNavContainer: {
    flex: 1,
    position: 'absolute',
    bottom: 0,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
    backgroundColor: Colors.background,
    borderTopWidth: 1,
    borderTopColor: Colors.card,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 2,
  },
  centerMenuIcon: {
    position: 'absolute',
    top: -66,
    left: -6,
    width: 72,
    height: 72,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 36,
    backgroundColor: Colors.primary,
  },
  bottomContainer: {
    alignItems: 'center',
  },
});

export default HomeScreen;
