import React from 'react';
import {
  Keyboard
} from 'react-native';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import CreateOrderAddTestScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import Colors from '../../../../config/Colors';
import {
  getProductDetails,
  getProductList,
  createOrderAddTest,
  getProductHospital,
  getTestHospital,
  createOrderProduct,
  createOrderTest,
} from '../../../../store/Actions';
import { delay } from '../../../../utils/Helpers';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';


const Data = [
  {
    id: 1,
    name: 'PNS',
    totalId: '05',
    testId: '02',
    image: Icons.nbs,
    color: Colors.card,
  },
  {
    id: 2,
    name: 'NBS',
    totalId: '08',
    testId: '01',
    image: Icons.pns,
    color: Colors.white,
  },
  {
    id: 3,
    name: 'Allied',
    totalId: '02',
    testId: '04',
    image: Icons.nbs,
    color: Colors.white,
  },
  {
    id: 4,
    name: 'Allied',
    totalId: '02',
    testId: '04',
    image: Icons.nbs,
    color: Colors.white,
  },
];

class CreateOrderAddTest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

      showToast: false,
      data: [],

      selectedSearchId: 0,
      payoutPrice: '',
      sellingPrice: '',

      textInputsPayout: [],
      localProductList: [],
      localProductListOrigin: [],
      productDetailsOrigin: [],

      product_code: '',
      product_id: 0,
      showToast: false,
      errorMsg: '',
      NO_REFERRAL: this.props.route.params.NO_REFERRAL,
      totalAmount: 0,

      actionValue: '',
      keyboardStatus: false

    };
  }

  validation = () => {
    var listSelected = this.state.localProductListOrigin.filter(item => item.selected == true);

    var valid = true;

    if (this.state.NO_REFERRAL) {
      for (var i = 0; i < listSelected.length; i++) {
        if (parseInt(listSelected[i].selling_price) > parseInt(listSelected[i].LC_TD_MAXPRICE)) {
          this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Selling price should be less than maximum price`)
          console.log('Selling price should be less than maximum price');
          return valid = false;
        }
        else if (parseInt(listSelected[i].selling_price < 1) || listSelected[i].selling_price == '') {
          this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter selling price`)
          console.log('Please enter price');
          return valid = false;
        }
      }
    } else {
      for (var i = 0; i < listSelected.length; i++) {
        if (parseInt(listSelected[i].selling_price) > parseInt(listSelected[i].LC_TD_MAXPRICE)) {
          this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Selling price should be less than maximum price`)
          console.log('Selling price should be less than maximum price');
          return valid = false;
        }
        else if (parseInt(listSelected[i].selling_price) < parseInt(listSelected[i].dr_payout)) {
          this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Selling price should ge greater than Dr payout`)
          console.log('Selling price should ge greater than Dr payout');
          return valid = false;
        }
        else if (parseInt(listSelected[i].selling_price < 1) || listSelected[i].selling_price == '') {
          this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter selling price`)
          console.log(`Test name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter selling price`);
          return valid = false;
        }
        // else if (parseInt(listSelected[i].dr_payout < 1) || listSelected[i].dr_payout == '') {
        //   this.toastMessage(`Plan name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter Dr payout price`)
        //   console.log(`Test name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter Dr payout price`);
        //   return valid = false;
        // }
      }
    }

    return valid;
  }

  saveData = () => {
    const listSelected = this.state.localProductListOrigin.filter(item => item.selected == true);
    var arr = [];
    for (var i = 0; i < listSelected.length; i++) {
      arr.push({
        product_code: this.state.product_code,
        product_id: listSelected[i].LC_PTM_PRODUCT_ID,
        test_code: listSelected[i].LC_TD_TEST_CODE,
        test_id: listSelected[i].LC_TD_TEST_ID,
        dr_payout: listSelected[i].dr_payout,
        selling_price: listSelected[i].selling_price,
        maxprice: listSelected[i].LC_TD_MAXPRICE,
        minprice: listSelected[i].LC_TD_MINPRICE,
      });

      // value += parseInt(listSelected[i].selling_price)
    }
    this.props.onCreateOrderAddTest(arr);
    this.saveProductsToSaga();
    this.saveTestToSaga();
    this.props.navigation.navigate(Sales.createOrderPickupDate, {
      totalAmount: this.state.totalAmount,
      slecteTest: listSelected,
    });
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  actionSearch = (text) => {
    var listSelected = this.state.localProductListOrigin.filter(item => item.LC_PTM_PRODUCT_ID == this.state.product_id);
    var filterdata = listSelected;

    var arraydata = filterdata.filter(function (x) {
      return (x.LC_TD_TEST_NAME.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1)
    });
    this.setState({
      localProductList: arraydata,
      actionValue: text
    })
  }

  saveProductsToSaga = () => {
    this.props.onCreateOrderProduct(this.state.productDetailsOrigin);
  };

  saveTestToSaga = () => {
    const data = {
      data: this.state.localProductListOrigin,
      invoiceAmount: this.state.totalAmount,
    };
    this.props.onCreateOrderTest(data);
  };

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createOrderPickupDate);
    var listSelected = this.state.localProductList.filter(item => item.selected == true);
    if (listSelected.length > 0) {
      const isValid = this.validation();
      console.log('Price validation  ' + isValid)
      if (isValid) {
        this.saveData();
      }
    }
    else {
      this.toastMessage('Please Select atleast one Test')
    }
  };

  cardClickHandler = item => {
    this.setState(prevState => {
      const temp = prevState.selectedSearchId == item.lc_PD_PRODUCT_CODE ? 0 : item.lc_PD_PRODUCT_CODE;
      this.filterData(temp);
      return {
        selectedSearchId: temp,
      };
    });

    this.setState({
      product_code: item.lc_PD_PRODUCT_CODE,
      product_id: item.lc_PD_PRODUCT_CODE,
      actionValue: ''
    })

  };

  filterData = (id) => {
    // console.log('ID' + id)
    const list = this.state.localProductListOrigin.filter(item => item.LC_PTM_PRODUCT_ID == id);
    this.setState({ localProductList: list })

  }

  toastMessage = msg => {
    this.setState({
      errorMsg: msg,
      showToast: true,
    },
      async () => {
        await delay(3000);
        this.resetValidation();
      });

  }

  setSelectedMethod = (list, itemList) => {
    return list.map(item => {
      if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
        parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)) {
        return {
          ...item,
          selected: !item.selected,
          dr_payout: '',
          selling_price: '',
        }
      }
      return item
    })
  }


  radioPress = (itemList) => {

    const newData = this.setSelectedMethod(this.state.localProductList, itemList);
    const newDataOrigin = this.setSelectedMethod(this.state.localProductListOrigin, itemList);

    this.setState({
      localProductList: newData,
      localProductListOrigin: newDataOrigin
    })


    var count = 0;
    for (var i = 0; i < newData.length; i++) {
      if (newData[i].selected) {
        count++
      }
      const productdata = this.state.productDetailsOrigin.map(item => {
        if (item.lc_PD_PRODUCT_CODE == itemList.LC_PTM_PRODUCT_ID) {
          return {
            ...item,
            test_added: count,
          }
        }
        return item
      })
      this.setState({ productDetailsOrigin: productdata });
    }

    var totalvalues = 0;
    for (var i = 0; i < newDataOrigin.length; i++) {
      if (!newDataOrigin[i].selling_price == '')
        totalvalues += parseInt(newDataOrigin[i].selling_price);
    }
    this.setState({
      totalAmount: totalvalues
    })

  };

  payoutHandler = (val, itemList) => {
    if (/^[0-9]*$/.test(val)) {
      var newData = this.state.localProductList.map(item => {
        if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
          parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
        ) {
          return {
            ...item,
            dr_payout: val,
          }
        }
        return item
      })
      this.setState({ localProductList: newData })

      var newDataOrigin = this.state.localProductListOrigin.map(item => {
        if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
          parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
        ) {
          return {
            ...item,
            dr_payout: val,
          }
        }
        return item
      })
      this.setState({ localProductListOrigin: newDataOrigin })
    }
  };


  sellingHandler = (val, itemList) => {
    if (/^[0-9]*$/.test(val)) {
      var newData = this.state.localProductList.map(item => {
        if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
          parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)) {
          return {
            ...item,
            selling_price: val,
          }
        }
        return item
      })
      this.setState({ localProductList: newData })

      var newDataOrigin = this.state.localProductListOrigin.map(item => {
        if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
          parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)) {
          return {
            ...item,
            selling_price: val,
          }
        }
        return item
      })

      this.setState({ localProductListOrigin: newDataOrigin })

      var totalvalues = 0;
      for (var i = 0; i < newDataOrigin.length; i++) {
        if (!newDataOrigin[i].selling_price == '')
          totalvalues += parseInt(newDataOrigin[i].selling_price);
      }
      this.setState({
        totalAmount: totalvalues
      })
    }
  };


  componentDidMount() {
    //alert(this.state.NO_REFERRAL)
    this.keyboardDidShowSubscription = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        this.setState({ keyboardStatus: true });
      },
    );
    this.keyboardDidHideSubscription = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        this.setState({ keyboardStatus: false });
      },
    );
    if (this.props.createOrderProduct != null) {
      this.setState({
        productDetailsOrigin: this.props.createOrderProduct,
        localProductListOrigin: this.props.createOrderTest.data,
        totalAmount: this.props.createOrderTest.invoiceAmount,
      });
    } else {
      this.props.onGetProductDetails(null, this.props.accessToken);
      const data = {
        product_id: null,
        test_search: null,
      };
      this.props.onGetProductList(data, this.props.accessToken);
    }
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.productDetailsStatus == false &&
      this.props.productDetailsStatus != prevProps.productDetailsStatus
    ) {

      const data = this.props.productDetails.map(item => {
        item.test_added = 0
        return item;
      });
      // console.log(JSON.stringify(data))
      this.setState({ productDetailsOrigin: data })
    }

    if (
      prevProps.productListStatus == false &&
      this.props.productListStatus != prevProps.productListStatus
    ) {
      const data = this.props.productList.properties.TestlistByProductIdModels.map(item => {
        item.dr_payout = 0,
          item.selling_price = 0,
          item.selected = false;
        return item;
      });
      // console.log(JSON.stringify(data))
      this.setState({ localProductListOrigin: data })
    }

  };

  componentWillUnmount() {
    this.keyboardDidShowSubscription.remove();
    this.keyboardDidHideSubscription.remove();
  }

  render() {
    return (
      <CreateOrderAddTestScreen
        loading={this.props.productListLoading}
        nextButtonHandler={this.nextButtonHandler}
        cardClickHandler={this.cardClickHandler}
        radioPress={this.radioPress}
        payoutHandler={this.payoutHandler}
        sellingHandler={this.sellingHandler}
        actionSearch={this.actionSearch}
        //
        data={this.state.data}
        textInputsPayout={this.state.textInputsPayout}
        selectedSearchId={this.state.selectedSearchId}
        productList={this.state.localProductList}
        productDetails={this.state.productDetailsOrigin}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        totalAmount={this.state.totalAmount}
        NO_REFERRAL={this.state.NO_REFERRAL}
        actionValue={this.state.actionValue}
        keyboardStatus={this.state.keyboardStatus}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    // product details
    productDetails: state.common.productDetailsResponse,
    productDetailsStatus: state.common.productDetailsStatus,
    // test details
    productList: state.common.productListResponse,
    productListStatus: state.common.productListStatus,
    productListLoading: state.common.productListLoading,
    // testHospitalLoading: state.createOrder.testHospitalLoading,
    // productDetails: state.createOrder.productHospiatlResponse,
    // productList: state.createOrder.testHospitalResponse,
    createOrderProduct: state.createOrder.createOrderProduct,
    createOrderTest: state.createOrder.createOrderTest,

  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetProductDetails: (data, token) => dispatch(getProductDetails(data, token)),
    onGetProductList: (data, token) => dispatch(getProductList(data, token)),
    // onGetProductHospital: (data, token) => dispatch(getProductHospital(data, token)),
    // onGetTestHospital: (data, token) => dispatch(getTestHospital(data, token)),
    onCreateOrderAddTest: data => dispatch(createOrderAddTest(data)),
    onCreateOrderProduct: data => dispatch(createOrderProduct(data)),
    onCreateOrderTest: data => dispatch(createOrderTest(data)),

  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateOrderAddTest);
