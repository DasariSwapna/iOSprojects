import React, {useRef, useState} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, {NextButton} from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import AddTestTopComponet from '../../../../components/AddTestTopComponent';
//import SearchBar from '../../../../components/SearchBar';
import SearchBar from '../../../../components/FilterBar';
import AddTestPayoutComponent from '../../../../components/AddTestPayoutContainer';
import PageNo from '../../../../constants/PageNo';
import {Toast} from '../../../../components/Toast';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

function CreateOrderAddTestScreen({
  addressTypeHandler,
  nextButtonHandler,
  cardClickHandler,
  actionSearch,
  data,
  radioPress,
  selectedSearchId,
  productList,
  productDetails,
  sellingHandler,
  payoutHandler,
  textInputsPayout,
  showToast,
  errorMsg,
  totalAmount,
  NO_REFERRAL,
  actionValue,
  keyboardStatus,
  loading,
}) {
  const [click, setClick] = useState(null);

  const renderPayoutContainer = ({item, index}) => {
    return (
      <AddTestPayoutComponent
        radioPress={() => radioPress(item)}
        title={item.LC_TD_TEST_NAME}
        minPrice={item.LC_TD_MINPRICE}
        maxPrice={item.LC_TD_MAXPRICE}
        sellingHandler={val => sellingHandler(val, item)}
        payoutHandler={val => payoutHandler(val, item)}
        selected={item.selected}
        dr_payout={item.dr_payout}
        selling_price={item.selling_price}
        NO_REFERRAL={NO_REFERRAL}
      />
    );
  };

  const renderTopContainer = ({item}) => {
    return (
      <AddTestTopComponet
        title={item.lc_PD_PRODUCT_NAME}
        image={item.lc_PD_ICON_IMAGE_PATH}
        testCount={item.total_TEST_COUNT}
        testAdded={item.test_added}
        onPress={() => cardClickHandler(item)}
        bgColor={
          selectedSearchId == item.lc_PD_PRODUCT_CODE
            ? Colors.card
            : Colors.white
        }
      />
    );
  };

  const renderHeader = () => {
    return (
      <View>
        <TimeLineContainer status={3} />
        <FlatList
          horizontal
          contentContainerStyle={{
            paddingHorizontal: 10,
            paddingVertical: 10,
          }}
          showsHorizontalScrollIndicator={false}
          data={productDetails}
          keyExtractor={(item, index) => item.id}
          renderItem={renderTopContainer}
          removeClippedSubviews={false}
        />
        <View style={styles.searchOuterContainer}>
          <View style={{height: hp('6%'), width: '70%'}}>
            <SearchBar onChangehandler={actionSearch} value={actionValue} />
          </View>
          <Text style={styles.textStyle}> ₹ {totalAmount}</Text>
        </View>
      </View>
    );
  };

  const renderNodata = () => {
    return (
      <>
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <Text style={{fontFamily: FontMagneta.bold}}>No data found</Text>
        </View>
      </>
    );
  };

  return (
    <RootView pageNo={PageNo.sales_createOrderAddTest} loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      {/* <KeyboardAvoidingView
        enabled
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: 80 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 2 : 2}> */}
      <View style={styles.mainContainer}>
        <View>
          <TimeLineContainer status={3} />
          <FlatList
            horizontal
            contentContainerStyle={{
              paddingHorizontal: 20,
              paddingVertical: 10,
            }}
            showsHorizontalScrollIndicator={false}
            data={productDetails}
            keyExtractor={(item, index) => item.id}
            renderItem={renderTopContainer}
            removeClippedSubviews={false}
          />
          <View style={styles.searchOuterContainer}>
            <View style={{height: hp('6%'), width: '70%'}}>
              <SearchBar onChangehandler={actionSearch} value={actionValue} />
            </View>
            <Text style={styles.textStyle}> ₹ {totalAmount}</Text>
          </View>
        </View>
        <KeyboardAwareScrollView
          extraHeight={hp('25%')}
          enableOnAndroid={true}>
          <FlatList
            style={{flex: 1}}
            data={productList}
            //  ListHeaderComponent={renderHeader}
            keyExtractor={(item, index) => item.key}
            renderItem={renderPayoutContainer}
            ListEmptyComponent={renderNodata}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.flatListInnerContainer}
            nestedScrollEnabled={true}
          />
        </KeyboardAwareScrollView>
        {keyboardStatus == false && (
          <View
            style={{
              width: '100%',
              position: 'absolute',
              bottom: 0,
              paddingBottom: 20,
              flexDirection: 'column',
              alignItems: 'center',
              backgroundColor: '#fff',
            }}>
            <View style={styles.buttonContainer}>
              <NextButton onPress={nextButtonHandler} />
            </View>
          </View>
        )}
      </View>
      {/* </KeyboardAvoidingView> */}
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    flexDirection: 'column',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
    marginTop: hp('1.5%'),
  },

  //////ScrollView Container
  TopViewContainer: {
    height: hp('14%'),
    marginTop: 20,
    width: '95%',
    marginLeft: '5%',
    alignSelf: 'center',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },

  /////Search outer Style
  searchOuterContainer: {
    width: '85%',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    paddingVertical: '2%',
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
    fontFamily: FontMagneta.thin,
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: 80,
  },
});

export default CreateOrderAddTestScreen;
