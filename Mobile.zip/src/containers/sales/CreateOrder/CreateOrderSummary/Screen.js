// import React, { useRef } from 'react';
// import {
//   ActivityIndicator,
//   Dimensions,
//   ImageBackground,
//   Image,
//   SafeAreaView,
//   Text,
//   View,
//   ScrollView,
//   Platform,
//   StyleSheet,
//   KeyboardAvoidingView,
//   TouchableOpacity,
// } from 'react-native';
// import RootView from '../../../../components/RootView';
// import Colors from '../../../../config/Colors';
// import Images from '../../../../constants/Images';
// import Button from '../../../../components/Button';
// import FaIcons from 'react-native-vector-icons/FontAwesome';
// import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
// import TimeLineContainer from '../../../../components/TimeLineContainer';
// import IonIcons from 'react-native-vector-icons/Ionicons';
// import DownloadImageComponent from '../../../../components/DownloadImageComponet';
// import {
//   widthPercentageToDP as wp,
//   heightPercentageToDP as hp,
// } from 'react-native-responsive-screen';
// import PageNo from '../../../../constants/PageNo';
// import Pdf from 'react-native-pdf';
// import { Toast } from '../../../../components/Toast';

// function TextConatiner({ leftText, rightText, rightTextColor }) {
//   return (
//     <View style={{ width: '100%', flexDirection: 'row' }}>
//       <Text
//         style={{
//           flex: 1,
//           paddingLeft: 25,
//           paddingVertical: 5,
//           color: Colors.border,
//           fontFamily: Font.bold,
//           fontSize: FontSize.regular,
//         }}>
//         {leftText}
//       </Text>
//       <Text
//         style={{
//           flex: 1,
//           paddingVertical: 5,
//           color: rightTextColor,
//           fontFamily: FontMagneta.medium,
//           fontSize: FontSize.regular,
//         }}>
//         {rightText}
//       </Text>
//     </View>
//   );
// }

// function BoxConatiner({
//   buttonContainer,
//   voilaRefNo,
//   address,
//   alternateMobile,
//   customerName,
//   emailId,
//   invoiceAmount,
//   notes,
//   primaryMobile,

//   testDetailsResModels,
// }) {
//   return (
//     <View
//       style={{
//         width: '80%',
//         flexDirection: 'column',
//         alignSelf: 'center',
//         backgroundColor: '#fff',
//         elevation: 2,
//         borderRadius: 10,
//         borderColor: Colors.border,
//         borderWidth: 0.5,
//         marginTop: 25,
//       }}>
//       <View
//         style={{
//           marginTop: 10,
//         }}
//       />
//       <TextConatiner leftText={'Voila Ref No'} rightText={voilaRefNo} />
//       <TextConatiner leftText={'Customer Name'} rightText={customerName} />
//       <TextConatiner leftText={'Primary Mobile #'} rightText={primaryMobile} />
//       <TextConatiner
//         leftText={'Alternate Mobile #'}
//         rightText={alternateMobile}
//       />
//       <TextConatiner leftText={'Email ID'} rightText={emailId} />
//       <TextConatiner leftText={'Address'} rightText={address} />
//       <TextConatiner leftText={'Notes'} rightText={notes} />

//       <View
//         style={{
//           marginTop: 10,
//         }}
//       />

//       <View
//         style={{
//           width: '100%',
//           height: 1,
//           backgroundColor: Colors.eWhite,
//           alignSelf: 'center',
//         }}
//       />

//       <View
//         style={{
//           marginTop: 10,
//         }}
//       />

//       <TextConatiner leftText={'Test Name'} rightText={''} />
//       <View style={{ marginTop: -25 }} />

//       {/* <ScrollView> */}
//       {testDetailsResModels &&
//         testDetailsResModels.map((item, index) => {
//           return <TextConatiner leftText={''} rightText={item.lcTdTestName} />;
//         })}

//       <View
//         style={{
//           width: '100%',
//           height: 1,
//           backgroundColor: Colors.eWhite,
//           alignSelf: 'center',
//         }}
//       />

//       <View
//         style={{
//           marginTop: 10,
//         }}
//       />

//       <TextConatiner
//         leftText={'Invoice Amount'}
//         rightText={'₹' + ' ' + invoiceAmount}
//       />

//       {!buttonContainer ? (
//         <TextConatiner
//           leftText={'Payment status'}
//           rightText={'Pending'}
//           rightTextColor={Colors.button}
//         />
//       ) : null}

//       <View
//         style={{
//           marginTop: 10,
//         }}
//       />
//     </View>
//   );
// }

// TextConatiner.defaultProps = {
//   rightTextColor: Colors.black,
// };

// function CreateOrderSummaryScreen({
//   payNowHandler,
//   payLaterHandler,
//   buttonContainer,
//   voilaRefNo,
//   address,
//   alternateMobile,
//   customerName,
//   emailId,
//   invoiceAmount,
//   notes,
//   primaryMobile,
//   testDetailsResModels,
//   shareButtonHandler,
//   downloadButtonHandler,
//   source,
//   showToast,
//   errorMsg,
//   nextButtonHandler
// }) {
//   return (
//     <RootView pageNo={PageNo.sales_createOrderSummary}>
//       <Toast
//         showToast={showToast}
//         msg={errorMsg}
//         bgColor={Colors.error}
//         txtColor={Colors.background}
//       />
//       <View style={styles.mainContainer}>
//         <TimeLineContainer status={5} />

//         <View
//           style={{
//             borderColor: Colors.primary,
//             backgroundColor: Colors.background,
//             marginHorizontal: wp('5%'),
//             marginVertical: hp('2%'),
//             width: '90%',
//             height: '65%',
//             borderWidth: 0.25,
//             borderRadius: 10,
//             shadowColor: Colors.primary,
//             shadowOffset: {
//               width: 0,
//               height: 3,
//             },
//             shadowOpacity: 0.29,
//             shadowRadius: 4.65,
//             elevation: 7,
//           }}>
//           <Pdf
//             source={source}
//             onLoadComplete={(numberOfPages, filePath) => {
//               console.log(`Number of pages: ${numberOfPages}`);
//             }}
//             onPageChanged={(page, numberOfPages) => {
//               console.log(`Current page: ${page}`);
//             }}
//             onError={error => {
//               console.log(error);
//             }}
//             onPressLink={uri => {
//               console.log(`Link pressed: ${uri}`);
//             }}
//             style={styles.pdf}
//           />
//         </View>
//         {!buttonContainer ? (
//           <View
//             style={{
//               alignSelf: 'flex-end',
//               flexDirection: 'row',
//               width: wp('10%'),
//               height: 40,
//               alignItems: 'center',
//               justifyContent: 'space-between',
//               marginRight: hp('7%'),
//               marginTop: hp('1%'),
//             }}>
//             <TouchableOpacity onPress={downloadButtonHandler}>
//               <Image
//                 source={Images.download1}
//                 style={{ width: hp('3%'), height: hp('3%'), marginRight: 8 }}
//                 resizeMode="cover"
//               />
//             </TouchableOpacity>
//             <TouchableOpacity onPress={shareButtonHandler}>
//               <IonIcons
//                 name={'share-social'}
//                 color={Colors.border}
//                 size={hp('3%')}
//               />
//             </TouchableOpacity>
//           </View>
//         ) : null}

//         {/* Bottom Container */}
//         <View
//           style={{
//             flex: 1,
//             flexDirection: 'column',
//             alignItems: 'center',
//           }}>
//           <View style={styles.buttonContainer}>
//             {buttonContainer ? (
//               <View
//                 style={{
//                   width: '100%',
//                   flexDirection: 'row',
//                   alignItems: 'center',
//                   justifyContent: 'space-evenly',
//                   marginTop: hp('5%'),
//                 }}>
//                 <Button
//                   title="Pay Later"
//                   buttonStyle={{
//                     width: '40%',
//                     paddingHorizontal: 2,
//                     borderRadius: hp('5%'),
//                     backgroundColor: '#fff',
//                     borderColor: Colors.darkPink,
//                     borderWidth: 1,
//                   }}
//                   buttonTextStyle={styles.buttonTextStylePink}
//                   onPress={payLaterHandler}
//                 />
//                 <Button
//                   title="Pay Now"
//                   buttonStyle={{
//                     width: '40%',
//                     paddingHorizontal: 2,
//                     borderRadius: hp('5%'),
//                   }}
//                   buttonTextStyle={styles.buttonStyleWhite}
//                   onPress={payNowHandler}
//                 />
//               </View>
//             ) :
//               null
//             }
//           </View>
//         </View>
//         {/* Bottom Container */}
//         {!buttonContainer ? (
//           <View style={{ position: 'absolute', bottom: 0, alignSelf: 'center' }}>
//             <Button
//               title="Home page"
//               buttonStyle={styles.buttonWithoutBorder}
//               buttonTextStyle={styles.buttonStyleWhite}
//               onPress={nextButtonHandler} />
//           </View>
//         ) : null}
//       </View>
//     </RootView>
//   );
// }

// const styles = StyleSheet.create({
//   mainContainer: {
//     width: '100%',
//     height: '100%',
//     backgroundColor: '#fff',
//     // overflow: 'hidden',
//   },
//   contentContainer: {
//     flexGrow: 1,
//     paddingBottom: 50,
//     backgroundColor: '#fff',
//   },
//   lineLargeContainer: {
//     width: '95%',
//     height: 1,
//     backgroundColor: Colors.eWhite,
//     alignSelf: 'center',
//   },
//   pdf: {
//     marginVertical: wp('1%'),
//     marginHorizontal: wp('1%'),
//     width: '98%',
//     height: '98%',
//     backgroundColor: Colors.white,
//   },
//   buttonContainer: {
//     width: '100%',
//     alignSelf: 'center',
//   },
//   textStyle: {
//     color: Colors.black,
//     fontFamily: Font.regular,
//     fontSize: FontSize.regular,
//     alignSelf: 'center',
//     paddingVertical: 15,
//   },
//   textStyleTeal: {
//     color: Colors.teal,
//     fontFamily: Font.regular,
//     fontSize: FontSize.regular,
//   },
//   ////Buttons Style
//   buttonPayContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     width: '80%',
//     alignSelf: 'center',
//     position: 'absolute',
//     bottom: 0,
//     marginBottom: 30,
//   },
//   buttonWithBorder: {
//     minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
//     height: hp('5%'),
//     paddingHorizontal: 2,
//     borderRadius: hp('5%'),
//     backgroundColor: '#fff',
//     borderColor: Colors.darkPink,
//     borderWidth: 1,
//   },
//   buttonWithoutBorder: {
//     minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
//     height: hp('5%'),
//     paddingHorizontal: 2,
//     borderRadius: hp('5%'),
//     backgroundColor: Colors.darkPink,
//     borderColor: Colors.darkPink,
//     borderWidth: 1,
//     marginBottom: hp('1.5%')
//   },
//   buttonTextStylePink: {
//     fontSize: FontSize.large,
//     color: Colors.darkPink,
//   },
//   buttonStyleWhite: {
//     fontSize: FontSize.large,
//   },
// });

// export default CreateOrderSummaryScreen;
import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import IonIcons from 'react-native-vector-icons/Ionicons';
import DownloadImageComponent from '../../../../components/DownloadImageComponet';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import PageNo from '../../../../constants/PageNo';
import Pdf from 'react-native-pdf';
import { Toast } from '../../../../components/Toast';

function TextConatiner({ leftText, rightText, rightTextColor }) {
  return (
    <View style={{ width: '100%', flexDirection: 'row' }}>
      <Text
        style={{
          flex: 1,
          paddingLeft: 25,
          paddingVertical: 5,
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>
        {leftText}
      </Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: 5,
          color: rightTextColor,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>
        {rightText}
      </Text>
    </View>
  );
}

TextConatiner.defaultProps = {
  rightTextColor: Colors.black,
};

function CreateOrderSummaryScreen({
  payNowHandler,
  payLaterHandler,
  buttonContainer,
  voilaRefNo,
  address,
  alternateMobile,
  customerName,
  customerLastName,
  emailId,
  invoiceAmount,
  notes,
  primaryMobile,
  testDetailsResModels,
  shareButtonHandler,
  downloadButtonHandler,
  source,
  showToast,
  errorMsg,
  selecteTest,
}) {
  const renderPayoutContainer = ({ item, index }) => {
    return (
      <TextConatiner
        leftText={index == 0 ? 'Test Name' : ''}
        rightText={item.LC_TD_TEST_NAME}
      />
    );
  };
  return (
    <RootView pageNo={PageNo.sales_createOrderSummary}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <View style={styles.mainContainer}>
        <TimeLineContainer status={5} />

        {/* <View
          style={{
            borderColor: Colors.primary,
            backgroundColor: Colors.background,
            marginHorizontal: wp('5%'),
            marginVertical: hp('2%'),
            width: '90%',
            height: '65%',
            borderWidth: 0.25,
            borderRadius: 10,
            shadowColor: Colors.primary,
            shadowOffset: {
              width: 0,
              height: 3,
            },
            shadowOpacity: 0.29,
            shadowRadius: 4.65,
            elevation: 7,
          }}>
          <Pdf
            source={source}
            onLoadComplete={(numberOfPages, filePath) => {
              console.log(`Number of pages: ${numberOfPages}`);
            }}
            onPageChanged={(page, numberOfPages) => {
              console.log(`Current page: ${page}`);
            }}
            onError={error => {
              console.log(error);
            }}
            onPressLink={uri => {
              console.log(`Link pressed: ${uri}`);
            }}
            style={styles.pdf}
          />
        </View> */}
        <View
          style={{
            width: '80%',
            flexDirection: 'column',
            alignSelf: 'center',
            backgroundColor: '#fff',
           // elevation: 2,
            borderRadius: 10,
            borderColor: Colors.border,
            borderWidth: 0.3,
            marginTop: 25,
          }}>
          <View
            style={{
              marginTop: 10,
            }}
          />
          {/* <TextConatiner leftText={'Voila Ref No'} rightText={'200411610034'} /> */}
          <TextConatiner leftText={'Customer Name'} rightText={customerName} />
          <TextConatiner
            leftText={'Primary Mobile #'}
            rightText={primaryMobile}
          />
          <TextConatiner
            leftText={'Alternate Mobile #'}
            rightText={alternateMobile}
          />
          <TextConatiner leftText={'Email'} rightText={emailId} />
          <TextConatiner leftText={'Address'} rightText={address} />
          <TextConatiner leftText={'Notes'} rightText={notes} />

          <View
            style={{
              marginTop: 10,
            }}
          />

          <View
            style={{
              width: '100%',
              height: 1,
              backgroundColor: Colors.eWhite,
              alignSelf: 'center',
            }}
          />

          <View
            style={{
              marginTop: 10,
            }}
          />
          {selecteTest != null || selecteTest != undefined ? (
            <FlatList
              data={selecteTest}
              extraData={selecteTest}
              renderItem={renderPayoutContainer}
              keyExtractor={(item, index) => item.LC_TD_TEST_ID}
            />
          ) : null}

          {/* <TextConatiner leftText={''} rightText={'Vitamin D'} />
          <TextConatiner leftText={''} rightText={'karyotyping-Cold Blood'} />
          <TextConatiner leftText={''} rightText={'karyotyping'} /> */}

          <View
            style={{
              width: '100%',
              height: 1,
              backgroundColor: Colors.eWhite,
              alignSelf: 'center',
            }}
          />

          <View
            style={{
              marginTop: 10,
            }}
          />

          <TextConatiner
            leftText={'Invoice Amount'}
            rightText={invoiceAmount}
          />

          <View
            style={{
              marginTop: 10,
            }}
          />
        </View>
      </View>

      {/* {!buttonContainer ? (
        <View
          style={{
            alignSelf: 'flex-end',
            flexDirection: 'row',
            width: wp('10%'),
            height: 40,
            alignItems: 'center',
            justifyContent: 'space-between',
            marginRight: hp('7%'),
            marginTop: hp('1%'),
          }}>
          <TouchableOpacity onPress={downloadButtonHandler}>
            <Image
              source={Images.download1}
              style={{width: hp('3%'), height: hp('3%'), marginRight: 8}}
              resizeMode="cover"
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={shareButtonHandler}>
            <IonIcons
              name={'share-social'}
              color={Colors.border}
              size={hp('3%')}
            />
          </TouchableOpacity>
        </View>
      ) : null} */}

      {/* Bottom Container */}
      <View
        style={{
          flex: 1,
          flexDirection: 'column',
          alignItems: 'center',
          backgroundColor: '#ffffff',
        }}>
        <View style={styles.buttonContainer}>
          {buttonContainer ? (
            <View
              style={{
                width: '100%',
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-evenly',
              }}>
              <Button
                title="Pay Later"
                buttonStyle={{
                  width: '40%',
                  paddingHorizontal: 2,
                  borderRadius: hp('5%'),
                  backgroundColor: '#fff',
                  borderColor: Colors.darkPink,
                  borderWidth: 1,
                }}
                buttonTextStyle={styles.buttonTextStylePink}
                onPress={payLaterHandler}
              />
              <Button
                title="Pay Now"
                buttonStyle={{
                  width: '40%',
                  paddingHorizontal: 2,
                  borderRadius: hp('5%'),
                }}
                buttonTextStyle={styles.buttonStyleWhite}
                onPress={payNowHandler}
              />
            </View>
          ) : null}
        </View>
      </View>
      {/* Bottom Container */}
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '90%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  pdf: {
    marginVertical: wp('1%'),
    marginHorizontal: wp('1%'),
    width: '98%',
    height: '98%',
    backgroundColor: Colors.white,
  },
  buttonContainer: {
    width: '100%',
    alignSelf: 'center',
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    alignSelf: 'center',
    paddingVertical: 15,
  },
  textStyleTeal: {
    color: Colors.teal,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  ////Buttons Style
  buttonPayContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '80%',
    alignSelf: 'center',
    position: 'absolute',
    bottom: 0,
    marginBottom: 30,
  },
  buttonWithBorder: {
    minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: '#fff',
    borderColor: Colors.darkPink,
    borderWidth: 1,
  },
  buttonWithoutBorder: {
    minWidth: Platform.OS === 'ios' ? hp('17%') : hp('20%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
  },
  buttonTextStylePink: {
    fontSize: FontSize.large,
    color: Colors.darkPink,
  },
  buttonStyleWhite: {
    fontSize: FontSize.large,
  },
});

export default CreateOrderSummaryScreen;
