import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { Share, PermissionsAndroid, Platform } from 'react-native';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import CreateOrderSummaryScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import { payDetails } from '../../../../store/Actions';
import RNFetchBlob from 'rn-fetch-blob';
import { delay } from '../../../../utils/Helpers';
import {
  insertOrder,
  userAvailability,
  createOrderBasic,
  createOrderRefer,
  createOrderProduct,
  createOrderTest,
  createOrderPickup
} from '../../../../store/Actions';

class CreateOrderSummary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      buttonContainer: true,
      voilaRefNo: '',
      address: '',
      alternateMobile: '',
      customerName: '',
      customerLastName: '',
      emailId: '',
      invoiceAmount: '',
      notes: '',
      primaryMobile: '',
      testdata: [],
      testDetailsResModels: [],
      source: {
        uri: this.props.PDFdatas,
        cache: true,
      },
      errorMsg: '',
      showToast: false,
      totalAmount: this.props.route.params.totalAmount,
      selecteTest: this.props.route.params.selecteTest,
      Date: this.props.route.params.Date,
      Time: this.props.route.params.Time,
    };
  }

  componentDidMount() {
    try {
      var invoiceAmount = '₹' + this.state.totalAmount;
      var customerName =
        this.props.basicDetail.patient_firstname +
        ' ' +
        this.props.basicDetail.patient_lastname;
      this.setState(
        {
          address: this.props.basicDetail.address,
          alternateMobile: this.props.basicDetail.alternatecontact,
          customerName: customerName,
          customerLastName: this.props.basicDetail.patient_lastname,
          emailId: this.props.basicDetail.email,
          invoiceAmount: invoiceAmount,
          notes: this.props.referDetailList.remarks,
          primaryMobile: this.props.basicDetail.primarycontact,
          // testDetailsResModels: this.props.data.testDetailsResModels,
        },
        function () {
          console.log(this.state.address);
        },
      );
    } catch (error) {
      console.log(error);
    }
  }

  payNowHandler = () => {
    // const data = {
    //   crmId: this.props.data.orderDetailsResModel.voilaRefNo,
    //   orderid: this.props.data.orderDetailsResModel.order_id,
    // };
    // this.props.onPayDetails(data);
    this.props.navigation.navigate(Sales.SalesPaymentCollection, {
      // URL: this.props.insertOrderresponsePDF,
      // Hospitalname: this.props.insertOrderresponsePDF,
      // vendorID: this.props.insertOrderresponsePDF,

      totalAmount: this.state.totalAmount,
      email: this.props.basicDetail.email,
      MobileNumber: this.props.basicDetail.primarycontact,
      Time: this.state.Time,
      Date: this.state.Date,
    });
  };

  // payLaterHandler = () => {
  //   this.setState({
  //     buttonContainer: false,
  //   });
  // };

  downloadButtonHandler = async () => {
    {
      Platform.OS == 'ios' ? this.actualDownloadiOS() : this.downloadFile();
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  shareButtonHandler = async () => {
    const result = await Share.share({
      message: this.state.source.uri,
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
        // shared with activity type of result.activityType
      } else {
        // shared
      }
    } else if (result.action === Share.dismissedAction) {
      // dismissed
    }
  };

  actualDownloadiOS = () => {
    try {
      const { config, fs } = RNFetchBlob;
      let dirs = fs.dirs;
      let options = {
        fileCache: false,
        appendExt: 'pdf',
        path:
          dirs.DocumentDir +
          '/' +
          this.props.data.orderDetailsResModel.voilaRefNo +
          '.pdf',
      };
      config(options)
        .fetch('GET', this.props.PDFdatas)
        .then(res => {
          // do some magic here
          // RNFetchBlob.ios.openDocument();
          this.setState(
            {
              errorMsg: I18n.t('valitation.iOS_download_path_msg'),
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );

          //  Downloding: On My iPhone =>Lifecell
          //  toastMsg(this.state.downloadtext);
          console.log('File download', res.path());
        });
    } catch (error) {
      console.log('File download error', error);
    }
  };

  async downloadFile() {
    console.log('plato', Platform.OS);

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload();
      } else {
        alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  actualDownload = () => {
    RNFetchBlob.fs
      .mkdir(RNFetchBlob.fs.dirs.SDCardDir + '/LifeCell')

      .then(() => {
        alert('created');
      })

      .catch(err => {
        console.log(err);
      });

    RNFetchBlob.fs
      .ls(RNFetchBlob.fs.dirs.SDCardDir)

      // files will an array contains filenames

      .then(files => {
        console.log(files);
      });

    const { dirs } = RNFetchBlob.fs;

    console.log(dirs);

    RNFetchBlob.config({
      fileCache: true,

      addAndroidDownloads: {
        useDownloadManager: true,

        notification: true,

        mediaScannable: true,

        title: this.props.data.orderDetailsResModel.voilaRefNo,
        path:
          dirs.DownloadDir +
          '/' +
          this.props.data.orderDetailsResModel.voilaRefNo +
          '.pdf',

        //  +''+this.state.PDF_name+".pdf"`,

        // path: `${dirs.DownloadDir}/this.state.PDF_name.pdf,
      },
    })

      .fetch('GET', this.props.PDFdatas, {})

      .then(res => {
        // toastMsg(this.state.downloadtext1);

        console.log('The file saved to ', res.path());
      })

      .catch(e => {
        console.log(e);
      });
  };

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.Create);
    this.props.navigation.reset({
      routes: [{ name: Sales.myDrawer }],
    });
  };

  payLaterHandler = () => {
    //this.props.navigation.navigate(Sales.createOrderSummary);

    const data = {
      patient_firstname: this.props.basicDetail.patient_firstname,
      patient_lastname: this.props.basicDetail.patient_lastname,
      primarycontact: this.props.basicDetail.primarycontact,
      alternatecontact: this.props.basicDetail.alternatecontact,
      email: this.props.basicDetail.email,
      addresstype: this.props.basicDetail.addresstype,
      address: this.props.basicDetail.address,
      city: this.props.basicDetail.city,
      state: this.props.basicDetail.state,
      pincode: this.props.basicDetail.pincode,
      hospitalid: this.props.referDetailList.hospitalid,
      doctorid: this.props.referDetailList.doctorid,
      remarks: this.props.referDetailList.remarks,
      pickupid: this.props.referDetailList.pickupid,
      testdetails: this.props.addTestList,
      pickupdatetime: this.state.Date,
      referid: this.props.referDetailList.referid,
      invoiceamount: this.state.totalAmount,
      servicetype: 'good',
      userid: this.props.UserID,
      time: this.state.Time,
      lattitude: this.props.basicDetail.lattitude,
      longitude: this.props.basicDetail.longitude,
    };
    this.props.onInsertOrder(data, this.props.accessToken, 1);
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.insertOrderStatus == false &&
      this.props.insertOrderStatus != prevProps.insertOrderStatus
    ) {
      this.props.onCreateOrderBasic(null);
      this.props.onCreateOrderRefer(null);
      this.props.onCreateOrderProduct(null);
      this.props.onCreateOrderTest(null);
      this.props.onCreateOrderPickup(null);
      this.props.navigation.navigate(Sales.CreateOrderConfirmationPreview, {
        URL: this.props.insertOrderresponsePDF,
        // Hospitalname: this.props.insertOrderresponsePDF,
         //vendorID: this.props.data.order_id,
      });
    }
    try {
      if (
        prevProps.insertOrderError != this.props.insertOrderError &&
        this.props.insertOrderError == true
      ) {
        this.setState(
          {
            errorMsg:
              this.props.insertOrderFailureResponse.orderDetailsResModel
                .voilaRefNo,
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
      }
    } catch (error) { }
  };

  render() {
    return (
      <CreateOrderSummaryScreen
        payNowHandler={this.payNowHandler}
        payLaterHandler={this.payLaterHandler}
        nextButtonHandler={this.nextButtonHandler}
        // States
        buttonContainer={this.state.buttonContainer}
        voilaRefNo={this.state.voilaRefNo}
        address={this.state.address}
        alternateMobile={this.state.alternateMobile}
        customerName={this.state.customerName}
        customerLastName={this.state.customerLastName}
        emailId={this.state.emailId}
        invoiceAmount={this.state.invoiceAmount}
        notes={this.state.notes}
        primaryMobile={this.state.primaryMobile}
        testDetailsResModels={this.state.testDetailsResModels}
        source={this.state.source}
        shareButtonHandler={this.shareButtonHandler}
        downloadButtonHandler={this.downloadButtonHandler}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        selecteTest={this.state.selecteTest}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    data: state.createOrder.insertOrderResponse,
    PDFdatas: state.createOrder.insertOrderresponsePDF,
    basicDetail: state.createOrder.basicDetail,
    referDetailList: state.createOrder.referDetail,
    addTestList: state.createOrder.addTest,
    UserID: state.signIn.userId,
    insertOrderTestMessage: state.createOrder.message,
    insertOrderresponsePDF: state.createOrder.insertOrderresponsePDF,
    insertOrderStatus: state.createOrder.insertOrderStatus,
    insertOrderError: state.createOrder.insertOrderError,
    insertOrderLoading: state.createOrder.insertOrderLoading,
    insertOrderFailureResponse: state.createOrder.insertOrderFailureResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onPayDetails: data => dispatch(payDetails(data)),
    onInsertOrder: (data, token) => dispatch(insertOrder(data, token, 1)),
    onCreateOrderBasic: data => dispatch(createOrderBasic(data)),
    onCreateOrderRefer: data => dispatch(createOrderRefer(data)),
    onCreateOrderProduct: data => dispatch(createOrderProduct(data)),
    onCreateOrderTest: data => dispatch(createOrderTest(data)),
    onCreateOrderPickup: data => dispatch(createOrderPickup(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateOrderSummary);
