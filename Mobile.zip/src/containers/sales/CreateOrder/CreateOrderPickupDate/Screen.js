import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { NextButton } from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import { Calendar } from 'react-native-calendars';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import Icon from 'react-native-vector-icons/FontAwesome';
import { TouchableOpacity } from 'react-native-gesture-handler';
import AntDesign from 'react-native-vector-icons/AntDesign';
import moment from 'moment';
import DateTimePicker from '@react-native-community/datetimepicker';
import { Toast } from '../../../../components/Toast';


function CalendarSection({
  onClickListener,
  markedDates,
  today
}) {
  return (
    <Calendar
      // getSelectedDayEvents={() => getSelectedDayEvents}
      onDayPress={day => onClickListener(day)}
      // Collection of dates that have to be marked. Default = {}
      style={{
        height: 350,
        backgroundColor: 'transparent',
      }}
      markingType={'custom'}
      markedDates={markedDates}
      minDate={today}
      // markedDates={{
      //   '2021-12-12': {
      //     customStyles: {
      //       container: {
      //         backgroundColor: 'green'
      //       },
      //       text: {
      //         color: 'black',
      //         fontWeight: 'bold'
      //       }
      //     }
      //   }
      // }}

      // Specify theme properties to override specific styles for calendar parts. Default = {}
      theme={{
        backgroundColor: '#ffffff',
        calendarBackground: '#ffffff',
        textSectionTitleColor: '#9E2575',
        textSectionTitleDisabledColor: '#d9e1e8',
        selectedDayBackgroundColor: 'red',
        selectedDayTextColor: '#ffffff',
        todayTextColor: '#00adf5',
        dayTextColor: '#2d4150',
        textDisabledColor: '#d9e1e8',
        dotColor: '#00adf5',
        selectedDotColor: '#ffffff',
        arrowColor: '#9E2575',
        disabledArrowColor: '#d9e1e8',
        monthTextColor: '#9E2575',
        indicatorColor: '#9E2575',
        textDayFontFamily: FontMagneta.medium,
        textMonthFontFamily: Font.bold,
        textDayHeaderFontFamily: Font.extraBold,
        textDayFontWeight: '300',
        textMonthFontWeight: 'bold',
        textDayHeaderFontWeight: '300',
        textDayFontSize: 14,
        textMonthFontSize: 14,
        textDayHeaderFontSize: 14,
        'stylesheet.calendar.header': {
          monthText: {
            fontSize: FontSize.large,
            fontFamily: Font.extraBold,
            fontWeight: '500', // default is 300
            color: Colors.border,
            margin: 10, // default
          },
        },
      }}
    />
  );
}

function CreateOrderPickupDateScreen({
  nextButtonHandler,
  getSelectedDayEvents,
  markedDates,
  selectTimeHandler,
  //
  hour,
  minutes,
  show,
  dateTime,
  onChangeTimeHandler,
  showToast,
  errorMsg,
  userAvailabilityList,
  loading,
  selectedTime,

  isValidDate,
  isValidTime,
  dateValidMsg,
  timevalidMsg,
}) {
  var today = moment().format("YYYY-MM-DD");
  // var tomorrow = moment(today).add(1, 'days').format("YYYY-MM-DD");

  return (
    <RootView pageNo={PageNo.sales_createOrderPickupdate} loading={loading}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff',
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>

                <TimeLineContainer status={4} />

                <Text
                  style={styles.textStyleBorder}>
                  {I18n.t('sales.createOrder.select_date_label')}
                </Text>

                <CalendarSection
                  onClickListener={day => getSelectedDayEvents(day)}
                  markedDates={markedDates}
                  today={today}
                />
                <View style={[{ marginTop: hp('2%') }, styles.lineLargeContainer]} />
                {!isValidDate && (
                  <Text style={styles.textValidationMsg}>
                    {!isValidDate ? dateValidMsg : ''}
                  </Text>
                )}
                <Text
                  style={styles.textStyleBorder}>
                  {I18n.t('sales.createOrder.select_time_label')}
                </Text>
                <DropDownMenu
                  labelName={'Select Time'}
                  labelKey={'msg_TIME'}
                  valueKey={'msg_TIME'}
                  listItems={userAvailabilityList}
                  valueChangeHandler={selectTimeHandler}
                  initValue={selectedTime}
                />
                {!isValidTime && (
                  <Text style={styles.textValidationMsg}>
                    {!isValidTime ? timevalidMsg : ''}
                  </Text>
                )}

              </View>
            </ScrollView>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
            }}>
            <View style={styles.buttonContainer}>
              <NextButton onPress={nextButtonHandler} />
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    // overflow: 'hidden',
    backgroundColor: '#fff',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    alignSelf: 'center',
    paddingVertical: 15,
  },
  textStyleTeal: {
    color: Colors.teal,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  textStyleBorder: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    margin: 20,
  },
  textValidationMsg: {
    width: '90%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingVertical: 4,
  },
});

export default CreateOrderPickupDateScreen;
