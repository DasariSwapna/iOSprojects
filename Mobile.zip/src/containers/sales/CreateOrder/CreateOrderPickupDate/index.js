import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import {
  isValidUsername,
  isValidPassword,
  validateRadioEmpty,
  validateOrderDate,
  validateOrderTime
} from '../../../../utils/Validators';
import CreateOrderPickupDateScreen from './Screen';
import {
  insertOrder,
  userAvailability,
  createOrderBasic,
  createOrderRefer,
  createOrderProduct,
  createOrderTest,
  createOrderPickup,

} from '../../../../store/Actions';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import Colors from '../../../../config/Colors';
import moment from 'moment';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { delay } from '../../../../utils/Helpers';

const sourceDate = moment.unix(1636797600).local().toDate();

class CreateOrderPickupDate extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMsg: '',
      isValidated: false,
      showToast: false,
      hour: 0,
      minutes: 0,
      selectedDate: '',
      markedDates: {},
      dateTime: sourceDate,
      show: false,
      timeSelected: false,
      showToast: false,
      errorMsg: '',
      serviceDate: '',
      selectedTime: '',
      totalAmount: this.props.route.params.totalAmount,
      selecteTest: this.props.route.params.slecteTest,
      stateUserAvailabilityList: null,

      isValidDate: true,
      isValidTime: true,

      dateValidMsg: '',
      timevalidMsg: '',
    };
  }



  nextButtonHandler = () => {
    //this.props.navigation.navigate(Sales.createOrderSummary);
    const valid1 = validateOrderDate(this.state.selectedDate);
    const valid2 = validateOrderTime(this.state.selectedTime);

    if (valid1.val &&
      valid2.val) {
      this.setState({
        isValidDate: valid1.val,
        dateValidMsg: '',
        isValidTime: valid2.val,
        timevalidMsg: '',
      })

      const data = {
        date: this.state.markedDates,
        date1: this.state.selectedDate,
        time: this.state.selectedTime,
      }
      this.props.onCreateOrderPickup(data);

      this.props.navigation.navigate(Sales.createOrderSummary, {
        // URL: this.props.insertOrderresponsePDF,
        // Hospitalname: this.props.insertOrderresponsePDF,
        // vendorID: this.props.insertOrderresponsePDF,
        selecteTest: this.state.selecteTest,
        totalAmount: this.state.totalAmount,
        Date: this.state.selectedDate,
        Time: this.state.selectedTime,
      })

    } else {
      this.setState({
        isValidDate: valid1.val,
        dateValidMsg: valid1.msg,
        isValidTime: valid2.val,
        timevalidMsg: valid2.msg,
      })

    }
  }



  // if (!valid1.val) {
  //   this.setState(
  //     {
  //       errorMsg: 'Please Select Date',
  //       showToast: true,
  //     },
  //     async () => {
  //       await delay(3000);
  //       this.resetValidation();
  //     },
  //   );
  // } else if (!valid2.val) {
  //   this.setState(
  //     {
  //       errorMsg: 'Please Select Time',
  //       showToast: true,
  //     },
  //     async () => {
  //       await delay(3000);
  //       this.resetValidation();
  //     },
  //   );
  // } else {

  //   const data = {
  //     date: this.state.markedDates,
  //     date1: this.state.selectedDate,
  //     time: this.state.selectedTime,
  //   }

  //   this.props.onCreateOrderPickup(data);

  //   this.props.navigation.navigate(Sales.createOrderSummary, {
  //     // URL: this.props.insertOrderresponsePDF,
  //     // Hospitalname: this.props.insertOrderresponsePDF,
  //     // vendorID: this.props.insertOrderresponsePDF,
  //     selecteTest: this.state.selecteTest,
  //     totalAmount: this.state.totalAmount,
  //     Date: this.state.selectedDate,
  //     Time: this.state.selectedTime,
  //   })
  // }
  // };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };


  getSelectedDayEvents = day => {
    this.setState({ selectedDate: day.dateString });
    let markedDates = {};
    //markedDates[day.dateString] = { selected: true, color: '#00B0BF', textColor: '#FFFFFF' };
    markedDates[day.dateString] = {
      customStyles: {
        container: {
          backgroundColor: Colors.border,
        },
        text: {
          color: Colors.white,
          fontFamily: FontMagneta.medium,
        },
      },
    };

    this.setState({
      markedDates: markedDates,
    });



    const data = {
      userid: '7',
      pickupdate: day.dateString,
    };
    this.props.onUserAvailability(data, this.props.accessToken);
    this.setState({
      selectedTime: '',
    });
  };


  componentDidUpdate = prevProps => {
    if (
      prevProps.userAvailabilityStatus == false &&
      this.props.userAvailabilityStatus != prevProps.userAvailabilityStatus
    ) {
      this.setState({ stateUserAvailabilityList: this.props.userAvailabilityList })
      // alert(this.state.selecteTest.length);
    }

  };

  componentDidMount = () => {

    if (this.props.createOrderPickup != null) {
      const data = {
        userid: '7',
        pickupdate: this.props.createOrderPickup.date1,
      };
      this.props.onUserAvailability(data, this.props.accessToken);

      this.setState({
        markedDates: this.props.createOrderPickup.date,
        selectedTime: this.props.createOrderPickup.time,
        selectedDate: this.props.createOrderPickup.date1
      }, () => {
        console.log(this.props.createOrderPickup.date, this.props.createOrderPickup.time)
      });
    }
  };

  selectTimeHandler = val => {
    // alert(typeOf(val))
    this.setState({
      selectedTime: val,
    });
  };

  render() {
    return (
      <CreateOrderPickupDateScreen
        loading={
          this.props.insertOrderLoading || this.props.userAvailabilityLoading
        }
        nextButtonHandler={this.nextButtonHandler}
        getSelectedDayEvents={this.getSelectedDayEvents}
        markedDates={this.state.markedDates}
        selectTimeHandler={this.selectTimeHandler}
        //
        hour={this.state.hour}
        minutes={this.state.minutes}
        dateTime={this.state.dateTime}
        show={this.state.show}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        selectedTime={this.state.selectedTime}
        userAvailabilityList={this.state.stateUserAvailabilityList}

        isValidDate={this.state.isValidDate}
        isValidTime={this.state.isValidTime}
        dateValidMsg={this.state.dateValidMsg}
        timevalidMsg={this.state.timevalidMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
    accessToken: state.signIn.accessToken,
    basicDetailList: state.createOrder.basicDetail,
    referDetailList: state.createOrder.referDetail,
    addTestList: state.createOrder.addTest,
    createOrderPickup: state.createOrder.createOrderPickup,
    insertOrderStatus: state.createOrder.insertOrderStatus,
    insertOrderError: state.createOrder.insertOrderError,
    insertOrderLoading: state.createOrder.insertOrderLoading,
    insertOrderFailureResponse: state.createOrder.insertOrderFailureResponse,
    userAvailabilityList: state.createOrder.userAvailabilityResponse,
    userAvailabilityStatus: state.createOrder.userAvailabilityStatus,
    userAvailabilityLoading: state.createOrder.userAvailabilityLoading,
    UserID: state.signIn.userId,
    insertOrderTestMessage: state.createOrder.message,
    insertOrderresponsePDF: state.createOrder.insertOrderresponsePDF,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onInsertOrder: (data, token) => dispatch(insertOrder(data, token)),
    onUserAvailability: (data, token) => dispatch(userAvailability(data, token)),
    // onCreateOrderBasic: data => dispatch(createOrderBasic(data)),
    // onCreateOrderRefer: data => dispatch(createOrderRefer(data)),
    // onCreateOrderProduct: data => dispatch(createOrderProduct(data)),
    //onCreateOrderTest: data => dispatch(createOrderTest(data)),
    onCreateOrderPickup: data => dispatch(createOrderPickup(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateOrderPickupDate);
