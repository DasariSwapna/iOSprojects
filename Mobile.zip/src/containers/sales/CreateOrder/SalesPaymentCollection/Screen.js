import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import RootView from '../../../../components/RootView';

import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { NextButton } from '../../../../components/Button';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import Icon from 'react-native-vector-icons/FontAwesome';
import Feather from 'react-native-vector-icons/Feather';
import OtpModal, {
  ModalConfirmNumber,
  ModalSuccess,
  OtpModalPayment,
} from '../../../../components/OtpModal';
import { TouchableOpacity } from 'react-native-gesture-handler';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import { Toast } from '../../../../components/Toast';

function OtpButton({ otpHandler, isTransparent }) {
  return (
    <View>
      <TouchableOpacity
        disabled={!isTransparent}
        style={[
          {
            backgroundColor: Colors.card,
            paddingHorizontal: hp('3%'),
            paddingVertical: hp('1.5%'),
            borderRadius: hp('3%'),
            color: '#fff',

          },
          isTransparent && { backgroundColor: Colors.teal },
        ]}
        onPress={otpHandler}>
        <Text
          style={{
            fontFamily: Font.bold,
            fontSize: FontSize.medium,
            color: Colors.background,
          }}>
          OTP
        </Text>
      </TouchableOpacity>
    </View>
  );
}

function PaymentCollectionScreen({
  nextButtonHandler,

  cancelMobileConfirmHandler,
  okayMobileConfirmHandler,
  otpHandler,
  otpSubmitHandler,

  // states
  showMobileConfirmModal,
  showOtpPaymentModal,
  showSuccessModal,
  otpSteal,
  otpCard,
  otpButtonEnabled,
  otp,
  otpVerified,
  nextButtonEnable,


  showToast,
  toastMsg,

  otpChangeHandler,
  resendOtpHandler,

  paymentModeHandler,
  amountHandler,
  emailHandler,
  mobileNumberHandler,
  remarksHandler,

  paymentMode,
  amount,
  email,
  mobileNumber,
  remarks,

  isValidPayementMode,
  isValidAmount,
  isValidEmail,
  isValidMobileNumber,
  isValidRemarks,

  pamentModeValidMsg,
  amountValidMsg,
  emailIdValidMsg,
  mobileNumberValidMsg,
  remarksValidMsg,

  payementModeResponseList,
  loading
}) {
  return (
    <RootView pageNo={PageNo.sales_paymentCollection} loading={loading}>
      <Toast
        showToast={showToast}
        msg={toastMsg}
        bgColor={Colors.button}
        txtColor={Colors.background}
      />
      {showMobileConfirmModal === true && (
        <ModalConfirmNumber
          visible={showMobileConfirmModal}
          dismissHandler={cancelMobileConfirmHandler}
          cancelHandler={cancelMobileConfirmHandler}
          okayHandler={okayMobileConfirmHandler}
          title={'Confirm Mobile Number'}
          mobileNumber={mobileNumber}
          pageNumber={117}
        />
      )}
      {showOtpPaymentModal === true && (
        <OtpModalPayment
          visible={showOtpPaymentModal}
          dismissHandler={cancelMobileConfirmHandler}
          otpSubmitHandler={otpSubmitHandler}
          otpChangeHandler={otpChangeHandler}
          resendOtpHandler={resendOtpHandler}
          otp={otp}

        />
      )}
      {showSuccessModal === true && (
        <ModalSuccess
          visible={showSuccessModal}
          dismissHandler={cancelMobileConfirmHandler}
          title={'Success'}
          message={'Cash Collected'}
          pageNumber={'20'}
        />
      )}
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff',
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>
                <View style={{ marginTop: 30 }}></View>
                <View style={styles.textContainer}>
                  {/* <Text style={styles.textColorBlack}>Payment Mode</Text> */}
                  <DropDownMenu
                    labelName={'Payment Mode'}
                    labelKey={'lc_pt_payment_type_name'}
                    valueKey={'lc_pt_payment_type_id'}
                    Width={'100%'}
                    listItems={payementModeResponseList}
                    valueChangeHandler={paymentModeHandler}
                    color={Colors.border}
                  />
                  {!isValidPayementMode == true && (
                    <Text style={styles.textValidationMsg}>
                      {pamentModeValidMsg}
                    </Text>
                  )}
                </View>
                <TextInputComponent
                  labelName={'Amount'}
                  onChangeHandler={amountHandler}
                  keyboardType={'numeric'}
                  value={amount}
                  isValid={!isValidAmount}
                  validationMsg={amountValidMsg}
                  Width={'90%'}
                  maxLength={7}
                  color={Colors.border}

                />
                <TextInputComponent
                  labelName={'Email'}
                  onChangeHandler={emailHandler}
                  keyboardType={'default'}
                  value={email}
                  isValid={!isValidEmail}
                  validationMsg={emailIdValidMsg}
                  Width={'90%'}
                  color={Colors.border}

                />
                <View style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  width: '90%',
                  alignSelf: 'center',
                }}>
                  <TextInputComponent
                    labelName={'Mobile Number'}
                    onChangeHandler={mobileNumberHandler}
                    keyboardType={'number-pad'}
                    value={mobileNumber}
                    isValid={!isValidMobileNumber}
                    validationMsg={mobileNumberValidMsg}
                    Width={'60%'}
                    maxLength={10}
                    color={Colors.border}

                  />
                  {otpVerified ? (
                    <Feather
                      style={{ alignSelf: 'center', marginTop: hp('2%') }}
                      name="check"
                      size={hp('4%')}
                      color={Colors.teal}
                    />
                  ) : null}
                  <View style={{ alignSelf: 'center' }}>
                    <OtpButton
                      otpHandler={otpHandler}
                      color={Colors.teal}
                      isTransparent={otpButtonEnabled}
                    />
                  </View>
                </View>
                <TextInputComponent
                  labelName={I18n.t('sales.paymentCollection.remarks_label')}
                  onChangeHandler={remarksHandler}
                  keyboardType={'default'}
                  value={remarks}
                  isValid={!isValidRemarks}
                  validationMsg={remarksValidMsg}
                  Width={'90%'}
                  multiline={true}
                  mode={'outline'}
                  color={Colors.border}
                />
              </View>
            </ScrollView>
          </View>
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
            }}>
            {nextButtonEnable ?
              <View style={styles.buttonContainer}>
                <NextButton onPress={nextButtonHandler} />
              </View>
              : null}

          </View>
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '1000%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
  },
  textContainer: {
    width: '100%',
    alignSelf: 'center',
    justifyContent: 'space-evenly',
    marginTop: 5,
    height: hp('10$'),
    marginTop: hp('1%'),
  },
  textColorBlack: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  textColorPink: {
    borderBottomWidth: 2,
    borderBottomColor: Colors.card,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  textValidationMsg: {
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    marginVertical: hp('1%'),
  },
  textValidationMsg1: {
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    marginVertical: hp('1%'),
    marginHorizontal: wp('5%'),
  },
  // textColorBlack: {
  //   borderBottomWidth: 2,
  //   borderBottomColor: Colors.black,
  //   color: Colors.border,
  //   fontFamily: FontMagneta.thin,
  //   fontSize: FontSize.medium,
  // },
});

export default PaymentCollectionScreen;
