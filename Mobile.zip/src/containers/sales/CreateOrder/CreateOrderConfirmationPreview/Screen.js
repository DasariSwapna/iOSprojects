import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import DownloadImageComponent from '../../../../components/DownloadImageComponet';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import PageNo from '../../../../constants/PageNo';
import Pdf from 'react-native-pdf';
import {Toast} from '../../../../components/Toast';
import IonIcons from 'react-native-vector-icons/Ionicons';

function TextConatiner({leftText, rightText}) {
  return (
    <View style={{width: '100%', flexDirection: 'row'}}>
      <Text
        style={{
          flex: 1,
          paddingLeft: 25,
          paddingVertical: 5,
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>
        {leftText}
      </Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: 5,
          color: Colors.black,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>
        {rightText}
      </Text>
    </View>
  );
}

function CreateOrderSummaryScreen({
  addressTypeHandler,
  nextButtonHandler,
  data,
  source,
  showToast,
  errorMsg,
  shareButtonHandler,
  downloadButtonHandler,
}) {
  return (
    <RootView pageNo={PageNo.sales_createOrderConfirmation}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <View style={styles.mainContainer}>
        <View
          style={{
            borderColor: Colors.primary,
            backgroundColor: Colors.background,
            marginHorizontal: wp('5%'),
            marginVertical: hp('2%'),
            width: '90%',
            height: '65%',
            borderWidth: Platform.OS == 'ios' ? 0.2 : 0.6,
            borderRadius: 10,
            shadowColor: Colors.primary,
            shadowOffset: {
              width: 0,
              height: 3,
            },
            // shadowOpacity: 0.29,
            // shadowRadius: 4.65,
           //  elevation: 7,
            marginTop: hp('5%'),
          }}>
          <Pdf
            source={source}
            onLoadComplete={(numberOfPages, filePath) => {
              console.log(`Number of pages: ${numberOfPages}`);
            }}
            onPageChanged={(page, numberOfPages) => {
              console.log(`Current page: ${page}`);
            }}
            onError={error => {
              console.log(error);
            }}
            onPressLink={uri => {
              console.log(`Link pressed: ${uri}`);
            }}
            style={styles.pdf}
          />
        </View>
        <View
          style={{
            alignSelf: 'flex-end',
            flexDirection: 'row',
            width: wp('10%'),
            height: 40,
            alignItems: 'center',
            justifyContent: 'space-between',
            marginRight: hp('7%'),
            marginTop: hp('1%'),
          }}>
          <TouchableOpacity onPress={downloadButtonHandler}>
            <Image
              source={Images.download1}
              style={{width: hp('3%'), height: hp('3%'), marginRight: 8}}
              resizeMode="cover"
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={shareButtonHandler}>
            <IonIcons
              name={'share-social'}
              color={Colors.border}
              size={hp('3%')}
            />
          </TouchableOpacity>
        </View>
        <View style={{position: 'absolute', bottom: 0, alignSelf: 'center'}}>
          <Button
            title="Home page"
            buttonStyle={styles.buttonWithoutBorder}
            buttonTextStyle={styles.buttonStyleWhite}
            onPress={nextButtonHandler}
          />
        </View>
      </View>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',

    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  ////Buttons Style
  buttonPayContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '75%',
    alignSelf: 'center',
    marginTop: 100,
    alignSelf: 'center',
  },

  buttonWithoutBorder: {
    minWidth: hp('18%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
    alignSelf: 'center',
    marginBottom: 20,
  },
  buttonTextStylePink: {
    fontSize: FontSize.large,
    color: Colors.darkPink,
  },
  buttonStyleWhite: {
    fontSize: FontSize.large,
  },
  pdf: {
    marginVertical: wp('1%'),
    marginHorizontal: wp('1%'),
    width: '98%',
    height: '98%',
    backgroundColor: Colors.white,
  },
});

export default CreateOrderSummaryScreen;
