import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import CreateOrderConfirmationScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import {Share, PermissionsAndroid, Platform} from 'react-native';
import RNFetchBlob from 'rn-fetch-blob';
import {delay} from '../../../../utils/Helpers';
import {BackHandler} from 'react-native';

class CreateOrderConfirmationPreview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      source: {
        uri: this.props.PDFPreview,
        cache: true,
      },
      errorMsg: '',
      showToast: false,
    };
  }
  shareButtonHandler = async () => {
    const result = await Share.share({
      message: this.state.source.uri,
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
        // shared with activity type of result.activityType
      } else {
        // shared
      }
    } else if (result.action === Share.dismissedAction) {
      // dismissed
    }
  };

  actualDownloadiOS = () => {
    //  alert(JSON.stringify(this.props.data1.orderDetailsResModel.customerName));
    try {
      const {config, fs} = RNFetchBlob;
      let dirs = fs.dirs;
      let options = {
        fileCache: false,
        appendExt: 'pdf',
        path:
          dirs.DocumentDir +
          '/' +
          this.props.data1.orderDetailsResModel.customerName +
          '.pdf',
      };
      config(options)
        .fetch('GET', this.props.PDFPreview)
        .then(res => {
          // do some magic here
          // RNFetchBlob.ios.openDocument();
          this.setState(
            {
              errorMsg: I18n.t('valitation.iOS_download_path_msg'),
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );

          //  Downloding: On My iPhone =>Lifecell
          //  toastMsg(this.state.downloadtext);
          console.log('File download', res.path());
        });
    } catch (error) {
      console.log('File download error', error);
    }
  };

  async downloadFile() {
    console.log('plato', Platform.OS);

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload();
      } else {
        alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  actualDownload = () => {
    RNFetchBlob.fs
      .mkdir(RNFetchBlob.fs.dirs.SDCardDir + '/LifeCell')

      .then(() => {
        alert('created');
      })

      .catch(err => {
        console.log(err);
      });

    RNFetchBlob.fs
      .ls(RNFetchBlob.fs.dirs.SDCardDir)

      // files will an array contains filenames

      .then(files => {
        console.log(files);
      });

    const {dirs} = RNFetchBlob.fs;

    console.log(dirs);

    RNFetchBlob.config({
      fileCache: true,

      addAndroidDownloads: {
        useDownloadManager: true,

        notification: true,

        mediaScannable: true,

        title: this.props.data1.orderDetailsResModel.customerName,

        path:
          dirs.DownloadDir +
          '/' +
          this.props.data1.orderDetailsResModel.customerName +
          '.pdf',

        //  +''+this.state.PDF_name+".pdf"`,

        // path: `${dirs.DownloadDir}/this.state.PDF_name.pdf,
      },
    })

      .fetch('GET', this.props.PDFPreview, {})

      .then(res => {
        // toastMsg(this.state.downloadtext1);

        console.log('The file saved to ', res.path());
      })

      .catch(e => {
        console.log(e);
      });
  };

  downloadButtonHandler = async () => {
    {
      Platform.OS == 'ios' ? this.actualDownloadiOS() : this.downloadFile();
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.Create);
    this.props.navigation.reset({
      routes: [{name: Sales.myDrawer}],
    });
  };

  componentDidMount() {
    this.backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backAction,
    );
  }

  componentWillUnmount() {
    this.backHandler.remove();
  }

  backAction = () => {
    // Alert.alert("Hold on!", "Are you sure you want to go back?", [
    //   {
    //     text: "Cancel",
    //     onPress: () => null,
    //     style: "cancel"
    //   },
    //   { text: "YES", onPress: () => BackHandler.exitApp() }
    // ]);
    this.props.navigation.reset({
      routes: [{name: Sales.myDrawer}],
    });
    return true;
  };

  render() {
    return (
      <CreateOrderConfirmationScreen
        nextButtonHandler={this.nextButtonHandler}
        shareButtonHandler={this.shareButtonHandler}
        downloadButtonHandler={this.downloadButtonHandler}
        source={this.state.source}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        data={this.props.data}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    data: state.payementMode.insertpayementModeResponse,
    PDFdatas: state.payementMode.insertpayementModeResponsePDF,
    PDFPreview: state.createOrder.insertOrderresponsePDF,
    data1: state.createOrder.insertOrderResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateOrderConfirmationPreview);
