import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, { NextButton } from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/OrderDropDownMenu';
import Data from '../../../../constants/Data';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import { TouchableOpacity } from 'react-native-gesture-handler';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo'


function ReferalDetailsScreen({
  addressTypeHandler,
  nextButtonHandler,

  referredByHandler,
  hospiatlHandler,
  doctorHandler,
  remarksHandler,
  pickupTypeHandler,

  isValidReferredBy,
  isValidHospiatl,
  isValidDoctor,
  isValidRemarks,
  isValidPickupType,

  referredByValidMsg,
  hospiatlValidMsg,
  doctorValidMsg,
  remarksValidMsg,
  pickupTypeValidMsg,
  createVendorHandler,

  referredByList,
  hospitalList,
  pickUpTypeList,
  doctorNameList,

  showHospital,

  referredBy,
  hospiatl,
  doctor,
  remarks,
  pickupType,
}) {
  return (
    <RootView pageNo={PageNo.sales_createOrderReferDetails}>
      <KeyboardAvoidingView
        enabled
        style={{ flex: 1, backgroundColor: Colors.white }}
        contentContainerStyle={{ paddingBottom: 80 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 30}>
        <View
          style={{
            flex: 9,
            flexDirection: 'column',
          }}>
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={styles.contentContainer}
            showsVerticalScrollIndicator={false}>
            <View style={styles.mainContainer}>
              <TimeLineContainer
                status={2}
              />
              <View
                style={styles.lineLargeContainer}
              />
              <View
                style={{ marginTop: hp('1.5%') }}
              />
              <DropDownMenu
                labelName={I18n.t('sales.createOrder.select_referred_by_placeholder')}
                labelKey={'lc_RT_REFER_TYPE_NAME'}
                valueKey={'lc_RT_REFER_TYPE_ID'}
                listItems={referredByList}
                initValue={referredBy}
                valueChangeHandler={referredByHandler}
              />
              {!isValidReferredBy && (
                <Text style={styles.textValidationMsg}>
                  {!isValidReferredBy ? referredByValidMsg : ''}
                </Text>
              )}
              {showHospital ?
                <>
                  <DropDownMenu
                    labelName={I18n.t('sales.createOrder.select_hospital_placeholder')}
                    labelKey={'lc_VD_HOSPITALNAME'}
                    valueKey={'lc_VD_VENID'}
                    listItems={hospitalList}
                    initValue={hospiatl}
                    valueChangeHandler={hospiatlHandler}
                  />
                  {!isValidHospiatl && (
                    <Text style={styles.textValidationMsg}>
                      {!isValidHospiatl ? hospiatlValidMsg : ''}
                    </Text>
                  )}
                  <DropDownMenu
                    labelName={I18n.t('sales.createOrder.select_doctor_placeholder')}
                    labelKey={'lc_dd_fullname'}
                    valueKey={'lc_dd_doctorid'}
                    listItems={doctorNameList}
                    initValue={doctor}
                    valueChangeHandler={doctorHandler}
                  />
                  {!isValidDoctor && (
                    <Text style={styles.textValidationMsg}>
                      {!isValidDoctor ? doctorValidMsg : ''}
                    </Text>
                  )}
                </>
                : null}

              <View style={{ marginTop: -5 }} />

              <TextInputComponent
                labelName={I18n.t('sales.createOrder.remarks_placeholder')}
                //isValid={!isValidRemarks}
                // validationMsg={remarksValidMsg}
                onChangeHandler={remarksHandler}
                value={remarks}
              />
              {!isValidRemarks && (
                <Text style={styles.textValidationMsg}>
                  {!isValidRemarks ? remarksValidMsg : ''}
                </Text>
              )}
              {showHospital ?
                <>
                  <View style={{
                    flexDirection: 'row',
                    alignSelf: 'center',
                    justifyContent: 'center',
                    alignItems: 'center',
                    marginVertical: hp('2%')
                  }}>
                    <Text style={styles.textStyle}>Hospital/Dr. not availbale?</Text>
                    <TouchableOpacity style={{ marginLeft: hp('2%') }} onPress={createVendorHandler}>
                      <Text style={styles.textStyleTeal}>{I18n.t('sales.createOrder.add_doctor_label')}</Text>
                    </TouchableOpacity>
                  </View>
                  <View
                    style={styles.lineLargeContainer}
                  />
                </>
                : null}
              <DropDownMenu
                labelName={I18n.t('sales.createOrder.select_pickup_placeholder')}
                labelKey={'lc_PT_NAME'}
                valueKey={'lc_PT_ID'}
                listItems={pickUpTypeList}
                initValue={pickupType}
                valueChangeHandler={pickupTypeHandler}
              />
              {!isValidPickupType && (
                <Text style={styles.textValidationMsg}>
                  {!isValidPickupType ? pickupTypeValidMsg : ''}
                </Text>
              )}
            </View>
          </ScrollView>
        </View>
        {/* Bottom Container */}
        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'center'
          }}>
          <View
            style={styles.buttonContainer}>
            <NextButton
              onPress={nextButtonHandler} />
          </View>
        </View>
        {/* Bottom Container */}
      </KeyboardAvoidingView>
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff'
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff'
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center'
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
    marginTop: ('1.5%')
  },
  textStyle: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    alignSelf: 'center',
    // paddingVertical: 15
  },
  textStyleTeal: {
    color: Colors.teal,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    alignSelf: 'center',

  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
  },

});

export default ReferalDetailsScreen;
