import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import ReferalDetailsScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import {
  validateEmpty,
  validateRadioEmpty,
  validateRemarksEmpty,
} from '../../../../utils/Validators';
import HelperText from '../../../../constants/HelperText';

import {
  getDoctorName,
  getHospital,
  getPickupType,
  getReferredBy,
  createOrderRefer,
  insertHospitalDoctor,
} from '../../../../store/Actions';

class ReferalDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      referredBy: '',
      hospiatl: '',
      doctor: '',
      remarks: '',
      pickupType: '',

      isValidReferredBy: true,
      isValidHospiatl: true,
      isValidDoctor: true,
      isValidRemarks: true,
      isValidPickupType: true,

      referredByValidMsg: '',
      hospiatlValidMsg: '',
      doctorValidMsg: '',
      remarksValidMsg: 'hii',
      pickupTypeValidMsg: '',

      showHospital: false,
    };
  }

  validateReferBy = () => {
    const valid1 = validateRadioEmpty(this.state.referredBy);
    const valid2 = validateRadioEmpty(this.state.hospiatl);
    const valid3 = validateRadioEmpty(this.state.doctor);

    if (
      valid1.val &&
      this.state.referredBy != '1' &&
      this.state.referredBy != '2'
    ) {
      // alert('hii')
      if (valid2.val && valid3.val) {
        this.setState({
          isValidHospiatl: valid2.val,
          hospiatlValidMsg: '',
          isValidDoctor: valid3.val,
          doctorValidMsg: '',
        });
        return true;
      } else {
        this.setState({
          isValidHospiatl: valid2.val,
          hospiatlValidMsg: 'Please select hospital',
          isValidDoctor: valid3.val,
          doctorValidMsg: 'Please select doctor',
        });
        return false;
      }
    } else {
      this.setState({
        isValidHospiatl: false,
        hospiatlValidMsg: '',
        isValidDoctor: false,
        doctorValidMsg: '',
      });
    }
    return true;
  };

  nextButtonHandler = () => {
    //  this.props.navigation.navigate(Sales.createOrderAddTest);

    const valid1 = validateRadioEmpty(this.state.referredBy);
    //  const valid4 = validateRemarksEmpty(this.state.remarks);
    const valid5 = validateRadioEmpty(this.state.pickupType);

    var isReferBy = this.validateReferBy();

    if (
      valid1.val &&
      // valid4.val &&
      valid5.val &&
      isReferBy
    ) {
      this.setState({
        isValidReferredBy: valid1.val,
        referredByValidMsg: '',
        // isValidRemarks: valid4.val,
        // remarksValidMsg: '',
        isValidPickupType: valid5.val,
        pickupTypeValidMsg: '',
      });
      this.saveData();
    } else {
      this.setState({
        isValidReferredBy: valid1.val,
        referredByValidMsg: 'Please select referral',
        // isValidRemarks: valid4.val,
        // remarksValidMsg: valid4.msg,
        isValidPickupType: valid5.val,
        pickupTypeValidMsg: 'Please select pickup type',
      });
    }

    console.log(valid1.val, valid5.val, isReferBy);
  };

  saveData = () => {
    const data = {
      hospitalid: this.state.hospiatl,
      doctorid: this.state.doctor,
      remarks: this.state.remarks,
      pickupid: this.state.pickupType,
      referid: this.state.referredBy,
    };
    this.props.onCreateOrderRefer(data);

    if (this.state.referredBy == '1' || this.state.referredBy == '2') {
      this.props.navigation.navigate(Sales.createOrderAddTest, {
        NO_REFERRAL: true,
      });
    } else {
      this.props.navigation.navigate(Sales.createOrderAddTest, {
        NO_REFERRAL: false,
      });
    }
  };

  componentDidMount = () => {

    this.props.navigation.addListener(
      'focus',
      payload => {
        const data = {
          search: null,
        };
        this.props.onGetHospital(data, this.props.accessToken);
        this.props.onGetReferredBy(null, this.props.accessToken);
        this.props.onGetPickupType(null, this.props.accessToken);

        if (this.props.referDetail != null) {
          this.setState({
            referredBy: this.props.referDetail.referid,
            hospiatl: this.props.referDetail.hospitalid,
            doctor: this.props.referDetail.doctorid,
            remarks: this.props.referDetail.remarks,
            pickupType: this.props.referDetail.pickupid,
          });
        }
        // else {
        //   const data = {
        //     search: null,
        //   };
        //   this.props.onGetHospital(data, this.props.accessToken);
        //   this.props.onGetReferredBy(null, this.props.accessToken);
        //   this.props.onGetPickupType(null, this.props.accessToken);
        // }
      }
    );



  };

  referredByHandler = val => {
    // alert(val)
    this.setState({
      referredBy: val,
    });

    if (val == '1' || val == '2') {
      this.setState({
        showHospital: false,
        hospiatl: '',
        doctor: '',
      });
    } else {
      //alert('hii')
      this.setState({
        showHospital: true,
        //  hospiatl: '',
        //  doctor: '',
      });
    }
  };

  hospiatlHandler = val => {
    this.setState({
      hospiatl: val,
    });

    const doctorData = {
      hostpitalid: val,
    };
    // alert(JSON.stringify(cityData));
    this.props.onGetDoctor(doctorData, this.props.accessToken);
  };

  doctorHandler = val => {
    this.setState({
      doctor: val,
    });
  };

  remarksHandler = val => {
    this.setState({
      remarks: val,
    });
  };

  pickupTypeHandler = val => {
    this.setState({
      pickupType: val,
    });
  };

  createVendorHandler = () => {
    const data = {
      createOrder: true,
    };
    this.props.OnInsertHospitalDoctor(data);
    this.props.navigation.navigate(Sales.createVendorBasicDetails);
  };

  render() {
    return (
      <ReferalDetailsScreen
        nextButtonHandler={this.nextButtonHandler}
        referredByHandler={this.referredByHandler}
        hospiatlHandler={this.hospiatlHandler}
        doctorHandler={this.doctorHandler}
        remarksHandler={this.remarksHandler}
        pickupTypeHandler={this.pickupTypeHandler}
        isValidReferredBy={this.state.isValidReferredBy}
        isValidHospiatl={this.state.isValidHospiatl}
        isValidDoctor={this.state.isValidDoctor}
        isValidRemarks={this.state.isValidRemarks}
        isValidPickupType={this.state.isValidPickupType}
        referredByValidMsg={this.state.referredByValidMsg}
        hospiatlValidMsg={this.state.hospiatlValidMsg}
        doctorValidMsg={this.state.doctorValidMsg}
        remarksValidMsg={this.state.remarksValidMsg}
        pickupTypeValidMsg={this.state.pickupTypeValidMsg}
        createVendorHandler={this.createVendorHandler}
        referredBy={this.state.referredBy}
        hospiatl={this.state.hospiatl}
        doctor={this.state.doctor}
        remarks={this.state.remarks}
        pickupType={this.state.pickupType}
        referredByList={this.props.referredByList}
        hospitalList={this.props.hospitalList}
        pickUpTypeList={this.props.pickUpTypeList}
        doctorNameList={this.props.doctorNameList}
        showHospital={this.state.showHospital}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    referredByList: state.common.referredbyResponse,
    hospitalList: state.common.hospitalResponse,
    doctorNameList: state.common.doctorNameResponse,
    pickUpTypeList: state.common.pickupTypeResponse,
    accessToken: state.signIn.accessToken,
    referDetail: state.createOrder.referDetail,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetReferredBy: (data, token) => dispatch(getReferredBy(data, token)),
    onGetHospital: (data, token) => dispatch(getHospital(data, token)),
    onGetPickupType: (data, token) => dispatch(getPickupType(data, token)),
    onGetDoctor: (data, token) => dispatch(getDoctorName(data, token)),
    onCreateOrderRefer: data => dispatch(createOrderRefer(data)),
    OnInsertHospitalDoctor: data => dispatch(insertHospitalDoctor(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ReferalDetails);
