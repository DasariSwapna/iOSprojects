import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import {
  isValidUsername,
  isValidPassword,
  validateFirstname,
  validateLastname,
  validateRadioEmpty,
  validatePrimaryContMobNo,
  validateAltContMobNo,
} from '../../../../utils/Validators';
import BasicDetailScreen from './Screen';
import { Sales } from '../../../../navigations/RouteTypes';
import {
  validateEmpty,
  validateName,
  validateMobileNo,
  validateEmail1,
  validateUsername,
  validateAddressLine,
  validatePincodeEmpty,
  validateState,
  validateCity,
  validateStateDropdownEmpty,
  validateCityDropdownEmpty,
  validateMatchMobileNo,
} from '../../../../utils/Validators';
import HelperText from '../../../../constants/HelperText';
import {
  getState,
  getCity,
  getAddressType,
  createOrderBasic,
  getPatientDetails,
  storeAddress,
} from '../../../../store/Actions';
import { delay } from '../../../../utils/Helpers';

class BasicDetail extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: '',
      lastName: '',
      primaryContact: '',
      alternateContact: '',
      emailId: '',
      addressType: '',
      address: '',
      state: '',
      city: '',
      pincode: '',

      isValidFirstname: true,
      isValidLastName: true,
      isValidPrimaryContact: true,
      isValidAlternateContact: true,
      isValidEmailId: true,
      isValidAddressType: true,
      isValidAddress: true,
      isValidState: true,
      isValidCity: true,
      isValidPincode: true,

      firstNameValidMsg: '',
      lastNameValidMsg: '',
      primaryConatctValidMsg: '',
      alternateContactValidMsg: '',
      emailIdValidMsg: '',
      addressTypeValidMsg: '',
      addressValidMsg: '',
      stateValidMsg: '',
      cityValidMsg: '',
      pincodeValidMsg: '',

      showToast: false,
      errorMsg: '',
    };
  }

  validateAlternateNo = () => {
    if (this.state.alternateContact != '') {
      const valid4 = validateAltContMobNo(this.state.alternateContact);
      if (valid4.val) {
        this.setState({
          isValidAlternateContact: valid4.val,
          alternateContactValidMsg: '',
        });
        return true;
      } else {
        this.setState({
          isValidAlternateContact: valid4.val,
          alternateContactValidMsg: valid4.msg,
        });
        return false;
      }
    }
    return true;
  };

  validateMatchNo = () => {
    if (this.state.primaryContact != '' && this.state.alternateContact != '') {
      const valid1 = validateMatchMobileNo(
        this.state.primaryContact,
        this.state.alternateContact,
      );
      if (valid1.val) {
        return true;
      } else {
        this.setState(
          {
            errorMsg: valid1.msg,
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );

        return false;
      }
      return true;
    }
    return true;
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createOrderReferalDetails);
    // /alert(typeof (this.state.address))
    const valid1 = validateFirstname(String(this.state.firstName));
    const valid2 = validateLastname(String(this.state.lastName));
    const valid3 = validatePrimaryContMobNo(String(this.state.primaryContact));
    // const valid4 = validateAltContMobNo(this.state.alternateContact);

    const valid5 = validateEmail1(String(this.state.emailId));

    const valid6 = validateRadioEmpty(String(this.state.addressType));
    const valid7 = validateAddressLine(String(this.state.address));
    const valid8 = validateStateDropdownEmpty(String(this.state.state));

    const valid9 = validateCityDropdownEmpty(String(this.state.city));
    const valid10 = validatePincodeEmpty(String(this.state.pincode));

    var isMatchNo = this.validateMatchNo();
    var isValAltNo = this.validateAlternateNo();

    if (
      valid1.val &&
      valid2.val &&
      valid3.val &&
      // valid4.val &&
      valid5.val &&
      valid6.val &&
      valid7.val &&
      valid8.val &&
      valid9.val &&
      valid10.val &&
      isMatchNo &&
      isValAltNo
    ) {
      this.setState({
        isValidFirstname: valid1.val,
        firstNameValidMsg: '',
        isValidLastName: valid2.val,
        lastNameValidMsg: '',
        isValidPrimaryContact: valid3.val,
        primaryConatctValidMsg: '',
        //  isValidAlternateContact: valid4.val,
        //  alternateContactValidMsg: '',
        isValidEmailId: valid5.val,
        emailIdValidMsg: '',

        isValidAddressType: valid6.val,
        addressTypeValidMsg: '',
        isValidAddress: valid7.val,
        addressValidMsg: '',
        isValidState: valid8.val,
        stateValidMsg: '',
        isValidCity: valid9.val,
        cityValidMsg: '',
        isValidPincode: valid10.val,
        pincodeValidMsg: '',
      });
      this.saveData();
    } else {
      this.setState({
        isValidFirstname: valid1.val,
        firstNameValidMsg: valid1.msg,
        isValidLastName: valid2.val,
        lastNameValidMsg: valid2.msg,
        isValidPrimaryContact: valid3.val,
        primaryConatctValidMsg: valid3.msg,
        //  isValidAlternateContact: valid4.val,
        // alternateContactValidMsg: valid4.msg,
        isValidEmailId: valid5.val,
        emailIdValidMsg: valid5.msg,

        isValidAddressType: valid6.val,
        addressTypeValidMsg: 'Please select address type',

        isValidAddress: valid7.val,
        addressValidMsg: valid7.msg,

        isValidState: valid8.val,
        stateValidMsg: valid8.msg,
        isValidCity: valid9.val,
        cityValidMsg: valid9.msg,
        isValidPincode: valid10.val,
        pincodeValidMsg: valid10.msg,
      });
    }
  };

  saveData = () => {

    const data = {
      patient_firstname: this.state.firstName,
      patient_lastname: this.state.lastName,
      primarycontact: this.state.primaryContact,
      alternatecontact: this.state.alternateContact,
      email: this.state.emailId,
      addresstype: this.state.addressType,
      address: this.state.address,
      city: this.state.city,
      state: this.state.state,
      pincode: this.state.pincode,
      lattitude: this.props.address != null ?
        this.props.address.latitude :
        this.props.patientDetailsResponse[0].LC_PBA_LATTITUDE,
      longitude: this.props.address != null ?
        this.props.address.longitude :
        this.props.patientDetailsResponse[0].LC_PBA_LONGITUDE,
    };
    this.props.onCreateOrderBasic(data);
    this.props.navigation.navigate(Sales.createOrderReferalDetails);
  };

  firstNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        firstName: val,
      });
    }
  };

  lastNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        lastName: val,
      });
    }
  };

  primaryContactHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      if (val.length > 9) {
        this.setState({
          primaryContact: val,
        });
        const data2 = { mobilenumber: val };
        this.props.onGetPatientDetails(data2, this.props.accessToken);
      } else {
        this.setState({
          primaryContact: val,
        });
      }
    }
  };

  alternateContactHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      this.setState({
        alternateContact: val,
      });
    }
  };

  emailIdHandler = val => {
    this.setState({
      emailId: val,
    });
  };

  addressTypeHandler = val => {
    this.setState({
      addressType: val,
    });
  };

  addressHandler = val => {
    this.setState({
      address: val,
    });
  };

  stateHandler = val => {
    this.setState({
      state: val,
    });

    const cityData = {
      stateid: val,
      search: null,
    };
    //alert(JSON.stringify(cityData));
    this.props.onGetCity(cityData, this.props.accessToken);
    this.setState({
      city: '',
    });
  };

  cityHandler = val => {
    this.setState({
      city: val,
    });
  };

  pincodeHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      this.setState({
        pincode: val,
      });
    }
  };
  mapnavigation = () => {
    this.props.navigation.navigate(Sales.Address);
  };



  componentDidMount = () => {
    // this.props.onStoreAddress({}, null);
    const data = {
      search: null,
    };
    this.props.onGetState(data, this.props.accessToken);
    this.props.onGetAddressType(null, this.props.accessToken);

    if (this.props.basicDetail != null) {
      this.setState({
        firstName: this.props.basicDetail.patient_firstname,
        lastName: this.props.basicDetail.patient_lastname,
        primaryContact: this.props.basicDetail.primarycontact,
        alternateContact: this.props.basicDetail.alternatecontact,
        emailId: this.props.basicDetail.email,
        addressType: this.props.basicDetail.addresstype,
        address: this.props.basicDetail.address,
        state: this.props.basicDetail.state,
        city: this.props.basicDetail.city,
        pincode: this.props.basicDetail.pincode,
      });
    }
    this.unsubscribe = this.props.navigation.addListener('focus', () => {
      if (this.props.address && Object.keys(this.props.address).length != 0) {
        this.setState({
          pincode: this.props.address.pincode,
          address: this.props.address.addrFirstLine,
        });
      }
    });
  };

  updateCity = (val) => {
    setTimeout(() => { this.setState({ city: val }) }, 100);

  }



  componentDidUpdate = prevProps => {
    if (
      prevProps.address &&
      prevProps.address.addrFirstLine !== this.props.address.addrFirstLine
    ) {
      this.setState({
        pincode: '',
        address: '',
      });
    }
    if (
      prevProps.stateError == false &&
      this.props.stateError != prevProps.stateError
    ) {
      // alert(this.props.stateList);
    }

    if (
      prevProps.patientDetailsStatus == false &&
      this.props.patientDetailsStatus != prevProps.patientDetailsStatus
    ) {
      if (this.props.patientDetailsResponse.length > 0) {
        this.setState({
          firstName: this.props.patientDetailsResponse[0].LC_PD_FIRSTNAME,
          lastName: this.props.patientDetailsResponse[0].LC_PD_LASTNAME,
          primaryContact: this.props.patientDetailsResponse[0].LC_PD_PRIMARYCONTACT,
          alternateContact: this.props.patientDetailsResponse[0].LC_PD_ALTERNATECONTACT,
          emailId: this.props.patientDetailsResponse[0].LC_PD_EMAILID,
          addressType: this.props.patientDetailsResponse[0].LC_ATE_ADDRESS_TYPE_ID,
          address: this.props.patientDetailsResponse[0].LC_PD_PATIENTADDRESS,
          state: this.props.patientDetailsResponse[0].LC_PD_STATE_ID,
          //city: this.props.patientDetailsResponse[0].LC_PD_CITYID,
          pincode: this.props.patientDetailsResponse[0].LC_PD_PINCODE,
        },
          this.updateCity(this.props.patientDetailsResponse[0].LC_PD_CITYID)
        )

      }
    }
    if (
      prevProps.address &&
      prevProps.address.addrFirstLine !== this.props.address.addrFirstLine
    ) {
      this.setState({
        pincode: this.props.address.pincode,
        address: this.props.address.addrFirstLine,
      });
    }
  };

  render() {
    return (
      <BasicDetailScreen
        loading={this.props.patientDetailsLoading}
        nextButtonHandler={this.nextButtonHandler}
        firstNameHandler={this.firstNameHandler}
        lastNameHandler={this.lastNameHandler}
        primaryContactHandle={this.primaryContactHandler}
        alternateContactHandler={this.alternateContactHandler}
        emailIdHandler={this.emailIdHandler}
        addressTypeHandler={this.addressTypeHandler}
        addressHandler={this.addressHandler}
        stateHandler={this.stateHandler}
        cityHandler={this.cityHandler}
        pincodeHandler={this.pincodeHandler}
        mapnavigation={this.mapnavigation}
        isValidFirstname={this.state.isValidFirstname}
        isValidLastName={this.state.isValidLastName}
        isValidPrimaryContact={this.state.isValidPrimaryContact}
        isValidAlternateContact={this.state.isValidAlternateContact}
        isValidEmailId={this.state.isValidEmailId}
        isValidAddressType={this.state.isValidAddressType}
        isValidAddress={this.state.isValidAddress}
        isValidState={this.state.isValidState}
        isValidCity={this.state.isValidCity}
        isValidPincode={this.state.isValidPincode}
        firstNameValidMsg={this.state.firstNameValidMsg}
        lastNameValidMsg={this.state.lastNameValidMsg}
        primaryConatctValidMsg={this.state.primaryConatctValidMsg}
        alternateContactValidMsg={this.state.alternateContactValidMsg}
        emailIdValidMsg={this.state.emailIdValidMsg}
        addressTypeValidMsg={this.state.addressTypeValidMsg}
        addressValidMsg={this.state.addressValidMsg}
        stateValidMsg={this.state.stateValidMsg}
        cityValidMsg={this.state.cityValidMsg}
        pincodeValidMsg={this.state.pincodeValidMsg}
        stateList={this.props.stateList}
        cityList={this.props.cityList}
        addressTypeList={this.props.addressTypeList}
        firstName={this.state.firstName}
        lastName={this.state.lastName}
        primaryContact={this.state.primaryContact}
        alternateContact={this.state.alternateContact}
        emailId={this.state.emailId}
        address={this.state.address}
        addressType={this.state.addressType}
        state={this.state.state}
        city={this.state.city}
        pincode={this.state.pincode}
        address={this.state.address}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        mapnavigation={this.mapnavigation}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    address: state.common.address,
    stateList: state.common.stateResponse,
    cityList: state.common.cityResponse,
    address: state.common.address,
    cityStatus: state.common.cityStatus,
    addressTypeList: state.common.addressTypeResponse,
    accessToken: state.signIn.accessToken,
    basicDetail: state.createOrder.basicDetail,
    patientDetailsResponse: state.createOrder.patientDetailsResponse,
    patientDetailsLoading: state.createOrder.patientDetailsLoading,
    patientDetailsStatus: state.createOrder.patientDetailsStatus,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetState: (data, token) => dispatch(getState(data, token)),
    onCreateOrderBasic: data => dispatch(createOrderBasic(data)),
    onGetCity: (data, token) => dispatch(getCity(data, token)),
    onGetAddressType: (data, token) => dispatch(getAddressType(data, token)),
    onGetPatientDetails: (data, token) =>
      dispatch(getPatientDetails(data, token)),
    onStoreAddress: (data, token) => dispatch(storeAddress(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BasicDetail);
