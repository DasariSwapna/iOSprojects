import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/OrderDropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import {NextButton} from '../../../../components/Button';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import HelperText from '../../../../constants/HelperText';
import {Toast} from '../../../../components/Toast';

function BasicDetailScreen({
  nextButtonHandler,

  firstNameHandler,
  lastNameHandler,
  primaryContactHandle,
  alternateContactHandler,
  emailIdHandler,
  addressTypeHandler,
  addressHandler,
  stateHandler,
  cityHandler,
  pincodeHandler,
  mapnavigation,

  isValidFirstname,
  isValidLastName,
  isValidPrimaryContact,
  isValidAlternateContact,
  isValidEmailId,
  isValidAddressType,
  isValidAddress,
  isValidState,
  isValidCity,
  isValidPincode,

  firstNameValidMsg,
  lastNameValidMsg,
  primaryConatctValidMsg,
  alternateContactValidMsg,
  emailIdValidMsg,
  addressTypeValidMsg,
  addressValidMsg,
  stateValidMsg,
  cityValidMsg,
  pincodeValidMsg,

  stateList,
  cityList,
  addressTypeList,

  firstName,
  lastName,
  pincode,
  primaryContact,
  alternateContact,
  emailId,
  address,
  addressType,
  state,
  city,
  showToast,
  errorMsg,
  loading,
}) {
  return (
    <RootView pageNo={PageNo.sales_createOrder} loading={loading}>
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 60 : 70}>
        <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <TimeLineContainer status={1} />
            <TextInputComponent
              labelName={'First name*'}
              //isValid={!isValidFirstname}
              // validationMsg={firstNameValidMsg}
              onChangeHandler={firstNameHandler}
              keyboardType={'default'}
              value={firstName}
            />
            {!isValidFirstname && (
              <Text style={styles.textValidationMsg}>
                {!isValidFirstname ? firstNameValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={'Last name*'}
              // isValid={!isValidLastName}
              // validationMsg={lastNameValidMsg}
              onChangeHandler={lastNameHandler}
              keyboardType={'default'}
              value={lastName}
            />
            {!isValidLastName && (
              <Text style={styles.textValidationMsg}>
                {!isValidLastName ? lastNameValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t(
                'sales.createOrder.patient_contact_placeholder',
              )}
              //isValid={!isValidPrimaryContact}
              //  validationMsg={primaryConatctValidMsg}
              onChangeHandler={primaryContactHandle}
              keyboardType={'number-pad'}
              maxLength={10}
              value={primaryContact}
            />
            {!isValidPrimaryContact && (
              <Text style={styles.textValidationMsg}>
                {!isValidPrimaryContact ? primaryConatctValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t(
                'sales.createOrder.alternate_contact_placeholder',
              )}
              // isValid={!isValidAlternateContact}
              // validationMsg={alternateContactValidMsg}
              onChangeHandler={alternateContactHandler}
              keyboardType={'number-pad'}
              maxLength={10}
              value={alternateContact}
            />
            {!isValidAlternateContact && (
              <Text style={styles.textValidationMsg}>
                {!isValidAlternateContact ? alternateContactValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t('sales.createOrder.email_id_placeholder')}
              // isValid={!isValidEmailId}
              // validationMsg={emailIdValidMsg}
              onChangeHandler={emailIdHandler}
              keyboardType={'default'}
              value={emailId}
            />
            {!isValidEmailId && (
              <Text style={styles.textValidationMsg}>
                {!isValidEmailId ? emailIdValidMsg : ''}
              </Text>
            )}
            <DropDownMenu
              labelName={I18n.t('sales.createOrder.address_type_placeholder')}
              labelKey={'lc_ATE_ADDRESS_TYPE_NAME'}
              valueKey={'lc_ATE_ADDRESS_TYPE_ID'}
              listItems={addressTypeList}
              outline={false}
              initValue={addressType}
              valueChangeHandler={addressTypeHandler}
            />
            {!isValidAddressType && (
              <Text style={styles.textValidationMsg}>
                {!isValidAddressType ? addressTypeValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t('sales.createOrder.address_placeholder')}
              // isValid={!isValidAddress}
              //  validationMsg={addressValidMsg}
              onChangeHandler={addressHandler}
              multliline={false}
              value={address}
              isExtra={true}
              iconPressed={() => mapnavigation()}
              editable={false}
            />
            {!isValidAddress && (
              <Text style={styles.textValidationMsg}>
                {!isValidAddress ? addressValidMsg : ''}
              </Text>
            )}
            <DropDownMenu
              labelName={I18n.t('sales.createOrder.select_state_placeholder')}
              labelKey={'lc_SM_STATE_NAME'}
              valueKey={'lc_SM_ID'}
              listItems={stateList}
              outline={false}
              initValue={state}
              valueChangeHandler={stateHandler}
            />
            {!isValidState && (
              <Text style={styles.textValidationMsg}>
                {!isValidState ? stateValidMsg : ''}
              </Text>
            )}
            <DropDownMenu
              labelName={I18n.t('sales.createOrder.select_city_placeholder')}
              labelKey={'lc_CM_CITY_NAME'}
              valueKey={'lc_CM_ID'}
              listItems={cityList}
              outline={false}
              initValue={city}
              valueChangeHandler={cityHandler}
            />
            {!isValidCity && (
              <Text style={styles.textValidationMsg}>
                {!isValidCity ? cityValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t('sales.createOrder.pincode_placeholder')}
              // isValid={!isValidPincode}
              // validationMsg={pincodeValidMsg}
              onChangeHandler={pincodeHandler}
              value={pincode}
              keyboardType={'number-pad'}
              maxLength={6}
            />
            {!isValidPincode && (
              <Text style={styles.textValidationMsg}>
                {!isValidPincode ? pincodeValidMsg : ''}
              </Text>
            )}
            <View style={styles.buttonContainer}>
              <NextButton onPress={nextButtonHandler} />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
    marginTop: 60,
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 15,
    paddingVertical: 4,
  },
});

export default BasicDetailScreen;

// mano@iSolve.global
//iSolve@123
