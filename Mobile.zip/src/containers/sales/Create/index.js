import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import CreateScreen from './Screen';
import { Paramedic, Sales } from '../../../navigations/RouteTypes';
import {
  createVendorTerms,
  createVendorAddTest,
  createOrderBasic,
  createOrderRefer,
  createOrderProduct,
  createOrderTest,
  createOrderPickup,
  insertHospitalDoctor,
  storeAddress
} from '../../../store/Actions';

class Create extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
    };
  }

  componentDidMount = () => {
    this.props.onCreateVendorTerms(null);
  };

  createOrderHandler = () => {
    this.props.onCreateOrderBasic(null);
    this.props.onCreateOrderRefer(null);
    this.props.onCreateOrderProduct(null);
    this.props.onCreateOrderTest(null);
    this.props.onCreateOrderPickup(null);
    this.props.onStoreAddress(null, null);

    this.props.navigation.navigate(Sales.createOrderBasicDetails);
    //  this.props.navigation.navigate(Sales.createOrderSummary);
  };

  createVendorHandler = () => {
    const data = {
      producttestDetails: null,
      productDetails: null,
      invoiceAmount: '',
      productSelectionindex: '',
      totalTestSelected: '',
      totalTestOutliners: '',
      totalTestAutoApproved: '',
    };

    this.props.OnInsertHospitalDoctor(null);
    this.props.onCreateVendorAddTest(data);
    this.props.navigation.navigate(Sales.createVendorBasicDetails);
  };

  render() {
    return (
      <CreateScreen
        createOrderHandler={this.createOrderHandler}
        createVendorHandler={this.createVendorHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    onCreateVendorTerms: data => dispatch(createVendorTerms(data)),
    onCreateVendorAddTest: data => dispatch(createVendorAddTest(data)),

    onCreateOrderBasic: data => dispatch(createOrderBasic(data)),
    onCreateOrderRefer: data => dispatch(createOrderRefer(data)),
    onCreateOrderProduct: data => dispatch(createOrderProduct(data)),
    onCreateOrderTest: data => dispatch(createOrderTest(data)),
    onCreateOrderPickup: data => dispatch(createOrderPickup(data)),
    OnInsertHospitalDoctor: data => dispatch(insertHospitalDoctor(data)),
    onStoreAddress: (data, token) => dispatch(storeAddress(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Create);
