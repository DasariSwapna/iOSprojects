import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,

} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Icons from '../../../constants/Icons';
import TaskType from '../../../components/TaskType';
import BottomNav from '../../../components/BottomNav';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

//Icons.createOrder


const { width, height } = Dimensions.get('screen');
const barWidth = width * 0.72;
const barHeight = height * 0.054;

function Box({ imgSrc, title, onClick, styll }) {
  return (

    <TouchableOpacity onPress={onClick}
      style={[styll, {
        alignItems: 'center',
        justifyContent: 'space-between',
        shadowColor: '#000',
        shadowOpacity: Platform.OS=='ios'?0.2: 0.5,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 2.5,
        elevation: Platform.OS=='ios'?1:5,
        backgroundColor: 'white',
        width: hp('18%'),
        borderRadius: hp('3%'),
      }]}>
      <Image
        source={imgSrc}
        style={{
          width: barHeight,
          height: barHeight,
          resizeMode: 'contain',
          marginVertical: hp('1%')
        }}
      />
      <Text
        style={{
          fontFamily: Font.regular,
          color: Colors.black,
          fontSize: FontSize.medium,
          marginTop: hp('2%'),
          marginBottom: hp('1.5%')
        }}>
        {title}
      </Text>

    </TouchableOpacity>

  )
}



function CreateScreen({
  createOrderHandler,
  createVendorHandler,

}) {
  return (
    <RootView pageNo={'13-A'} isPageWhite>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View style={{
              flexDirection: 'row',
              justifyContent: 'space-between',
              marginTop: hp('5%'),
              // width: '75%',
              alignSelf: 'center',
              // backgroundColor: 'red'
            }}>
              <Box
                title={'Create Order'}
                imgSrc={Icons.createOrder}
                onClick={createOrderHandler}
                styll={{ marginRight: hp('2%') }}
              />
              <Box
                title={'Create vendor'}
                imgSrc={Icons.createVendor}
                onClick={createVendorHandler}
                styll={{ marginLeft: hp('2%') }}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    flex: 1,
    width: '100%',
    paddingBottom: 62,
    backgroundColor: Colors.white,
  },

  bottomContainer: {
    alignItems: 'center',
  },
});

export default CreateScreen;
