import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import CashCollect_DepositScreen from './Screen';
import { Sales } from '../../../navigations/RouteTypes';
import { getDepositCash } from '../../../store/Actions';
import { BackHandler } from 'react-native';

var Qrcode = '';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      isValidUsername: true,
      isValidPassword: true,
      showToast: false,
      isPending: 0,
      dropdownValue: '',
      radio: false,
      receivecash: 0,
      pendingResponse: [],
      completedResponse: [],
      loading:''
    };
  }

  componentDidMount = () => {
    const data = {
      userid: this.props.userId,
    };

    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.getDepositCash(data, this.props.accessToken);
    });
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidUpdate = prevProps => {
    if (
      prevProps.cashDepositStatus == false &&
      this.props.cashDepositStatus != prevProps.cashDepositStatus
    ) {
      try {
        // alert(this.props.response.properties.Pending)
        const data = this.props.response.properties.Pending.map(item => {
          item.selected = false;
          return item;
        });
        // alert(JSON.stringify(data))
        this.setState({ pendingResponse: data });
        console.log(
          'pendinggggggggg---------------->',
          this.state.pendingResponse,
        );
      } catch (error) { }
    }
    if (
      prevProps.cashDepositLoading == false &&
      this.props.cashDepositLoading != prevProps.cashDepositLoading
    ) {
      this.setState({
        loading: true
      })
    }
  };

  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }
  pendingState = val => {
    this.setState({
      isPending: 0,
    });
  };
  completedState = val => {
    this.setState({
      isPending: 1,
    });
  };
  dropdownoption = val => {
    this.setState({
      dropdownValue: val,
    });
  };
  // nextButton = () => {
  //   this.props.navigation.navigate(Sales.cashdepositCalendar);
  // };
  nextButton = () => {
    var qrvalue = [];
    for (var i = 0; i < this.state.pendingResponse.length; i++) {
      if (this.state.pendingResponse[i].selected == true) {
        qrvalue.push(this.state.pendingResponse[i].LC_PYD_ORDERID);
      }
    }

    Qrcode = qrvalue.toString() + '|' + this.props.userId;
    //  alert(Qrcode)
    var qrString = Qrcode;

    var userIDSpliting = qrString.split('|');
    var orderIdSpliting = userIDSpliting[0].split(',');
    var orderid = [];
    orderIdSpliting &&
      orderIdSpliting.map(item => {
        const obj = {};
        obj.orderid = Number(item);
        orderid.push(obj);
      });

    // this.setState({ orderId: orderid });

    this.props.navigation.navigate(Sales.cashdepositCalendar, {
      orderId: orderid,
    });
  };
  radioPress = itemList => {
    this.setState({
      radio: true,
    });
    const newData = this.state.pendingResponse.map(item => {
      if (item.LC_PYD_CRMID == itemList.LC_PYD_CRMID) {
        return {
          ...item,
          selected: !item.selected,
        };
      }
      return item;
    });
    // alert(JSON.stringify(newData))
    this.setState({ pendingResponse: newData });
  };
  rec_Cash = () => {
    this.setState({
      receivecash: 1,
    });
  };
  cash_dep = () => {
    this.setState({
      receivecash: 0,
    });
  };
  QRNav = () => {
    this.props.navigation.navigate(Sales.cashdepositQR);
  };
  render() {
    return (
      <CashCollect_DepositScreen
        isPending={this.state.isPending}
        dropdownValue={this.state.dropdownValue}
        radio={this.state.radio}
        pendingState={this.pendingState}
        completedState={this.completedState}
        nextButton={this.nextButton}
        QRNav={this.QRNav}
        radioPress={this.radioPress}
        receivecash={this.state.receivecash}
        rec_Cash={this.rec_Cash}
        cash_dep={this.cash_dep}
        pendingResponse={this.state.pendingResponse}
        response={this.props.response}
        loading={this.state.loading}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    userId: state.signIn.userId,
    response: state.depositCash.response,
    cashDepositLoading: state.depositCash.cashDepositLoading,
    cashDepositStatus: state.depositCash.cashDepositStatus,
    cashDepositError: state.depositCash.cashDepositError,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getDepositCash: (data, token) => dispatch(getDepositCash(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
