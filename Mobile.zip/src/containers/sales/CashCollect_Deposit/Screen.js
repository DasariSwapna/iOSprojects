import { placeholder } from '@babel/types';
import React, { useRef } from 'react';
import {
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import Button from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import CheckCircle from '../../../components/CheckCircle';
import MaterialCommunityIcon from 'react-native-vector-icons/MaterialCommunityIcons';
import {
  heightPercentageToDP,
  widthPercentageToDP,
} from 'react-native-responsive-screen';
import AppButton from '../../../components/Button';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function RenderItem({ item, radioPress }) {
  console.log('item Details------>', item.item.LC_PYD_CRMID);
  return (
    <View style={styles.pendingCard}>
      <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
          }}>
          <Text style={styles.cardTitle}>{item.item.LC_VD_HOSPITALNAME}</Text>
          <CheckCircle
            length={20}
            onPress={() => radioPress(item.item)}
            selceted={item.item.selected}
          />
        </View>
        <View
          style={{
            borderBottomColor: '#dcdcdc',
            borderBottomWidth: 0.6,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text>{item.item.LC_PYD_CRMID}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Amount :</Text>
            <Text>{item.item.LC_PYD_AMOUNT}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function RendercompletedItem({ item, radioPress }) {
  return (
    <View key={item.key} style={styles.pendingCard}>
      <View style={{ paddingHorizontal: 20, paddingVertical: 10 }}>
        <Text style={styles.cardTitle}>{item.LC_VD_HOSPITALNAME}</Text>
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM Count :</Text>
            <Text>{item.item.LC_PYD_CRMID}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Total Amount :</Text>
            <Text>{item.item.LC_PYD_AMOUNT}</Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Date :</Text>
            <Text>{item.item.Handover_Date}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Time :</Text>
            <Text>{item.item.Handover_Time}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function CashCollect_Deposit({
  isPending,
  pendingState,
  completedState,
  nextButton,
  radioPress,
  radio,
  receivecash,
  rec_Cash,
  cash_dep,
  QRNav,
  pendingResponse,
  completedResponse,
  response,
  loading
}) {
  console.log('response details--------->', response);
  return (
    <RootView pageNo={'14'} loading={loading}>
      <KeyboardAvoidingView style={styles.mainContainer}>
        <View style={styles.depositContainer}>
          <TouchableOpacity
            style={{
              backgroundColor: receivecash == 0 ? Colors.border : Colors.card,
              width: wp('40%'),
              alignItems: 'center',
              paddingVertical: 5,
              borderRadius: 40,
            }}
            onPress={cash_dep}>
            <Text
              style={{
                fontFamily: Font.regular,
                color: receivecash == 0 ? Colors.white : Colors.black,
              }}>
              Cash deposit
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={rec_Cash}
            style={{
              backgroundColor: receivecash == 1 ? Colors.border : Colors.card,
              width: wp('40%'),
              alignItems: 'center',
              paddingVertical: 5,
              borderRadius: 40,
            }}>
            <Text
              style={{
                fontFamily: Font.regular,
                color: receivecash == 1 ? Colors.white : Colors.black,
              }}>
              Receive Cash
            </Text>
          </TouchableOpacity>
        </View>
        {receivecash == 0 ? (
          <View>
            <View style={{ flexDirection: 'row', justifyContent: 'center' }}>
              <TouchableOpacity
                style={{ alignItems: 'center' }}
                onPress={pendingState}>
                <Text
                  style={[
                    styles.pending_CompletedText,
                    { color: isPending == 0 ? Colors.black : Colors.border },
                  ]}>
                  Pending
                </Text>
                {isPending == 0 ? <View style={styles.highliteLine} /> : null}
              </TouchableOpacity>
              <View style={{ borderLeftWidth: 1, height: 25 }} />
              <TouchableOpacity
                style={{ alignItems: 'center' }}
                onPress={completedState}>
                <Text
                  style={[
                    styles.pending_CompletedText,
                    { color: isPending == 1 ? Colors.black : Colors.border },
                  ]}>
                  Completed
                </Text>
                {isPending == 1 ? <View style={styles.highliteLine} /> : null}
              </TouchableOpacity>
            </View>
            <View style={{ borderBottomWidth: 0.3, borderColor: '#D3D3D3' }} />
            <View style={{}}>
              {isPending == 0 ? (
                <FlatList
                  contentContainerStyle={{ paddingBottom: hp('30%') }}
                  data={pendingResponse}
                  renderItem={item => (
                    <RenderItem item={item} radioPress={radioPress} />
                  )}
                  keyExtractor={item => item.id}
                />
              ) : (
                <FlatList
                  data={response.properties.Completed}
                  renderItem={item => (
                    <RendercompletedItem item={item} radioPress={radioPress} />
                  )}
                  keyExtractor={item => item.id}
                />
              )}
            </View>
          </View>
        ) : (
          <View
            style={{
              alignItems: 'center',
              justifyContent: 'center',
              flex: 1,
            }}>
            <Text
              style={{
                color: Colors.border,
                fontFamily: Font.extraBold,
                fontSize: FontSize.large,
                width: widthPercentageToDP('60%'),
                textAlign: 'center',
                padding: heightPercentageToDP('4%'),
              }}>
              Please click QR button to Scan paramedic's Qr code
            </Text>
            <TouchableOpacity onPress={QRNav}>
              <MaterialCommunityIcon
                name={'qrcode-scan'}
                size={heightPercentageToDP('20%')}
                color={Colors.border}
              />
            </TouchableOpacity>
          </View>
        )}
        {receivecash == 0 ? (
          radio == true ? (
            isPending == 0 ?
              <View style={{
                backgroundColor: '#ffffff',
                position: 'absolute',
                bottom: 0, width: wp('100%'),
                paddingTop: hp('3%'),
                height: hp('7%')
              }}>
                <AppButton
                  title={"Next"}
                  buttonStyle={styles.reachedButton}
                  onPress={nextButton}
                />
              </View> : null
          ) : null
        ) : null}
      </KeyboardAvoidingView>
    </RootView>
  );
}

CashCollect_Deposit.prototype = {
  isPending: PropTypes.string,
  pendingState: PropTypes.func,
  completedState: PropTypes.func,
  generateQR: PropTypes.func,
  dropdownoption: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  flex: {
    flex: 1,
  },
  buttonText: {
    fontFamily: Font.regular,
    color: Colors.background,
    fontSize: FontSize.large,
  },

  pending_CompletedText: {
    paddingHorizontal: 20,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
  },
  cardTitle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: 5,
  },
  highliteLine: {
    borderBottomWidth: 2,
    width: 50,
    marginTop: 20,
    borderColor: Colors.border,
  },
  cashText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.darkBlue,
  },
  taskText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  depositContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    width: wp('86%'),
    alignSelf: 'center',
    paddingTop: hp('3%'),
    justifyContent: 'space-between',
    paddingBottom: hp('3%'),
  },

  pendingCard: {
    borderRadius: 10,
    // marginHorizontal: 20,
    justifyContent: 'center',
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: wp('85%'),
    alignSelf: 'center',
    marginVertical: hp('2%'),
    marginTop: 6,
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingVertical: 5,
  },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('2%'),
  },

});

export default CashCollect_Deposit;
