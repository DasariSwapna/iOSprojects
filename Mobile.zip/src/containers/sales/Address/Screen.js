import React, {useState, useEffect, useRef} from 'react';
import {
  View,
  Text,
  Modal,
  SafeAreaView,
  Dimensions,
  StyleSheet,
  ScrollView,
  FlatList,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
} from 'react-native';
import axios from 'axios';
import Config from 'react-native-config';
import FaIcon from 'react-native-vector-icons/FontAwesome';
import Geolocation from 'react-native-geolocation-service';
import Geocoder from 'react-native-geocoding';
import {GooglePlacesAutocomplete} from 'react-native-google-places-autocomplete';
import Button from '../../../components/Button';
import Colors from '../../../config/Colors';
import {getAddress} from '../../../services/Location';
import MapLocation from '../../../components/MapLocation';
import {Font, FontSize} from '../../../config/Fonts';
import RootView from '../../../components/RootView';
import {GooglePlacesAutoComplete} from '../../../components/GoolgePlaceAutoComplete';

const {width, height} = Dimensions.get('screen');
const modelHeight = height * 0.36;
const modelWidth = width;

const AddressModal = ({
  title,
  toggle,
  action,
  updateCoordinates,
  setLocation,
}) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(toggle);
  }, [toggle]);

  const ref = useRef();

  useEffect(() => {
    ref.current?.setAddressText('Some Text');
  }, []);

  function onChange(val) {
    console.log('onchange===>', val);
  }

  return (
    <Modal
      transparent={true}
      animationType={'none'}
      visible={visible}
      onRequestClose={() => {
        console.log('close modal');
      }}>
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 2 : 70}>
        <View style={styles.modalBackground}>
          <View
            style={{
              width: 40,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
              backgroundColor: 'white',
              padding: 2,
              margin: 20,
              borderRadius: 40 / 2,
            }}>
            <TouchableOpacity onPress={() => action(false)}>
              <FaIcon name="close" size={32} />
            </TouchableOpacity>
          </View>
          <View style={styles.wrapper}>
            <View style={{width: '100%', minHeight: 60}}>
              <GooglePlacesAutoComplete
                updateCoordinates={updateCoordinates}
                closeModal={val => action(val)}
              />
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
};

export default ({
  loading,
  showModal,
  initialCoords,
  updatedCoords,
  addressLine1,
  addressLine2,
  getCoordinates,
  updateCoordinates,
  showAddressModalHandler,
  confirmAddressHandler,
}) => {
  return (
    <RootView loading={loading} isWhite isPageWhite>
      <AddressModal
        toggle={showModal}
        action={showAddressModalHandler}
        updateCoordinates={updateCoordinates}
      />
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 70}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={{flex: 1}}>
            <View style={{width: '100%', height: '80%'}}>
              <MapLocation
                initialCoord={initialCoords}
                updatedCoords={updatedCoords}
                getCoordinates={getCoordinates}
              />
            </View>

            <View style={{width: '100%', height: '20%'}}>
              <View
                style={{
                  flex: 1,
                  flexDirection: 'row',
                  justifyContent: 'center',
                }}>
                <View style={{width: '70%', paddingLeft: 10}}>
                  <Text
                    style={{
                      fontFamily: Font.bold,
                      fontSize: FontSize.semiLarge,
                      paddingTop: 10,
                      paddingHorizontal: 10,
                    }}>
                    Address
                  </Text>
                  <View
                    style={{
                      paddingLeft: 10,
                      paddingRight: 5,
                      paddingVertical: 5,
                    }}>
                    <Text
                      style={{
                        fontFamily: Font.bold,
                        fontSize: FontSize.regular,
                      }}>
                      <Text>{addressLine1}</Text>,<Text>{addressLine2}</Text>
                    </Text>
                  </View>
                </View>
                <View style={{width: '30%'}}>
                  <Button
                    title="Change"
                    isTransparent={true}
                    buttonTextStyle={{color: Colors.button}}
                    onPress={() => showAddressModalHandler()}
                  />
                </View>
              </View>
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  justifyContent: 'flex-end',
                  padding: 5,
                }}>
                <Button
                  title={'Confirm'}
                  onPress={() => confirmAddressHandler()}
                />
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    // flex: 1,
    backgroundColor: Colors.background,
  },
  modalBackground: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
    backgroundColor: '#00000080',
  },
  wrapper: {
    backgroundColor: Colors.background,
    height: modelHeight,
    width: modelWidth,
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    padding: 12,
    opacity: 0.98,
  },
  buttonContainer: {
    flex: 1,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'flex-end',
  },
  yesButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 5,
    backgroundColor: Colors.primary,
  },
  noButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 5,
    backgroundColor: Colors.primary,
  },
});
