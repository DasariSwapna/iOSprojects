import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import UploadCopyScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import { UploadsignedCopy } from '../../../../store/Actions';
import { BackHandler } from 'react-native';

const searchData = [
  { id: 1, name: 'All' },
  { id: 2, name: 'Retail to invoice' },
  { id: 3, name: 'MOU' },
];

const completedData = [
  {
    id: 1,
    name: 'QU06-10610 Jothi',
    crmid: '12345',
    date: '5',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
  {
    id: 2,
    name: 'QU06-10611 Laxmi',
    crmid: '12345',
    date: '5',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
  {
    id: 2,
    name: 'QU06-10611 Laxmi',
    crmid: '12345',
    date: '3',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
];

class UploadCopy extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      selectedTab: 1,
      data: [],
      selectedSearchId: 1,
      approved: true,
      rejected: false,
      salesMangerResponse: '',
      actionValue: '',
      localProductList: [],
      responseAll: [],
      responseRetail: [],
      responseMou: [],

      responseAllDublicate: [],
      responseRetailDublicate: [],
      responseMouDublicate: []

    };
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.UploadPreview);
  };
  actionSearch = (text) => {
    if (text != "") {
      var searchresponsedata = this.state.selectedSearchId == 1 ?
        this.state.responseAll
        : this.state.selectedSearchId == 2
          ? this.state.responseRetail
          : this.state.responseMou
      var arraydata = searchresponsedata.filter(function (x) {
        return (x.Hospital_Name.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1)
      });
      this.setState({
        responseAll: this.state.selectedSearchId == 1 ? arraydata : this.state.responseAll,
        responseRetail: this.state.selectedSearchId == 2 ? arraydata : this.state.responseRetail,
        responseMou: this.state.selectedSearchId == 3 ? arraydata : this.state.responseMou,
        actionValue: text
      })
    }
    else {
      this.setState({
        responseAll: this.state.responseAllDublicate,
        responseRetail: this.state.responseRetailDublicate,
        responseMou: this.state.responseMouDublicate,
        actionValue: text
      })
    }
  }

  approveHandler = (vendorID, pdfuploadStatus) => {
    //  this.props.navigation.navigate(Sales.UploadPreview);

    this.props.navigation.navigate(Sales.UploadPreview, {
      vendorID: vendorID,
      pdfuploadStatus: pdfuploadStatus,
    });
  };

  revisedHandler = () => {
    /* this.props.navigation.navigate(Sales.ManagerApprovalStatus, {
      rejected: false,
    });  */
  };

  rejectedHandler = () => {
    /* this.props.navigation.navigate(Sales.ManagerApprovalStatus, {
      rejected: true,
    }); */
  };

  changeTab = id => {
    this.setState({ selectedTab: id });
    this.fetchData(id);
  };

  fetchData(id) {
    if (id == '1') {
      this.setState({
        approved: true,
        rejected: false,
      });
    } else if (id == '2') {
      this.setState({
        rejected: true,
        approved: false,
      });
    }
  }

  componentDidMount() {
    const data = {
      statusid: '1',
      userid: this.props.UserID,
    };

    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetsignedcopyDetails(data, this.props.accessToken);
    });

    BackHandler.addEventListener('hardwareBackPress', this.backHandler);
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.uploadsignedcopyStatus == false &&
      this.props.uploadsignedcopyStatus !=
      prevProps.uploadsignedcopyStatus
    ) {

      this.setState({ responseAll: this.props.response.All, responseAllDublicate: this.props.response.All, responseRetail: this.props.response.RetailtoInvoice, responseRetailDublicate: this.props.response.RetailtoInvoice, responseMou: this.props.response.MOU, responseMouDublicate: this.props.response.MOU })

    }


  };

  componentWillUnmount() {
    this._unsubscribe();
  }

  Homehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    // this.props.navigation.navigate(Sales.Home);
    this.props.navigation.goBack(null);
    return true;
  };

  searchClickHandler = id => {
    this.setState(prevState => {
      const temp = prevState.selectedSearchId == id ? id : id;
      return {
        selectedSearchId: temp,
      };
    });
  };

  render() {
    return (
      <UploadCopyScreen
        nextButtonHandler={this.nextButtonHandler}
        changeTab={this.changeTab}
        selectedTab={this.state.selectedTab}
        searchClickHandler={this.searchClickHandler}
        selectedSearchId={this.state.selectedSearchId}
        approveHandler={this.approveHandler}
        rejectedHandler={this.rejectedHandler}
        revisedHandler={this.revisedHandler}
        actionSearch={this.actionSearch}
        responseAll={this.state.responseAll}
        responseRetail={this.state.responseRetail}
        responseMou={this.state.responseMou}
        data={this.state.data}
        approved={this.state.approved}
        rejected={this.state.rejected}
        searchData={searchData}
        completedData={this.props.responseall}
        salesMangerResponse={this.props.response}
        loading={this.props.uploadsignedcopyLoading}
        Homehandler={this.Homehandler}
        actionValue={this.state.actionValue}
      />
    );
  }
}
const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    responseuploadsignedcopydetails: state.signIn.userId,
    response: state.uploadsignedcopydetails.response,
    responseall: state.uploadsignedcopydetails.responseall,
    responsearetailtoinvoice:
      state.uploadsignedcopydetails.responseretailtoinvoice,
    responseamou: state.uploadsignedcopydetails.responseMOU,
    uploadsignedcopyLoading:
      state.uploadsignedcopydetails.uploadsignedcopyLoading,
    uploadsignedcopyStatus: state.uploadsignedcopydetails.uploadsignedcopyStatus
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetsignedcopyDetails: (data, token) =>
      dispatch(UploadsignedCopy(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(UploadCopy);
