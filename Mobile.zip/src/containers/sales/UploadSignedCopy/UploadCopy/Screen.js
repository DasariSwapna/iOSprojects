import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import Ionicons from 'react-native-vector-icons/Ionicons';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import {TanTwoContainer} from '../../../../components/TabContainer';
import SearchButtonView from '../../../../components/SearchButtonView';
import SearchBar from '../../../../components/SearchBar';

function Approved({nextButtonHandler, rejected, approveText, data}) {
  return (
    <View
      style={{
        width: '90%',

        backgroundColor: '#fff',

        borderWidth: 0.3,

        borderColor: Colors.border,

        borderRadius: 15,

        marginTop: 25,

        alignSelf: 'center',

        elevation: 5,
      }}>
      <TouchableOpacity
        onPress={() => nextButtonHandler(data.VENDOR_ID, data.Signed_Copy)}>
        <View
          style={{
            flexDirection: 'row',

            paddingHorizontal: wp('7%'),

            paddingVertical: hp('1%'),

            justifyContent: 'space-between',
          }}>
          <View
            style={{
              flexDirection: 'row',
            }}>
            <Text
              style={{
                fontFamily: Font.bold,

                color: Colors.border,

                fontSize: FontSize.medium,

                alignSelf: 'center',
              }}>
              Quote ID
            </Text>

            <Text
              style={{
                fontFamily: FontMagneta.thin,

                color: Colors.black,

                fontSize: FontSize.medium,

                alignSelf: 'center',

                marginLeft: 10,
              }}>
              {data.QUOTATION_ID}
            </Text>
          </View>

          <Icon name="chevron-right" size={wp('4%')} color={Colors.darkPink} />
        </View>

        <View
          style={{
            width: '100%',

            height: hp('0.1%'),

            backgroundColor: Colors.border,
          }}></View>

        <View
          style={{
            flexDirection: 'row',

            paddingHorizontal: wp('7%'),

            paddingVertical: hp('1%'),

            justifyContent: 'space-between',

            marginTop: 5,
          }}>
          <Text
            style={{
              fontFamily: Font.regular,

              color: Colors.border,

              fontSize: FontSize.medium,

              alignSelf: 'center',
            }}>
            Hospital
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',

            paddingHorizontal: wp('7%'),

            justifyContent: 'space-between',
          }}>
          <Text
            style={{
              fontFamily: Font.regular,

              color: Colors.black,

              fontSize: FontSize.regular,

              alignSelf: 'center',
            }}>
            {data.Hospital_Name}
          </Text>
        </View>

        <View
          style={{
            flexDirection: 'row',

            paddingHorizontal: wp('7%'),

            justifyContent: 'space-between',

            paddingBottom: hp('1%'),
          }}>
          <View
            style={{
              flexDirection: 'row',

              marginTop: hp('1.5%'),
            }}>
            <Text
              style={{
                fontFamily: Font.bold,

                color: Colors.black,

                fontSize: FontSize.regular,

                alignSelf: 'center',
              }}>
              Total test{' '}
            </Text>

            <Text
              style={{
                fontFamily: FontMagneta.semiBold,

                color: Colors.black,

                fontSize: FontSize.regular,

                alignSelf: 'center',
              }}>
              {data.Tests}
            </Text>
          </View>

          <Text
            style={[
              {
                fontFamily: Font.regular,

                color: Colors.darkGreen,

                fontSize: FontSize.regular,

                alignSelf: 'center',

                marginLeft: wp('2%'),
              },

              {color: Colors.darkGreen},
            ]}>
            {data.Approved_Status}
          </Text>
        </View>
      </TouchableOpacity>
    </View>
  );
}

function UploadCopyScreen({
  addressTypeHandler,
  approveHandler,
  rejectedHandler,
  revisedHandler,
  changeTab,
  selectedTab,
  searchData,
  completedData,
  selectedSearchId,
  salesMangerResponse,
  searchClickHandler,
  loading,
  approved,
  rejected,
  actionValue,
  actionSearch,
  responseAll,
  responseRetail,
  responseMou,
}) {
  const renderSearchItem = ({item}) => (
    <SearchButtonView
      title={item.name}
      onPress={() => searchClickHandler(item.id)}
      isActive={selectedSearchId == item.id}
    />
  );

  const renderNodata = () => {
    return (
      <>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            marginTop: hp('30%'),
          }}>
          <Text
            style={{fontFamily: FontMagneta.bold, fontSize: FontSize.large}}>
            No data found
          </Text>
        </View>
      </>
    );
  };

  return (
    <RootView pageNo={'S-96'} loading={loading}>
      <KeyboardAvoidingView style={{flex: 1}}>
        <View style={styles.mainContainer}>
          <TanTwoContainer
            approvedText={'Quotation'}
            rejectedText={'Agreement'}
            selectedTab={selectedTab}
            changeTab={changeTab}
          />

          <View style={styles.topSearchContainer}>
            <FlatList
              contentContainerStyle={styles.topcontentContainerStyle}
              columnWrapperStyle={{justifyContent: 'space-between'}}
              data={searchData}
              keyExtractor={item => item.id}
              numColumns={3}
              renderItem={renderSearchItem}
            />
          </View>
          <View style={{width: '80%', alignSelf: 'center', height: hp('6%')}}>
            <SearchBar onChangehandler={actionSearch} value={actionValue} />
          </View>
          <FlatList
            contentContainerStyle={styles.flatListInnerContainer}
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={
              selectedSearchId == 1
                ? responseAll
                : selectedSearchId == 2
                ? responseRetail
                : responseMou
            }
            renderItem={({item}) => (
              <Approved
                nextButtonHandler={approveHandler}
                rejected={rejected}
                approveText={'Approved'}
                data={item}
              />
            )}
            extraData={salesMangerResponse}
            keyExtractor={item => item.VENDOR_ID}
            contentContainerStyle={styles.flatListInnerContainer}
            ListEmptyComponent={renderNodata}
          />
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
  },
  topcontentContainerStyle: {
    padding: 2,
    width: '90%',
    alignSelf: 'center',
    marginVertical: 10,
  },
  //
  /////Search outer Style
  searchOuterContainer: {
    width: '90%',
    alignSelf: 'center',
    marginBottom: 20,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  /////////Serach Section
  searchSection: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
    alignSelf: 'center',
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  buttonWithoutBorder: {
    minWidth: 160,
    paddingHorizontal: hp('2%'),
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
    alignSelf: 'center',
    marginBottom: 5,
  },
  buttonStyleWhite: {
    fontSize: FontSize.medium,
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: hp('20%'),
  },

  topSearchContainer: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    overflow: 'scroll',
  },
});

export default UploadCopyScreen;
