import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import { Table, Row, Rows, TableWrapper, Cell, Col, Cols } from 'react-native-table-component';



function TextConatiner({
  leftText,
  rightText,
}) {
  return (
    <View style={{ width: '100%', flexDirection: 'row' }}>
      <Text
        style={{
          flex: 1,
          paddingLeft: 25,
          paddingVertical: 5,
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>{leftText}</Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: 5,
          color: Colors.black,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>{rightText}</Text>
    </View>
  )
}

function UploadPreviewScreen({
  addressTypeHandler,
  nextButtonHandler,
  tableHead,
  tableData,
  tableTitle,
  tableColumnData,
  doctorDatas,
  loading,
  pdfuploadStatus
}) {
  return (
    <RootView pageNo={'S-110'} loading = {loading}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 10,
            flexDirection: 'column',
            backgroundColor: '#fff'
          }}>
          <View
            style={{
              flex: 9,
              flexDirection: 'column',
            }}>
            <ScrollView
              style={{ flex: 1 }}
              contentContainerStyle={styles.contentContainer}
              showsVerticalScrollIndicator={false}>
              <View style={styles.mainContainer}>

              {doctorDatas == null ||
              doctorDatas == undefined ||
              doctorDatas == '' ? null :


                <View
                  style={{
                    width: '80%',
                    flexDirection: 'column',
                    alignSelf: 'center',
                    backgroundColor: '#fff',
                    elevation: 2,
                    borderRadius: 10,
                    borderColor: Colors.bgDarkGray,
                    borderWidth: 0.3,
                    marginTop: hp('5.0%')
                  }}>

                  <View style={{
                     marginTop: hp('1.5%')
                  }} />

                  <Text
                    style={[styles.textStyleHeader, { marginHorizontal : wp('3.5%') ,marginTop: 0 }]}>
                    Vendor Details</Text>

                  <View style={{
                    width: '100%',
                    marginTop: hp('1.5%'),
                    
                    height: 1,
                    backgroundColor: Colors.eWhite,
                    alignSelf: 'center'
                  }} />
                  <View style={{ marginHorizontal : wp('-2.5%') ,marginTop: hp('1.5%')}}>
                  <TextConatiner
                    leftText={'Hospital Name'}
                    rightText={doctorDatas[0].LC_VD_HOSPITALNAME}
                  />
                  <TextConatiner
                    leftText={'Customer Name'}
                    rightText={doctorDatas[0].LC_VD_CONTACTPERSON_NAME}
                  />
                  <TextConatiner
                    leftText={'Mobile'}
                    rightText={doctorDatas[0].LC_VD_PRIMARYCONTACT}
                  />

                  <TextConatiner
                    leftText={'Email'}
                    rightText={doctorDatas[0].LC_VD_EMAILID}
                  />
                  <TextConatiner
                    leftText={'Address'}
                    rightText={doctorDatas[0].LC_VD_HOSPITALADDRESS}
                  />
                  <TextConatiner
                    leftText={'Account Type'}
                    rightText={doctorDatas[0].LC_AT_ACCOUNT_TYPE_NAME}
                  />
                  </View>

                  <View style={{
                    marginTop: hp('1.5%')
                  }} />

                  <View style={{
                    width: '100%',
                    height: 1,
                    backgroundColor: Colors.eWhite,
                    alignSelf: 'center'
                  }} />
                  <Text
                    style={[styles.textStyleHeader, {marginHorizontal : wp('3.5%') ,  marginTop: hp('1.5%') }]}>
                    Price and Package Details</Text>
                      <View style={{ width: wp('73%'),marginHorizontal : wp('3.5%') , marginTop: hp('1.5%') }}>
                      <Table borderStyle={{ borderWidth: 1, borderColor: '#cccccc', }}>
                      <Row data={tableHead} style={styles.head} textStyle={styles.textBorder} />
                      <Rows data={tableData} textStyle={styles.text} />
                    </Table>
                  </View>
                <View style={{
                    marginTop: hp('2.5%')
                  }} />
                </View> }
              </View>
            </ScrollView>
          </View>

          { pdfuploadStatus == '1' ? null :
                
          <View
            style={{
              flex: 1,
              flexDirection: 'column',
              alignItems: 'center',
              backgroundColor: Colors.white
            }}>
            <View
              style={styles.buttonContainer}>
              <Button 
                title="Next"
                buttonTextStyle={{ fontSize: FontSize.large }}
                onPress={nextButtonHandler}
              />
            </View> 
          </View>}

        </View>
      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff'
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center'
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
   
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center'
  },
  head: {
    height: 40,
    backgroundColor: '#fff',
    color: Colors.border
  },
  text: {
    margin: 4,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.black
  },
  textBorder: {
    margin: 4,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.border
  },
  textStyleBold: {
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.black,
    marginTop: 30
  },
  textStyleHeader: {
    flex: 1,
  //  paddingLeft: 25,
    paddingVertical: 5,
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  }



});

export default UploadPreviewScreen;
