import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import CreateVendorPreviewScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import UploadPreviewScreen from './Screen';
import {getApprovalDetails} from '../../../../store/Actions';
import {BackHandler} from 'react-native';

class UploadPreview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      vendorID: this.props.route.params.vendorID,
      pdfuploadStatus: this.props.route.params.pdfuploadStatus,
      tableHead: ['Product', 'Test', 'Amount', 'Sample Type'],
      tableData: [
        ['Maternity Screening', '5000/- INR', 'Heel Prick'],
        ['QFPCR', '8000/- INR', 'Heel Prick'],
        ['Hb Pathies', '9000/- INR', 'Blood sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
      ],
    };
  }

  nextButtonHandler = () => {
    //   this.props.navigation.navigate(Sales.UploadCapture);
    this.props.navigation.navigate(Sales.UploadCapture, {
      vendorID: this.state.vendorID,
    });
  };

  Homehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    // this.props.navigation.navigate(Sales.UploadCopy);
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    const data = {
      hospitalid: this.state.vendorID,
    };

    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalDetails(data, this.props.accessToken);
    });

    BackHandler.addEventListener('hardwareBackPress', this.backHandler);
  }
  componentWillUnmount() {
    this._unsubscribe();
  }

  render() {
    return (
      <UploadPreviewScreen
        nextButtonHandler={this.nextButtonHandler}
        // states
        tableHead={this.state.tableHead}
        tableData={this.state.tableData}
        vendorID={this.state.vendorID}
        tableData={this.props.managerapprovaltestTableDetails}
        data={this.state.data}
        doctorDatas={this.props.managerapprovaldoctorDetails}
        testData1={this.props.managerapprovalproducttestDetails}
        loading={this.props.managerapprovaldetailsLoading}
        Homehandler={this.Homehandler}
        pdfuploadStatus={this.state.pdfuploadStatus}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    managerapprovaldetailsError:
      state.salesmanagerapprovals.approvaldetailstError,
    managerapprovaldetailsStatus:
      state.salesmanagerapprovals.apporvaldetailsStatus,
    managerapprovaldetailsLoading:
      state.salesmanagerapprovals.approvaldetailsLoading,
    managerapprovaldoctorDetails:
      state.salesmanagerapprovals.approvaldoctorDetails,
    managerapprovalproducttestDetails:
      state.salesmanagerapprovals.approvalproducttestDetails,
    managerapprovaltestTableDetails:
      state.salesmanagerapprovals.approvalproducttesttableDetails,
    approvalDetailsProcessmessage: state.salesmanagerapprovals.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getApprovalDetails(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(UploadPreview);
