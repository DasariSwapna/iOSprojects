import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import CreateVendorAuthenticationScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import {
  insertSignature
} from '../../../../store/Actions';
import RNFetchBlob from 'rn-fetch-blob';
import RNImageToPdf from 'react-native-image-to-pdf';


class CreateVendorAuthentication extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showOtpPaymentModal: false,
      signature: ''
    };
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createVendorRetailAgreement);
    // this.setState({
    //   showOtpPaymentModal: true,

    // })
    //this.onSaveEvent();
    this.upload();
  }

  onSaveEvent = result => {
    console.log("hii" + JSON.stringify(result));
    this.setState({ signature: result.encoded })
  };

  upload = () => {
    const data = {
      "signature_path": this.state.signature,
      "user_id": this.props.UserID,
      "signature_imagename": `${this.props.VendorId}image.png`,
      "hostpital_id": this.props.VendorId
    }
    this.props.onInsertSignature(data, this.props.accessToken)
  }


  // myAsyncPDFFunction = async (path) => {
  //   const arr = this.state.signature
  //   try {
  //     const options = {
  //       imagePaths: [path],
  //       name: 'PDFName',
  //       maxSize: { // optional maximum image dimension - larger images will be resized 
  //         width: 1800,
  //         height: 2400,
  //       },
  //       quality: .7, // optional compression paramter
  //     };
  //     const pdf = await RNImageToPdf.createPDFbyImages(options);
  //     this.converttoBase64(pdf.filePath)
  //   } catch (e) {
  //     console.log("check" + e);
  //   }
  // }

  // converttoBase64 = (path) => {
  //   RNFetchBlob.fs
  //     .readFile(path, 'base64')
  //     .then((data) => {
  //       // alert('converted'+data);
  //       this.afterConversionBase64(path, data)
  //       console.log('converted' + data)
  //     })
  //     .catch((err) => {
  //       console.log('fetchblob' + err)
  //     });
  // }


  // afterConversionBase64 = (item, base64String) => {
  //   var Base64Img = base64String.replace(/\r?\n|\r/g, "");
  //   console.log('BASE 64' + Base64Img);
  //   // this.uploadImage(item, Base64Img)
  // }


  otpSubmitHandler = () => {
    this.setState({
      showOtpPaymentModal: false,

    })
    this.props.navigation.navigate(Sales.createVendorRetailAgreement);
  }

  retailHandler = () => {
    this.props.navigation.navigate(Sales.createVendorRetailAgreement);
  }


  render() {
    return <CreateVendorAuthenticationScreen
      nextButtonHandler={this.nextButtonHandler}
      otpSubmitHandler={this.otpSubmitHandler}
      retailHandler={this.retailHandler}
      showOtpPaymentModal={this.state.showOtpPaymentModal}
      onSaveEvent={this.onSaveEvent}
    />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
    accessToken: state.signIn.accessToken,
    VendorId: state.createVendor.insertVendorResponse,
    UserID: state.signIn.userId,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onInsertSignature: (data, token) => dispatch(insertSignature(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateVendorAuthentication);
