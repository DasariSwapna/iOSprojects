import React, { useRef } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome'
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import { Table, Row, Rows } from 'react-native-table-component';
import DownloadImageComponent from '../../../../components/DownloadImageComponet'
//import Table from '../../../../components/Table';
import PageNo from '../../../../constants/PageNo'

function TextConatiner({
  leftText,
  rightText,
}) {
  return (
    <View style={{ width: '100%', flexDirection: 'row' }}>
      <Text
        style={{
          flex: 1,
          paddingLeft: 25,
          paddingVertical: 5,
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>{leftText}</Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: 5,
          color: Colors.black,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>{rightText}</Text>
    </View>
  )
}




function CreateVendorRetailAgreementScreen({
  addressTypeHandler,
  nextButtonHandler,
  tableHead,
  tableData,
  data }) {
  return (
    <RootView pageNo={PageNo.sales_createVendorRetailAgreement}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <View
          style={{
            flex: 9,
            flexDirection: 'column',
          }}>
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={styles.contentContainer}
            showsVerticalScrollIndicator={false}>
            <View
              style={styles.mainContainer}>

              <View
                style={{
                  width: '80%',
                  flexDirection: 'column',
                  alignSelf: 'center',
                  backgroundColor: '#fff',
                  elevation: 2,
                  borderRadius: 10,
                  borderColor: Colors.border,
                  borderWidth: 0.5,
                  marginTop: 25
                }}>

                <View style={{
                  marginTop: 10
                }} />
                <Image
                  source={Images.logo}
                  style={{ width: 100, height: 100, marginLeft: 20, marginTop: -10, }}
                  resizeMode="contain"
                />



                <View
                  style={{
                    width: '85%',
                    alignSelf: 'center',
                    marginTop: -10
                  }}>

                  <Text
                    style={{
                      flex: 1,
                      paddingVertical: 5,
                      color: Colors.border,
                      fontFamily: Font.bold,
                      fontSize: FontSize.medium,
                    }}>Dear Dr.Smitha Patil</Text>
                  <Text
                    style={{
                      fontFamily: Font.bold,
                      fontSize: FontSize.regular,
                      color: Colors.black,
                      marginTop: 10
                    }}>
                    At the outset we wish to thank you for giving us an opportunity to work with you on our range of PNS, NBS & Genetic Test
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    We have arrived at a special pricing for your esteemed organization.
                  </Text>

                </View>



                <View style={{
                  marginTop: 20
                }} />

                <View style={{
                  width: '100%',
                  height: 0.3,
                  backgroundColor: Colors.border,
                  alignSelf: 'center'
                }} />

                <Text
                  style={{
                    flex: 1,
                    paddingLeft: 25,
                    paddingVertical: hp('2%'),
                    color: Colors.border,
                    fontFamily: Font.bold,
                    fontSize: FontSize.medium,
                  }}>
                  Price and Package Details</Text>

                <View style={{ width: '85%', alignSelf: 'center', }}>
                  <Table borderStyle={{ borderWidth: 1, borderColor: '#cccccc', }}>
                    <Row data={tableHead} style={styles.head} textStyle={styles.textBorder} />
                    <Rows data={tableData} textStyle={styles.text} />
                  </Table>
                </View>
                {/* <View style={{ paddingLeft: 25, marginBottom: 4 }}>
                  <Table
                    data={data}
                  />
                </View> */}

                <View style={{
                  width: '100%',
                  height: 1,
                  backgroundColor: Colors.eWhite,
                  alignSelf: 'center',
                  marginTop: 20
                }} />

                <Text
                  style={styles.textStyleHeader}>
                  key terms & Conditions:</Text>

                <View
                  style={{
                    width: '85%',
                    alignSelf: 'center'
                  }}>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will offer its diagnostic testing services in a timely and
                    efficient manner and in adherence with best clinical and diagnostic practices.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell shall provide training to qualified medical staff for sample collection. It is the responsibility of the ………………to collect sample for conducting the required tests.
                  </Text>
                  <Text
                    style={styles.textStyleRegular}>
                    *LifeCell will inform and educate about the quantity/volume of the patient’s sample required to be collected for conducting the required tests
                  </Text>
                </View>

                <Text
                  style={{
                    flex: 1,
                    paddingLeft: 25,
                    paddingVertical: 5,
                    color: Colors.border,
                    fontFamily: Font.bold,
                    fontSize: FontSize.medium,
                    marginTop: 20,
                    alignSelf: 'flex-end',
                    marginRight: 25
                  }}>Hospital's authorised signatory</Text>

                <Image
                  source={Images.signature}
                  style={{
                    width: 100,
                    height: 100,
                    marginLeft: 20,
                    alignSelf: 'flex-end',
                    marginTop: -10,
                    marginRight: 25
                  }}
                  resizeMode="contain"
                />


                <View style={{
                  marginTop: 10
                }} />
              </View>

              <View style={{
                alignSelf: 'flex-end',
              }}>
                <DownloadImageComponent />
              </View>
            </View>
          </ScrollView>
        </View>

        <View
          style={{
            flex: 1,
            flexDirection: 'column',
            alignItems: 'center',
            backgroundColor: '#fff'
          }}>
          <View
            style={styles.buttonContainer}>
            <Button title="Home page"
              buttonStyle={styles.buttonWithoutBorder}
              buttonTextStyle={{ fontSize: FontSize.large }}
              onPress={nextButtonHandler}
            />
          </View>
        </View>
      </KeyboardAvoidingView >
    </RootView >
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff'
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff'
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center'
  },
  buttonContainer: {
    width: '35%',
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center'
  },
  head: {
    height: 40,
    backgroundColor: '#fff'
  },
  buttonWithoutBorder: {
    minWidth: hp('18%'),
    height: hp('5%'),
    paddingHorizontal: 2,
    borderRadius: hp('5%'),
    backgroundColor: Colors.darkPink,
    borderColor: Colors.darkPink,
    borderWidth: 1,
    alignSelf: 'center',
    marginBottom: 20
  },
  textStyleRegular: {
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.black,
    marginTop: 30
  },
  textStyleHeader: {
    flex: 1,
    paddingLeft: 25,
    paddingVertical: 5,
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    marginTop: 20
  },
  text: {
    margin: 4,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.black,
    alignSelf: 'center',
    textAlign: 'center'
  },
  textBorder: {
    margin: 4,
    fontFamily: Font.bold,
    fontSize: FontSize.regular,
    color: Colors.border,
    alignSelf: 'center',
    textAlign: 'center'
  },


});

export default CreateVendorRetailAgreementScreen;
