import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import CreateVendorRetailAgreementScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';

const data1 = [
  {
    title: 'Maternity Screening',
    amount: '5000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'QFPCR',
    amount: '8000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'Hb Pathies',
    amount: '9000/-INR',
    type: 'Blood sample',
  },
  {
    title: 'Free Testosterone',
    amount: '9000/-INR',
    type: 'Urine sample',
  },
];

class CreateVendorRetailAgreement extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      tableHead: ['Test Panel', 'Amount', 'Sample Type',],
      tableData: [
        ['Maternity Screening', '5000/- INR', 'Heel Prick'],
        ['QFPCR', '8000/- INR', 'Heel Prick',],
        ['Hb Pathies', '9000/- INR', 'Blood sample'],
        ['Free Testosterone', '9000/- INR', 'Urine sample',]
      ],
      data: data1
    };
  }

  nextButtonHandler = () => {
    this.props.navigation.navigate(Sales.home);
  }

  render() {
    return <CreateVendorRetailAgreementScreen
      nextButtonHandler={this.nextButtonHandler}
      // states
      tableHead={this.state.tableHead}
      tableData={this.state.tableData}
      data={this.state.data} />;
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(CreateVendorRetailAgreement);
