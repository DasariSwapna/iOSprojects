import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, {NextButton} from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/VendorDropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import TimeLineContainer from '../../../../components/VendoreTimeLineContainer';
import Icons from '../../../../constants/Icons';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import { Toast } from '../../../../components/Toast';
import { Col } from 'react-native-table-component';

function CreateVendorQuestionTermsCondition({
  contactName,
  mobileNumber,
  emailId,
  address,
  speciality,
  Answerid,

  specialityHandler,
  contactNameHandler,
  mobileNumberHandler,
  emailIdHandler,
  addressHandler,

  isValidContactName,
  isValidSpeciality,
  isvalidMobileNumber,
  isaValidEmailId,
  isValidAddress,

  contactnNameValidMsg,
  specialityValidMsg,
  mobileNumberValidmsg,
  emailIdValidmsg,
  addressValidMsg,


  questionHandler,
  nextButtonHandler,
  getQuestionAnswerResponse = [],
  typeid,
  showToast,
  errorMsg,


}) {
  function answerSelectHandler(item, answer) {
    console.log(item, answer);
    questionHandler(item.question_id, answer);
  }

  return (
    <RootView pageNo={PageNo.sales_createVendorTermsCondition}>
      
      <KeyboardAvoidingView
        enabled
        style={{flex: 1,backgroundColor: Colors.white}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 70}>
      <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <View style={styles.mainContainer}>
          <TimeLineContainer status={3} />
          <View style={styles.lineLargeContainer} />
          <ScrollView>
            {getQuestionAnswerResponse &&
              getQuestionAnswerResponse.map((item,index) => {
                return (
                  <View>
                    <View
                      style={{
                        width: wp('80%'),
                        alignSelf: 'center',
                      }}>
                      <Text style={styles.textStyleRegular}>
                        {item.question_name}
                      </Text>
                    </View>
                    <View>

                    {Answerid == undefined || Answerid == '' || Answerid == null ? 
                      <DropDownMenu
                        labelName={I18n.t('sales.createOrder.select_answer')}
                        valueChangeHandler={answer =>
                          answerSelectHandler(item, answer)
                        }
                        listItems={item.answer_master}
                        labelKey={'value'}
                        valueKey={'id'}
                      
                      /> :

                      <DropDownMenu
                      labelName={I18n.t('sales.createOrder.select_answer')}
                      valueChangeHandler={answer =>
                        answerSelectHandler(item, answer)
                      }
                      listItems={item.answer_master}
                      labelKey={'value'}
                      valueKey={'id'}
                      initValue= {Answerid[index].answer_id}
                    /> }
                    </View>
                  </View>
                );
              })}
            {typeid == 3 ? (
              <View>
                <View
                  style={{
                    width: wp('80%'),
                    alignSelf: 'center',
                  }}>
                  <Text style={styles.textStyleRegular}>
                    * Signing Authority details
                  </Text>
                </View>
              

                <TextInputComponent
                  labelName={'Name of signing authority '}
                  isValid={!isValidContactName}
                  validationMsg={contactnNameValidMsg}
                  onChangeHandler={contactNameHandler}
                  keyboardType={'default'}
                  maxLength={250}
                  value={contactName}
                />             

                <TextInputComponent
                  labelName={'Designation'}
                  isValid={!isValidSpeciality}
                  validationMsg={specialityValidMsg}
                  onChangeHandler={specialityHandler}
                  keyboardType={'default'}
                  maxLength={250}
                  value={speciality}
                />

                <TextInputComponent
                  labelName={'Mobile number'}
                  isValid={!isvalidMobileNumber}
                  validationMsg={mobileNumberValidmsg}
                  onChangeHandler={mobileNumberHandler}
                  keyboardType={'number-pad'}
                  maxLength={10}
                  value={mobileNumber}
                />

                <TextInputComponent
                  labelName={I18n.t('sales.createOrder.email_id_placeholder')}
                  isValid={!isaValidEmailId}
                  validationMsg={emailIdValidmsg}
                  onChangeHandler={emailIdHandler}
                  keyboardType={'default'}
                  maxLength={250}
                  value={emailId}
                />

                <TextInputComponent
                  labelName={I18n.t('sales.createOrder.address_placeholder')}
                  isValid={!isValidAddress}
                  validationMsg={addressValidMsg}
                  onChangeHandler={addressHandler}
                  keyboardType={'default'}
                  maxLength={250}
                  value={address}
                />
              </View>
            ) : null}

           
          </ScrollView>
      
        </View>
      </KeyboardAvoidingView>
      <View
              style={{
               // flex: 1,
                flexDirection: 'column',
                alignItems: 'center',
             //   marginTop: hp('1%'),
                paddingBottom : hp('2.5%'),
                backgroundColor : Colors.white,
              }}>
              <View style={styles.buttonContainer}>
                <NextButton onPress={nextButtonHandler} />
              </View>
            </View>
           
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: Colors.white,
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: wp('30%'),
   // marginTop: 8,
   // marginBottom : 10,
    backgroundColor : Colors.white
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  textStyleRegular: {
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    color: Colors.black,
    marginTop: hp('3%'),
  },
});

export default CreateVendorQuestionTermsCondition;
