import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';

import CreateVendorTermsConditionScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import {
  getTermsQuestionAnswer,
  insertTermsQuestionAnswer,
  createVendorTerms,
  createVendorAddTest,
} from '../../../../store/Actions';
import {
  validateLastname,
  validateMobileNo,
  validateSpecilityname,
  validateState,
  validateCity,
  validateAddressLine,
  validateAccountype,
  validatePincodeEmpty,
  validateEmail,
} from '../../../../utils/Validators';
import {delay} from '../../../../utils/Helpers';
import {BackHandler} from 'react-native';

class CreateVendorQuestionTermsCondition extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      contactName: '',
      mobileNumber: '',
      emailId: '',
      address: '',
      speciality: '',

      isValidContactName: '',
      isvalidMobileNumber: '',
      isaValidEmailId: '',
      isValidAddress: '',
      isValidSpeciality: '',

      contactnNameValidMsg: '',
      mobileNumberValidmsg: '',
      emailIdValidmsg: '',
      addressValidMsg: '',
      specialityValidMsg: '',

      isValidated: false,
      showToast: false,
      errorMsg: '',
      terms: [],
      ACTYPE: this.props.route.params.ACTYPE,
      Answerid: '',
    };
  }

  questionHandler = (questionId, answerId) => {
    const newlist = this.state.terms.filter(
      item => item.question_id == questionId,
    );
    if (newlist.length == 0) {
      const term = {
        hostpital_id: this.props.VendorId,
        types_id: this.state.ACTYPE,
        question_id: questionId,
        answer_id: answerId,
        user_id: this.props.UserID,
      };
      console.log(this.state.terms);
      this.setState(prevState => {
        const temp = prevState.terms.find(
          item => item.question_id == questionId && item.answer_id == answerId,
        );
        if (temp) {
          const tempList = prevState.terms.filter(
            item =>
              item.question_id != questionId && item.answer_id != answerId,
          );
          return {
            terms: tempList.concat(term),
          };
        } else {
          return {
            terms: prevState.terms.concat(term),
          };
        }
      });
    } else {
      for (var i = 0; i < this.state.terms.length; i++) {
        if (this.state.terms[i].question_id == questionId) {
          this.state.terms[i].answer_id = answerId;
        }
      }
    }
  };
  contactNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        contactName: val,
      });
    }
  };

  mobileNumberHandler = val => {
    this.setState({
      mobileNumber: val,
    });
  };

  emailIdHandler = val => {
    this.setState({
      emailId: val,
    });
  };

  addressHandler = val => {
    this.setState({
      address: val,
    });
  };

  validateButtonHnadler = () => {
    //  alert('Hi')
    if (this.state.ACTYPE == 3) {
      const valid1 = validateLastname(this.state.speciality);
      const valid2 = validateLastname(this.state.contactName);
      const valid3 = validateMobileNo(this.state.mobileNumber);
      const valid4 = validateEmail(this.state.emailId);
      const valid5 = validateAddressLine(this.state.address);

      if (valid1.val && valid2.val && valid3.val && valid4.val && valid5.val) {
        this.setState({
          isValidSpeciality: valid1.val,
          specialityValidMsg: '',
          isValidContactName: valid2.val,
          contactnNameValidMsg: '',
          isvalidMobileNumber: valid3.val,
          mobileNumberValidmsg: '',
          isaValidEmailId: valid4.val,
          emailIdValidmsg: '',
          isValidAddress: valid5.val,
          emailIdValidMsg: '',
        });
        this.nextButtonHandler();
      } else {
        this.setState({
          isValidSpeciality: valid1.val,
          specialityValidMsg: valid1.msg,
          isValidContactName: valid2.val,
          contactnNameValidMsg: valid2.msg,
          isvalidMobileNumber: valid3.val,
          mobileNumberValidmsg: valid3.msg,
          isaValidEmailId: valid4.val,
          emailIdValidmsg: valid4.msg,
          isValidAddress: valid5.val,
          addressValidMsg: valid5.msg,
        });
      }
    } else {
      //  alert('hi')
      //this.nextButtonHandler();
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  nextButtonHandler = () => {
    if (this.state.ACTYPE == 3) {
      if (this.props.getQuestionAnswerResponse != null) {
        if (
          this.props.getQuestionAnswerResponse.length == this.state.terms.length
        ) {
          const valid1 = validateLastname(this.state.speciality);
          const valid2 = validateLastname(this.state.contactName);
          const valid3 = validateMobileNo(this.state.mobileNumber);
          const valid4 = validateEmail(this.state.emailId);
          const valid5 = validateAddressLine(this.state.address);

          if (
            valid1.val &&
            valid2.val &&
            valid3.val &&
            valid4.val &&
            valid5.val
          ) {
            this.setState({
              isValidSpeciality: valid1.val,
              specialityValidMsg: '',
              isValidContactName: valid2.val,
              contactnNameValidMsg: '',
              isvalidMobileNumber: valid3.val,
              mobileNumberValidmsg: '',
              isaValidEmailId: valid4.val,
              emailIdValidmsg: '',
              isValidAddress: valid5.val,
              emailIdValidMsg: '',
            });
            this.update();
          } else {
            this.setState({
              isValidSpeciality: valid1.val,
              specialityValidMsg: 'Please enter designation',
              isValidContactName: valid2.val,
              contactnNameValidMsg: 'Please enter name',
              isvalidMobileNumber: valid3.val,
              mobileNumberValidmsg: valid3.msg,
              isaValidEmailId: valid4.val,
              emailIdValidmsg: valid4.msg,
              isValidAddress: valid5.val,
              addressValidMsg: valid5.msg,
            });
          }
        } else {
          this.setState(
            {
              errorMsg: 'Please select all terms and conditions',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
        }
      }
    } else {
      if (this.props.getQuestionAnswerResponse != null) {
        if (
          this.props.getQuestionAnswerResponse.length == this.state.terms.length
        ) {
          this.update();
        } else {
          this.setState(
            {
              errorMsg: 'Please select all terms and conditions',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
        }
      }
    }
  };

  update() {
    const data = {
      hostpital_id: this.props.VendorId,
      types_id: Number(this.state.ACTYPE),
      terms: this.state.terms,
      name_of_signing: this.state.contactName,
      designation: this.state.speciality,
      contact_number: this.state.mobileNumber,
      email_id: this.state.emailId,
      address: this.state.address,
      user_id: this.props.UserID,
    };

    // this.props.navigation.navigate(Sales.createVendorTermsCondition);
    this.props.onInsertTermsQuestionAnswer(data, this.props.accessToken);
  }

  specialityHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        speciality: val,
      });
    }
  };

  navigationNextpage = () => {
    this.setState({
      terms: [],
    });
    this.props.onCreateVendorTerms(null);
    const data = {
      producttestDetails: null,
      productDetails: null,
      invoiceAmount: null,
      productSelectionindex: null,
      totalTestSelected: null,
      totalTestOutliners: null,
      totalTestAutoApproved: null,
    };

    this.props.onCreateVendorAddTest(data);
    this.props.navigation.navigate(Sales.createVendorTermsCondition, {
      URL: this.props.insertQuestionAnswerResponse.Message,
      Hospitalname: this.props.insertQuestionAnswerResponse.LC_VD_HOSPITALNAME,
      vendorID: this.props.insertQuestionAnswerResponse.LC_VD_VENID,
      ACTYPE: this.state.ACTYPE,
    });

    // this.props.navigation.navigate(Sales.createVendorTermsCondition);
  };

  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    //console.log("Terms and consitions lenght : ",this.props.vendortermsDetail)

    if (
      this.props.vendortermsDetail == undefined ||
      this.props.vendortermsDetail == null ||
      this.props.vendortermsDetail == ''
    ) {
      this.props.onCreateVendorTerms(null);
    } else {
      this.setState({terms: this.props.vendortermsDetail});
    }

    // alert(this.props.vendortermsDetail[0].answer_id)
    // if (this.props.payDetailResponse.crmId != null) {
    const data = {
      typeid: this.state.ACTYPE,
    };
    // };
    this.props.onGetTermsQuestionAnswer(data, this.props.accessToken);
  }

  componentDidUpdate = prevProps => {
    // send otp error

    if (
      prevProps.getQuestionAnswerStatus == false &&
      this.props.getQuestionAnswerStatus != prevProps.getQuestionAnswerStatus
    ) {
    }
    if (
      prevProps.insertQuestionAnswerStatus == false &&
      this.props.insertQuestionAnswerStatus !=
        prevProps.insertQuestionAnswerStatus
    ) {
      this.navigationNextpage();
    }
    //send otp success

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  };

  componentWillUnmount() {
    this.props.onCreateVendorTerms(null);
    this.props.onCreateVendorTerms(this.state.terms);
  }

  render() {
    //console.log('valide props 1', this.props.getQuestionAnswerResponse.length);
    return (
      <CreateVendorTermsConditionScreen
        contactNameHandler={this.contactNameHandler}
        mobileNumberHandler={this.mobileNumberHandler}
        emailIdHandler={this.emailIdHandler}
        addressHandler={this.addressHandler}
        specialityHandler={this.specialityHandler}
        nextButtonHandler={this.nextButtonHandler}
        contactName={this.state.contactName}
        mobileNumber={this.state.mobileNumber}
        emailId={this.state.emailId}
        address={this.state.address}
        speciality={this.state.speciality}
        isValidContactName={this.state.isValidContactName}
        isvalidMobileNumber={this.state.isvalidMobileNumber}
        isaValidEmailId={this.state.isaValidEmailId}
        isValidAddress={this.state.isValidAddress}
        isValidSpeciality={this.state.isValidSpeciality}
        contactnNameValidMsg={this.state.contactnNameValidMsg}
        mobileNumberValidmsg={this.state.mobileNumberValidmsg}
        emailIdValidmsg={this.state.emailIdValidmsg}
        addressValidMsg={this.state.addressValidMsg}
        specialityValidMsg={this.state.specialityValidMsg}
        getQuestionAnswerResponse={this.props.getQuestionAnswerResponse}
        questionHandler={this.questionHandler}
        typeid={this.state.ACTYPE}
        Answerid={this.props.vendortermsDetail}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  // console.log("state Details:======================>", state);
  return {
    message: state.createVendor.message,
    getQuestionAnswerLoading: state.createVendor.getQuestionAnswerLoading,
    getQuestionAnswerStatus: state.createVendor.getQuestionAnswerStatus,
    getQuestionAnswerError: state.createVendor.getQuestionAnswerError,
    getQuestionAnswerResponse: state.createVendor.getQuestionAnswerResponse,
    insertQuestionAnswerLoading: state.createVendor.insertQuestionAnswerLoading,
    insertQuestionAnswerStatus: state.createVendor.insertQuestionAnswerStatus,
    insertQuestionAnswerError: state.createVendor.insertQuestionAnswerError,
    insertQuestionAnswerResponse:
      state.createVendor.insertQuestionAnswerResponse,
    UserID: state.signIn.userId,
    VendorId: state.createVendor.insertVendorResponse,
    vendortermsDetail: state.createVendor.vendortermsDetail,
    accessToken: state.signIn.accessToken,

    //  payementOtpResponseStatus: state.payementMode.payementModeOtpStatus,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetTermsQuestionAnswer: (data, token) =>
      dispatch(getTermsQuestionAnswer(data, token)),
    onInsertTermsQuestionAnswer: (data, token) =>
      dispatch(insertTermsQuestionAnswer(data, token)),

    onCreateVendorTerms: data => dispatch(createVendorTerms(data)),

    onCreateVendorAddTest: data => dispatch(createVendorAddTest(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateVendorQuestionTermsCondition);
