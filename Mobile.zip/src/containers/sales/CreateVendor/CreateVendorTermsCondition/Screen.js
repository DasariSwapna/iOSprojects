import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  TouchableOpacity,
  Share,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, {HomeButton} from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import TimeLineContainer from '../../../../components/TimeLineContainer';
import Icons from '../../../../constants/Icons';
import PageNo from '../../../../constants/PageNo';
import Pdf from 'react-native-pdf';
import IonIcons from 'react-native-vector-icons/Ionicons';
import {color} from 'react-native-reanimated';
import DownloadImageComponent from '../../../../components/DownloadImageComponet';
// const source = {
//   uri: 'http://samples.leanpub.com/thereactnativebook-sample.pdf',
//   cache: true,
// };
import {Toast} from '../../../../components/Toast';

function CreateVendorTermsConditionScreen({
  addressTypeHandler,
  shareButtonHandler,
  nextButtonHandler,
  downloadButtonHandler,
  downloadButtonHandler1,
  showToast,
  errorMsg,
  source,
  ACTYPE,
}) {
  return (
    
    <RootView pageNo={PageNo.sales_createVendorTermsCondition}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
     <View style={styles.mainContainer}>

      <View style={styles.lineLargeContainer} />
      <View
        style={{
          borderColor: Colors.primary,
          backgroundColor: Colors.background,
          marginHorizontal: wp('5%'),
          marginVertical: hp('2%'),
          marginTop : hp('5%'),
          width: '90%',
          height: '65%',
          borderWidth: Platform.OS == 'ios' ? 0.2 : 0.6,
          borderRadius: 10,
         // shadowColor: Colors.primary,
          shadowOffset: {
            width: 0,
            height: 3,
          },
         // shadowOpacity: 0.29,
         // shadowRadius: 4.65,
          elevation: 7,
        }}>
        <Pdf
          source={source}
          onLoadComplete={(numberOfPages, filePath) => {
            console.log(`Number of pages: ${numberOfPages}`);
          }}
          onPageChanged={(page, numberOfPages) => {
            console.log(`Current page: ${page}`);
          }}
          onError={error => { 
            console.log(error);
          }}
          onPressLink={uri => {
            console.log(`Link pressed: ${uri}`);
          }}
          style={styles.pdf}
        />
      </View>

      <View
        style={{
          alignSelf: 'flex-end',
          flexDirection: 'row',
          width: wp('80%'),
          height: 40,
          alignItems: 'center',
          justifyContent: 'space-between',
          marginRight: hp('5%'),
          marginTop: hp('0.5%'),
        }}>
        <View>
          {ACTYPE == '1' ? null : (
            <TouchableOpacity onPress={downloadButtonHandler1}>
              <Text style={styles.textValidationMsg}>Enrollment form</Text>
            </TouchableOpacity>
          )}
        </View>
        <View
          style={{
            alignSelf: 'flex-end',
            flexDirection: 'row',
            justifyContent: 'space-between',
            //  flex : 1
          }}>
          <TouchableOpacity onPress={downloadButtonHandler}>
            <Image
              source={Images.download1}
              style={{width: hp('3%'), height: hp('3%'), marginRight: 8}}
              resizeMode="cover"
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={shareButtonHandler}>
            <IonIcons
              name={'share-social'}
              color={Colors.border}
              size={hp('3%')}
            />
          </TouchableOpacity>
        </View>
      </View>

     
      </View>
      <View
        style={{
        //  flex: 1,
          flexDirection: 'column',
          alignItems: 'center',
          backgroundColor : Colors.white,
          paddingBottom : hp('2.5%'),
        }}>
        <View style={styles.buttonContainer}>
          <HomeButton onPress={nextButtonHandler} />
        </View>
        </View>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor : Colors.white
 
  },
  pdf: {
    marginVertical: wp('1%'),
    marginHorizontal: wp('1%'),
    width: '98%',
    height: '98%',
    backgroundColor: Colors.white,
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    marginTop: 8,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  textStyleRegular: {
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
    color: Colors.termsTextColor,
    marginTop: 30,
  },
  textValidationMsg: {
    // width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    // alignSelf: 'center',
    textDecorationLine: 'underline',
  },
});

export default CreateVendorTermsConditionScreen;
