import React from 'react';
import {Share, PermissionsAndroid, Platform} from 'react-native';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../../utils/Validators';
import CreateVendorTermsConditionScreen from './Screen';
import Routes, {Sales} from '../../../../navigations/RouteTypes';
import DocumentPicker from 'react-native-document-picker';
import RNFetchBlob from 'rn-fetch-blob';
import {delay} from '../../../../utils/Helpers';
import {
  createVendorTerms,
  createVendorAddTest,
} from '../../../../store/Actions';
import {BackHandler} from 'react-native';

class CreateVendorTermsCondition extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      isValidated: false,
      errorMsg: '',
      showToast: false,
      source: {
        uri: this.props.insertQuestionAnswerResponse.Message,
        cache: false,
      },
      appConfigResponse: '',
      ACTYPE: this.props.route.params.ACTYPE,
    };
  }

  actualDownloadiOS = () => {
    try {
      const {config, fs} = RNFetchBlob;
      let dirs = fs.dirs;
      let options = {
        fileCache: false,
        appendExt: 'pdf',
        path:
          dirs.DocumentDir +
          '/' +
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID +
          '.pdf',
      };
      config(options)
        .fetch('GET', this.props.route.params.URL)
        .then(res => {
          // do some magic here
          // RNFetchBlob.ios.openDocument();
          this.setState(
            {
              errorMsg: 'Downloding: On My iPhone =>Lifecell',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );

          //  Downloding: On My iPhone =>Lifecell
          //  toastMsg(this.state.downloadtext);
          console.log('File download', res.path());
        });
    } catch (error) {
      console.log('File download error', error);
    }
  };

  actualDownloadiOS1 = () => {
    try {
      // alert(this.props.appConfigResponse);
      const {config, fs} = RNFetchBlob;
      let dirs = fs.dirs;
      let options = {
        fileCache: false,
        appendExt: 'pdf',
        path: dirs.DocumentDir + '/' + 'Enrollment form' + '.pdf',
      };
      config(options)
        .fetch('GET', this.props.appConfigResponse)
        .then(res => {
          // do some magic here
          // RNFetchBlob.ios.openDocument();
          this.setState(
            {
              errorMsg: 'Downloding: On My iPhone =>Lifecell',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );

          //  Downloding: On My iPhone =>Lifecell
          //  toastMsg(this.state.downloadtext);
          console.log('File download', res.path());
        });
    } catch (error) {
      console.log('File download error', error);
    }
  };

  async downloadFile1() {
    console.log('plato', Platform.OS);

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload1();
      } else {
        alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  actualDownload1 = () => {
    RNFetchBlob.fs
      .mkdir(RNFetchBlob.fs.dirs.SDCardDir + '/LifeCell')

      .then(() => {
        alert('created');
      })

      .catch(err => {
        console.log(err);
      });

    RNFetchBlob.fs
      .ls(RNFetchBlob.fs.dirs.SDCardDir)

      // files will an array contains filenames

      .then(files => {
        console.log(files);
      });

    const {dirs} = RNFetchBlob.fs;

    console.log(dirs);

    RNFetchBlob.config({
      fileCache: true,

      addAndroidDownloads: {
        useDownloadManager: true,

        notification: true,

        mediaScannable: true,

        title: 'Enrollment form',

        path: dirs.DownloadDir + '/' + 'Enrollment form' + '.pdf',

        //  +''+this.state.PDF_name+".pdf"`,

        // path: `${dirs.DownloadDir}/this.state.PDF_name.pdf,
      },
    })

      .fetch('GET', this.props.appConfigResponse, {})

      .then(res => {
        // toastMsg(this.state.downloadtext1);

        console.log('The file saved to ', res.path());
      })

      .catch(e => {
        console.log(e);
      });
  };

  async downloadFile() {
    console.log('plato', Platform.OS);

    try {
      const granted = await PermissionsAndroid.request(
        PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
      );

      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        this.actualDownload();
      } else {
        alert(
          'Permission Denied!',
          'You need to give storage permission to download the file',
        );
      }
    } catch (err) {
      console.warn(err);
    }
  }

  actualDownload = () => {
    RNFetchBlob.fs
      .mkdir(RNFetchBlob.fs.dirs.SDCardDir + '/LifeCell')

      .then(() => {
        alert('created');
      })

      .catch(err => {
        console.log(err);
      });

    RNFetchBlob.fs
      .ls(RNFetchBlob.fs.dirs.SDCardDir)

      // files will an array contains filenames

      .then(files => {
        console.log(files);
      });

    const {dirs} = RNFetchBlob.fs;

    console.log(dirs);

    RNFetchBlob.config({
      fileCache: true,

      addAndroidDownloads: {
        useDownloadManager: true,

        notification: true,

        mediaScannable: true,

        title:
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID,

        path:
          dirs.DownloadDir +
          '/' +
          this.props.route.params.Hospitalname +
          '' +
          this.props.route.params.vendorID +
          '.pdf',

        //  +''+this.state.PDF_name+".pdf"`,

        // path: `${dirs.DownloadDir}/this.state.PDF_name.pdf,
      },
    })

      .fetch('GET', this.props.route.params.URL, {})

      .then(res => {
        // toastMsg(this.state.downloadtext1);

        console.log('The file saved to ', res.path());
      })

      .catch(e => {
        console.log(e);
      });
  };

  downloadButtonHandler = async () => {
    {
      Platform.OS == 'ios' ? this.actualDownloadiOS() : this.downloadFile();
    }
  };

  downloadButtonHandler1 = async () => {
    {
      Platform.OS == 'ios' ? this.actualDownloadiOS1() : this.downloadFile1();
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  backHandler = () => {
    this.props.navigation.navigate(Sales.myDrawer);
    return true;
  };
  componentDidMount() {
    this.setState({
      source: {
        uri: this.props.route.params.URL,
        cache: false,
      },
    });
    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  componentWillUnmount() {
    this.back.remove();
  }

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createVendorPreview);
    this.props.onCreateVendorTerms(null);
    const data = {
      producttestDetails: null,
      productDetails: null,
      invoiceAmount: '',
      productSelectionindex: '',
      totalTestSelected: '',
      totalTestOutliners: '',
      totalTestAutoApproved: '',
    };
    this.props.onCreateVendorAddTest(data);
    this.props.navigation.navigate(Sales.myDrawer);
  };

  shareButtonHandler = async () => {
    const result = await Share.share({
      message: this.state.source.uri,
    });
    if (result.action === Share.sharedAction) {
      if (result.activityType) {
        // shared with activity type of result.activityType
      } else {
        // shared
      }
    } else if (result.action === Share.dismissedAction) {
      // dismissed
    }
  };
  // downloadButtonHandler = () => {
  //   //Function to check the platform
  //   //If iOS the start downloading
  //   //If Android then ask for runtime permission
  //   if (Platform.OS === 'ios') {
  //     this.downloadHistory();
  //   } else {
  //     try {
  //       PermissionsAndroid.request(
  //         PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
  //         {
  //           title: 'storage title',
  //           message: 'storage_permission',
  //         },
  //       ).then(granted => {
  //         if (granted === PermissionsAndroid.RESULTS.GRANTED) {
  //           //Once user grant the permission start downloading
  //           console.log('Storage Permission Granted.');
  //           this.downloadHistory();
  //         } else {
  //           //If permission denied then show alert 'Storage Permission

  //           Alert.alert('storage_permission');
  //         }
  //       });
  //     } catch (err) {
  //       //To handle permission related issue
  //       console.log('error', err);
  //     }
  //   }
  // };
  // downloadHistory = async () => {
  //   const {config, fs} = RNFetchBlob;
  //   let PictureDir = fs.dirs.PictureDir;
  //   let date = new Date();
  //   let options = {
  //     fileCache: true,
  //     addAndroidDownloads: {
  //       //Related to the Android only
  //       useDownloadManager: true,
  //       notification: true,
  //       path:
  //         PictureDir +
  //         '/Report_Download' +
  //         Math.floor(date.getTime() + date.getSeconds() / 2),
  //       description: 'Risk Report Download',
  //     },
  //   };
  //   config(options)
  //     .fetch('GET', this.state.source.uri)
  //     .then(res => {
  //       //Showing alert after successful downloading
  //       console.log('res -> ', JSON.stringify(res));
  //       alert('Report Downloaded Successfully.');
  //     });
  // };

  render() {
    return (
      <CreateVendorTermsConditionScreen
        nextButtonHandler={this.nextButtonHandler}
        shareButtonHandler={this.shareButtonHandler}
        downloadButtonHandler={this.downloadButtonHandler}
        downloadButtonHandler1={this.downloadButtonHandler1}
        source={this.state.source}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        appConfigResponse={this.props.appConfigResponse}
        ACTYPE={this.state.ACTYPE}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
    appConfigResponse: state.common.appConfigEnrollmentPDFResponse,
    insertQuestionAnswerResponse:
      state.createVendor.insertQuestionAnswerResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onCreateVendorTerms: data => dispatch(createVendorTerms(data)),

    onCreateVendorAddTest: data => dispatch(createVendorAddTest(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateVendorTermsCondition);
