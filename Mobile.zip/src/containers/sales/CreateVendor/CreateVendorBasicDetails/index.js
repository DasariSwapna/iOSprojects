import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {
  isValidUsername,
  isValidPassword,
  validatedoctorFirstname,
  validatedoctorLastname,
  validateFirstname,
  validateLastname,
  validateMobileNo,
  validateSpecilityname,
  validateState,
  validateCity,
  validateAddressLine,
  validateAccountype,
  validatePincodeEmpty,
  validateEmail,
  validateStateDropdownEmpty,
  validateCityDropdownEmpty,
} from '../../../../utils/Validators';
import CreateVendorBasicDetailScreen from './Screen';
import {Sales} from '../../../../navigations/RouteTypes';
import {
  getState,
  geAccountType,
  getCity,
  getSpeciality,
  insertVendor,
  insertHospitalDoctor,
  createVendorBasic,
  getVendorDetails,
  createVendorTerms,
} from '../../../../store/Actions';
import {delay} from '../../../../utils/Helpers';
import {Auth} from '../../navigations/RouteTypes';
import {BackHandler} from 'react-native';

class CreateVendorBasicDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      accountType: '',
      hospitalName: '',
      contactName: '',
      mobileNumber: '',
      emailId: '',
      address: '',
      state: '',
      city: '',
      pincode: '',
      doctorName: '',
      doctorLastname: '',
      speciality: '',

      isValidAccountType: true,
      isValidHospitalName: true,
      isValidContactName: true,
      isvalidMobileNumber: true,
      isaValidEmailId: true,
      isValidAddress: true,
      isValidState: true,
      isValidCity: true,
      isValidPincode: true,
      isValidDoctorName: true,
      isValidDoctorLastname: true,
      isValidSpeciality: true,

      accountTypeValidMsg: '',
      hospitalValidMsg: '',
      contactnNameValidMsg: '',
      mobileNumberValidmsg: '',
      emailIdValidmsg: '',
      addressValidMsg: '',
      stateValidmsg: '',
      cityValidMsg: '',
      pincodeValidMsg: '',
      doctorNameValidMsg: '',
      doctorLastNameValidMsg: '',
      specialityValidMsg: '',

      doctorList: [],

      showToast: false,
      errorMsg: '',
    };
  }

  validateDoctorList = () => {
    if (this.state.doctorList.length < 1) {
      if (this.state.doctorName == '') {
        this.setState(
          {
            errorMsg: 'Please add Doctor',
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Firstname empty');
      } else if (this.state.doctorLastname == '') {
        this.setState(
          {
            errorMsg: 'Please add Doctor',
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Lastname empty');
      } else if (this.state.speciality == '') {
        this.setState(
          {
            errorMsg: 'Please add Doctor',
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Speciality empty S');
      } else {
       
        if (this.state.doctorList.length < 1) {
          this.setState(
            {
              errorMsg: 'Please add Doctor',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
        }
        else
        {

         const data = {
          drfirstname: this.state.doctorName,
          drlastname: this.state.doctorLastname,
          specialityid: this.state.speciality,
          speciality: this.state.speciality,
        };

      
        this.setState({doctorList: data});
      
        this.setState({
          doctorName: '',
          doctorLastname: '',
          speciality: '',
        });
        const data1 = {
          search: null,
        };
        this.props.onGetSpeciality(data1, this.props.accessToken);
        this.update();
      }
      }

      return false;
    } else {
      return true;
    }
  };

  nextButtonHandler = () => {
    // this.props.navigation.navigate(Sales.createVendorAddTest,
    //   {
    //     RETAIL: this.state.accountType == '1' ? true : false,
    //   });

    const valid1 = validateFirstname(this.state.hospitalName);
    const valid2 = validateLastname(this.state.contactName);
    const valid3 = validateMobileNo(this.state.mobileNumber);
    const valid4 = validateEmail(this.state.emailId);
    const valid5 = validateAddressLine(this.state.address);
    const valid6 = validatePincodeEmpty(this.state.pincode);

    const valid8 = validateStateDropdownEmpty(this.state.state);
    const valid9 = validateCityDropdownEmpty(this.state.city);
    const valid7 = validateAccountype(this.state.accountType);

    var isValidDoctor = this.validateDoctorList();

    if (
      valid1.val &&
      valid2.val &&
      valid3.val &&
      valid4.val &&
      valid5.val &&
      valid6.val &&
      valid7.val &&
      valid8.val &&
      valid9.val &&
      isValidDoctor
    ) {
      this.setState({
        isValidHospitalName: valid1.val,
        hospitalValidMsg: '',
        isValidContactName: valid2.val,
        contactnNameValidMsg: '',
        isvalidMobileNumber: valid3.val,
        mobileNumberValidmsg: '',
        isaValidEmailId: valid4.val,
        emailIdValidmsg: '',
        isValidAddress: valid5.val,
        emailIdValidMsg: '',
        isValidPincode: valid6.val,
        pincodeValidMsg: '',
        isValidAccountType: valid7.val,
        accountTypeValidMsg: '',
        isValidState: valid8.val,
        stateValidmsg: '',
        isValidCity: valid9.val,
        cityValidMsg: '',
      });

      this.update();
    } else {
      this.setState({
        isValidHospitalName: valid1.val,
        hospitalValidMsg: 'Please enter hospital name',
        isValidContactName: valid2.val,
        contactnNameValidMsg: 'Please enter contact name',
        isvalidMobileNumber: valid3.val,
        mobileNumberValidmsg: valid3.msg,
        isaValidEmailId: valid4.val,
        emailIdValidmsg: valid4.msg,
        isValidAddress: valid5.val,
        addressValidMsg: valid5.msg,

        isValidPincode: valid6.val,
        pincodeValidMsg: valid6.msg,

        isValidAccountType: valid7.val,
        accountTypeValidMsg: valid7.msg,
        isValidState: valid8.val,
        stateValidmsg: valid8.msg,
        isValidCity: valid9.val,
        cityValidMsg: valid9.msg,
      });
    }
    // this.update();
  };

  update = () => {
    // 20.204.247.200:8087/LifeCellMobile/vendor/insertUpdateVendorDetails
    const data = {
      accounttype: this.state.accountType,
      vendorname: this.state.hospitalName,
      contactname: this.state.contactName,
      mobilenumber: this.state.mobileNumber,
      email: this.state.emailId,
      hospitaladdress: this.state.address,
      city: this.state.city,
      state: this.state.state,
      pincode: this.state.pincode,
      drdetails: this.state.doctorList,
      userid: this.props.userid,
    };
    console.log('data' + JSON.stringify(data));

    this.props.onInsertVendor(data, this.props.accessToken);

    this.props.onCreateVendorBasic(data);
  };

  accountTypeHandler = val => {
    this.props.onCreateVendorTerms(null);

    this.setState({
      accountType: val,
    });

    /* if (this.props.insertHospitalDoctorResponse != null) {
      if (this.props.insertHospitalDoctorResponse.createOrder) {
        if (val != '1') {
          this.setState(
            {
              errorMsg: 'Please select only retail',
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
          this.setState({
            accountType: '',
          });
        } else {
          this.setState({
            accountType: val,
          });
        }
      } else {
        this.setState({
          accountType: val,
        });
      }
    } */
  };

  hospitalNameHandler = val => {
    //alert(val)
    // if (!/[^a-zA-Z, ]/.test(val)) {
    this.setState({
      hospitalName: val,
    });
    //  }
  };

  contactNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        contactName: val,
      });
    }
  };

  mobileNumberHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      if (val.length > 9) {
        this.setState({
          mobileNumber: val,
        });
        const data2 = {mobilenumber: val};
        this.props.onGetVendorDetails(data2, this.props.accessToken);
      } else {
        this.setState({
          mobileNumber: val,
        });
      }
    }
  };

  emailIdHandler = val => {
    this.setState({
      emailId: val,
    });
  };

  addressHandler = val => {
    this.setState({
      address: val,
    });
  };

  stateHandler = val => {
    this.setState({
      state: val,
    });
    const cityData = {
      stateid: val,
      search: null,
    };
    // alert(JSON.stringify(cityData));
    this.props.onGetCity(cityData, this.props.accessToken);
  };

  cityHandler = val => {
    this.setState({
      city: val,
    });
  };

  pincodeHandler = val => {
    this.setState({
      pincode: val,
    });
  };

  doctorNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        doctorName: val,
      });
    }
  };

  doctorLastNameHandler = val => {
    if (!/[^a-zA-Z, ]/.test(val)) {
      this.setState({
        doctorLastname: val,
      });
    }
  };

  specialityHandler = val => {
    this.setState({
      speciality: val,
    });
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  addDoctorHandler = () => {
    const valid1 = validatedoctorFirstname(this.state.doctorName);
    const valid2 = validatedoctorLastname(this.state.doctorLastname);
    const valid3 = validateSpecilityname(this.state.speciality);

    if (valid1.val && valid2.val) {
      this.setState({
        isValidDoctorName: valid1.val,
        doctorNameValidMsg: valid1.msg,
        isValidDoctorLastname: valid2.val,
        isValidSpeciality: valid3.val,
        specialityValidMsg: valid3.msg,
        doctorLastNameValidMsg: valid2.msg,
      });
    } else {
      this.setState({
        isValidDoctorName: valid1.val,
        doctorNameValidMsg: valid1.msg,
        isValidDoctorLastname: valid2.val,
        doctorLastNameValidMsg: valid2.msg,
        isValidSpeciality: valid3.val,
        specialityValidMsg: valid3.msg,
      });
    }

    if (this.state.doctorName == '') {
      console.log('Firstname empty');
    } else if (this.state.doctorLastname == '') {
      console.log('Lastname empty');
    } else if (this.state.speciality == '') {
      console.log('Speciality empty');
    } else {
      const data = {
        drfirstname: this.state.doctorName,
        drlastname: this.state.doctorLastname,
        specialityid: this.state.speciality,
        speciality: this.state.speciality,
      };
      this.setState({doctorList: [...this.state.doctorList, data]});
      this.setState({
        doctorName: '',
        doctorLastname: '',
        speciality: '',
      });
      const data1 = {
        search: null,
      };
      this.props.onGetSpeciality(data1, this.props.accessToken);
    }
  };

  removeHandler = index => {
    //alert(index)
    let arr = this.state.doctorList;
    arr.splice(index, 1);
    this.setState({doctorList: arr});
  };

  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount = () => {
    /* if(this.props.vendorbasicDetail == undefined || this.props.vendorbasicDetail == '' || this.props.vendorbasicDetail == [])
    {

    }
    else
    {
      this.setState(
        {
          hospitalName : this.props.vendorbasicDetail.vendorname,
          accountType : this.props.vendorbasicDetail.accounttype,
        })
    } */
    //alert(this.props.accessToken)
    const data = {
      search: null,
    };
    this.props.onGetState(data, this.props.accessToken);
    this.props.onGetSpeciality(data, this.props.accessToken);
    const data1 = {
      flag: this.props.insertHospitalDoctorResponse != null ? 1 : 0,
    };
    this.props.onGetAccountType(data1, this.props.accessToken);

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.insertVendorStatus != this.props.insertVendorStatus &&
      this.props.insertVendorStatus == true
    ) {
      /*  this.setState(
        {
          errorMsg: 'Vendor created successfully',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      ); */
      // this.props.navigation.navigate(Sales.createVendorAddTest, {
      //   RETAIL: this.state.accountType == '1' ? true : false,
      //   ACTYPE: this.state.accountType,
      // });
      //await delay(1000);
      // alert(this.props.insertHospitalDoctorResponse)
      if (this.props.insertHospitalDoctorResponse != null) {
        if (this.props.insertHospitalDoctorResponse.createOrder) {
          // const data = {
          //   createOrder: false,
          // }
          this.props.OnInsertHospitalDoctor(null);
          this.props.navigation.goBack();
        }
      } else {
        this.props.navigation.navigate(Sales.createVendorAddTest, {
          RETAIL: this.state.accountType == '1' ? true : false,
          ACTYPE: this.state.accountType,
        });
      }
    }

    if (
      prevProps.vendorDetailsStatus == false &&
      this.props.vendorDetailsStatus != prevProps.vendorDetailsStatus
    ) {
      // alert(this.props.vendorDetailsResponse.LC_VD_ACCOUNT_TYPE_ID)

      if (this.props.vendorDetailsResponse == undefined) {
      } else {
        // this.setState({doctorList : this.props.vendorDetailsDoctorResponse })
        if (
          this.props.vendorDetailsDoctorResponse == undefined ||
          this.props.vendorDetailsDoctorResponse == ''
        ) {
        } else {
          this.setState({doctorList: []});
          this.setState({
            doctorList: [
              ...this.state.doctorList,
              this.props.vendorDetailsDoctorResponse,
            ],
          });
        }
        //   alert(this.props.vendorDetailsDoctorResponse )

        this.setState({
          accountType: this.props.vendorDetailsResponse.LC_VD_ACCOUNT_TYPE_ID,
          hospitalName: this.props.vendorDetailsResponse.LC_VD_HOSPITALNAME,
          contactName:
            this.props.vendorDetailsResponse.LC_VD_CONTACTPERSON_NAME,
          mobileNumber: this.props.vendorDetailsResponse.LC_VD_PRIMARYCONTACT,
          emailId: this.props.vendorDetailsResponse.LC_VD_EMAILID,
          address: this.props.vendorDetailsResponse.LC_VD_HOSPITALADDRESS,
          city: this.props.vendorDetailsResponse.City_ID,
          state: this.props.vendorDetailsResponse.State_ID,
          pincode: this.props.vendorDetailsResponse.LC_VD_PINCODE,
        });
      }
    }

    if (
      prevProps.insertVendorError != this.props.insertVendorError &&
      this.props.insertVendorError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.insertvendorresponsedatas,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  render() {
    return (
      <CreateVendorBasicDetailScreen
        loading={
          this.props.insertVendorLoading || this.props.vendorDetailsLoading
        }
        nextButtonHandler={this.nextButtonHandler}
        addDoctorHandler={this.addDoctorHandler}
        removeHandler={this.removeHandler}
        accountTypeHandler={this.accountTypeHandler}
        hospitalNameHandler={this.hospitalNameHandler}
        contactNameHandler={this.contactNameHandler}
        mobileNumberHandler={this.mobileNumberHandler}
        emailIdHandler={this.emailIdHandler}
        addressHandler={this.addressHandler}
        stateHandler={this.stateHandler}
        cityHandler={this.cityHandler}
        pincodeHandler={this.pincodeHandler}
        doctorNameHandler={this.doctorNameHandler}
        doctorLastNameHandler={this.doctorLastNameHandler}
        specialityHandler={this.specialityHandler}
        accountType={this.state.accountType}
        hospitalName={this.state.hospitalName}
        contactName={this.state.contactName}
        mobileNumber={this.state.mobileNumber}
        emailId={this.state.emailId}
        address={this.state.address}
        state={this.state.state}
        city={this.state.city}
        pincode={this.state.pincode}
        doctorName={this.state.doctorName}
        doctorLastname={this.state.doctorLastname}
        speciality={this.state.speciality}
        isValidAccountType={this.state.isValidAccountType}
        isValidHospitalName={this.state.isValidHospitalName}
        isValidContactName={this.state.isValidContactName}
        isvalidMobileNumber={this.state.isvalidMobileNumber}
        isaValidEmailId={this.state.isaValidEmailId}
        isValidAddress={this.state.isValidAddress}
        isValidState={this.state.isValidState}
        isValidCity={this.state.isValidCity}
        isValidPincode={this.state.isValidPincode}
        isValidDoctorName={this.state.isValidDoctorName}
        isValidDoctorLastname={this.state.isValidDoctorLastname}
        isValidSpeciality={this.state.isValidSpeciality}
        accountTypeValidMsg={this.state.accountTypeValidMsg}
        hospitalValidMsg={this.state.hospitalValidMsg}
        contactnNameValidMsg={this.state.contactnNameValidMsg}
        mobileNumberValidmsg={this.state.mobileNumberValidmsg}
        emailIdValidmsg={this.state.emailIdValidmsg}
        addressValidMsg={this.state.addressValidMsg}
        stateValidmsg={this.state.stateValidmsg}
        cityValidMsg={this.state.cityValidMsg}
        pincodeValidMsg={this.state.pincodeValidMsg}
        doctorNameValidMsg={this.state.doctorNameValidMsg}
        doctorLastNameValidMsg={this.state.doctorLastNameValidMsg}
        specialityValidMsg={this.state.specialityValidMsg}
        accountTypeList={this.props.accountTypeList}
        stateList={this.props.stateList}
        cityList={this.props.cityList}
        specialityList={this.props.specialityList}
        doctorList={this.state.doctorList}
        status={this.state.status}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    stateList: state.common.stateResponse,
    cityList: state.common.cityResponse,
    accessToken: state.signIn.accessToken,
    userid: state.signIn.userId,
    accountTypeList: state.common.accountTypeResponse,
    specialityList: state.common.specialityResponse,
    insertVendorStatus: state.createVendor.insertVendorStatus,
    insertvendorresponsedatas: state.createVendor.message,
    insertVendorError: state.createVendor.insertVendorError,
    insertVendorLoading: state.createVendor.insertVendorLoading,

    insertHospitalDoctorResponse:
      state.createVendor.insertHospitalDoctorResponse,

    vendorbasicDetail: state.createVendor.vendorbasicDetail,

    vendorDetailsResponse: state.createVendor.vendorDetailsResponse,
    vendorDetailsLoading: state.createVendor.vendorDetailsLoading,
    vendorDetailsStatus: state.createVendor.vendorDetailsStatus,
    vendorDetailsDoctorResponse: state.createVendor.vendorDetailsDoctorResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetSpeciality: (data, token) => dispatch(getSpeciality(data, token)),
    onGetAccountType: (data, token) => dispatch(geAccountType(data, token)),
    onGetState: (data, token) => dispatch(getState(data, token)),
    onGetCity: (data, token) => dispatch(getCity(data, token)),
    onInsertVendor: (data, token) => dispatch(insertVendor(data, token)),
    OnInsertHospitalDoctor: data => dispatch(insertHospitalDoctor(data)),

    onCreateVendorBasic: data => dispatch(createVendorBasic(data)),

    onGetVendorDetails: (data, token) =>
      dispatch(getVendorDetails(data, token)),

    onCreateVendorTerms: data => dispatch(createVendorTerms(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateVendorBasicDetails);
