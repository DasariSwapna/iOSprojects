import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  FlatList,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, {NextButton} from '../../../../components/Button';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/VendorDropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import TimeLineContainer from '../../../../components/VendoreTimeLineContainer';
import Ionicons from 'react-native-vector-icons/Ionicons';
import I18n from '../../../../locale/i18n';
import PageNo from '../../../../constants/PageNo';
import {Toast} from '../../../../components/Toast';

function Footer({title, onPress}) {
  return (
    <View
      style={{
        width: '82%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignSelf: 'center',
        marginTop: 15,
      }}>
      <Text style={styles.textStyleBlack}>{title}</Text>
      <TouchableOpacity onPress={() => onPress()}>
        <Ionicons
          name="remove-circle-outline"
          size={hp('3%')}
          style={{color: Colors.button}}
        />
      </TouchableOpacity>
    </View>
  );
}

function CreateVendorBasicDetailScreen({
  accountTypeHandler,
  hospitalNameHandler,
  removeHandler,
  contactNameHandler,
  mobileNumberHandler,
  emailIdHandler,
  addressHandler,
  stateHandler,
  cityHandler,
  pincodeHandler,
  doctorNameHandler,
  doctorLastNameHandler,
  specialityHandler,

  accountType,
  hospitalName,
  contactName,
  mobileNumber,
  emailId,
  address,
  state,
  city,
  pincode,
  doctorName,
  doctorLastname,
  speciality,

  isValidAccountType,
  isValidHospitalName,
  isValidContactName,
  isvalidMobileNumber,
  isaValidEmailId,
  isValidAddress,
  isValidState,
  isValidCity,
  isValidPincode,
  isValidDoctorName,
  isValidDoctorLastname,
  isValidSpeciality,

  accountTypeValidMsg,
  hospitalValidMsg,
  contactnNameValidMsg,
  mobileNumberValidmsg,
  emailIdValidmsg,
  addressValidMsg,
  stateValidmsg,
  cityValidMsg,
  pincodeValidMsg,
  doctorNameValidMsg,
  doctorLastNameValidMsg,
  specialityValidMsg,

  nextButtonHandler,
  addDoctorHandler,
  accountTypeList,
  stateList,
  cityList,
  specialityList,
  showToast,
  errorMsg,

  loading,

  doctorList,
}) {
  //console.log("Doctor List" + JSON.stringify(doctorList));

  const renderFooter = ({item, index}) => {
    return (
      <Footer
        title={item.drfirstname + ' ' + item.drlastname}
        onPress={() => removeHandler(index)}
      />
    );
  };

  return (
    <RootView pageNo={PageNo.sales_createVendor} loading={loading}>
      <KeyboardAvoidingView
        enabled
        style={{flex: 1,backgroundColor: Colors.white,}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 60}>
        <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />

        <ScrollView
          style={{flex: 1, backgroundColor: Colors.white}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <TimeLineContainer status={1} />

            <View style={styles.lineLargeContainer} />

            <DropDownMenu
              labelName={'Select account type*'}
              listItems={accountTypeList}
              labelKey={'lc_AT_ACCOUNT_TYPE_NAME'}
              valueKey={'lc_AT_ACCOUNT_TYPE_ID'}
              valueChangeHandler={accountTypeHandler}
              initValue={accountType}
              outline={false}
            />
            {!isValidAccountType && (
              <Text style={styles.textValidationMsg}>
                {!isValidAccountType ? accountTypeValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={'Hospital name*'}
              // isValid={!isValidHospitalName}
              // validationMsg={hospitalValidMsg}
              onChangeHandler={hospitalNameHandler}
              keyboardType={'default'}
              maxLength={250}
              value={hospitalName}
            />
            {!isValidHospitalName && (
              <Text style={styles.textValidationMsg}>
                {!isValidHospitalName ? hospitalValidMsg : ''}
              </Text>
            )}

            <TextInputComponent
              labelName={'Contact name*'}
              // isValid={!isValidContactName}
              // validationMsg={contactnNameValidMsg}
              onChangeHandler={contactNameHandler}
              keyboardType={'default'}
              maxLength={250}
              value={contactName}
            />
            {!isValidContactName && (
              <Text style={styles.textValidationMsg}>
                {!isValidContactName ? contactnNameValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={'Mobile number*'}
              // isValid={!isvalidMobileNumber}
              // validationMsg={mobileNumberValidmsg}
              onChangeHandler={mobileNumberHandler}
              keyboardType={'number-pad'}
              maxLength={10}
              value={mobileNumber}
            />
            {!isvalidMobileNumber && (
              <Text style={styles.textValidationMsg}>
                {!isvalidMobileNumber ? mobileNumberValidmsg : ''}
              </Text>
            )}

            <TextInputComponent
              labelName={I18n.t('sales.createOrder.email_id_placeholder')}
              // isValid={!isaValidEmailId}
              // validationMsg={emailIdValidmsg}
              onChangeHandler={emailIdHandler}
              keyboardType={'default'}
              maxLength={250}
              value={emailId}
            />

            {!isaValidEmailId && (
              <Text style={styles.textValidationMsg}>
                {!isaValidEmailId ? emailIdValidmsg : ''}
              </Text>
            )}

            <TextInputComponent
              labelName={I18n.t('sales.createOrder.address_placeholder')}
              // isValid={!isValidAddress}
              //  validationMsg={addressValidMsg}
              onChangeHandler={addressHandler}
              keyboardType={'default'}
              maxLength={250}
              value={address}
            />
            {!isValidAddress && (
              <Text style={styles.textValidationMsg}>
                {!isValidAddress ? addressValidMsg : ''}
              </Text>
            )}
            <DropDownMenu
              labelName={I18n.t('sales.createOrder.select_state_placeholder')}
              labelKey={'lc_SM_STATE_NAME'}
              valueKey={'lc_SM_ID'}
              listItems={stateList}
              outline={false}
              valueChangeHandler={stateHandler}
              initValue={state}
            />
            {!isValidState && (
              <Text style={styles.textValidationMsg}>
                {!isValidState ? stateValidmsg : ''}
              </Text>
            )}
            <DropDownMenu
              labelName={I18n.t('sales.createOrder.select_city_placeholder')}
              valueChangeHandler={accountTypeHandler}
              labelKey={'lc_CM_CITY_NAME'}
              valueKey={'lc_CM_ID'}
              listItems={cityList}
              outline={false}
              valueChangeHandler={cityHandler}
              initValue={city}
            />
            {!isValidCity && (
              <Text style={styles.textValidationMsg}>
                {!isValidCity ? cityValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={I18n.t('sales.createOrder.pincode_placeholder')}
              //  isValid={!isValidPincode}
              //  validationMsg={pincodeValidMsg}
              onChangeHandler={pincodeHandler}
              keyboardType={'numeric'}
              maxLength={6}
              value={pincode}
            />
            {!isValidPincode && (
              <Text style={styles.textValidationMsg}>
                {!isValidPincode ? pincodeValidMsg : ''}
              </Text>
            )}
            <TextInputComponent
              labelName={'Dr first name'}
              //  isValid={!isValidDoctorName}
              // validationMsg={doctorNameValidMsg}
              onChangeHandler={doctorNameHandler}
              keyboardType={'default'}
              maxLength={250}
              value={doctorName}
            />
            {!isValidDoctorName && (
              <Text style={styles.textValidationMsg}>
                {!isValidDoctorName ? doctorNameValidMsg : ''}
              </Text>
            )}

            <TextInputComponent
              labelName={'Dr last name'}
              //  isValid={!isValidDoctorLastname}
              //  validationMsg={doctorLastNameValidMsg}
              onChangeHandler={doctorLastNameHandler}
              keyboardType={'default'}
              maxLength={250}
              value={doctorLastname}
            />

            {!isValidDoctorLastname && (
              <Text style={styles.textValidationMsg}>
                {!isValidDoctorLastname ? doctorLastNameValidMsg : ''}
              </Text>
            )}
            <View>
              <DropDownMenu
                labelName={'Speciality'}
                listItems={specialityList}
                outline={false}
                labelKey={'lc_DS_SPECIALITY_NAME'}
                valueKey={'lc_DS_SPECIALITY_TYPE_ID'}
                valueChangeHandler={specialityHandler}
              />
            </View>
            {!isValidSpeciality && (
              <Text style={styles.textValidationMsg}>
                {!isValidSpeciality ? specialityValidMsg : ''}
              </Text>
            )}
            <TouchableOpacity onPress={addDoctorHandler}>
              <Text style={styles.textStyleTeal}>+Add Dr</Text>
            </TouchableOpacity>

            <FlatList
              //  scrollEnabled={true}
              data={doctorList}
              keyExtractor={(item, index) => index}
              renderItem={renderFooter}
            />

            {/* <Footer title={'Dr Deepak-Peadiatrician'} />

            <Footer title={'Dr Arun Kumar-Gynecologic'} /> */}
        
          </View>
          <View style={styles.buttonContainer}>
            <NextButton onPress={nextButtonHandler} />
       </View>
        </ScrollView>
      
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: wp('100%'),
   // height: hp('100%'),
    backgroundColor: Colors.white,
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: Colors.white,
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: wp('30%'),
    alignSelf: 'center',
    marginTop: hp('5%'),
    backgroundColor: Colors.white,
  },
  textStyleTeal: {
    color: Colors.teal,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    alignSelf: 'flex-end',
    marginRight: hp('5%'),
    marginTop: 15,
  },
  textStyleBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 15,
    paddingVertical: 4,
  },
});

export default CreateVendorBasicDetailScreen;
