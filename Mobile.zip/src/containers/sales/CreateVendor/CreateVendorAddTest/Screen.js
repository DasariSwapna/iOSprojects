import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
} from 'react-native';
import RootView from '../../../../components/RootView';
import Colors from '../../../../config/Colors';
import Images from '../../../../constants/Images';
import Button, {NextButton} from '../../../../components/Button';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontSize, FontMagneta} from '../../../../config/Fonts';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import TextInputComponent from '../../../../components/TextInputComponent';
import DropDownMenu from '../../../../components/DropDownMenu';
import Data from '../../../../constants/Data';
import InnerHeader from '../../../../components/InnerHeader';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import TimeLineContainer from '../../../../components/VendoreTimeLineContainer';
import Icons from '../../../../constants/Icons';
import AddTestTopComponet from '../../../../components/AddTestTopComponent';
//import SearchBar from '../../../../components/SearchBar'
import SearchBar from '../../../../components/FilterBar';
///import AddTestPayoutComponent from '../../../../components/AddTestPayoutContainer'
import CheckCircle, {CheckCircle1} from '../../../../components/CheckCircle';
import PageNo from '../../../../constants/PageNo';
import {Toast} from '../../../../components/Toast';
import I18n from '../../../../locale/i18n';
import KeyboardSpacer from 'react-native-keyboard-spacer';
import {KeyboardAwareScrollView} from 'react-native-keyboard-aware-scroll-view';

function AddTestPayoutComponent({
  radioPress,
  title,
  RETAIL,
  priceHandler,
  price,
  minPrice,
  maxPrice,
  selected,
}) {
  return (
    <View style={styles.payoutContainer}>
      <View
        style={[
          {
            justifyContent: RETAIL ? 'flex-start' : 'space-between',
          },
          styles.payoutBottomContainer,
        ]}>
        <View
          style={{
            marginTop: hp('1.0%'),
            justifyContent: 'space-between',
          }}>
          <View style={{marginTop: hp('1.0'), flexDirection: 'row'}}>
            <Text style={styles.payoutTextContainerBlack}>Plan name</Text>

            <View style={{width: wp('50%')}}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <Text numberOfLines={1} style={styles.payoutTextContainerBold}>
                  {title}
                </Text>
              </ScrollView>
            </View>

            <View style={{width: wp('20%')}}>
              <CheckCircle1
                length={20}
                onPress={() => radioPress()}
                selected={selected}
              />
            </View>
          </View>

          <View
            style={{
              flexDirection: 'row',
            }}>
            {!RETAIL ? (
              <AddTestPayoutMinMaxComponent title={'Min'} price={minPrice} />
            ) : (
              <AddTestPayoutMinMaxComponent title={'MRP'} price={maxPrice} />
            )}

            {!RETAIL ? (
              <AddTestPayoutMaxComponent title={'Max'} price={maxPrice} />
            ) : null}

            {!RETAIL ? (
              <View
                style={{
                  marginTop: hp('1.0%'),
                  width: wp('20%'),
                  marginLeft: wp('2.0%'),
                }}>
                <AddTestPayoutInputComponent
                  title={'Enter price'}
                  value={selected ? price : 0}
                  editable={selected ? true : false}
                  selected={selected}
                  backgroundColor={selected ? '#fff' : '#00000029'}
                  onChangeText={priceHandler}
                />
              </View>
            ) : null}
          </View>
        </View>
      </View>
    </View>
  );
}

function AddTestPayoutInputComponent({
  editable,
  title,
  value,
  backgroundColor,
  onChangeText,
}) {
  return (
    <View style={{marginTop: hp('0.5%'), width: wp('20%')}}>
      <Text style={styles.payoutTextContainerBlackRegular}>{title}</Text>
      <View
        style={[
          {
            flexDirection: 'row',
            // width: Platform.OS === 'ios' ? hp('9.5%') : hp('11%'),
            borderWidth: hp('0.1%'),
            borderColor: Colors.border,
            borderRadius: 7,
            height: hp('5%'),
            alignItems: 'center',
            // justifyContent: 'flex-start',
            paddingLeft: 10,
          },
          {backgroundColor: backgroundColor},
        ]}>
        <Text
          style={{
            color: Colors.black,
            fontFamily: FontMagneta.thin,
            fontSize: FontSize.medium,
            marginTop: hp('-0.2%'),
          }}>
          {I18n.t('valitation.rupee')}
        </Text>
        <TextInput
          style={styles.payoutTextInputContainer}
          //  placeholder="₹    100"
          placeholderTextColor={Colors.bgDarkGray}
          onChangeText={onChangeText}
          underlineColorAndroid="transparent"
          maxLength={6}
          keyboardType={'numeric'}
          value={value}
          editable={editable}
        />
      </View>
    </View>
  );
}

function AddTestPayoutMinMaxComponent({title, price}) {
  return (
    <View style={{marginTop: hp('1.0%'), width: wp('20%')}}>
      <Text style={styles.payoutTextContainerBorder}>{title}</Text>
      <Text style={styles.payoutTextContainerMagenta}>₹ {price}</Text>
    </View>
  );
}

function AddTestPayoutMaxComponent({title, price}) {
  return (
    <View style={{marginTop: hp('1.0%'), width: wp('40%')}}>
      <Text style={styles.payoutTextContainerBorder}>{title}</Text>
      <Text style={styles.payoutTextContainerMagenta}>₹ {price}</Text>
    </View>
  );
}

const renderNodata = () => {
  return (
    <>
      <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
        <Text style={{fontFamily: FontMagneta.bold}}>No data found</Text>
      </View>
    </>
  );
};

function Footer({totalTest, totalOutliner, toatlAutoApproved}) {
  return (
    <View
      style={{
        width: '90%',
        justifyContent: 'space-between',
        flexDirection: 'row',
        alignSelf: 'center',
        marginVertical: 20,
      }}>
      <View
        style={{
          width: hp('14%'),
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: hp('10%'),
          backgroundColor: '#F0F6D8',
          paddingVertical: 4,
        }}>
        <Text
          style={{
            color: Colors.black,
            fontFamily: Font.regular,
            fontSize: FontSize.regular,
          }}>
          Total Test
        </Text>
        <Text>{totalTest}</Text>
      </View>
      <View
        style={{
          width: hp('14%'),
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: hp('10%'),
          backgroundColor: Colors.card,
          paddingVertical: 4,
        }}>
        <Text
          style={{
            color: Colors.black,
            fontFamily: Font.regular,
            fontSize: FontSize.regular,
          }}>
          outliners
        </Text>
        <Text>{totalOutliner}</Text>
      </View>
      <View
        style={{
          width: hp('14%'),
          justifyContent: 'center',
          alignItems: 'center',
          borderRadius: hp('10%'),
          backgroundColor: '#CCEAE5',
          paddingVertical: 4,
        }}>
        <Text
          style={{
            color: Colors.black,
            fontFamily: Font.regular,
            fontSize: FontSize.regular,
          }}>
          Auto approved
        </Text>
        <Text>{toatlAutoApproved}</Text>
      </View>
    </View>
  );
}

function CreateVendorAddTestScreen({
  addressTypeHandler,
  nextButtonHandler,
  cardClickHandler,
  priceHandler,
  radioPress,
  data,
  selectedSearchId,
  productDetails,
  productList,
  RETAIL,
  showToast,
  errorMsg,
  totalAmount,
  actionSearch,
  actionValue,
  totalTest,
  totalOutliner,
  toatlAutoApproved,

  loading,
  keyboardStatus,
}) {
  const renderPayoutContainer = ({item, index}) => {
    return (
      <AddTestPayoutComponent
        radioPress={() => radioPress(item)}
        title={item.LC_TD_TEST_NAME}
        RETAIL={RETAIL}
        priceHandler={val => priceHandler(val, item)}
        price={item.price}
        //price={item.lc_TD_MAXPRICE}
        minPrice={item.LC_TD_MINPRICE}
        maxPrice={item.LC_TD_MAXPRICE}
        selected={item.selected}
      />
    );
  };

  const renderTopContainer = ({item}) => {
    return (
      <AddTestTopComponet
        title={item.lc_PD_PRODUCT_NAME}
        image={item.lc_PD_ICON_IMAGE_PATH}
        testCount={item.total_TEST_COUNT}
        testAdded={item.test_added}
        onPress={() => cardClickHandler(item)}
        bgColor={
          selectedSearchId == item.lc_PD_PRODUCT_CODE
            ? Colors.card
            : Colors.white
        }
      />
    );
  };

  return (
    <RootView pageNo={PageNo.sales_createVendorAddTest} loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />

      <View
        style={{
          flex: 10,
          flexDirection: 'column',
          backgroundColor: '#fff',
        }}>
        <View
          style={{
            flex: 9,
            flexDirection: 'column',
          }}>
          <View style={{flex: 1}}>
            <View style={styles.mainContainer}>
              <TimeLineContainer status={2} />

              <View style={styles.lineLargeContainer} />

              {/* Top Conatiner */}
              <View style={styles.TopViewContainer}>
                <FlatList
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  data={productDetails}
                  keyExtractor={item => item.id}
                  renderItem={renderTopContainer}
                />
              </View>

              {/* Serach Section */}
              <View style={styles.searchOuterContainer}>
                <View
                  style={{height: hp('6%'), width: RETAIL ? '100%' : '70%'}}>
                  <SearchBar
                    onChangehandler={actionSearch}
                    value={actionValue}
                  />
                </View>
                {!RETAIL ? (
                  <Text style={styles.textStyle}>
                    {' '}
                    {I18n.t('valitation.rupee')} {totalAmount}
                  </Text>
                ) : null}
              </View>

              {/* Payout Section */}
              <View
                style={{
                  alignSelf: 'center',
                  alignContent: 'flex-start',
                  width: '88%',
                  //backgroundColor: 'red'
                }}>
                <KeyboardAwareScrollView
                  extraHeight={hp('25%')}
                  enableOnAndroid={true}>
                  <FlatList
                    //  style={{marginTop: 10, backgroundColor: "white", paddingBottom: 90}}
                    data={productList}
                    keyExtractor={(item, index) => item.key}
                    renderItem={renderPayoutContainer}
                    ListEmptyComponent={renderNodata}
                    contentContainerStyle={styles.flatListInnerContainer}
                    showsVerticalScrollIndicator={false}
                  />
                </KeyboardAwareScrollView>
              </View>
            </View>
          </View>
        </View>

        {keyboardStatus != true && (
          <View
            style={{
              flex: RETAIL ? 1 : 2,
              flexDirection: 'column',
              alignItems: 'center',
              backgroundColor: '#fff',
            }}>
            {!RETAIL ? (
              <Footer
                totalTest={totalTest}
                totalOutliner={totalOutliner}
                toatlAutoApproved={toatlAutoApproved}
              />
            ) : null}
            <View
              style={[
                {marginTop: RETAIL ? hp('1.5%') : 0},
                styles.buttonContainer,
              ]}>
              <NextButton onPress={nextButtonHandler} />
            </View>
          </View>
        )}
      </View>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    width: '30%',
    alignSelf: 'center',
  },
  TopViewContainer: {
    height: hp('14%'),
    marginTop: 20,
    width: '95%',
    marginLeft: '5%',
    alignSelf: 'center',
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  /////////Serach Section
  searchSection: {
    width: '90%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  /////Search outer Style
  searchOuterContainer: {
    width: '85%',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    paddingVertical: 20,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  ////Payout Section Container
  payoutContainer: {
    width: wp('88%'),
    height: Platform.OS === 'ios' ? hp('14%') : hp('16%'),
    borderWidth: hp('0.1%'),
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginTop: 15,
    marginBottom: 10,
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutTextContainerBlack: {
    width: wp('20%'),
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBold: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    // width: wp('58%'),
    // height: hp('6%'),
    // marginLeft: hp('1.5%'),
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,
  },
  payoutBottomContainer: {
    flexDirection: 'row',

    paddingHorizontal: wp('2.5%'),
    // paddingVertical: 10
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    marginTop: hp('2%'),
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    // marginTop: hp('1.0%'),
    width: wp('11%'),
    // borderWidth: hp('0.1%'),
    // borderColor: Colors.border,
    // borderRadius: 7,
    height: hp('5%'),
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: 5,
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: hp('50%'),
  },
});

export default CreateVendorAddTestScreen;
