import React from 'react';
import { Keyboard } from 'react-native';
import { connect } from 'react-redux';
import I18n from 'i18next';
import { isValidUsername, isValidPassword } from '../../../../utils/Validators';
import CreateVendorAddTestScreen from './Screen';
import Routes, { Sales } from '../../../../navigations/RouteTypes';
import Colors from '../../../../config/Colors';
import {
  getProductDetails,
  getProductList,
  insertVendorTest,
  createVendorAddTest,
} from '../../../../store/Actions';
import { delay } from '../../../../utils/Helpers';
import { BackHandler } from 'react-native';

const Data = [
  {
    id: 1,
    name: 'PNS',
    totalId: '05',
    testId: '02',
    image: Icons.nbs,
    color: Colors.card,
  },
  {
    id: 2,
    name: 'NBS',
    totalId: '08',
    testId: '01',
    image: Icons.pns,
    color: Colors.white,
  },
  {
    id: 3,
    name: 'Allied',
    totalId: '02',
    testId: '04',
    image: Icons.nbs,
    color: Colors.white,
  },
  {
    id: 4,
    name: 'Allied',
    totalId: '02',
    testId: '04',
    image: Icons.nbs,
    color: Colors.white,
  },
];

class CreateVendorAddTest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      errorMsg: '',
      showToast: false,

      data: [],
      localProductList: [],
      localProductListOrigin: [],
      productDetailsOrigin: [],

      product_code: '',
      product_id: 0,
      selectedSearchId: 0,
      totalAmount: 0,

      RETAIL: this.props.route.params.RETAIL,
      ACTYPE: this.props.route.params.ACTYPE,

      totalTest: 0,
      totalOutliner: 0,
      toatlAutoApproved: 0,
    };
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  nextButtonHandler = () => {
    //  this.props.navigation.navigate(Sales.createVendorTermsCondition);

    var listSelected = this.state.localProductList.filter(
      item => item.selected == true,
    );
    if (listSelected.length > 0) {
      const isValid = this.validation();
      console.log('Price validation  ' + isValid);
      if (isValid) {
        this.saveData();
      }
    } else {
      this.setState(
        {
          errorMsg: 'Please Select atleast one Test',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  validation = () => {
    var listSelected = this.state.localProductListOrigin.filter(
      item => item.selected == true,
    );

    var valid = true;

    console.log('validation listselected ' + JSON.stringify(listSelected));

    if (!this.state.RETAIL) {
      for (var i = 0; i < listSelected.length; i++) {
        if (
          parseInt(listSelected[i].price) >
          parseInt(listSelected[i].LC_TD_MAXPRICE)
        ) {
          this.setState(
            {
              errorMsg: `Test name:${listSelected[i].LC_TD_TEST_NAME} \n Price shoul be less than max price`,
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
          console.log('Price shoul be less than max price');
          return (valid = false);
        } else if (
          parseInt(listSelected[i].price < 1) ||
          listSelected[i].price == ''
        ) {
          this.setState(
            {
              errorMsg: `Test name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter price`,
              showToast: true,
            },
            async () => {
              await delay(3000);
              this.resetValidation();
            },
          );
          console.log('Please enter price');
          return (valid = false);
        }
      }
    }
    return valid;
  };

  actionSearch = text => {
    var listSelected = this.state.localProductListOrigin.filter(
      item => item.LC_PTM_PRODUCT_ID == this.state.product_id,
    );
    var filterdata = listSelected;

    var arraydata = filterdata.filter(function (x) {
      return (
        x.LC_TD_TEST_NAME.toUpperCase()
          .trim()
          .indexOf(text.toUpperCase().trim()) > -1
      );
    });
    this.setState({
      localProductList: arraydata,
      actionValue: text,
    });
  };

  // countTestForProducts = (id) => {
  //   const list = this.state.localProductListOrigin.filter(item => item.lc_PTM_PRODUCT_ID == id);
  //   var listSelected = list.filter(item => item.selected == true);
  //   var count = listSelected.length;
  //   this.state.productDetailsOrigin.map(item => {
  //     if (item.lc_PD_PRODUCT_CODE == id) {
  //       return {
  //         ...item,
  //         test_added: count,
  //       }
  //     }
  //     return item
  //   })
  // }

  radioPress = itemList => {
    //console.log(this.state.product_id);

    const newData = this.state.localProductList.map(item => {
      if (
        item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
        parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
      ) {
        return {
          ...item,
          selected: !item.selected,
          price: '',
        };
      }
      return item;
    });
    console.log(newData);
    this.setState({ localProductList: newData });

    const newDataOrigin = this.state.localProductListOrigin.map(item => {
      if (
        item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
        parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
      ) {
        return {
          ...item,
          selected: !item.selected,
          price: '',
        };
      }
      return item;
    });
    console.log(newDataOrigin);
    this.setState({ localProductListOrigin: newDataOrigin });

    var listSelected = newDataOrigin.filter(item => item.selected == true);
    this.setState({
      totalTest: listSelected.length,
    });
    this.countFunction(newDataOrigin);

    var count = 0;
    for (var i = 0; i < newData.length; i++) {
      if (newData[i].selected) {
        count++;
      }
      const productdata = this.state.productDetailsOrigin.map(item => {
        if (item.lc_PD_PRODUCT_CODE == itemList.LC_PTM_PRODUCT_ID) {
          return {
            ...item,
            test_added: count,
          };
        }
        return item;
      });
      this.setState({ productDetailsOrigin: productdata });
    }
  };

  saveData = () => {
    const listSelected = this.state.localProductListOrigin.filter(
      item => item.selected == true,
    );

    if (listSelected.length > 0) {
      var arr = [];
      var value = 0;
      if (this.state.RETAIL) {
        //  RETAIL
        for (var i = 0; i < listSelected.length; i++) {
          arr.push({
            product_code: parseInt(listSelected[i].LC_PTM_PRODUCT_CODE),
            product_id: parseInt(listSelected[i].LC_PTM_PRODUCT_ID),
            test_code: listSelected[i].LC_TD_TEST_CODE,
            test_id: parseInt(listSelected[i].LC_TD_TEST_ID),
            price: parseInt(listSelected[i].LC_TD_MAXPRICE),
            user_id: this.props.UserID,
            hospital_id: this.props.VendorId,
          });
          value += parseInt(listSelected[i].LC_TD_MAXPRICE);
        }
      } else {
        // RETAIL TO INVOICE and MOU
        for (var i = 0; i < listSelected.length; i++) {
          arr.push({
            product_code: parseInt(listSelected[i].LC_PTM_PRODUCT_CODE),
            product_id: parseInt(listSelected[i].LC_PTM_PRODUCT_ID),
            test_code: listSelected[i].LC_TD_TEST_CODE,
            test_id: parseInt(listSelected[i].LC_TD_TEST_ID),
            price: parseInt(listSelected[i].price),
            user_id: this.props.UserID,
            hospital_id: this.props.VendorId,
          });
          value += parseInt(listSelected[i].price);
        }
      }

      const data = {
        hospital_id: this.props.VendorId,
        testDetails: arr,
        invoice_amount: value,
        user_id: this.props.UserID,
      };
      // console.log("Create vendor Array" + JSON.stringify(arr));
      this.props.onInsertVendorTest(data, this.props.accessToken);
      // this.props.navigation.navigate(Sales.createVendorTermsCondition);
    } else {
      this.setState(
        {
          errorMsg: 'Please Select atleast one Test',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  cardClickHandler = item => {
    console.log('Select cards ------', item.lc_PD_PRODUCT_CODE);
    this.setState(prevState => {
      const temp =
        prevState.selectedSearchId == item.lc_PD_PRODUCT_CODE
          ? 0
          : item.lc_PD_PRODUCT_CODE;
      this.filterData(temp);
      return {
        selectedSearchId: temp,
      };
    });
    /*  set State  */
    this.setState({
      product_code: item.lc_PD_PRODUCT_CODE,
      product_id: item.lc_PD_PRODUCT_CODE,
    });
  };

  filterData = id => {
    const list = this.state.localProductListOrigin.filter(
      item => item.LC_PTM_PRODUCT_ID == id,
    );
    this.setState({ localProductList: list });
  };

  countFunction = newDataOrigin => {
    var totalvalues = 0;
    var count = 0;
    var countAuto = 0;
    for (var i = 0; i < newDataOrigin.length; i++) {
      if (newDataOrigin[i].selected) {
        if (
          newDataOrigin[i].price == '' ||
          parseInt(newDataOrigin[i].price) <
          parseInt(newDataOrigin[i].LC_TD_MINPRICE)
        ) {
          count++;
        }
        if (
          parseInt(newDataOrigin[i].price) >
            parseInt(newDataOrigin[i].LC_TD_MINPRICE) &&
          parseInt(newDataOrigin[i].price) <
            parseInt(newDataOrigin[i].LC_TD_MAXPRICE) ||  parseInt(newDataOrigin[i].price) ==
            parseInt(newDataOrigin[i].LC_TD_MAXPRICE)
        ) {
          countAuto++;
        }
        if (!newDataOrigin[i].price == '')
          totalvalues += parseInt(newDataOrigin[i].price);
      }
    }
    this.setState({
      totalAmount: totalvalues,
      totalOutliner: count,
      toatlAutoApproved: countAuto,
    });
  };

  priceHandler = (val, itemList) => {
    var newData = this.state.localProductList.map(item => {
      if (
        item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
        parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
      ) {
        return {
          ...item,
          price: val,
        };
      }
      return item;
    });
    this.setState({ localProductList: newData });

    var newDataOrigin = this.state.localProductListOrigin.map(item => {
      if (
        item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE &&
        parseInt(item.LC_PTM_PRODUCT_ID) === parseInt(this.state.product_id)
      ) {
        return {
          ...item,
          price: val,
        };
      }
      return item;
    });

    this.setState({
      localProductListOrigin: newDataOrigin,
    });
    this.countFunction(newDataOrigin);
  };

  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    // alert(this.props.VendoraddTest)
    this.keyboardDidShowSubscription = Keyboard.addListener(
      'keyboardDidShow',
      () => {
        this.setState({ keyboardStatus: true });
      },
    );
    this.keyboardDidHideSubscription = Keyboard.addListener(
      'keyboardDidHide',
      () => {
        this.setState({ keyboardStatus: false });
      },
    );
    this.setState({ data: Data });
    // this.props.onGetProductDetails(null, this.props.accessToken);
    const data = {
      product_id: null,
      test_search: null,
    };

    // this.props.onGetProductList(data, this.props.accessToken);
    //alert(this.props.VendoraddTest)

    if (
      this.props.VendoraddTest == undefined ||
      this.props.VendoraddTest == '' ||
      this.props.VendoraddTest == []
    ) {
      this.props.onGetProductList(data, this.props.accessToken);
      this.props.onGetProductDetails(null, this.props.accessToken);
    } else {
      this.setState({ localProductListOrigin: this.props.VendoraddTest });
      this.setState({ localProductList: this.props.VendoraddTest });
      this.setState({ productDetailsOrigin: this.props.VendoraddTestProduct });

      this.setState({
        totalAmount: this.props.VendoraddTestInvoiceAmount,
        totalOutliner: this.props.VendoraddTesttotalTestOutliners,
        toatlAutoApproved: this.props.VendoraddTesttotalTestAutoApproved,
        totalTest: this.props.VendoraddTesttotalTestSelected,
        selectedSearchId: this.props.VendoraddTestProductSelection,
      });
    }

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.productDetailsStatus == false &&
      this.props.productDetailsStatus != prevProps.productDetailsStatus
    ) {
      const data = this.props.productDetails.map(item => {
        item.test_added = 0;
        return item;
      });
      this.setState({ productDetailsOrigin: data });
    }
    if (
      prevProps.productListStatus == false &&
      this.props.productListStatus != prevProps.productListStatus
    ) {
      const data =
        this.props.productList.properties.TestlistByProductIdModels.map(
          item => {
            (item.price = 0), (item.selected = false);
            return item;
          },
        );
      this.setState({ localProductListOrigin: data });

      /*   if(this.props.VendoraddTest == undefined || this.props.VendoraddTest == '' || this.props.VendoraddTest == [] )
        {
        const data =
        this.props.productList.properties.TestlistByProductIdModels.map(
          item => {
            (item.price = 0), (item.selected = false);
            return item;
          },
        );
        this.setState({localProductListOrigin: data});
        }
        else
        {
          this.setState({localProductListOrigin: this.props.VendoraddTest });
        } */
    }

    if (
      prevProps.insertVendorTestStatus == false &&
      this.props.insertVendorTestStatus != prevProps.insertVendorTestStatus
    ) {
      const data = {
        producttestDetails: this.state.localProductListOrigin,
        productDetails: this.state.productDetailsOrigin,
        invoiceAmount: this.state.totalAmount,
        productSelectionindex: this.state.selectedSearchId,
        totalTestSelected: this.state.totalTest,
        totalTestOutliners: this.state.totalOutliner,
        totalTestAutoApproved: this.state.toatlAutoApproved,
      };

      this.props.onCreateVendorAddTest(data);

      this.props.navigation.navigate(
        Sales.createVendorQuestionsTermsCondition,
        {
          ACTYPE: this.state.ACTYPE,
        },
      );
    }

    if (
      prevProps.insertVendorTestError != this.props.insertVendorTestError &&
      this.props.insertVendorTestError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.insertVendorTestMessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  componentWillUnmount() {
    const data = {
      producttestDetails: this.state.localProductListOrigin,
      productDetails: this.state.productDetailsOrigin,
      invoiceAmount: this.state.totalAmount,
      productSelectionindex: this.state.selectedSearchId,
      totalTestSelected: this.state.totalTest,
      totalTestOutliners: this.state.totalOutliner,
      totalTestAutoApproved: this.state.toatlAutoApproved,
    };

    this.props.onCreateVendorAddTest(data);
  }

  render() {
    return (
      <CreateVendorAddTestScreen
        loading={this.props.productListLoading}
        nextButtonHandler={this.nextButtonHandler}
        cardClickHandler={this.cardClickHandler}
        priceHandler={this.priceHandler}
        actionSearch={this.actionSearch}
        radioPress={this.radioPress}
        data={this.state.data}
        selectedSearchId={this.state.selectedSearchId}
        productList={this.state.localProductList}
        //   productList= {this.props.VendoraddTest == undefined ? this.state.localProductList : this.props.VendoraddTest}
        productDetails={this.state.productDetailsOrigin}
        RETAIL={this.state.RETAIL}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        totalAmount={this.state.totalAmount}
        actionValue={this.state.actionValue}
        totalTest={this.state.totalTest}
        totalOutliner={this.state.totalOutliner}
        toatlAutoApproved={this.state.toatlAutoApproved}
        keyboardStatus={this.state.keyboardStatus}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,

    accessToken: state.signIn.accessToken,
    productDetails: state.common.productDetailsResponse,
    productList: state.common.productListResponse,
    productListLoading: state.common.productListLoading,
    
    productListStatus: state.common.productListStatus,
    VendorId: state.createVendor.insertVendorResponse,
    insertVendorTestError: state.createVendor.insertVendorTestError,
    insertVendorTestStatus: state.createVendor.insertVendorTestStatus,
    insertVendorTestMessage: state.createVendor.message,
    insertVendorTestLoading: state.createVendor.insertVendorTestLoading,
    UserID: state.signIn.userId,
    productDetailsStatus: state.common.productDetailsStatus,
    VendoraddTest: state.createVendor.VendoraddTest,
    VendoraddTestProduct: state.createVendor.VendoraddTestProduct,
    VendoraddTestInvoiceAmount: state.createVendor.VendoraddTestInvoiceAmount,

    VendoraddTesttotalTestSelected:
      state.createVendor.VendoraddTesttotalTestSelected,
    VendoraddTesttotalTestOutliners:
      state.createVendor.VendoraddTesttotalTestOutliners,
    VendoraddTesttotalTestAutoApproved:
      state.createVendor.VendoraddTesttotalTestAutoApproved,
    VendoraddTestProductSelection:
      state.createVendor.VendoraddTestProductSelection,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetProductDetails: (data, token) =>
      dispatch(getProductDetails(data, token)),
    onGetProductList: (data, token) => dispatch(getProductList(data, token)),
    onInsertVendorTest: (data, token) =>
      dispatch(insertVendorTest(data, token)),

    onCreateVendorAddTest: data => dispatch(createVendorAddTest(data)),
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(CreateVendorAddTest);
