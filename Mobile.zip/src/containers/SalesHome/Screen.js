import React, { useRef } from 'react';
import {
    ActivityIndicator,
    Dimensions,
    StyleSheet,
    ImageBackground,
    Image,
    SafeAreaView,
    Text,
    View,
    ScrollView,
    Platform,
    TouchableOpacity,
    KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import Images from '../../constants/Images';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import { Font, FontSize, FontMagneta } from '../../config/Fonts';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

//import HeaderBig from '../../components/Header'

function HeaderBig({ ...props }) {
    return (
        <View style={styles.headerBigContainer}>
            <View style={styles.headerBigLayout}>
                <Image
                    source={Images.dawerMenu}
                    style={styles.imageConatiner}
                    resizeMode="contain"
                />
                <Text style={styles.headerTextContainer}>Home</Text>
                <Image
                    source={Images.logoIsolve}
                    style={styles.imageConatiner}
                    resizeMode="contain"
                />
            </View>

        </View>
    );
}

function TopConatiner({ ...props }) {
    return (
        <View style={styles.topContainer}>
            <View style={styles.topContainerLoyout}>
                <Text style={styles.topTextContainerPink}>Order value (MTD)</Text>
                <Text style={styles.topTextContainerBlack}>20000</Text>
            </View>

            <View style={styles.topContainerLoyout}>
                <Text style={styles.topTextContainerPink}>Order Count(MTD)</Text>
                <Text style={styles.topTextContainerBlack}>26</Text>
            </View>

            <View style={styles.topContainerLoyoutNoBottomLine}>
                <Text style={styles.topTextContainerPink}>New MOU Conversion(MTD)</Text>
                <Text style={styles.topTextContainerBlack}>12</Text>
            </View>

        </View>
    );
}


function CardConatiner({ imgSrc, title, color, handler }) {
    return (
        <TouchableOpacity style={styles.cardContainer} onPress={handler}>
            <Image
                source={imgSrc}
                style={styles.cardImageConatiner}
                resizeMode="cover"
            />
            <Text
                style={styles.cardTextContainer}>
                {title}
            </Text>
        </TouchableOpacity>
    );
}




function HomeScreen({ createOrderHandler }) {
    return (

        <RootView pageNo={'13'}>
            <KeyboardAvoidingView style={{ flex: 1 }}>
                <ScrollView
                    style={{ flex: 1 }}
                    contentContainerStyle={styles.contentContainer}
                    showsVerticalScrollIndicator={false}

                >
                    <View style={styles.mainContainer}>
                        <HeaderBig />
                        <TopConatiner />

                        <CardConatiner
                            color={Colors.darkGreen}
                            title={'Create Order'}
                            imgSrc={Images.createOrder}
                            handler={createOrderHandler} />

                        <CardConatiner
                            color={Colors.darkPink}
                            title={'Manage Orders'}
                            imgSrc={Images.manageOrder} />

                        <CardConatiner
                            color={Colors.lightGreen}
                            title={'Create vendor'}
                            imgSrc={Images.createVendor} />


                        <CardConatiner
                            color={Colors.lightPink}
                            title={'Manage vendor'}
                            imgSrc={Images.mangaeVendor} />

                        <CardConatiner
                            color={Colors.violet}
                            title={'Manager approval'}
                            imgSrc={Images.manageApproval} />

                       

                        <CardConatiner
                            color={Colors.darkGreen}
                            title={'Plans and test catlog with price'}
                            imgSrc={Images.plansTest} />

                        <CardConatiner
                            color={Colors.violet}
                            title={'Cash collection /deposit'}
                            imgSrc={Images.cash} />

                        <CardConatiner
                            color={Colors.darkPink}
                            title={'Invoice payments'}
                            imgSrc={Images.invoice} />

                        <CardConatiner
                            color={Colors.taleBlue}
                            title={'upload signed copy'}
                            imgSrc={Images.upload} />
                    </View>
                </ScrollView>
            </KeyboardAvoidingView>
        </RootView>

    );
}


const styles = StyleSheet.create({
    mainContainer: {
        width: '100%',
        height: '100%',
        // overflow: 'hidden',
    },
    contentContainer: {
        flexGrow: 1,
        paddingBottom: 20,
    },
    headerBigContainer: {
        width: '100%',
        height: '30%',
        alignItems: 'center',
        justifyContent: 'flex-start',
        paddingHorizontal: 30,
        paddingVertical: 6,
        backgroundColor: Colors.card,
        borderBottomLeftRadius: 20,
        borderBottomRightRadius: 20
    },
    headerBigLayout: {
        width: '90%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 15
    },
    headerTextContainer: {
        color: Colors.border,
        fontFamily: Font.extraBold,
        fontSize: FontSize.extraLarge,
        alignSelf: 'center'

    },
    logoImage: {
        width: '10%',
        height: '100%',
        resizeMode: 'contain',
        // backgroundColor: "yellow",
    },
    topContainer: {
        width: '80%',
        height: '23%',
        backgroundColor: Colors.background,
        marginTop: -150,
        alignSelf: 'center',
        borderRadius: 20,
        elevation: 1,
        marginBottom: 18

    },
    topContainerLoyout: {
        width: '80%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 15,
        alignSelf: 'center',
        borderBottomWidth: 1,
        borderBottomColor: Colors.lineColor,
        paddingVertical: 8
    },
    topContainerLoyoutNoBottomLine: {
        width: '80%',
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 15,
        alignSelf: 'center',
        paddingVertical: 8
    },
    topTextContainerPink: {
        color: Colors.border,
        fontFamily: Font.regular,
        fontSize: FontSize.medium,

    },
    topTextContainerBlack: {
        color: Colors.black,
        fontFamily: FontMagneta.medium,
        fontSize: FontSize.medium,
    },
    cardContainer: {
        width: '70%',
        height: hp('4.5%'),
        backgroundColor: Colors.background,
        borderRadius: 25,
        alignSelf: 'center',
        flexDirection: 'row',
        marginTop: 15,
        elevation: 2
    },
    cardImageConatiner: {
        width: wp('9%'),
        height: hp('4.5%'),
        borderRadius: 25,
        backgroundColor: 'transparent'
    },
    imageConatiner: {
        width: 35,
        height: 40,
    },
    cardTextContainer: {
        alignSelf: 'center',
        marginLeft: 10,
        color: Colors.black,
        fontFamily: FontMagneta.medium,
        fontSize: FontSize.regular,
    }
});

export default HomeScreen;
