import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import {
  isValidUsername,
  isValidPassword,
  validateEmpty,
  validateOTP,
  validateMobileNo,
  validateMobileNoOrEmail,
} from '../../utils/Validators';
import SignUpWithOtpScreen from './Screen';
import HelperText from '../../constants/HelperText';
import {getLogin, getOTP, getToken} from '../../store/Actions';
import {delay} from '../../utils/Helpers';
import {Auth} from '../../navigations/RouteTypes';

class SignUpWithOtp extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      otp: '',
      mobileNoOrEmail: '',
      errorMsg: '',
      showToast: false,
      otpValidationMsg: '',
      mobileNoOrEmailValidationMsg: '',
      passwordValidationMsg: '',
      isValidMobileNoOrEmail: true,
      isValidOtp: true,
      showOtpModal: false,
      leaving: false,
      loading: false,
    };
  }

  mobileNoOrEmailChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        mobileNoOrEmail: val,
      });
    }
  };

  otpChangeHandler = val => {
    if (!/[^0-9 ]/.test(val)) {
      this.setState({
        otp: val,
      });
    }
  };

  otpModalDismissHandler = () => {
    this.setState({
      showOtpModal: false,
    });
  };

  requestOtpSubmitHandler = () => {
    const valid1 = validateMobileNoOrEmail(this.state.mobileNoOrEmail);
    if (valid1.val) {
      this.setState({
        isValidUsername: valid1.val,
        mobileNoOrEmailValidationMsg: '',
      });
      const data = {
        mobile_email: this.state.mobileNoOrEmail,
        lang_id: 1,
        sms_validtimelimit: '5',
      };
      this.props.onGetOTP(data, null);
    } else {
      this.setState({
        isValidMobileNoOrEmail: valid1.val,
        mobileNoOrEmailValidationMsg: valid1.msg,
      });
    }
  };

  otpSubmitHandler = () => {
    const valid1 = validateOTP(this.state.otp);
    // console.log('validated', valid1);

    if (valid1.val) {
      this.setState({
        otp: '',
        mobileNoOrEmail: '',
        showOtpModal: false,
        otpValidationMsg: '',
        isValidOtp: valid1.val,
        loading: true,
      });
      const data = {
        loginUser: this.state.mobileNoOrEmail,
        password: this.state.otp,
        loginType: 'OTP',
        loginMode: 4,
        langId: '1',
        // lcUsdLatitude: '',
        // lcUsdLongitude: '',
        firebaseId: '',
        // androidIOSWeb: '',
      };
      this.props.onGetLogin(data, this.props.accessToken);
      // this.props.onGetToken(data, this.props.accessToken);
    } else {
      this.setState({
        isValidOtp: valid1.val,
        otpValidationMsg: valid1.msg,
      });
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  resendOtpHandler = () => {
    console.log('resend otp');
    this.requestOtpSubmitHandler();
  };

  signUpHandler = () => {
    this.props.navigation.navigate(Auth.signUp);
  };

  componentDidMount = () => {};

  componentDidUpdate = prevState => {
    if (
      prevState.getOTPError != this.props.getOTPError &&
      this.props.getOTPError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevState.getOTPStatus != this.props.getOTPStatus &&
      this.props.getOTPStatus == true
    ) {
      this.setState({
        showOtpModal: true,
      });
    }

    if (
      prevState.loginStatus != this.props.loginStatus &&
      this.props.loginStatus == true &&
      this.props.activationStatus == false
    ) {
      this.setState({
        loading: false,
      });
      this.props.navigation.navigate(Auth.profilePending);
    }

    if (
      prevState.loginError != this.props.loginError &&
      this.props.loginError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.messageSignIn,
          showToast: true,
          loading: false,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  componentWillUnmount = async () => {
    await this.setState({
      loading: false,
    });
  };

  render() {
    return (
      <SignUpWithOtpScreen
        loading={this.props.getOTPLoading}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        showOtpModal={this.state.showOtpModal}
        mobileNoOrEmail={this.state.mobileNoOrEmail}
        otp={this.state.otp}
        isValidMobileNoOrEmail={this.state.isValidMobileNoOrEmail}
        isValidOtp={this.state.isValidOtp}
        otpValidationMsg={this.state.otpValidationMsg}
        mobileNoOrEmailValidationMsg={this.state.mobileNoOrEmailValidationMsg}
        mobileNoOrEmailChangeHandler={this.mobileNoOrEmailChangeHandler}
        otpChangeHandler={this.otpChangeHandler}
        otpSubmitHandler={this.otpSubmitHandler}
        requestOtpSubmitHandler={this.requestOtpSubmitHandler}
        otpDismissHandler={this.otpModalDismissHandler}
        resendOtpHandler={this.resendOtpHandler}
        signUpHandler={this.signUpHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    otpMessage: state.common.OTPResponse,
    getOTPLoading: state.common.getOTPLoading,
    getOTPStatus: state.common.getOTPStatus,
    getOTPError: state.common.getOTPError,
    message: state.common.message,

    // loginLoading: state.signIn.loginLoading,
    loginStatus: state.signIn.loginStatus,
    loginError: state.signIn.loginError,
    accessToken: state.signIn.accessToken,
    activationStatus: state.signIn.activationStatus,
    messageSignIn: state.signIn.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetOTP: (data, token) => dispatch(getOTP(data, token)),
    onGetLogin: (data, token) => dispatch(getLogin(data, token)),
    onGetToken: (data, token) => dispatch(getToken(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SignUpWithOtp);
