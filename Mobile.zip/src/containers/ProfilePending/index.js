import React from 'react';
import {connect} from 'react-redux';
import {BackHandler} from 'react-native';
import I18n from 'i18next';
import FaIcons5 from 'react-native-vector-icons/FontAwesome5';
import {isValidUsername, isValidPassword} from '../../utils/Validators';
import ProfilePendingScreen from './Screen';
import {Auth} from '../../navigations/RouteTypes';

class ProfilePending extends React.Component {
  static navigationOptions = {
    title: 'Details',
  };
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  backHandler = () => {
    console.log('back handler called-------->');
    this.props.navigation.navigate(Auth.signIn);
    // this.props.navigation.goBack(null);
    // return true;
  };

  componentDidMount = () => {
    BackHandler.addEventListener('hardwareBackPress', this.backHandler);
  };

  componentWillUnmount() {
    BackHandler.removeEventListener('hardwareBackPress', this.backHandler);
  }

  render() {
    return <ProfilePendingScreen />;
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ProfilePending);
