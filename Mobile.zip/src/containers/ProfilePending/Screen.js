import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Images from '../../constants/Images';

const {width, height} = Dimensions.get('screen');
const bottomImageWidth = width;
const bottomImageHeight = height * 0.5;
const horizontalPadding = width * 0.25;

function ProfilePendingScreen() {
  return (
    <RootView pageNo={'12'} isWhite isPageCard>
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View style={styles.firstHalfContainer}>
              <View style={styles.logoContainer}>
                <Image
                  source={Images.logo}
                  style={styles.logoImage}
                  resizeMode="cover"
                />
              </View>
              <View style={styles.textContainer}>
                <Text style={styles.landingText}>
                  Your account is not activated yet. Please contact your Manager
                </Text>
              </View>
              <View style={styles.buttonContainer}></View>
            </View>
            <View style={styles.bottomConatiner}>
              <ImageBackground
                style={styles.bottomImageContainer}
                resizeMode="stretch"
                source={Images.startDayBg}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  firstHalfContainer: {
    width: '100%',
    height: '50%',
    paddingHorizontal: horizontalPadding,
  },
  logoContainer: {
    height: '50%',
    justifyContent: 'flex-end',
    paddingVertical: 16,
  },
  textContainer: {
    justifyContent: 'center',
    paddingVertical: 16,
    backgroundColor: Colors.background,
  },
  buttonContainer: {
    height: '20%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  landingText: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    textAlign: 'center',
    fontWeight: '600',
    marginVertical: 10,
  },
  logoImage: {
    height: 60,
    alignSelf: 'center',
  },
  bottomConatiner: {
    width: '100%',
    height: '50%',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  bottomImageContainer: {
    width: bottomImageWidth,
    height: bottomImageHeight,
    bottom: -20,
  },
});

export default ProfilePendingScreen;
