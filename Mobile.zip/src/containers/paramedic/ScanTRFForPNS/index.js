import React from 'react';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
import ImgToBase64 from 'react-native-image-base64';
import RNImageToPdf from 'react-native-image-to-pdf';
import ScanTRFScreen from './Screen';
import RNFetchBlob from 'rn-fetch-blob';
import {delay} from '../../../utils/Helpers';
import {
  mytaskUpdatePNSWithTRF,
  mytaskGetCrmidOrderidForRegularBeat,
  payDetails,
} from '../../../store/Actions';

class scanTRFForPNS extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      showSuccessModal: false,
      showAddImageModal: false,
      setShowCamera: true,
      setPath: '',
      showNextButton: false,
      confirmImage: false,
      showList: false,
      stopClick: false,
      headerTitle: this.props.route.params.title,
      message: this.props.route.params.message,
      barcodeNumber: this.props.route.params.barcodeNumber,
      crmId: this.props.route.params.crmId,
      orderId: this.props.route.params.orderId,
      paymentStatus: this.props.route.params.paymentStatus,
      productId: this.props.route.params.productId,
      imageArray: [],
      imageArrayForFlatList: [],
      showToast: false,
      errorMsg: '',
      loading:false
    };
  }
  componentDidMount() {
    this.props.navigation.setOptions({title: this.state.headerTitle});
    // alert(this.state.paymentStatus)
  }
  // openModal = () => {
  //   this.setState({ showModal: true })
  // }
moveToPayment=()=>{
  this.setState({ showSuccessModal: false});
  this.setState({loading:false})
  this.props.navigation.navigate(Paramedic.paymentCollection);
  
}
  cancelImage = () => {
    this.setState({setPath: ''});
    this.setState({confirmImage: false});
    if (this.state.imageArray.length >= 1) {
      this.setState({
        setShowCamera: false,
        showNextButton: true,
        showList: true,
      });
    } else {
      this.setState({setShowCamera: true});
    }
  };
  correctImage = () => {
    this.setState({confirmImage: false});
    //push
    this.pushImage();

    //this.setState({ showNextButton: true })
  };
  cancelModalHandler = () => {
    this.setState({showModal: false});
  };
  setDontShowCamera = () => {
    this.setState({setShowCamera: false});
  };
  moveToNext = () => {
    
    if (this.state.paymentStatus == '0') {
    //  alert('1')
      this.setState({ showSuccessModal: true });
      const data = {
        crmId: this.state.crmId,
        orderid: this.state.orderId,
      };
      this.props.onPayDetails(data);
     
      setTimeout(() => {
        this.moveToPayment()
      }, 500);
    } else {
      if (this.state.productId == '7') {
        this.setState({ showSuccessModal: true });
        this.props.onMytaskGetCrmidOrderidForRegularBeat(
          {
            orderId: this.state.orderId,
            crmId: this.state.crmId,
          },
          this.props.accessToken,
        );
      
        setTimeout(() => {
          this.setState({ showSuccessModal: false ,loading:false});
          this.props.navigation.goBack();
        }, 2000);
      
       
      } else {
      //  alert('3')
        this.setState({ showSuccessModal: true });
        setTimeout(() => {
          this.setState({ showSuccessModal: false ,loading:false});
          this.props.navigation.navigate(Paramedic.myTask);
        }, 2000);
        
      }
    }

    //this.myAsyncPDFFunction();
  };
  okayConfirmHandler = () => {
    // this.setState({ showModal: false })
    this.myAsyncPDFFunction();
  };
  okayAddImageHandler = () => {
    this.setState({showAddImageModal: false});
    this.setState({showNextButton: false, showList: false});
    this.setState({setShowCamera: true});

    // this.myAsyncPDFFunction()
  };
  cancelAddImageHandler = () => {
    this.setState({showAddImageModal: false});

    this.setState({showNextButton: true, showList: true, setPath: ''});
    // this.myAsyncPDFFunction()
  };
  pushImage = () => {
    // console.log(this.state.setPath)
    var imageUri = this.state.setPath;
    this.state.imageArrayForFlatList.push({
      imageUri: imageUri,
    });
    var fileNamePath = this.state.setPath.replace('file://', '');
    // console.log('name ' + fileNamePath)
    this.setState({imageArray: [...this.state.imageArray, fileNamePath]}); //simple value
    //}
    // console.log("Length " + JSON.stringify(this.state.imageArray))
    this.setState({setPath: '', showNextButton: true, showList: true});
  };
  addMoreImageHandler = () => {
    // alert(this.state.imageArrayForFlatList.length)
    if (this.state.imageArrayForFlatList.length < 5) {
      this.setState({stopClick: false});
      this.setState({showAddImageModal: true});
    } else {
      this.setState({stopClick: true});
    }
  };
  takePicture = async camera => {
    const options = {
      quality: 0.9,
      maxWidth: 1800,
      maxHeight: 2400,
      base64: true,
      forceUpOrientation: true,
      pauseAfterCapture: true,
      writeExif: true,
      fixOrientation: true,
    };
    const data = await camera.takePictureAsync(options);
    this.setState({setPath: data.uri});
    this.setState({setShowCamera: false});
    this.setState({confirmImage: true});
  };
  myAsyncPDFFunction = async () => {
    const arr = this.state.imageArray;

    try {
      const options = {
        imagePaths: arr,
        name: 'PDFName',
        maxSize: {
          // optional maximum image dimension - larger images will be resized
          width: 1800,
          height: 2400,
        },
        quality: 0.7, // optional compression paramter
      };
      const pdf = await RNImageToPdf.createPDFbyImages(options);
      this.converttoBase64(pdf.filePath);
    } catch (e) {
      console.log('check' + e);
    }
  };
  converttoBase64 = path => {
    RNFetchBlob.fs
      .readFile(path, 'base64')
      .then(data => {
        // alert('converted'+data);
        this.afterConversionBase64(path, data);
        //  console.log('converted' + data)
      })
      .catch(err => {
        console.log('fetchblob' + err);
      });
  };
  afterConversionBase64 = (item, base64String) => {
    //alert(base64String)
    var Base64Img = base64String.replace(/\r?\n|\r/g, '');
    this.uploadImage(item, Base64Img);
  };

  uploadImage = (item, Base64Img) => {
    this.setState({loading:true})
    var filename = '';
    if (item.fileName == undefined || item.fileName == null) {
      var name = item.replace(
        /[`~0-9!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gi,
        '',
      );
      filename = name;
    } else {
      filename = item.fileName;
    }
    const data = {
      userid: this.props.UserID,
      crmid: this.state.crmId,
      orderid: this.state.orderId,
      trffile: Base64Img,
      trffilename: 'pdf',
    };
    console.log('before encrypt-------------------->' + JSON.stringify(data));
    this.props.onUpdatePNSWithTRF(data, this.props.accessToken);
    
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.updateError == false &&
      this.props.updateError != prevProps.updateError
    ) {
      this.setState(
        {
          loading:false,
          errorMsg: this.props.message,
          showToast: true,
          
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
      // alert('Update failed')
    }
    if (
      this.props.updateStatus == true &&
      this.props.updateStatus != prevProps.updateStatus
    ) {
      this.moveToNext();
    }


    console.log(this.props.updateStatus,this.props.updateLoading)
  };
  deleteImage = deleteItem => {
    var arr = this.state.imageArray;
    arr.splice(deleteItem, 1);
    this.setState({imageArray: arr, imageArrayForFlatList: arr});

    var imgarr = this.state.imageArrayForFlatList;
    imgarr.splice(deleteItem, 1);
    this.setState({imageArrayForFlatList: imgarr});
    if (this.state.imageArrayForFlatList.length == 0) {
      this.setState({showList: false, showNextButton: false});
      this.setState({setShowCamera: true});
    } else {
      this.setState({showList: true});
    }
    this.setState({stopClick: false});
  };

  render() {
    return (
      <ScanTRFScreen
        cancelModalHandler={this.cancelModalHandler}
        okayConfirmHandler={this.okayConfirmHandler}
        openModal={this.openModal}
        showModal={this.state.showModal}
        showSuccessModal={this.state.showSuccessModal}
        setShowCamera={this.state.setShowCamera}
        setDontShowCamera={this.setDontShowCamera}
        takePicture={this.takePicture}
        setPath={this.state.setPath}
        showList={this.state.showList}
        cancelImage={this.cancelImage}
        correctImage={this.correctImage}
        showNextButton={this.state.showNextButton}
        confirmImage={this.state.confirmImage}
        message={this.state.message}
        showAddImageModal={this.state.showAddImageModal}
        okayAddImageHandler={this.okayAddImageHandler}
        cancelAddImageHandler={this.cancelAddImageHandler}
        addMoreImageHandler={this.addMoreImageHandler}
        data={this.state.imageArrayForFlatList}
        deleteImage={this.deleteImage}
        stopClick={this.state.stopClick}
        loading={this.state.loading}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    updateLoading: state.mytask.MytaskUploadPNSWithTRFLoading,
    responseData: state.mytask.MytaskUploadPNSWithTRFResponse,
    updateStatus: state.mytask.MytaskUploadPNSWithTRFStatus,
    updateError: state.mytask.MytaskUploadPNSWithTRFError,
    message: state.mytask.message,
    //message: state.updateBabyCordDetailsReducer.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onUpdatePNSWithTRF: (data, token) =>
      dispatch(mytaskUpdatePNSWithTRF(data, token)),
    onMytaskGetCrmidOrderidForRegularBeat: (data, token) =>
      dispatch(mytaskGetCrmidOrderidForRegularBeat(data, token)),
    onPayDetails: data => dispatch(payDetails(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(scanTRFForPNS);
