import React, { useRef } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  Image,
  Platform, FlatList
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { heightPercentageToDP as hp, widthPercentageToDP, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AppButton from '../../../components/Button';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import { RNCamera } from 'react-native-camera';
import Icon from 'react-native-vector-icons/FontAwesome';
import IonIcons from 'react-native-vector-icons/Ionicons';
import I18n from '../../../locale/i18n';
import { NetworkContext } from '../../../contexts/NetworkContext';
import { Toast } from '../../../components/Toast';
function ScanTRFForPNSScreen({ openModal, showModal, cancelModalHandler, okayConfirmHandler, showSuccessModal, setShowCamera, setDontShowCamera,
  takePicture, setPath, cancelImage, correctImage, showNextButton, confirmImage, message, showAddImageModal,
  okayAddImageHandler, cancelAddImageHandler, addMoreImageHandler, data, showList, deleteImage, stopClick,
  errorMsg,
  showToast,
  loading }) {
  const { isConnected } = React.useContext(NetworkContext);
  const renderCamera = () => {
    return (
      <View style={styles.cameraInnerContainer}>
        <RNCamera
          style={styles.cameraContainer}
          captureAudio={false}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.off}
          ratio={'4:4'}
          fixOrientation={true}
        >
          {({ camera, status, recordAudioPermissionStatus }) => {
            {
              status == 'PENDING_AUTHORIZATION'
                ? null
                : status == 'NOT_AUTHORIZED'
                  ? alertnotauthorized()
                  : setShowCamera;
            }

            return (
              <View style={{ alignItems: 'flex-end', justifyContent: 'flex-end' }}>

                <View
                  style={{
                    flex: 0,
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginBottom: hp('-40%'),
                    alignItems: 'center',
                  }}>
                  <TouchableOpacity
                    onPress={() => takePicture(camera)}
                    style={{ alignItems: 'flex-end' }}>

                    <View
                      style={{
                        backgroundColor: 'transparent',
                        borderWidth: wp('1.5%'),
                        borderColor: Colors.border,
                        height: hp('8%'),
                        width: hp('8%'),
                        borderRadius: 50,
                        alignItems: 'center',
                        justifyContent: 'center',

                      }}>
                      <View
                        style={{
                          backgroundColor: Colors.card,
                          height: hp('5%'),
                          width: hp('5%'),
                          borderRadius: 50,
                        }}></View>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            );
          }}
        </RNCamera>
      </View>
    );
  };
  const renderImage = () => {
    return (
      <View style={styles.previewImageContainer}>
        <Image
          source={{ uri: setPath }}
          resizeMode={'contain'}
          style={styles.image}
        />
      </View>
    );
  };

  const renderItem = ({ item, index }) => {
    return (
      <View style={{ flexDirection: 'column', marginVertical: wp('3%') }}>
        <View style={styles.removeIconContainer}>
          <IonIcons name='remove-circle-outline' size={wp('5%')} style={{ color: Colors.button }} onPress={() => deleteImage(index)} />
        </View>
        <Image
          source={{ uri: item.imageUri }}
          resizeMode={'contain'}
          style={styles.flatListimage}
        />

      </View>
    );
  };

  return (
    <RootView pageNo={'25'} loading={loading} connected={isConnected}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <View style={styles.rootView}>
        <View style={styles.topContainer}>
          <View style={styles.topColOne}>
            <View style={styles.headerTextContainer}>
              <Text style={styles.headerText}>{message}</Text>
            </View>
          </View>

        </View>
        <View style={{ height: hp('65%'), width: wp('80%'), alignItems: 'center', justifyContent: 'center' }}>
          {setShowCamera ? renderCamera() : null}
          {setPath ? renderImage() : null}
          {showList ?
            <View>
              <FlatList
                showsVerticalScrollIndicator={false}
                data={data}
                renderItem={renderItem}
                //horizontal={true}
                keyExtractor={(item, index) => item.id}
                contentContainerStyle={styles.flatListInnerContainer}
              />
            </View> : null

          }
        </View>

        <View style={{ width: wp('100%'), height: hp('10%'), alignItems: 'center', justifyContent: 'center', flexDirection: 'row', marginTop: hp('2%') }}>
          {confirmImage ?
            <>
              <TouchableOpacity onPress={cancelImage}>
                <View style={styles.buttonGreenConfirm}>
                  <Ionicons name="close" color={Colors.white} size={24} />
                </View>
              </TouchableOpacity>
              <TouchableOpacity onPress={correctImage}>
                <View style={styles.buttonPinkConfirm}>
                  <Ionicons name="checkmark-outline" color={Colors.white} size={24} />
                </View>
              </TouchableOpacity>
            </>
            : null}
          {showNextButton ?
            <View style={{ width: wp('100%'), flexDirection: 'row' }}>
              {/* <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={openModal} buttonStyle={styles.nextButton}/>
      <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={openModal} buttonStyle={styles.nextButton}/> */}
              <View style={styles.bottomButtonContainer}>
                <View style={styles.bottonButtonRowContainer}>
                  <AppButton
                    title={I18n.t('paramedic.myTask.add_more_label')}
                    buttonStyle={styles.startButton}
                    buttonTextStyle={styles.buttonTextReschedule}
                    onPress={stopClick ? null : addMoreImageHandler}
                  />
                </View>
                <View style={styles.bottonButtonRowContainer}>
                  <AppButton
                    title={I18n.t('paramedic.myTask.next_label')}
                    buttonStyle={styles.viewButton}
                    buttonTextStyle={styles.buttonTextStyle}
                    onPress={okayConfirmHandler}
                  />
                </View>

              </View>
            </View>
            : null}
        </View>
        {/* <ModalSuccess
          visible={showSuccessModal}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.biobank_kit_collected_from_customer_label')}
          pageNumber={'30'}
        /> */}
        {/* <ModalConfirmNumber
          title={I18n.t('paramedic.myTask.kit_pickup_label')}
          message={I18n.t('paramedic.myTask.collected_kit_from_customer_label')}
          pageNumber={27}
          visible={showModal}
          dismissHandler={cancelModalHandler}
          cancelHandler={cancelModalHandler}
          okayHandler={okayConfirmHandler}
        /> */}
        <ModalConfirmNumber
          title={I18n.t('paramedic.myTask.add_more_label')}
          message={I18n.t('paramedic.myTask.do_you_want_more_images_to_add_label')}
          pageNumber={27}
          visible={showAddImageModal}
          dismissHandler={cancelAddImageHandler}
          cancelHandler={cancelAddImageHandler}
          okayHandler={okayAddImageHandler}
        />
          <ModalSuccess
          visible={showSuccessModal}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.sample_collected_label')}
          pageNumber={'47'}
        />

      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  topContainer: {
    width: wp('100%'),
    height: hp('10%'),
    padding: wp('3%'),

  },
  topColOne: {
    width: wp('88%'),
    height: hp('6%'),
    marginVertical: wp('1%'),
    flexDirection: 'row',
    marginHorizontal: wp('3%'),
    alignItems: 'center',
    justifyContent: 'center',

  },
  headerTextContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: wp('5%')
  },
  headerText:
  {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    color: Colors.border,
    textAlign: 'center'
  },
  barcodeTextInput:
  {
    height: hp('6%'),
    width: wp('70%'),
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.bWhite,
    paddingHorizontal: wp('3%'),
    alignItems: 'center',
    marginVertical: hp('3%'),
    fontFamily: FontMagneta.semiBold,
    fontSize: FontSize.medium,
    color: Colors.border,
  },
  barcodeTextContainer:
  {
    width: wp('80%'),
    alignItems: 'center',
    justifyContent: 'center',

  },
  cameraContainer: {
    width: wp('80%'),
    height: hp('50%'),
    alignItems: 'center',
    justifyContent: 'center'
  },
  cameraInnerContainer: {
    width: wp('80%'),
    height: hp('40%'),
    alignItems: 'center',
    justifyContent: 'center'
  },
  previewImageContainer: {
    height: hp('70%'),
    width: wp('80%'),
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flexDirection: 'column',
  },
  image: {
    width: wp('80%'), height: hp('70%')
  },
  flatListimage: {
    width: wp('80%'), height: hp('50%')
  },
  containerConfirm: {
    width: '85%',
    minHeight: 140,
    justifyContent: 'space-between',
    paddingTop: 30,
    flexDirection: 'row'
  },
  buttonGreenConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkPink,
    borderRadius: 50,
    marginHorizontal: wp('3%')
  },
  buttonPinkConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkGreen,
    borderRadius: 50,
    marginHorizontal: wp('3%')
  },
  // nextButton:{
  //   height: hp('4.5%'),
  //   width: wp('38%'),
  //   alignItems: 'center',
  //   justifyContent: 'center',
  //   backgroundColor: Colors.button,
  //   elevation: 2,
  //   borderRadius: 50,
  //   paddingVertical: 3,
  //   paddingHorizontal: 10,
  //   marginHorizontal: 3
  // },
  buttonContainer:
  {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: '4%'
  },
  flatListContainer:
  {
    alignItems: 'flex-start',
    paddingHorizontal: 10,
    height: '60%'
  },
  bottomButtonContainer:
  {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 15,
  },
  bottonButtonRowContainer:
  {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  nextButtonContainer: {
    width: '100%',
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,

  },
  buttonTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  },
  startButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    borderWidth: Platform.OS == 'ios' ? hp('0.07%') : hp('0.1%'),
    borderColor: Colors.button
  },
  viewButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3
  },
  buttonTextReschedule: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.button
  },
  flatListInnerContainer: {
    paddingBottom: 30
  },
  removeIconContainer:
  {
    width: wp('77%'),
    height: hp('4%'),
    alignItems: 'flex-end',
    marginVertical:hp('1%'),
marginHorizontal:wp('3%')
  },

})


export default ScanTRFForPNSScreen;