import React from "react";
import { connect } from "react-redux";
import I18n from "i18next";
import PropTypes from "prop-types";
import CashDepositCalendarScreen from "./Screen";
import { Paramedic } from "../../../navigations/RouteTypes";
import Colors from "../../../config/Colors";
import { FontMagneta } from "../../../config/Fonts";
import { getDepositCashBank, getDepositCashBranch, getDepositCashTime } from "../../../store/Actions";
import { BackHandler } from 'react-native';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      isValidUsername: true,
      isValidPassword: true,
      showToast: false,
      isPending: 0,
      dropdownValue: "",
      radio: false,
      hours: new Date().getHours(),
      mins: new Date().getMinutes(),
      year: new Date().getFullYear(),
      month: new Date().getMonth(),
      date: new Date().getDate(),
      successModal: false,
      selectedDate: '',
      markedDates: {},
      time: '',
      timeValue: '',
      branch: '',
      bank: '',
      errormsg: '',
      branchtoast: false,
      banktoast: false,
      timetoast: false,
      datetoast: false
    };
  }

  componentDidMount = () => {
    const bankData = {
      "search": null
    };
    this.props.getBank(bankData, this.props.accessToken);
    // const branchData = {
    //   "bankid": null,
    //   "search": null
    // };
    // this.props.getBranch(branchData, this.props.accessToken);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  getSelectedDayEvents = day => {
    this.setState({
      datetoast: false
    })
    const timedata = {
      "pickupdate": day.dateString
    }
    this.props.getTime(timedata, this.props.accessToken);

    this.setState({ selectedDate: day.dateString });
    let markedDates = {};
    markedDates[day.dateString] = {
      customStyles: {
        container: {
          backgroundColor: Colors.border
        },
        text: {
          color: Colors.white,
          fontFamily: FontMagneta.medium
        }
      }
    };
    this.setState({
      markedDates: markedDates
    });
  };
  componentWillUnmount() { this.back.remove(); }
  componentDidUpdate = prevProps => {
    if (
      prevProps.cashDepositTimeStatus == false &&
      this.props.cashDepositTimeStatus !=
      prevProps.cashDepositTimeStatus
    ) {
      this.setState({
        time: this.props.timeRespose
      })
    }
  };
  pendingState = val => {
    this.setState({
      isPending: 0
    });
  };
  completedState = val => {
    this.setState({
      isPending: 1
    });
  };
  dropdownoption = val => {
    this.setState({
      dropdownValue: val
    });
  };
  dropdownBranchoption = val => {
    this.setState({
      branch: val,
      branchtoast: false
    });
  }
  dropdownBankoption = val => {
    this.setState({
      bank: val,
      banktoast: false
    });
    const branchData = {
      "bankid": val,
      "search": null
    };
    this.props.getBranch(branchData, this.props.accessToken);
  }
  radioPress = () => {
    this.setState({
      radio: true
    });
  };
  captureReceipt = () => {
    // if (this.state.selectedDate != "" && this.state.timeValue != "" && this.state.branch != "" && this.state.bank != "") {
    //   this.props.navigation.navigate(Paramedic.depositCamera, {
    //     "orderIds": this.props.route.params.orderId,
    //     "depositdatetime": this.state.selectedDate,
    //     "deposittime": this.state.timeValue,
    //     "bankid": this.state.bank,
    //     "branchid": this.state.branch
    //   });
    // }
    // else {
    //   console.log(this.state.selectedDate, this.state.timeValue, this.state.branch, this.state.bank)
    //   this.setState({
    //     showToast: true,
    //     errormsg: 'Please enter all fields '
    //   })
    // }
    this.state.selectedDate == "" ?
      this.setState({
        datetoast: true
      }) : this.setState({
        datetoast: false
      })
    this.state.bank != "" ? this.state.branch == "" ? this.setState({
      branchtoast: true
    }) : this.setState({
      branchtoast: false
    }) : null
    this.state.bank == "" ? this.setState({
      banktoast: true
    }) : this.setState({
      banktoast: false
    })
    this.state.selectedDate != "" ? this.state.timeValue == "" ? this.setState({
      timetoast: true
    }) : this.setState({
      timetoast: false
    }) : null

    this.state.selectedDate != "" && this.state.timeValue != "" && this.state.branch != "" && this.state.bank != "" ?
      this.props.navigation.navigate(Paramedic.depositCamera, {
        "orderIds": this.props.route.params.orderId,
        "depositdatetime": this.state.selectedDate,
        "deposittime": this.state.timeValue,
        "bankid": this.state.bank,
        "branchid": this.state.branch
      }) : null
    // this.setState({ successModal: !this.state.successModal });
    // setTimeout(() => {
    //   this.setState({ successModal: false });
    //   this.props.navigation.navigate(Paramedic.deposit);
    // }, 2000);
  };
  Timevalue = (val) => {
    this.setState({
      timeValue: val,
      timetoast: false
    })
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  render() {
    return (
      <CashDepositCalendarScreen
        isPending={this.state.isPending}
        dropdownValue={this.state.dropdownValue}
        radio={this.state.radio}
        pendingState={this.pendingState}
        completedState={this.completedState}
        dropdownoption={this.dropdownoption}
        radioPress={this.radioPress}
        hours={this.state.hours}
        mins={this.state.mins}
        captureReceipt={this.captureReceipt}
        showSuccessModal={this.state.successModal}
        getSelectedDayEvents={this.getSelectedDayEvents}
        markedDates={this.state.markedDates}
        bankData={this.props.bankResponse}
        branchResponse={this.props.branchResponse}
        time={this.state.time}
        Timevalue={this.Timevalue}
        dropdownBranchoption={this.dropdownBranchoption}
        dropdownBankoption={this.dropdownBankoption}
        showToast={this.state.showToast}
        errormsg={this.state.errormsg}
        branchtoast={this.state.branchtoast}
        banktoast={this.state.banktoast}
        timetoast={this.state.timetoast}
        datetoast={this.state.datetoast}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    bankResponse: state.depositCash.bankResponse,
    branchResponse: state.depositCash.branchResponse,
    timeRespose: state.depositCash.timeResponse,
    cashDepositTimeLoading: state.depositCash.cashDepositTimeLoading,
    cashDepositTimeStatus: state.depositCash.cashDepositTimeStatus
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getBank: (data, token) => dispatch(getDepositCashBank(data, token)),
    getBranch: (data, token) => dispatch(getDepositCashBranch(data, token)),
    getTime: (data, token) => dispatch(getDepositCashTime(data, token))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
