import React from "react";
import { connect } from "react-redux";
import I18n from "i18next";
import AlertScreen from "./Screen";

class MangerApproval extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pressable: false,
      longPress: false
    };
  }

  press = () => {
    this.setState({
      pressable: !this.state.pressable
    });
  };

  onlongPress = () => {
    this.setState({
      longPress: !this.state.longPress
    });
  };

  render() {
    return (
      <AlertScreen
        pressable={this.state.pressable}
        press={this.press}
        onlongPress={this.onlongPress}
        longPress={this.state.longPress}
      />
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(MangerApproval);
