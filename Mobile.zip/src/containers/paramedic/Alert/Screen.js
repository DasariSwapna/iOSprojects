import React, { useRef } from "react";
import {
  Image,
  Text,
  View,
  KeyboardAvoidingView,
  FlatList,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  Platform
} from "react-native";
import RootView from "../../../components/RootView";
import Icon from "react-native-vector-icons/FontAwesome";
import Colors from "../../../config/Colors";
import { Font, FontMagneta, FontSize } from "../../../config/Fonts";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import PropTypes from "prop-types";

function AlertScreen({ press, pressable, longPress, onlongPress }) {
  return (
    <RootView pageNo={"299"}>
      <KeyboardAvoidingView style={styles.container}>
        <View style={styles.searchOuterContainer}>
          <View style={styles.searchSection}>
            <TextInput
              style={styles.input}
              placeholder="Search"
              underlineColorAndroid="transparent"
            />
            <Icon
              style={styles.searchIcon}
              name="search"
              size={24}
              color={Colors.dWhite}
            />
          </View>
          <Icon
            style={styles.searchIcon}
            name="trash"
            size={24}
            color={longPress == true ? Colors.border : Colors.dWhite}
          />
        </View>
        <FlatList
          style={styles.flatlistStyle}
          data={[
            {
              key: "New Task ",
              message:
                "Collect the sample from the location on  and handover the sample to lab",
              badge: "1",
              date: "12-11-2021"
            },
            {
              key: "New Task  ",
              message:
                "Collect the sample from the location on and handover the sample to lab",
              badge: "4",
              date: "12-11-2021"
            },
            {
              key: "New Task ",
              message:
                "Collect the sample from the location on and handover the sample to lab",
              badge: "1",
              date: "11-11-2021"
            }
          ]}
          renderItem={({ item }) =>
            <TouchableOpacity
              style={[
                styles.flatTouch,
                {
                  backgroundColor:
                    longPress == true ? Colors.dWhite : Colors.white
                }
              ]}
              onPress={press}
              onLongPress={onlongPress}
            >
              <Image
                source={require("../../../assets/icons/manageOrder.png")}
                style={styles.img}
              />
              <View style={styles.card}>
                <View style={styles.titleView}>
                  <Text style={styles.titleTxt}>
                    {item.key}
                  </Text>
                  <Text style={styles.dateTxt}>
                    {item.date}
                  </Text>
                </View>
                <View style={styles.msgView}>
                  <Text
                    style={styles.msgTxt}
                    numberOfLines={pressable == false ? 2 : null}
                  >
                    {item.message}
                  </Text>
                  <View style={styles.badge}>
                    <Text style={{ color: Colors.white }}>
                      {item.badge}
                    </Text>
                  </View>
                </View>
              </View>
            </TouchableOpacity>}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

AlertScreen.prototype = {
  pressable: PropTypes.func,
  press: PropTypes.func,
  onlongPress: PropTypes.func,
  longPress: PropTypes.func
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white
  },
  searchOuterContainer: {
    width: "90%",
    flexDirection: "row",
    alignSelf: "center",
    justifyContent: "space-between",
    paddingVertical: "5%",
    alignItems: "center"
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: "center"
  },
  searchSection: {
    width: "85%",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "transparent",
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25
  },
  searchIcon: {
    paddingHorizontal: wp("4%")
  },
  input: {
    paddingHorizontal: wp("5%"),
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
    paddingVertical: Platform.OS === 'ios' ? hp('1.8%') : null
  },
  flatlistStyle: {
    flex: 1,
    width: "100%",
    height: "100%"
  },
  flatTouch: {
    flexDirection: "row",
    paddingTop: "6%",
    alignItems: "center",
    paddingHorizontal: Platform.OS == "android" ? "6%" : "6%"
  },
  img: {
    height: hp("8%"),
    width: hp("8%"),
    borderRadius: hp("7%")
  },
  titleTxt: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large
  },
  dateTxt: {
    color: Colors.black,
    fontFamily: FontMagneta.regular,
    fontSize: FontSize.regular
  },
  msgTxt: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    width: "72%"
  },
  badge: {
    height: hp("3.5%"),
    width: hp("3.5%"),
    backgroundColor: Colors.border,
    borderRadius: hp("8%"),
    alignItems: "center",
    justifyContent: "center"
  },
  msgView: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  titleView: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  card: {
    width: "79%",
    marginStart: "4%"
  }
});

export default AlertScreen;
