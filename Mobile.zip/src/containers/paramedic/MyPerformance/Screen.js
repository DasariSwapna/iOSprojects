import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../components/RootView';

function MyPerformanceScreen() {
  return (
    <RootView>
      <Text>My Performance</Text>
    </RootView>
  );
}

export default MyPerformanceScreen;
