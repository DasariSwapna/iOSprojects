// import React, { useRef } from 'react';
// import {
//   Text,
//   View,
//   TouchableOpacity,
//   StyleSheet,
//   Image
// } from 'react-native';
// import RootView from '../../../components/RootView';
// import Colors from '../../../config/Colors';
// import { heightPercentageToDP as hp,widthPercentageToDP,widthPercentageToDP as wp} from 'react-native-responsive-screen';
// import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
// import Ionicons from 'react-native-vector-icons/Ionicons';
// import AppButton from '../../../components/Button';
// import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
// import {RNCamera} from 'react-native-camera';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import PageNo from '../../../constants/PageNo';
// import I18n from "../../../locale/i18n";
// function DepositCameraScreen({openModal,showModal,cancelModalHandler,okayConfirmHandler,showSuccessModal,setShowCamera,setDontShowCamera,takePicture,setPath,cancelImage,correctImage,showNextButton,confirmImage}) {
//   const renderCamera = () => {
//     return (
//       <View style={styles.cameraInnerContainer}>
//         <RNCamera
//           style={styles.cameraContainer}
//           captureAudio={false}
//           type={RNCamera.Constants.Type.back}
//           flashMode={RNCamera.Constants.FlashMode.off}
//           ratio={'4:4'}
//           fixOrientation={true}
//         >
//           {({camera, status, recordAudioPermissionStatus}) => {
//             {
//               status == 'PENDING_AUTHORIZATION'
//                 ? null
//                 : status == 'NOT_AUTHORIZED'
//                 ? alertnotauthorized()
//                 : setShowCamera;
//             }

//             return (
//               <View style={{alignItems:'flex-end',justifyContent:'flex-end'}}>
//                 {/* <View
//                   style={{
//                     width: wp('90%'),
//                     height: hp('10%'),
//                     backgroundColor: 'transparent',
//                     marginBottom: hp('30%'),
//                     alignItems: 'flex-end',
//                     justifyContent: 'center',
//                     marginRight: wp('80%'),
//                   }}>
//                   <Icon
//                     name="times-circle"
//                     style={{alignSelf: 'center'}}
//                     size={hp('6%')}
//                     color={'red'}
//                     onPress={() => {
//                      setDontShowCamera
//                     }}
//                   />
//                 </View> */}
//                 <View
//                   style={{
//                     flex: 0,
//                     flexDirection: 'row',
//                     justifyContent: 'center',
//                     marginBottom: hp('-40%'),
//                     alignItems: 'center',
//                   }}>
//                   <TouchableOpacity
//                     onPress={() => takePicture(camera)}
//                     style={{alignItems:'flex-end'}}>
//                     {/* <Text style={{ fontSize: hp('3%'),fontFamily:theme.fontfamily.fontbold,color:theme.colors.white }}> Capture </Text> */}
//                     <View
//                       style={{
//                         backgroundColor: 'transparent',
//                         borderWidth: wp('1.5%'),
//                         borderColor: Colors.border,
//                         height: hp('8%'),
//                         width: hp('8%'),
//                         borderRadius: 50,
//                         alignItems: 'center',
//                         justifyContent: 'center',
                      
//                       }}>
//                       <View
//                         style={{
//                           backgroundColor: Colors.card,
//                           height: hp('5%'),
//                           width: hp('5%'),
//                           borderRadius: 50,
//                         }}></View>
//                     </View>
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             );
//           }}
//         </RNCamera>
//       </View>
//     );
//   };
//   const renderImage = () => {
//     return (
//       <View style={styles.previewImageContainer}>
//         <Image
//           source={{uri: setPath}}
//           resizeMode={'cover'}
//           style={styles.image}
//         />
//       {/*   <View
//           style={{
//             flexDirection: 'row',
//             justifyContent: 'center',
//             justifyContent: 'center',
//             height: hp('6%'),
//             width: wp('100%'),
//             backgroundColor:'yellow',
//             marginTop:hp('-10%')
//           }}>
//           <View
//             style={{
//               width: wp('50%'),
//               backgroundColor: 'transparent',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Icon
//               name="times-circle"
//               style={{alignSelf: 'center'}}
//               size={hp('6%')}
//               color={'red'}
//               onPress={() => {
//                 //setpath(null);
//               }}
//             />
//           </View>
//           <View
//             style={{
//               width: wp('50%'),
//               backgroundColor: 'transparent',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Icon
//               name="check-circle"
//               style={{alignSelf: 'center'}}
//               size={hp('6%')}
//               color={Colors.babyCordTextColor}
//               onPress={() => {
//              //   convertto64(path), setpath(null);
//               }}
//             />
//           </View>
//         </View> */}
//       </View>
//     );
//   };

//   return (
//     <RootView pageNo={PageNo.paramedic_depositCamera}>
//       <View style={styles.rootView}>
//        <View style={styles.topContainer}>
//          <View style={styles.topColOne}>
//          <View style={styles.headerTextContainer}>
//          <Text style={styles.headerText}>{I18n.t('paramedic.deposit.capture_deposit_receipt')} </Text>
//          </View>
//            </View>
       
//        </View>
//        <View style={{height:hp('65%'),width:wp('80%'),alignItems:'center',justifyContent:'center'}}>
//        {setShowCamera ? renderCamera() : null}
//       {setPath ? renderImage() : null}
//       </View>
     
//         <View style={{width:wp('100%'),height:hp('10%'),alignItems:'center',justifyContent:'center',flexDirection:'row',marginTop:hp('2%')}}>
//            {confirmImage ? 
//            <>
//             <TouchableOpacity onPress={cancelImage}>
//               <View style={styles.buttonGreenConfirm}>
//                 <Ionicons name="close" color={Colors.white} size={24} />
//               </View>
//             </TouchableOpacity>
//             <TouchableOpacity onPress={correctImage}>
//               <View style={styles.buttonPinkConfirm}>
//                 <Ionicons name="checkmark-outline" color={Colors.white} size={24} />
//               </View>
//             </TouchableOpacity>
//             </>
//        :null}
//         {showNextButton ? 
//       <AppButton title={'Next'} onPress={openModal}/>
//        :null}
//         </View>
//        <ModalSuccess
//           visible={showSuccessModal}
//           title={'Success'}
//           message={'Cash Deposit captured'}
//           pageNumber={'30'}
//         />
//          <ModalConfirmNumber
//           title={'Kit pickup'}
//           message={'Collected the kit from customer?'}
//           pageNumber={27}
//           visible={showModal}
//           dismissHandler={cancelModalHandler}
//           cancelHandler={cancelModalHandler}
//           okayHandler={okayConfirmHandler}
//         />
//       </View>
//     </RootView>
//   );
// }
// const styles = StyleSheet.create({
//   rootView: {
//     flex: 1,
//     backgroundColor: Colors.background,
//     flexDirection: 'column', 
//     alignItems: 'center', 
//     justifyContent: 'flex-start'
//   },
//   topContainer: {
//   width:wp('100%'),
//   height:hp('10%'),
//   padding:wp('3%'),
  
//   },
//   topColOne:{
//     width:wp('88%'),
//     height:hp('6%'),
//     marginVertical:wp('1%'),
//     flexDirection:'row',
//     marginHorizontal:wp('3%'),
//     alignItems:'center',
//     justifyContent:'center',
 
//   },
//   headerTextContainer:{
//     alignItems:'center',
//     justifyContent:'center',
//     marginHorizontal:wp('5%')
//   },
//   headerText:
//   {
//     fontFamily:Font.extraBold,
//     fontSize:FontSize.medium,
//     color:Colors.border,
//     textAlign:'center'
//   },
//   barcodeTextInput:
//   {
//     height:hp('6%'),
//     width:wp('70%'),
//     borderWidth:1,
//     borderRadius:10,
//     borderColor:Colors.bWhite,
//     paddingHorizontal:wp('3%'),
//     alignItems:'center', 
//     marginVertical:hp('3%'),
//     fontFamily:FontMagneta.semiBold,
//     fontSize:FontSize.medium,
//     color:Colors.border,
// },
// barcodeTextContainer:
// {
//   width:wp('80%'),
//   alignItems:'center',
//   justifyContent:'center',
  
// },
// cameraContainer:{
//   width:wp('80%'),
//   height:hp('50%'),
//   alignItems:'center',
//   justifyContent:'center'
// },
// cameraInnerContainer:{
//   width:wp('80%'),
//   height:hp('40%'),
//   alignItems:'center',
//   justifyContent:'center'
// },
// previewImageContainer:{
//   height:hp('70%'),
//   width:wp('80%'),
//   alignItems:'flex-start',
//   justifyContent:'flex-start',
//   flexDirection:'column',
// },
// image:{
//   width:wp('80%'),height:hp('70%')
// },
// containerConfirm: {
//   width: '85%',
//   minHeight: 140,
//   justifyContent: 'space-between',
//   paddingTop: 30,
//   flexDirection: 'row'
// },
// buttonGreenConfirm: {
//   alignItems: 'center',
//   paddingVertical:wp('2%'),
//   paddingHorizontal: wp('16%'),
//   backgroundColor: Colors.darkPink,
//   borderRadius: 50,
//   marginHorizontal:wp('3%')
// },
// buttonPinkConfirm: {
//   alignItems: 'center',
//   paddingVertical:wp('2%'),
//   paddingHorizontal: wp('16%'),
//   backgroundColor: Colors.darkGreen,
//   borderRadius: 50,
//   marginHorizontal:wp('3%')
// },

// })


// export default DepositCameraScreen;
// import React, { useRef } from 'react';
// import {
//   Text,
//   View,
//   TouchableOpacity,
//   StyleSheet,
//   Image
// } from 'react-native';
// import RootView from '../../../components/RootView';
// import Colors from '../../../config/Colors';
// import { heightPercentageToDP as hp,widthPercentageToDP,widthPercentageToDP as wp} from 'react-native-responsive-screen';
// import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
// import Ionicons from 'react-native-vector-icons/Ionicons';
// import AppButton from '../../../components/Button';
// import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
// import {RNCamera} from 'react-native-camera';
// import Icon from 'react-native-vector-icons/FontAwesome';
// import I18n from "../../../locale/i18n";
// import PageNo from '../../../constants/PageNo';
// function DepositCameraScreen({openModal,showModal,cancelModalHandler,okayConfirmHandler,showSuccessModal,setShowCamera,setDontShowCamera,takePicture,setPath,cancelImage,correctImage,showNextButton,confirmImage}) {
//   const renderCamera = () => {
//     return (
//       <View style={styles.cameraInnerContainer}>
//         <RNCamera
//           style={styles.cameraContainer}
//           captureAudio={false}
//           type={RNCamera.Constants.Type.back}
//           flashMode={RNCamera.Constants.FlashMode.off}
//           ratio={'4:4'}
//           fixOrientation={true}
//         >
//           {({camera, status, recordAudioPermissionStatus}) => {
//             {
//               status == 'PENDING_AUTHORIZATION'
//                 ? null
//                 : status == 'NOT_AUTHORIZED'
//                 ? alertnotauthorized()
//                 : setShowCamera;
//             }

//             return (
//               <View style={{alignItems:'flex-end',justifyContent:'flex-end'}}>
//                 {/* <View
//                   style={{
//                     width: wp('90%'),
//                     height: hp('10%'),
//                     backgroundColor: 'transparent',
//                     marginBottom: hp('30%'),
//                     alignItems: 'flex-end',
//                     justifyContent: 'center',
//                     marginRight: wp('80%'),
//                   }}>
//                   <Icon
//                     name="times-circle"
//                     style={{alignSelf: 'center'}}
//                     size={hp('6%')}
//                     color={'red'}
//                     onPress={() => {
//                      setDontShowCamera
//                     }}
//                   />
//                 </View> */}
//                 <View
//                   style={{
//                     flex: 0,
//                     flexDirection: 'row',
//                     justifyContent: 'center',
//                     marginBottom: hp('-40%'),
//                     alignItems: 'center',
//                   }}>
//                   <TouchableOpacity
//                     onPress={() => takePicture(camera)}
//                     style={{alignItems:'flex-end'}}>
//                     {/* <Text style={{ fontSize: hp('3%'),fontFamily:theme.fontfamily.fontbold,color:theme.colors.white }}> Capture </Text> */}
//                     <View
//                       style={{
//                         backgroundColor: 'transparent',
//                         borderWidth: wp('1.5%'),
//                         borderColor: Colors.border,
//                         height: hp('8%'),
//                         width: hp('8%'),
//                         borderRadius: 50,
//                         alignItems: 'center',
//                         justifyContent: 'center',

//                       }}>
//                       <View
//                         style={{
//                           backgroundColor: Colors.card,
//                           height: hp('5%'),
//                           width: hp('5%'),
//                           borderRadius: 50,
//                         }}></View>
//                     </View>
//                   </TouchableOpacity>
//                 </View>
//               </View>
//             );
//           }}
//         </RNCamera>
//       </View>
//     );
//   };
//   const renderImage = () => {
//     return (
//       <View style={styles.previewImageContainer}>
//         <Image
//           source={{uri: setPath}}
//           resizeMode={'cover'}
//           style={styles.image}
//         />
//       {/*   <View
//           style={{
//             flexDirection: 'row',
//             justifyContent: 'center',
//             justifyContent: 'center',
//             height: hp('6%'),
//             width: wp('100%'),
//             backgroundColor:'yellow',
//             marginTop:hp('-10%')
//           }}>
//           <View
//             style={{
//               width: wp('50%'),
//               backgroundColor: 'transparent',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Icon
//               name="times-circle"
//               style={{alignSelf: 'center'}}
//               size={hp('6%')}
//               color={'red'}
//               onPress={() => {
//                 //setpath(null);
//               }}
//             />
//           </View>
//           <View
//             style={{
//               width: wp('50%'),
//               backgroundColor: 'transparent',
//               alignItems: 'center',
//               justifyContent: 'center',
//             }}>
//             <Icon
//               name="check-circle"
//               style={{alignSelf: 'center'}}
//               size={hp('6%')}
//               color={Colors.babyCordTextColor}
//               onPress={() => {
//              //   convertto64(path), setpath(null);
//               }}
//             />
//           </View>
//         </View> */}
//       </View>
//     );
//   };

//   return (
//     <RootView pageNo={PageNo.paramedic_kitCourierCamera}>
//       <View style={styles.rootView}>
//        <View style={styles.topContainer}>
//          <View style={styles.topColOne}>
//          <View style={styles.headerTextContainer}>
//          <Text style={styles.headerText}>{I18n.t('paramedic.kitSampleHandover.capture_pod')}</Text>
//          </View>
//            </View>

//        </View>
//        <View style={{height:hp('65%'),width:wp('80%'),alignItems:'center',justifyContent:'center'}}>
//        {setShowCamera ? renderCamera() : null}
//       {setPath ? renderImage() : null}
//       </View>

//         <View style={{width:wp('100%'),height:hp('10%'),alignItems:'center',justifyContent:'center',flexDirection:'row',marginTop:hp('2%')}}>
//            {confirmImage ?
//            <>
//             <TouchableOpacity onPress={cancelImage}>
//               <View style={styles.buttonGreenConfirm}>
//                 <Ionicons name="close" color={Colors.white} size={24} />
//               </View>
//             </TouchableOpacity>
//             <TouchableOpacity onPress={correctImage}>
//               <View style={styles.buttonPinkConfirm}>
//                 <Ionicons name="checkmark-outline" color={Colors.white} size={24} />
//               </View>
//             </TouchableOpacity>
//             </>
//        :null}
//         {showNextButton ?
//       <AppButton title={'Next'} onPress={openModal}/>
//        :null}
//         </View>
//        <ModalSuccess
//           visible={showSuccessModal}
//           title={'Success'}
//           message={'Sample Delivered through courier'}
//           pageNumber={'30'}
//         />
//          <ModalConfirmNumber
//           title={'Kit pickup'}
//           message={'Collected the kit from customer?'}
//           pageNumber={27}
//           visible={showModal}
//           dismissHandler={cancelModalHandler}
//           cancelHandler={cancelModalHandler}
//           okayHandler={okayConfirmHandler}
//         />
//       </View>
//     </RootView>
//   );
// }
// const styles = StyleSheet.create({
//   rootView: {
//     flex: 1,
//     backgroundColor: Colors.background,
//     flexDirection: 'column',
//     alignItems: 'center',
//     justifyContent: 'flex-start'
//   },
//   topContainer: {
//   width:wp('100%'),
//   height:hp('10%'),
//   padding:wp('3%'),

//   },
//   topColOne:{
//     width:wp('88%'),
//     height:hp('6%'),
//     marginVertical:wp('1%'),
//     flexDirection:'row',
//     marginHorizontal:wp('3%'),
//     alignItems:'center',
//     justifyContent:'center',

//   },
//   headerTextContainer:{
//     alignItems:'center',
//     justifyContent:'center',
//     marginHorizontal:wp('5%')
//   },
//   headerText:
//   {
//     fontFamily:Font.extraBold,
//     fontSize:FontSize.medium,
//     color:Colors.border,
//     textAlign:'center'
//   },
//   barcodeTextInput:
//   {
//     height:hp('6%'),
//     width:wp('70%'),
//     borderWidth:1,
//     borderRadius:10,
//     borderColor:Colors.bWhite,
//     paddingHorizontal:wp('3%'),
//     alignItems:'center',
//     marginVertical:hp('3%'),
//     fontFamily:FontMagneta.semiBold,
//     fontSize:FontSize.medium,
//     color:Colors.border,
// },
// barcodeTextContainer:
// {
//   width:wp('80%'),
//   alignItems:'center',
//   justifyContent:'center',

// },
// cameraContainer:{
//   width:wp('80%'),
//   height:hp('50%'),
//   alignItems:'center',
//   justifyContent:'center'
// },
// cameraInnerContainer:{
//   width:wp('80%'),
//   height:hp('40%'),
//   alignItems:'center',
//   justifyContent:'center'
// },
// previewImageContainer:{
//   height:hp('70%'),
//   width:wp('80%'),
//   alignItems:'flex-start',
//   justifyContent:'flex-start',
//   flexDirection:'column',
// },
// image:{
//   width:wp('80%'),height:hp('70%')
// },
// containerConfirm: {
//   width: '85%',
//   minHeight: 140,
//   justifyContent: 'space-between',
//   paddingTop: 30,
//   flexDirection: 'row'
// },
// buttonGreenConfirm: {
//   alignItems: 'center',
//   paddingVertical:wp('2%'),
//   paddingHorizontal: wp('16%'),
//   backgroundColor: Colors.darkPink,
//   borderRadius: 50,
//   marginHorizontal:wp('3%')
// },
// buttonPinkConfirm: {
//   alignItems: 'center',
//   paddingVertical:wp('2%'),
//   paddingHorizontal: wp('16%'),
//   backgroundColor: Colors.darkGreen,
//   borderRadius: 50,
//   marginHorizontal:wp('3%')
// },

// })

// export default DepositCameraScreen;
import React, { useRef } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  Image,
  Platform,
  FlatList,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Ionicons from 'react-native-vector-icons/Ionicons';
import AppButton from '../../../components/Button';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import { RNCamera } from 'react-native-camera';
import Icon from 'react-native-vector-icons/FontAwesome';
import IonIcons from 'react-native-vector-icons/Ionicons';
import I18n from '../../../locale/i18n';
function ScanTRFScreen({
  openModal,
  showModal,
  cancelModalHandler,
  okayConfirmHandler,
  showSuccessModal,
  setShowCamera,
  setDontShowCamera,
  takePicture,
  setPath,
  cancelImage,
  correctImage,
  showNextButton,
  confirmImage,
  message,
  showAddImageModal,
  okayAddImageHandler,
  cancelAddImageHandler,
  addMoreImageHandler,
  data,
  showList,
  deleteImage,
  stopClick,
}) {
  const renderCamera = () => {
    return (
      <View style={styles.cameraInnerContainer}>
        <RNCamera
          style={styles.cameraContainer}
          captureAudio={false}
          type={RNCamera.Constants.Type.back}
          flashMode={RNCamera.Constants.FlashMode.off}
          ratio={'4:4'}
          fixOrientation={true}>
          {({ camera, status, recordAudioPermissionStatus }) => {
            {
              status == 'PENDING_AUTHORIZATION'
                ? null
                : status == 'NOT_AUTHORIZED'
                  ? alertnotauthorized()
                  : setShowCamera;
            }

            return (
              <View
                style={{ alignItems: 'flex-end', justifyContent: 'flex-end' }}>
                <View
                  style={{
                    flex: 0,
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginBottom: hp('-40%'),
                    alignItems: 'center',
                  }}>
                  <TouchableOpacity
                    onPress={() => takePicture(camera)}
                    style={{ alignItems: 'flex-end' }}>
                    <View
                      style={{
                        backgroundColor: 'transparent',
                        borderWidth: wp('1.5%'),
                        borderColor: Colors.border,
                        height: hp('8%'),
                        width: hp('8%'),
                        borderRadius: 50,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}>
                      <View
                        style={{
                          backgroundColor: Colors.card,
                          height: hp('5%'),
                          width: hp('5%'),
                          borderRadius: 50,
                        }}></View>
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            );
          }}
        </RNCamera>
      </View>
    );
  };
  const renderImage = () => {
    return (
      <View style={styles.previewImageContainer}>
        <Image
          source={{ uri: setPath }}
          resizeMode={'cover'}
          style={styles.image}
        />
      </View>
    );
  };

  const renderItem = ({ item, index }) => {
    return (
      <View style={{ flexDirection: 'column', margin: wp('3%') }}>
        <View style={styles.removeIconContainer}>
          <IonIcons
            name="remove-circle-outline"
            size={wp('5%')}
            style={{ color: Colors.button }}
            onPress={() => deleteImage(index)}
          />
        </View>
        <Image
          source={{ uri: item.imageUri }}
          resizeMode={'cover'}
          style={styles.flatListimage}
        />
      </View>
    );
  };

  return (
    <RootView pageNo={'25'}>
      <View style={styles.rootView}>
        <View style={styles.topContainer}>
          <View style={styles.topColOne}>
            <View style={styles.headerTextContainer}>
              <Text style={styles.headerText}>{message}</Text>
            </View>
          </View>
        </View>
        <View
          style={{
            height: hp('65%'),
            width: wp('80%'),
            alignItems: 'center',
            justifyContent: 'center',
          }}>
          {setShowCamera ? renderCamera() : null}
          {setPath ? renderImage() : null}
          {showList ? (
            <View>
              <FlatList
                showsVerticalScrollIndicator={false}
                data={data}
                renderItem={renderItem}
                //horizontal={true}
                keyExtractor={(item, index) => item.id}
                contentContainerStyle={styles.flatListInnerContainer}
              />
            </View>
          ) : null}
        </View>

        <View
          style={{
            width: wp('100%'),
            height: hp('10%'),
            alignItems: 'center',
            justifyContent: 'center',
            flexDirection: 'row',
            marginTop: hp('2%'),
          }}>
          {confirmImage ? (
            <>
              <TouchableOpacity onPress={cancelImage}>
                <View style={styles.buttonGreenConfirm}>
                  <Ionicons name="close" color={Colors.white} size={24} />
                </View>
              </TouchableOpacity>
              <TouchableOpacity onPress={correctImage}>
                <View style={styles.buttonPinkConfirm}>
                  <Ionicons
                    name="checkmark-outline"
                    color={Colors.white}
                    size={24}
                  />
                </View>
              </TouchableOpacity>
            </>
          ) : null}
          {showNextButton ? (
            <View style={{ width: wp('100%'), flexDirection: 'row' }}>
              {/* <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={openModal} buttonStyle={styles.nextButton}/>
      <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={openModal} buttonStyle={styles.nextButton}/> */}
              <View style={styles.bottomButtonContainer}>
                <View style={styles.bottonButtonRowContainer}>
                  <AppButton
                    title={I18n.t('paramedic.myTask.add_more_label')}
                    buttonStyle={styles.startButton}
                    buttonTextStyle={styles.buttonTextReschedule}
                    onPress={stopClick ? null : addMoreImageHandler}
                  />
                </View>
                <View style={styles.bottonButtonRowContainer}>
                  <AppButton
                    title={I18n.t('paramedic.myTask.next_label')}
                    buttonStyle={styles.viewButton}
                    buttonTextStyle={styles.buttonTextStyle}
                    onPress={openModal}
                  />
                </View>
              </View>
            </View>
          ) : null}
        </View>
        <ModalSuccess
          visible={showSuccessModal}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t(
            'Cash deposit captured',
          )}
          pageNumber={'30'}
        />
        <ModalConfirmNumber
          title={"Deposit cash"}
          message={"Collected the Cash deposit from customer?"}
          pageNumber={27}
          visible={showModal}
          dismissHandler={cancelModalHandler}
          cancelHandler={cancelModalHandler}
          okayHandler={okayConfirmHandler}
        />
        <ModalConfirmNumber
          title={I18n.t('paramedic.myTask.add_more_label')}
          message={I18n.t(
            'paramedic.myTask.do_you_want_more_images_to_add_label',
          )}
          pageNumber={27}
          visible={showAddImageModal}
          dismissHandler={cancelAddImageHandler}
          cancelHandler={cancelAddImageHandler}
          okayHandler={okayAddImageHandler}
        />
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  topContainer: {
    width: wp('100%'),
    height: hp('10%'),
    padding: wp('3%'),
  },
  topColOne: {
    width: wp('88%'),
    height: hp('6%'),
    marginVertical: wp('1%'),
    flexDirection: 'row',
    marginHorizontal: wp('3%'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerTextContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: wp('5%'),
  },
  headerText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    color: Colors.border,
    textAlign: 'center',
  },
  barcodeTextInput: {
    height: hp('6%'),
    width: wp('70%'),
    borderWidth: 1,
    borderRadius: 10,
    borderColor: Colors.bWhite,
    paddingHorizontal: wp('3%'),
    alignItems: 'center',
    marginVertical: hp('3%'),
    fontFamily: FontMagneta.semiBold,
    fontSize: FontSize.medium,
    color: Colors.border,
  },
  barcodeTextContainer: {
    width: wp('80%'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraContainer: {
    width: wp('80%'),
    height: hp('50%'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  cameraInnerContainer: {
    width: wp('80%'),
    height: hp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewImageContainer: {
    height: hp('70%'),
    width: wp('80%'),
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
    flexDirection: 'column',
  },
  image: {
    width: wp('80%'),
    height: hp('70%'),
  },
  flatListimage: {
    width: wp('80%'),
    height: hp('50%'),
  },
  containerConfirm: {
    width: '85%',
    minHeight: 140,
    justifyContent: 'space-between',
    paddingTop: 30,
    flexDirection: 'row',
  },
  buttonGreenConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkPink,
    borderRadius: 50,
    marginHorizontal: wp('3%'),
  },
  buttonPinkConfirm: {
    alignItems: 'center',
    paddingVertical: wp('2%'),
    paddingHorizontal: wp('16%'),
    backgroundColor: Colors.darkGreen,
    borderRadius: 50,
    marginHorizontal: wp('3%'),
  },
  // nextButton:{
  //   height: hp('4.5%'),
  //   width: wp('38%'),
  //   alignItems: 'center',
  //   justifyContent: 'center',
  //   backgroundColor: Colors.button,
  //   elevation: 2,
  //   borderRadius: 50,
  //   paddingVertical: 3,
  //   paddingHorizontal: 10,
  //   marginHorizontal: 3
  // },
  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: '4%',
  },
  flatListContainer: {
    alignItems: 'flex-start',
    paddingHorizontal: 10,
    height: '60%',
  },
  bottomButtonContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 15,
  },
  bottonButtonRowContainer: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  nextButtonContainer: {
    width: '100%',
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  buttonTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  },
  startButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    borderWidth: Platform.OS == 'ios' ? hp('0.07%') : hp('0.1%'),
    borderColor: Colors.button,
  },
  viewButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3,
  },
  buttonTextReschedule: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.button,
  },
  flatListInnerContainer: {
    paddingBottom: 30,
  },
  removeIconContainer: {
    width: wp('77%'),
    height: hp('3%'),
    alignItems: 'flex-end',
  },
});

export default ScanTRFScreen;
