// import React from 'react';
// import {connect} from 'react-redux';
// import {Paramedic} from '../../../navigations/RouteTypes';
// import DepositCameraScreen from './Screen';

// const data=[

// ]
// class DepositCamScreen extends React.Component {

//   constructor(props) {
//     super(props);
//     this.state = {
//         showModal: false,
//         showSuccessModal: false,
//         setShowCamera:true,
//         setPath:'',
//         showNextButton:false,
//         confirmImage:false
//     };
//   }
//   openModal=()=>{
//     this.setState({showSuccessModal:true})
//     setTimeout(() => {
//         this.setState({showSuccessModal:false})
//         this.props.navigation.navigate(Paramedic.deposit)
//       }, 2000);
//    }

//    cancelImage=()=>{
//     this.setState({setPath:''})
//     this.setState({confirmImage:false})
//     this.setState({setShowCamera:true})
//    }
//    correctImage=()=>{
//     this.setState({confirmImage:false})
//      this.setState({showNextButton:true})

//    }

//   cancelModalHandler=()=>{
//     this.setState({showModal:false})
//    }
//    setDontShowCamera=()=>{
//     this.setState({setShowCamera:false})
//    }

//    moveToNext=()=>{
//     this.props.navigation.navigate(Paramedic.babyCord);
//    }
//    okayConfirmHandler=()=>{
//     this.setState({showModal:false})
//     this.setState({showSuccessModal:true})
//     setTimeout(() => {
//         this.setState({showSuccessModal:false})
//         this.moveToNext()
//       }, 2000);
//    }
//    takePicture = async (camera) => {
//     const options = {
//       quality: 0.9,
//       maxWidth: 1800,
//       maxHeight: 2400,
//       base64: true,
//       forceUpOrientation: true,
//       pauseAfterCapture: true,
//       writeExif: true,
//     };
//     const data = await camera.takePictureAsync(options)
//      this.setState({setPath:data.uri})
//      this.setState({setShowCamera:false})
//      this.setState({confirmImage:true})

//   };

//   render() {
//     return <DepositCameraScreen
//       cancelModalHandler={this.cancelModalHandler}
//       okayConfirmHandler={this.okayConfirmHandler}
//       openModal={this.openModal}
//       showModal={this.state.showModal}
//       showSuccessModal={this.state.showSuccessModal}
//       setShowCamera={this.state.setShowCamera}
//       setDontShowCamera={this.setDontShowCamera}
//       takePicture={this.takePicture}
//       setPath={this.state.setPath}
//       cancelImage={this.cancelImage}
//       correctImage={this.correctImage}
//       showNextButton={this.state.showNextButton}
//       confirmImage={this.state.confirmImage}/>
//   }
// }

// const mapStateToProps = state => {
//   return {
//    /// loading: state.login.loading,
//   };
// };

// const mapDispatchToProps = dispatch => {
//   return {};
// };

// export default connect(mapStateToProps, mapDispatchToProps)(DepositCamScreen);
import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import ImgToBase64 from 'react-native-image-base64';
import RNImageToPdf from 'react-native-image-to-pdf';
import ScanTRFScreen from './Screen';
import RNFetchBlob from 'rn-fetch-blob';
import { delay } from '../../../utils/Helpers';
import { getUpdateCashDeposit } from '../../../store/Actions';
import { BackHandler } from 'react-native';
class CourierCamera extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal: false,
      showSuccessModal: false,
      showAddImageModal: false,
      setShowCamera: false,
      setPath: '',
      showNextButton: false,
      confirmImage: false,
      showList: false,
      stopClick: false,
      message: this.props.route.params.message,
      barcodeNumber: this.props.route.params.barcodeNumber,
      productId: this.props.route.params.productId,
      crmId: this.props.route.params.crmId,
      orderId: this.props.route.params.orderId,
      imageArray: [],
      imageArrayForFlatList: [],
      loading: false,
    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidMount() {
    this.setState({ setShowCamera: false });
    setTimeout(() => {
      this.setState({ setShowCamera: true });
    }, 1000);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  }

  componentWillUnmount() {
    this.setState({ setShowCamera: false });
    this.back.remove();
  }
  openModal = () => {
    this.setState({ showModal: true });
  };

  cancelImage = () => {
    this.setState({ setPath: '' });
    this.setState({ confirmImage: false });
    if (this.state.imageArray.length >= 1) {
      this.setState({
        setShowCamera: false,
        showNextButton: true,
        showList: true,
      });
    } else {
      this.setState({ setShowCamera: true });
    }
  };
  correctImage = () => {
    this.setState({ confirmImage: false });
    //push
    this.pushImage();

    //this.setState({ showNextButton: true })
  };
  cancelModalHandler = () => {
    this.setState({ showModal: false });
  };
  setDontShowCamera = () => {
    this.setState({ setShowCamera: false });
  };
  moveToNext = () => {
    this.props.navigation.navigate(Paramedic.deposit);
    //this.myAsyncPDFFunction();
  };
  okayConfirmHandler = () => {
    this.setState({ showModal: false });
    this.myAsyncPDFFunction();
  };
  okayAddImageHandler = () => {
    this.setState({ showAddImageModal: false });
    this.setState({ showNextButton: false, showList: false });
    this.setState({ setShowCamera: true });

    // this.myAsyncPDFFunction()
  };
  cancelAddImageHandler = () => {
    this.setState({ showAddImageModal: false });

    this.setState({ showNextButton: true, showList: true, setPath: '' });
    // this.myAsyncPDFFunction()
  };
  pushImage = () => {
    // console.log(this.state.setPath)
    var imageUri = this.state.setPath;
    this.state.imageArrayForFlatList.push({
      imageUri: imageUri,
    });
    var fileNamePath = this.state.setPath.replace('file://', '');
    // console.log('name ' + fileNamePath)
    this.setState({ imageArray: [...this.state.imageArray, fileNamePath] }); //simple value
    //}
    // console.log("Length " + JSON.stringify(this.state.imageArray))
    this.setState({ setPath: '', showNextButton: true, showList: true });
  };
  addMoreImageHandler = () => {
    // alert(this.state.imageArrayForFlatList.length)
    if (this.state.imageArrayForFlatList.length < 5) {
      this.setState({ stopClick: false });
      this.setState({ showAddImageModal: true });
    } else {
      this.setState({ stopClick: true });
    }
  };
  takePicture = async camera => {
    try {
      const options = {
        quality: 0.9,
        maxWidth: 1800,
        maxHeight: 2400,
        base64: true,
        forceUpOrientation: true,
        pauseAfterCapture: true,
        writeExif: true,
      };
      const data = await camera.takePictureAsync(options);
      if (data !== null || data != undefined || data != '') {
        this.setState({ setPath: data.uri });
        this.setState({ setShowCamera: false });
        this.setState({ confirmImage: true });
      } else {
        alert('failed');
      }
    } catch (err) {
      console.log('err' + err);
    }
  };

  myAsyncPDFFunction = async () => {
    const arr = this.state.imageArray;
    try {
      const options = {
        imagePaths: arr,
        name: 'PDFName',
        maxSize: {
          // optional maximum image dimension - larger images will be resized
          width: 1800,
          height: 2400,
        },
        quality: 0.7, // optional compression paramter
      };
      const pdf = await RNImageToPdf.createPDFbyImages(options);
      this.converttoBase64(pdf.filePath);
    } catch (e) {
      console.log('check' + e);
    }
  };
  converttoBase64 = path => {
    RNFetchBlob.fs
      .readFile(path, 'base64')
      .then(data => {
        // alert('converted'+data);
        this.afterConversionBase64(path, data);
        //  console.log('converted' + data)
      })
      .catch(err => {
        console.log('fetchblob' + err);
      });
  };
  afterConversionBase64 = (item, base64String) => {
    //alert(base64String)
    var Base64Img = base64String.replace(/\r?\n|\r/g, '');
    this.uploadImage(item, Base64Img);
  };

  uploadImage = (item, Base64Img) => {
    var filename = '';
    if (item.fileName == undefined || item.fileName == null) {
      //var foo = item.replace( "file:///data/user/0/com.albgtechnicianbase/cache/", "");
      var name = item.replace(
        /[`~0-9!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gi,
        '',
      );
      filename = name;
    } else {
      filename = item.fileName;
    }
    const data = {
      // orderIds: this.props.route.params.orderid,
      // userid: this.props.userId,
      // type: 'COURIER',
      // centerid: null,
      // labid: null,
      // courierid: this.props.route.params.courierServiceid,
      // podnumber: this.props.route.params.pod,
      // courierdate: this.props.route.params.date,
      // courierlabcenter: this.props.route.params.LabORcenter,
      // courierlabid: this.props.route.params.labid,
      // couriercenterid: this.props.route.params.centerid,
      // // image: Base64Img,
      // // imagefilename: 'pdf',
      // courierimg: Base64Img,
      // courierimgfname: 'pdf',
      orderIds: this.props.route.params.orderIds,
      userid: this.props.userId,
      depositdatetime: this.props.route.params.depositdatetime,
      deposittime: this.props.route.params.deposittime,
      depositimage: Base64Img,
      depositimagename: 'pdf',
      bankid: this.props.route.params.bankid,
      branchid: this.props.route.params.branchid,
    };
    this.props.update(data, this.props.accessToken);
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.updatecashDepositError == false &&
      this.props.updatecashDepositError != prevProps.updatecashDepositError
    ) {
      alert('Update failed');
    }
    if (
      prevProps.updatecashDepositStatus == false &&
      this.props.updatecashDepositStatus != prevProps.updatecashDepositStatus
    ) {
      this.setState({ showSuccessModal: true });
      setTimeout(() => {
        this.setState({ showSuccessModal: false });
        this.moveToNext();
      }, 2000);
    }
    if (
      prevProps.updatecashDepositLoading == true &&
      this.props.updatecashDepositLoading != prevProps.updatecashDepositLoading
    ) {
      this.setState({
        loading: true,
      });
    }
  };
  deleteImage = deleteItem => {
    var arr = this.state.imageArray;
    arr.splice(deleteItem, 1);
    this.setState({ imageArray: arr, imageArrayForFlatList: arr });

    var imgarr = this.state.imageArrayForFlatList;
    imgarr.splice(deleteItem, 1);
    this.setState({ imageArrayForFlatList: imgarr });
    if (this.state.imageArrayForFlatList.length == 0) {
      this.setState({ showList: false, showNextButton: false });
      this.setState({ setShowCamera: true });
    } else {
      this.setState({ showList: true });
    }
    this.setState({ stopClick: false });
  };

  render() {
    return (
      <ScanTRFScreen
        cancelModalHandler={this.cancelModalHandler}
        okayConfirmHandler={this.okayConfirmHandler}
        openModal={this.openModal}
        showModal={this.state.showModal}
        showSuccessModal={this.state.showSuccessModal}
        setShowCamera={this.state.setShowCamera}
        setDontShowCamera={this.setDontShowCamera}
        takePicture={this.takePicture}
        setPath={this.state.setPath}
        showList={this.state.showList}
        cancelImage={this.cancelImage}
        correctImage={this.correctImage}
        showNextButton={this.state.showNextButton}
        confirmImage={this.state.confirmImage}
        message={this.state.message}
        showAddImageModal={this.state.showAddImageModal}
        okayAddImageHandler={this.okayAddImageHandler}
        cancelAddImageHandler={this.cancelAddImageHandler}
        addMoreImageHandler={this.addMoreImageHandler}
        data={this.state.imageArrayForFlatList}
        deleteImage={this.deleteImage}
        stopClick={this.state.stopClick}
        loading={this.state.loading}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    userId: state.signIn.userId,
    updatecashDepositStatus: state.depositCash.updatecashDepositStatus,
    updatecashDepositError: state.depositCash.updatecashDepositError,
    updatecashDepositLoading: state.depositCash.updatecashDepositLoading,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    update: (data, token) => dispatch(getUpdateCashDeposit(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(CourierCamera);
