import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import MyTaskScreen from './Screen';
import {Paramedic} from '../../../navigations/RouteTypes';
import Colors from '../../../config/Colors';
import Images from '../../../constants/Icons';
import {
  viewMytasklist,
} from "../../../store/Actions";
import { delay } from '../../../utils/Helpers';
const data=[{
  id:'1',
  type:'1',
  imageSrc:Images.babyCord,
  title:'Baby Cord',
  titleColor:Colors.babyCordTextColor,
  totalCount:'07',
  taskText:'Tasks',
  pendingCount:'03',
  pendingText:'Pending',
  completedCount:'02',
  completedText:'Completed',
  canOrReschCount:'02',
  canOrReschText:'Can/Resch',
  },
  {
  id:'2',
  type:'2',
  imageSrc:Images.pns,
  title:'PNS',
  titleColor:Colors.pnsTextColor,
  totalCount:'06',
  taskText:'Tasks',
  pendingCount:'02',
  pendingText:'Pending',
  completedCount:'02',
  completedText:'Completed',
  canOrReschCount:'02',
  canOrReschText:'Can/Resch',
  },
  {
    id:'3',
    type:'2',
    imageSrc:Images.nbs,
    title:'NBS',
    titleColor:Colors.nbsTextColor,
    totalCount:'09',
    taskText:'Tasks',
    pendingCount:'02',
    pendingText:'Pending',
    completedCount:'05',
    completedText:'Completed',
    canOrReschCount:'02',
    canOrReschText:'Can/Resch',
    },
    {
      id:'4',
      type:'2',
      imageSrc:Images.alliedOrRoutine,
      title:'Allied / Routine',
      titleColor:Colors.allorroutineTextColor,
      totalCount:'06',
      taskText:'Tasks',
      pendingCount:'03',
      pendingText:'Pending',
      completedCount:'01',
      completedText:'Completed',
      canOrReschCount:'02',
      canOrReschText:'Can/Resch',
      },
      {
        id:'5',
        type:'5',
        imageSrc:Images.cancelledOrReturnKit,
        title:'Cancelled / Return Kit',
        titleColor:Colors.cancelledorretunkitTextColor,
        totalCount:'07',
        taskText:'Tasks',
        pendingCount:'03',
        pendingText:'Pending',
        completedCount:'02',
        completedText:'Completed',
        canOrReschCount:'02',
        canOrReschText:'Can/Resch',
        },
        {
          id:'6',
          type:'2',
          imageSrc:Images.covid,
          title:'Covid',
          titleColor:Colors.covidTextColor,
          totalCount:'03',
          taskText:'Tasks',
          pendingCount:'03',
          pendingText:'Pending',
          completedCount:'0',
          completedText:'Completed',
          canOrReschCount:'0',
          canOrReschText:'Can/Resch',
          },
          {
            id:'7',
            type:'3',
            imageSrc:Images.tieupHospital,
            title:'Tie-up hospital',
            titleColor:Colors.tieuphospitalColor,
            totalCount:'17',
            taskText:'Tasks',
            pendingCount:'10',
            pendingText:'Pending',
            completedCount:'07',
            completedText:'Completed',
            },
            {
              id:'8',
              type:'4',
              imageSrc:Images.reports,
              title:'Report dispatch',
              titleColor:Colors.reportTextColor,
              totalCount:'01',
              taskText:'Tasks',
              pendingCount:'01',
              pendingText:'Pending',
              completedCount:'0',
              completedText:'Completed',
              },
  ]
  

class MyTask extends React.Component 
{
  static propTypes = {
    // ...prop type definitions here
  };
  constructor(props) 
  {
    super(props);
    this.state = 
    {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      data: ""
    };
  }

  cardClickHandler = (title,imageSrc,taskText,totalCount,titleColor,productId) => {
    this.props.navigation.navigate(Paramedic.babyCord,{title:title,
      imageSrc:imageSrc,taskText:taskText,totalCount:totalCount,titleColor:titleColor,productId:productId});
  };
  pnsClickHandler = (title,imageSrc,taskText,totalCount,titleColor,productId) => {
      this.props.navigation.navigate(Paramedic.pns,{title:title,
      imageSrc:imageSrc,taskText:taskText,totalCount:totalCount,titleColor:titleColor,productId:productId});
  };
  reportDispatchClickHandler = () => {
    this.props.navigation.navigate(Paramedic.reportDispatch);
  };
  tieUpHospitalClickHandler = (title,imageSrc,taskText,totalCount,titleColor,productId) => {
    this.props.navigation.navigate(Paramedic.tieUpHospital,{title:title,
      imageSrc:imageSrc,taskText:taskText,totalCount:totalCount,titleColor:titleColor,productId:productId});
  };
  cancelledOrReturnKitClickHandler = (title,imageSrc,taskText,totalCount,titleColor,productId) => {
    this.props.navigation.navigate(Paramedic.cancelledOrReturnKit,{title:title,
      imageSrc:imageSrc,taskText:taskText,totalCount:totalCount,titleColor:titleColor,productId:productId});
  };

  componentDidMount = () => {
    const data = {
      userid: this.props.UserID
    };
    this.props.viewMytasklist(data, this.props.accessToken);
  };
  
  render() {
    return (
      <MyTaskScreen
        cardClickHandler={this.cardClickHandler}
        pnsClickHandler={this.pnsClickHandler}
        reportDispatchClickHandler={this.reportDispatchClickHandler}
        tieUpHospitalClickHandler={this.tieUpHospitalClickHandler}
        cancelledOrReturnKitClickHandler={this.cancelledOrReturnKitClickHandler}
        data = {this.props.response}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        loading={this.props.MytasklistLoading}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    MytasklistLoading:
      state.mytask.MytasklistLoading,
      MytasklistStatus:
      state.mytask.MytasklistStatus,
      MytasklistError:
      state.mytask.MytasklistError,
     response: state.mytask.response
  };

};


const mapDispatchToProps = dispatch => {
  return {
    viewMytasklist: (data, token) =>
      dispatch(viewMytasklist(data, token)),
    
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(MyTask);
