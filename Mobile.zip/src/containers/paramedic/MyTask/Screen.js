import React, {useRef} from 'react';
import {
  Image,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  FlatList,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import Images from '../../../constants/Icons';
import I18n from '../../../locale/i18n';
import Icon from 'react-native-vector-icons/FontAwesome';
import {NetworkContext} from '../../../contexts/NetworkContext';
import {Toast} from '../../../components/Toast';
import { heightPercentageToDP as hp,widthPercentageToDP as wp} from 'react-native-responsive-screen';

function MyTaskScreen({
 data,
  cardClickHandler,
  pnsClickHandler,
  reportDispatchClickHandler,
  tieUpHospitalClickHandler,
  cancelledOrReturnKitClickHandler,
  showToast,errorMsg,loading
//  response,
}) {
  const {isConnected} = React.useContext(NetworkContext);
  const CardView = ({
    imageSrc,
    title,
    titleColor,
    totalCount,
    taskText,
    pendingCount,
    pendingText,
    completedCount,
    completedText,
    canOrReschCount,
    canOrReschText,
    onClickListener,
    
  }) => {
    return (
      <TouchableOpacity
        style={styles.cardContainer}
        onPress={() => onClickListener()}>
        <View style={styles.rowOne}>
          <Image
            style={styles.imageStyle}
            resizeMode={'contain'}
            source={{uri:imageSrc}}/>
        </View>
        <View style={styles.rowTwo}>
          <Text style={[styles.textHeader,{color: titleColor}]}>{title}</Text>
          <View style={styles.taskCountContainer}>
            <Text style={styles.textNumberofTask}>{totalCount}</Text>
            <View style={styles.taskTextContainer}>
            <Text style={styles.textTask}>{taskText}</Text>
            </View>
          </View>
          <View style={styles.iconContainer}>
            <Icon name="chevron-right" color={Colors.black} />
          </View>
          <View style={styles.innerBottomContainer}>
            <View style={styles.ibcRowOne}>
              <Text style={styles.textCountPending}>{pendingCount}</Text>
              <Text style={styles.textPending}>{pendingText}</Text>
            </View>
            <View style={styles.ibcRowTwo}>
              <Text style={styles.textCountCompleted}>{completedCount}</Text>
              <Text style={styles.textCompleted}>{completedText}</Text>
            </View>
            <View style={styles.ibcRowThree}>
              <Text style={styles.textCountCancel}>{canOrReschCount}</Text>
              <Text style={styles.textCancel}>{canOrReschText}</Text>
            </View>
          </View>
        </View>
      </TouchableOpacity>
    );
  };
  const renderItem = ({item}) => (
    <CardView
      imageSrc={item.icon_IMAGE_PATH}
      title={item.lc_PD_PRODUCT_NAME}
      titleColor={item.color}
      totalCount={item.total}
      taskText={I18n.t('paramedic.myTask.tasks_label')}
      pendingCount={item.pending}
      pendingText={item.pending_TEXT}
      completedCount={item.completed}
      completedText={item.completed_TEXT}
      canOrReschCount={item.cancel}
      canOrReschText={item.cancel_TEXT}
      onClickListener={()=>
        item.lc_PD_PRODUCT_ID == '5'
          ? cardClickHandler(
            item.lc_PD_PRODUCT_NAME,
            item.icon_IMAGE_PATH,
            I18n.t('paramedic.myTask.tasks_label'),
            item.total,
            item.color,
            item.lc_PD_PRODUCT_ID)
          : item.lc_PD_PRODUCT_ID == '1'|| item.lc_PD_PRODUCT_ID == '2' || item.lc_PD_PRODUCT_ID == '3'|| item.lc_PD_PRODUCT_ID == '4'|| item.lc_PD_PRODUCT_ID == '9'
          ? pnsClickHandler(
            item.lc_PD_PRODUCT_NAME,
            item.icon_IMAGE_PATH,
            I18n.t('paramedic.myTask.tasks_label'),
            item.total,
            item.color,
            item.lc_PD_PRODUCT_ID
            )
          : item.lc_PD_PRODUCT_ID == '7'
          ? tieUpHospitalClickHandler(
            item.lc_PD_PRODUCT_NAME,
            item.icon_IMAGE_PATH,
            I18n.t('paramedic.myTask.tasks_label'),
            item.total,
            item.color,
            item.lc_PD_PRODUCT_ID
            )
          : item.lc_PD_PRODUCT_ID == '8'
          ? reportDispatchClickHandler( item.lc_PD_PRODUCT_NAME,
            item.icon_IMAGE_PATH,
            I18n.t('paramedic.myTask.tasks_label'),
            item.total,
            item.color,
            item.lc_PD_PRODUCT_ID)
          : item.lc_PD_PRODUCT_ID == '6'
          ? cancelledOrReturnKitClickHandler( item.lc_PD_PRODUCT_NAME,
            item.icon_IMAGE_PATH,
            I18n.t('paramedic.myTask.tasks_label'),
            item.total,
            item.color,
            item.lc_PD_PRODUCT_ID)
          : null
      }


    />
  );
  const renderNodata=()=>{
    return(
      <>
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontFamily:FontMagneta.bold}}>No data found</Text>
    </View>
    </>
    )
  }
  return (
    <RootView pageNo={'16'} loading={loading} connected={isConnected}>
    <Toast
      showToast={showToast}
      msg={errorMsg}
      bgColor={Colors.error}
      txtColor={Colors.background}/>
      <View style={styles.rootView}>
      {data == null || data == '' ? null :
        <FlatList
          showsVerticalScrollIndicator={false}
          style={{flex: 1}}
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.lc_PD_PRODUCT_ID}
          contentContainerStyle={styles.contentContainer}
          ListEmptyComponent={renderNodata}
        />
  }
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
  },

  contentContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  mainContainer: {
    paddingHorizontal: 30,
  },
  cardContainer: {
    flex: 1,
    borderRadius: 25,
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.2,
    shadowRadius: 2.5,
    elevation: 5,
    flexDirection: 'row',
    paddingHorizontal: 10,
    paddingVertical:15,
    marginTop: '5%',
    marginHorizontal: wp('8%'),
  },
  rowOne: {
    flex: 0.25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  rowTwo: {
    flex: 0.75,
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginVertical: 4,
    paddingHorizontal:6,
    marginBottom: 4,
  },
  rowThree: {
    flex: 0.1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize:FontSize.regular
  },
  textNumberofTask: {
    color: Colors.black,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    textAlign: 'center',
  },
  innerBottomContainer: {
    flex: 1,
    flexDirection: 'row',
  },
  ibcRowOne: {
    flex: 0.32,
    flexDirection: 'column',
  },
  ibcRowTwo: {
    flex: 0.34,
    flexDirection: 'column',
    marginHorizontal: 5,
  },
  ibcRowThree: {
    flex: 0.34,
    flexDirection: 'column',
    marginHorizontal: 5,
  },
  textCountPending: {
    color: Colors.button,
    fontSize: FontSize.small,
    fontFamily: FontMagneta.medium,
  },
  textPending: {
    color: Colors.button,
    fontSize: FontSize.small,
    fontFamily: Font.bold,
  },
  textCountCompleted: {
    color: Colors.teal,
    fontSize: FontSize.small,
    fontFamily: FontMagneta.medium,
  },
  textCompleted: {
    color: Colors.teal,
    fontSize: FontSize.small,
    fontFamily: Font.bold,
  },
  textCountCancel: {
    color: Colors.primary,
    fontSize: FontSize.small,
    fontFamily: FontMagneta.medium,
  },
  textCancel: {
    color: Colors.primary,
    fontSize: FontSize.small,
    fontFamily: Font.bold,
  },
  imageStyle: {
    width: '80%',
    height: '80%',
  },
  textTask: {
    color: Colors.black,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    marginHorizontal: 5,
  
  },
  taskCountContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    height: hp('2.3%'),
 
  },
  iconContainer: {
    width: '92%',
    alignItems: 'flex-end',
    marginBottom: 1,
  },
  flatListContainer: {
    alignItems: 'flex-start',
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },
  taskTextContainer:{
    alignItems:'flex-end',
    justifyContent:'flex-end',
  }
});

export default MyTaskScreen;
