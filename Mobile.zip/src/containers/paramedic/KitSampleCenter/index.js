import React from "react";
import { connect } from "react-redux";
import I18n from "i18next";
import PropTypes from "prop-types";
import DepositQRScreen from "./Screen";
import { Paramedic } from "../../../navigations/RouteTypes";
import {
  getHanoverCenter,
  kitSampleInsert
} from '../../../store/Actions';
import { BackHandler } from 'react-native';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      kitModal: false,
      success_Modal: false,
      value: '',
      id: ''
    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidMount = () => {
    const data = { cityid: null }
    this.props.getHandoveCenter(data, this.props.accessToken);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  componentWillUnmount() { this.back.remove(); }
  componentDidUpdate = prevProps => {
    if (
      prevProps.kitsampleInsertStatus == true &&
      this.props.kitsampleInsertStatus != prevProps.kitsampleInsertStatus
    ) {

      try {
        this.setState({
          kitModal: !this.state.kitModal
        })
        this.setState({
          success_Modal: !this.state.success_Modal
        })
        setTimeout(() => {
          this.setState({ success_Modal: false });
          this.props.navigation.navigate(Paramedic.kitSampleHandover);
        }, 2000);
      } catch (error) {
      }
    }
  };

  cancelQR = () => {
    this.props.navigation.navigate(Paramedic.kitSampleHandover)
  }
  kitConfirmModal = (val) => {
    console.log("val.lc_TC_TASK_NAME", val.lc_TC_TASK_NAME)
    this.setState({
      kitModal: !this.state.kitModal,
      value: val.lc_TC_TASK_NAME,
      id: val.lc_cen_m_id
    })
  }
  cancelModal = () => {
    this.setState({
      kitModal: !this.state.kitModal,
    })
  }
  SuccessModal = () => {
    //updating center call
    const data = {

      "orderIds": this.props.route.params.orderiD,
      "userid": this.props.userId,
      "type": "CENTER",
      "centerid": this.state.id,
      "labid": null,
      "courierid": null,
      "podnumber": null,
      "courierdate": null,
      "courierlabcenter": null,
      "courierlabid": null,
      "couriercenterid": null,
      "courierimg": null,
      "courierimgfname": null,

    };
    this.props.updateCenter(data, this.props.accessToken);


    // this.setState({
    //   kitModal: !this.state.kitModal
    // })
    // this.setState({
    //   success_Modal: !this.state.success_Modal
    // })
    // setTimeout(() => {
    //   this.setState({ success_Modal: false });
    //   this.props.navigation.navigate(Paramedic.kitSampleHandover);
    // }, 2000);
  }
  render() {
    console.log("this.props.centerResponse", this.props.centerResponse, this.props.route.params.orderiD)
    return (
      <DepositQRScreen
        cancelQR={this.cancelQR}
        kitConfirmModal={this.kitConfirmModal}
        kitModal={this.state.kitModal}
        SuccessModal={this.SuccessModal}
        success_Modal={this.state.success_Modal}
        center={this.props.centerResponse}
        orderid={this.props.route.params.orderiD}
        cancelModal={this.cancelModal}

      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    centerResponse: state.kitsampleHandoverBiodata.centerResponse,
    userId: state.signIn.userId,
    kitsampleInsertStatus: state.kitInsert.kitsampleInsertStatus
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getHandoveCenter: (data, token) => dispatch(getHanoverCenter(data, token)),
    updateCenter: (data, token) => dispatch(kitSampleInsert(data, token))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
