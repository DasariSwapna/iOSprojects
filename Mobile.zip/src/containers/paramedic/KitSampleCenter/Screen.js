import { placeholder } from "@babel/types";
import React, { useRef } from "react";
import {
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList
} from "react-native";
import PropTypes from "prop-types";
import I18n from "../../../locale/i18n";
import Button from "../../../components/Button";
import RootView from "../../../components/RootView";
import Colors from "../../../config/Colors";
import { Font, FontSize } from "../../../config/Fonts";
import Images from "../../../constants/Images";
import InnerHeader from "../../../components/InnerHeader";
import DropDown from "../../../components/DropDown";
import CheckCircle from "../../../components/CheckCircle";
import { ModalConfirmNumber, ModalSuccess } from "../../../components/OtpModal";
import PageNo from "../../../constants/PageNo";
import { heightPercentageToDP, widthPercentageToDP } from "react-native-responsive-screen";
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: "48%", alignItems: "flex-end" }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: "48%", alignItems: "flex-start" }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function DepositQRScreen({
  kitConfirmModal,
  kitModal,
  SuccessModal,
  success_Modal,
  center,
  cancelModal
}) {
  return (
    <RootView pageNo={PageNo.paramedic_kitSampleCenter}>
      <KeyboardAvoidingView style={styles.container}>
        <FlatList
          style={{ marginTop: "5%", marginBottom: heightPercentageToDP('8%') }}
          data={center}
          renderItem={({ item }) =>
            <TouchableOpacity onPress={() => kitConfirmModal(item)}>
              <Text
                style={{
                  paddingHorizontal: widthPercentageToDP('10%'),
                  paddingVertical: widthPercentageToDP('3.5%'),
                  color: Colors.border,
                  fontFamily: Font.regular,
                  fontSize: FontSize.medium
                }}
              >
                {item.lc_cen_m_center_name}
              </Text>
              <View
                style={{
                  borderBottomWidth: 0.3,
                  borderBottomColor: Colors.border,
                  marginHorizontal: "5%"
                }}
              />
            </TouchableOpacity>}
        />
        <ModalConfirmNumber
          visible={kitModal}
          title={"Kit / Sample handover"}
          message={I18n.t('paramedic.kitSampleHandover.sample_to_center')}
          okayHandler={SuccessModal}
          cancelHandler={cancelModal}
          dismissHandler={cancelModal}
        />

        <ModalSuccess
          visible={success_Modal}
          title={"Success"}
          message={I18n.t('paramedic.kitSampleHandover.sample_delivered_center')}

          pageNumber={"209"}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

DepositQRScreen.prototype = {
  cancelQR: PropTypes.func
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white"
  },
  txt: {
    alignSelf: "center",
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: 18
  },
  containerView: {
    flex: 1,
    justifyContent: "center"
  },
  cancelButton: {
    width: "50%",
    height: 45,
    alignSelf: "center",
    position: "absolute",
    bottom: 15,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    borderColor: "#EE2C6C",
    borderWidth: 1
  },
  cancelText: {
    fontFamily: Font.extraBold,
    color: "#EE2C6C",
    fontSize: 18
  },
  amountText: {
    color: "black"
  }
});

export default DepositQRScreen;
