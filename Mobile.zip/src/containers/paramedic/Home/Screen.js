import React, {useRef} from 'react';
import {
  Dimensions,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import MaComIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import TaskType from '../../../components/TaskType';
import BottomNavParam from '../../../components/BottomNav';
import Icons from '../../../constants/Icons';
import {CircularPrograssBar} from '../../../components/ProgressBar';

const {width, height} = Dimensions.get('screen');
const boardHeight = height * 0.22;
const taskPaddingHeight = boardHeight / 2.5;
const horizontalPadding = width * 0.2;

function BoardItem({title, value}) {
  return (
    <View style={{padding: 4}}>
      <Text
        style={{
          color: Colors.teal,
          fontFamily: FontMagneta.thin,
          fontSize: FontSize.small,
        }}>
        {value}%
      </Text>
      <Text
        style={{
          color: Colors.black,
          fontFamily: Font.regular,
          fontSize: FontSize.small,
        }}>
        {title}
      </Text>
    </View>
  );
}

function Board({}) {
  return (
    <View style={styles.boardContainer}>
      <View style={styles.boardFirstHalfContainer}>
        <CircularPrograssBar
          width={boardHeight / 1.4}
          height={boardHeight / 1.4}
          percent={20}
        />
      </View>
      <View style={styles.boardSecondHalfContainer}>
        <BoardItem title={'Biobank kit delivery'} value={59} />
        <BoardItem title={'Biobank kit pickup'} value={63} />
        <BoardItem title={'Retail / Emergency'} value={59} />
        <BoardItem title={'Lab Delivery'} value={59} />
      </View>
    </View>
  );
}

function HomeScreen({
  homeNavHandler,
  alertNavHandler,
  createTaskNavHandler,
  myTaskNavHandler,
  calendarNavHandler,
  shuttleNavHandler,
  depositNavHandler,
  kitNavHandler,
}) {
  return (
    <RootView pageNo={'5'} isPageWhite>
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View style={styles.boardBackContainer}>
              <Board />
            </View>
            <View style={styles.taskContainer}>
              <TaskType
                imageSource={Icons.myTaskIcon}
                color={Colors.teal}
                label={'My Task'}
                onPress={myTaskNavHandler}
              />
              <TaskType
                imageSource={Icons.referEnrollment}
                color={Colors.border}
                label={'Refer Enrollment'}
              />
              <TaskType
                imageSource={Icons.cash}
                color={Colors.lightGreen}
                label={'Deposit cash'}
                onPress={depositNavHandler}
              />
              <TaskType
                imageSource={Icons.kit}
                color={Colors.button}
                label={'Kit / sample handover'}
                onPress={kitNavHandler}
              />
              <TaskType
                imageSource={Icons.covid}
                color={Colors.darkBlue}
                label={'Covid enrollment'}
              />
              <TaskType
                imageSource={Icons.shuttle}
                color={Colors.button}
                label={'Shuttle pickup'}
                onPress={shuttleNavHandler}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <View style={styles.bottomContainer}>
        <BottomNavParam
          menu1Handler={homeNavHandler}
          menu2Handler={alertNavHandler}
          centerMenuHandler={createTaskNavHandler}
          menu3Handler={myTaskNavHandler}
          menu4Handler={calendarNavHandler}
        />
      </View>
    </RootView>
  );
}

HomeScreen.prototype = {
  homeNavHandler: PropTypes.func,
  alertNavHandler: PropTypes.func,
  createTaskNavHandler: PropTypes.func,
  myTaskNavHandler: PropTypes.func,
  calendarNavHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 30,
  },
  mainContainer: {
    flex: 1,
    width: '100%',
    paddingBottom: 62,
    backgroundColor: Colors.bgLightGray,
  },

  boardBackContainer: {
    width: '100%',
    height: boardHeight / 1.2,
    minHeight: 140,
    borderBottomLeftRadius: 15,
    borderBottomRightRadius: 15,
    backgroundColor: Colors.card,
  },
  boardContainer: {
    width: '80%',
    height: boardHeight,
    minWidth: 320,
    minHeight: 180,
    flexDirection: 'row',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingHorizontal: 16,
    paddingTop: 10,
    paddingBottom: 8,
    borderRadius: 16,
    backgroundColor: Colors.background,
  },
  boardFirstHalfContainer: {
    width: '50%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
  },
  boardSecondHalfContainer: {
    width: '50%',
    height: '100%',
    justifyContent: 'space-between',
    paddingVertical: 10,
  },
  taskContainer: {
    paddingTop: taskPaddingHeight,
    alignItems: 'center',
    justifyContent: 'center',
  },
  bottomContainer: {
    alignItems: 'center',
  },
});

export default HomeScreen;
