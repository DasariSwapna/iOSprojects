import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import HomeScreen from './Screen';
import {Paramedic} from '../../../navigations/RouteTypes';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  homeNavHandler = () => {
    console.log('Home Nav');
  };

  alertNavHandler = () => {
    this.props.navigation.navigate(Paramedic.alert);
  };

  createTaskNavHandler = () => {
    this.props.navigation.navigate(Paramedic.task);
  };

  myTaskNavHandler = () => {
    console.log('my task');
    this.props.navigation.navigate(Paramedic.myTask);
  };

  calendarNavHandler = () => {
    this.props.navigation.navigate(Paramedic.calender);
  };
  shuttleNavHandler = () => {
    this.props.navigation.navigate(Paramedic.taskqr);
  };
  depositNavHandler = () => {
    this.props.navigation.navigate(Paramedic.deposit);
  };
  kitNavHandler = () => {
    this.props.navigation.navigate(Paramedic.kitSampleHandover);
  };
  render() {
    return (
      <HomeScreen
        homeNavHandler={this.homeNavHandler}
        alertNavHandler={this.alertNavHandler}
        createTaskNavHandler={this.createTaskNavHandler}
        myTaskNavHandler={this.myTaskNavHandler}
        calendarNavHandler={this.calendarNavHandler}
        shuttleNavHandler={this.shuttleNavHandler}
        depositNavHandler={this.depositNavHandler}
        kitNavHandler={this.kitNavHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
