import React, { useRef } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList
} from "react-native";
import PropTypes from "prop-types";
import I18n from "../../../locale/i18n";
import Button from "../../../components/Button";
import RootView from "../../../components/RootView";
import Colors from "../../../config/Colors";
import { Font, FontMagneta, FontSize } from "../../../config/Fonts";
import Images from "../../../constants/Images";
import CheckCircle from "../../../components/CheckCircle";
import { ModalConfirmNumber, ModalSuccess } from "../../../components/OtpModal";
import DropDownMenu from "../../../components/DropDownMenu";
import {
  heightPercentageToDP,
  widthPercentageToDP
} from "react-native-responsive-screen";
import Font5 from "react-native-vector-icons/FontAwesome5";
import Feather from "react-native-vector-icons/Feather";
import Entypo from "react-native-vector-icons/Entypo";
import PageNo from "../../../constants/PageNo";
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: "48%", alignItems: "flex-end" }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: "48%", alignItems: "flex-start" }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function RenderItem({ item, radioPress, onShare }) {
  return (
    <View style={styles.pendingCard}>
      <View style={styles.pendingView}>
        <View
          style={{
            flexDirection: "row",
            flex: 1,
            justifyContent: "space-between",
            paddingHorizontal: widthPercentageToDP("4%")
          }}
        >
          <Text style={styles.cardTitle}>
            {item.title}
          </Text>
          <Text style={styles.cardTitle}>
            {"5524"}
          </Text>
          <CheckCircle
            length={heightPercentageToDP("2.3%")}
            tick={heightPercentageToDP("2%")}
            onPress={() => radioPress()}
          />
        </View>
        <View style={[styles.borderLine]} />
        <View
          style={[styles.row, { paddingHorizontal: widthPercentageToDP("4%") }]}
        >
          <View
            style={{
              flexDirection: "row",
              width: widthPercentageToDP("60%"),
              justifyContent: "space-between",
              marginBottom: heightPercentageToDP("2%")
            }}
          >
            <View>
              <Text style={styles.cardText}>CRM ID :</Text>
              <Text style={styles.numberTxt}>
                {item.crmID}
              </Text>
            </View>
            <View>
              <Text style={styles.cardText}>Amount :</Text>
              <Text style={styles.numberTxt}>
                {item.amount}
              </Text>
            </View>
          </View>

          <View
            style={[
              styles.flex,
              {
                alignItems: "flex-end",
                justifyContent: "flex-end",
                marginBottom: heightPercentageToDP("2%"),
                flexDirection: "row"
              }
            ]}
          >
            <Feather
              name={"download"}
              size={heightPercentageToDP("3%")}
              color={Colors.border}
              style={{ paddingRight: widthPercentageToDP("1%") }}
            />
            <Entypo
              name={"share"}
              size={heightPercentageToDP("3%")}
              color={Colors.border}
              onPress={onShare}
            />
          </View>
        </View>
      </View>
    </View>
  );
}
function TaskScreen({
  SearchTask,
  modalVisible,
  showSuccessModal,
  successModal,
  onShare,
  createTask,
  SuccessModal
}) {
  console.log("modal", modalVisible);
  return (
    <RootView pageNo={PageNo.paramedic_taskReport}>
      <KeyboardAvoidingView style={styles.container}>
        <View style={{ marginTop: heightPercentageToDP("4%") }}>
          <DropDownMenu
            labelName={I18n.t("paramedic.task.select_hospital")}
            labelKey={"value"}
            valueKey={"value"}
            listItems={[
              {
                label: "Baby cord",
                value: "Baby cord"
              },
              {
                label: "PNS",
                value: "PNS"
              },
              {
                label: "NBS",
                value: "NBS"
              },
              {
                label: "Coivd",
                value: "Coivd"
              },
              {
                label: "Report Delivery",
                value: "Report Delivery"
              }
            ]}
            // valueChangeHandler={dropdownoption}
          />
          <View
            style={{
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-evenly"
            }}
          >
            <TouchableOpacity
              style={{
                borderRadius: heightPercentageToDP("6%"),
                marginTop: heightPercentageToDP("2%"),
                justifyContent: "space-between",
                backgroundColor: Colors.background,
                shadowColor: Colors.black,
                shadowOffset: { width: 1, height: 1 },
                shadowOpacity: 0.4,
                shadowRadius: 3,
                elevation: 5,
                width: widthPercentageToDP("40%"),
                height: heightPercentageToDP("6%"),
                alignSelf: "center",
                paddingHorizontal: widthPercentageToDP("4%"),
                flexDirection: "row",
                alignItems: "center"
              }}
              onPress={SearchTask}
            >
              <Text
                style={{
                  color: Colors.bgDarkGray,
                  fontFamily: Font.regular,
                  fontSize: FontSize.large
                }}
              >
                {I18n.t("paramedic.task.from_date")}
              </Text>
              <Font5
                name={"calendar-alt"}
                size={heightPercentageToDP("2%")}
                color={Colors.bgDarkGray}
              />
            </TouchableOpacity>
            <TouchableOpacity
              style={{
                borderRadius: heightPercentageToDP("6%"),
                marginTop: heightPercentageToDP("2%"),
                justifyContent: "space-between",
                backgroundColor: Colors.background,
                shadowColor: Colors.black,
                shadowOffset: { width: 1, height: 1 },
                shadowOpacity: 0.4,
                shadowRadius: 3,
                elevation: 5,
                width: widthPercentageToDP("40%"),
                height: heightPercentageToDP("6%"),
                alignSelf: "center",
                paddingHorizontal: widthPercentageToDP("4%"),
                flexDirection: "row",
                alignItems: "center"
              }}
              onPress={SearchTask}
            >
              <Text
                style={{
                  color: Colors.bgDarkGray,
                  fontFamily: Font.regular,
                  fontSize: FontSize.large
                }}
              >
                {I18n.t("paramedic.task.to_date")}
              </Text>
              <Font5
                name={"calendar-alt"}
                size={heightPercentageToDP("2%")}
                color={Colors.bgDarkGray}
              />
            </TouchableOpacity>
          </View>
          <TouchableOpacity
            style={{
              width: widthPercentageToDP("40%"),
              height: heightPercentageToDP("6%"),
              backgroundColor: Colors.darkPink,
              marginVertical: heightPercentageToDP("2%"),
              alignItems: "center",
              justifyContent: "center",
              alignSelf: "center",
              borderRadius: 30
            }}
            onPress={SearchTask}
          >
            <Text
              style={{
                color: Colors.white,
                fontFamily: Font.regular,
                fontSize: FontSize.large
              }}
            >
              {I18n.t("paramedic.task.search")}
            </Text>
          </TouchableOpacity>

          <FlatList
            data={[
              {
                id: "1",
                title: "SRM Hospital",
                crmID: "12345",
                amount: "1555.00",
                crmcount: "1",
                date: "15.11.2021",
                time: "12:55",
                person: "RE / BDO: Ramesh kumar"
              }
            ]}
            renderItem={({ item }) =>
              <RenderItem item={item} onShare={onShare} />}
            keyExtractor={item => item.id}
          />
        </View>
        <View style={{ flexDirection: "row", position: "absolute", bottom: 0 }}>
          <TouchableOpacity
            style={{
              width: widthPercentageToDP("40%"),
              height: heightPercentageToDP("6%"),
              marginVertical: heightPercentageToDP("2%"),
              alignItems: "center",
              justifyContent: "center",
              alignSelf: "center",
              borderRadius: 30,
              marginStart: widthPercentageToDP("7%"),
              marginEnd: widthPercentageToDP("3%"),
              borderWidth: 1,
              borderColor: Colors.darkPink
            }}
          >
            <Text
              style={{
                color: Colors.darkPink,
                fontFamily: Font.regular,
                fontSize: FontSize.large
              }}
            >
              {I18n.t("paramedic.task.download")}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={{
              width: widthPercentageToDP("40%"),
              height: heightPercentageToDP("6%"),
              backgroundColor: Colors.darkPink,
              marginVertical: heightPercentageToDP("2%"),
              alignItems: "center",
              justifyContent: "center",
              alignSelf: "center",
              borderRadius: 30,
              marginEnd: widthPercentageToDP("7%"),
              marginStart: widthPercentageToDP("3%")
            }}
            onPress={createTask}
          >
            <Text
              style={{
                color: Colors.white,
                fontFamily: Font.regular,
                fontSize: FontSize.large
              }}
            >
              {I18n.t("paramedic.task.create_tsk")}
            </Text>
          </TouchableOpacity>
        </View>
        <ModalConfirmNumber
          visible={modalVisible}
          title={I18n.t("paramedic.task.create_tsk")}
          message={I18n.t("paramedic.task.want_create_task")}
          okayHandler={successModal}
        />
        <ModalSuccess
          visible={showSuccessModal}
          title={"Success"}
          message={I18n.t("paramedic.task.task_success")}
          pageNumber={"209"}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

TaskScreen.prototype = {
  cancelQR: PropTypes.func
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white
  },

  rowNum: {
    fontFamily: FontMagneta.medium,
    color: Colors.black
  },
  txt: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    marginHorizontal: widthPercentageToDP("10%")
  },
  containerView: {
    flex: 1,
    justifyContent: "center"
  },
  cancelButton: {
    width: "50%",
    height: 45,
    alignSelf: "center",
    position: "absolute",
    bottom: 15,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    borderColor: Colors.darkPink,
    borderWidth: 1
  },
  cancelText: {
    fontFamily: Font.extraBold,
    color: Colors.darkPink,
    fontSize: 18
  },
  amountText: {
    color: "black"
  },

  dropView: {
    marginVertical: 20
  },
  optionContainer: {
    backgroundColor: Colors.white,
    height: "50%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 25
  },
  rowTxt: {
    color: Colors.border,
    fontFamily: Font.regular
  },
  pendingCard: {
    borderRadius: 10,
    marginVertical: heightPercentageToDP("2%"),
    justifyContent: "center",
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: widthPercentageToDP("85%"),
    alignSelf: "center"
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.border,
    paddingVertical: 5
  },
  numberTxt: {
    fontFamily: FontMagneta.bold,
    color: Colors.black,
    fontSize: FontSize.large,
    paddingBottom: 2
  },
  row: {
    flexDirection: "row"
  },
  cardTitle: {
    fontSize: FontSize.large,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: heightPercentageToDP("2%")
  },
  cashText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.darkBlue
  },
  borderLine: {
    borderBottomColor: Colors.border,
    borderBottomWidth: 0.2
  },
  flex: {
    flex: 1,
    marginBottom: heightPercentageToDP("2%")
  }
});

export default TaskScreen;
