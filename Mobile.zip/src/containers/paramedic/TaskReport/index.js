import React from "react";
import { connect } from "react-redux";
import I18n from "i18next";
import PropTypes from "prop-types";
import TaskReportScreen from "./Screen";
import { Paramedic } from "../../../navigations/RouteTypes";
import { Modal } from "../../../components/Modal";
import { Share } from "react-native";
class TaskReport extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      showSuccessModal: false
    };
  }

  componentDidMount = () => {};
  onShare = async () => {
    try {
      const result = await Share.share({
        message:
          "Share"
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };
  componentDidUpdate = () => {};

  SearchTask = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    });
  };
  successModal = () => {
    this.setState({
      showSuccessModal: !this.state.showSuccessModal
    });
    this.setState({
      modalVisible: false
    });
    setTimeout(() => {
      this.setState({ showSuccessModal: false });
      this.props.navigation.navigate(Paramedic.home);
    }, 2000);
  };
  createTask = () => {
    this.setState({
      modalVisible: !this.state.modalVisible
    });
  }
  render() {
    return (
      <TaskReportScreen
        SearchTask={this.SearchTask}
        modalVisible={this.state.modalVisible}
        showSuccessModal={this.state.showSuccessModal}
        successModal={this.successModal}
        onShare={this.onShare}
        createTask={this.createTask}
      />
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(TaskReport);
