// import { placeholder } from "@babel/types";
// import React, { useRef } from "react";
// import {
//   Image,
//   Text,
//   View,
//   StyleSheet,
//   KeyboardAvoidingView,
//   TouchableOpacity
// } from "react-native";
// import PropTypes from "prop-types";
// import I18n from "../../../locale/i18n";
// import RootView from "../../../components/RootView";
// import Colors from "../../../config/Colors";
// import { Font, FontSize } from "../../../config/Fonts";
// import Images from "../../../constants/Images";
// import FontAwesome from "react-native-vector-icons/FontAwesome";
// import { heightPercentageToDP, widthPercentageToDP } from "react-native-responsive-screen";
// import PageNo from "../../../constants/PageNo";
// function Footer() {
//   return (
//     <View style={styles.footerContainer}>
//       <View>
//         <Text style={styles.poweredby}>Powered by</Text>
//       </View>
//       <View style={styles.footerLogoContainer}>
//         <View style={{ width: "48%", alignItems: "flex-end" }}>
//           <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
//         </View>
//         <View style={styles.seperator} />
//         <View style={{ width: "48%", alignItems: "flex-start" }}>
//           <Image source={Images.voilaLogo} style={styles.voilaLogo} />
//         </View>
//       </View>
//     </View>
//   );
// }

// Footer.prototype = {};

// function DepositQRScreen({ cancelQR }) {
//   return (
//     <RootView pageNo={PageNo.paramedic_depositQr}>
//       <KeyboardAvoidingView style={styles.container}>
//         <View style={styles.containerView}>
//           <Text style={styles.txt}>{I18n.t('paramedic.deposit.show_qrcode')}</Text>
//           <View style={{ alignItems: "center" }}>
//             <Image
//               source={require("../../../assets/images/qr.png")}
//               style={{ width: 300, height: 300 }}
//             />
//             <View style={styles.amount}>
//             <FontAwesome name={"rupee"} size={heightPercentageToDP('2%')} color={Colors.black}/>
//             <Text style={styles.amountText}> 1500.00</Text>
//             </View>
//             {/* <Text style={styles.amountText}>$ 1500.00</Text> */}
//           </View>
//         </View>
//         <TouchableOpacity style={styles.cancelButton} onPress={cancelQR}>
//           <Text style={styles.cancelText}>{I18n.t('paramedic.deposit.cancel')}</Text>
//         </TouchableOpacity>
//       </KeyboardAvoidingView>
//     </RootView>
//   );
// }

// DepositQRScreen.prototype = {
//   cancelQR: PropTypes.func
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: "white"
//   },
//   txt: {
//     alignSelf: "center",
//     color: Colors.border,
//     fontFamily: Font.regular,
//     fontSize: 18
//   },
//   containerView: {
//     flex: 1,
//     justifyContent: "center"
//   },
//   cancelButton: {
//     width: widthPercentageToDP('35%'),
//     height: heightPercentageToDP('5.5%'),
//     alignSelf: "center",
//     position: "absolute",
//     bottom: 15,
//     borderRadius: 40,
//     alignItems: "center",
//     justifyContent: "center",
//     borderColor: Colors.button,
//     borderWidth: 1
//   },
//   cancelText: {
//     fontFamily: Font.extraBold,
//     color: Colors.button,
//     fontSize: FontSize.large
//   },
//   amountText: {
//     color: "black"
//   },
//   amount: {
//     flexDirection:'row',
//     alignItems:"center",
//     justifyContent:'center'
//   }
// });

// export default DepositQRScreen;

import React, { useRef } from 'react';
import {
  Image,
  Text,
  View,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import PageNo from '../../../constants/PageNo';
import QRCode from 'react-native-qrcode-svg';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import FontAwesome from "react-native-vector-icons/FontAwesome";
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function DepositQRScreen({ cancelQR, qrvalue, modalVisible, successModal, amount }) {
  return (
    <RootView pageNo={PageNo.paramedic_kitSampleQR}>
      <KeyboardAvoidingView style={styles.container}>
        <View style={styles.containerView}>
          <Text style={styles.txt}>
            {I18n.t('paramedic.deposit.show_qrcode')}
          </Text>

          <TouchableOpacity style={{ alignItems: 'center' }} onPress={successModal}>
            <QRCode value={qrvalue} size={hp('35%')} />
          </TouchableOpacity>
          <View>
            <View style={styles.amount}>
              <FontAwesome name={"rupee"} size={hp('2%')} color={Colors.black} />
              <Text style={styles.amountText}> {amount}</Text>
            </View>
          </View>
        </View>

        <TouchableOpacity style={styles.cancelButton} onPress={cancelQR}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
      <ModalSuccess
        visible={modalVisible}
        title={I18n.t('paramedic.myTask.success_label')}
        message={"Cash delivered to RE / BDO"}
        pageNumber={'30'}
      />
    </RootView>
  );
}

DepositQRScreen.prototype = {
  cancelQR: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  txt: {
    alignSelf: 'center',
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.large,
    padding: hp('2%'),
  },
  containerView: {
    flex: 1,
    justifyContent: 'center',
  },
  cancelButton: {
    width: wp('40%'),
    height: hp('5.5%'),
    alignSelf: 'center',
    position: 'absolute',
    bottom: 15,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: '#EE2C6C',
    borderWidth: 1,
  },
  cancelText: {
    fontFamily: Font.regular,
    color: '#EE2C6C',
    fontSize: FontSize.large,
  },
  amountText: {
    color: 'black',
  },
  amount: {
    flexDirection: 'row',
    alignItems: "center",
    justifyContent: 'center',
    paddingVertical: hp('2%')
  }
});

export default DepositQRScreen;
