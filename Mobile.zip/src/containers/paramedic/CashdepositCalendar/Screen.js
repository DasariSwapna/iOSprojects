// import React, {useRef} from 'react';
// import {
//   Image,
//   Text,
//   TextInput,
//   View,
//   StyleSheet,
//   ScrollView,
//   KeyboardAvoidingView,
//   TouchableOpacity,
//   FlatList,
// } from 'react-native';
// import PropTypes from 'prop-types';
// import I18n from '../../../locale/i18n';
// import Button from '../../../components/Button';
// import RootView from '../../../components/RootView';
// import Colors from '../../../config/Colors';
// import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
// import Images from '../../../constants/Images';
// import InnerHeader from '../../../components/InnerHeader';
// import DropDown from '../../../components/DropDown';
// import CheckCircle from '../../../components/CheckCircle';
// import {color} from 'react-native-reanimated';
// import {Calendar} from 'react-native-calendars';
// import AntDesign from 'react-native-vector-icons/AntDesign';
// import {ModalSuccess} from '../../../components/OtpModal';
// import {
//   widthPercentageToDP as wp,
//   heightPercentageToDP as hp,
// } from 'react-native-responsive-screen';
// import DropDownMenu from '../../../components/DropDownMenu';

// function Footer() {
//   return (
//     <View style={styles.footerContainer}>
//       <View>
//         <Text style={styles.poweredby}>Powered by</Text>
//       </View>
//       <View style={styles.footerLogoContainer}>
//         <View style={{width: '48%', alignItems: 'flex-end'}}>
//           <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
//         </View>
//         <View style={styles.seperator} />
//         <View style={{width: '48%', alignItems: 'flex-start'}}>
//           <Image source={Images.voilaLogo} style={styles.voilaLogo} />
//         </View>
//       </View>
//     </View>
//   );
// }


// function CalendarSection({ onClickListener, markedDates }) {
//   return (
//     <Calendar
//       onDayPress={day => onClickListener(day)}
//       style={{
//         height: 350,
//         backgroundColor: "transparent"
//       }}
//       minDate={new Date()}
//       markingType={"custom"}
//       markedDates={markedDates}
//       theme={{
//         backgroundColor: Colors.white,
//         calendarBackground: Colors.white,
//         textSectionTitleColor: Colors.border,
//         textSectionTitleDisabledColor: "#d9e1e8",
//         selectedDayBackgroundColor: "red",
//         selectedDayTextColor: Colors.white,
//         todayTextColor: Colors.border,
//         dayTextColor: "#2d4150",
//         textDisabledColor: "#d9e1e8",
//         dotColor: "#00adf5",
//         selectedDotColor: Colors.white,
//         arrowColor: Colors.border,
//         disabledArrowColor: "#d9e1e8",
//         monthTextColor: Colors.border,
//         indicatorColor: Colors.border,
//         textDayFontFamily: FontMagneta.medium,
//         textMonthFontFamily: Font.extraBold,
//         textDayHeaderFontFamily: Font.extraBold,
//         textDayFontWeight: "300",
//         textMonthFontWeight: "bold",
//         textDayHeaderFontWeight: "300",
//         textDayFontSize: 16,
//         textMonthFontSize: 16,
//         textDayHeaderFontSize: 16,
//         "stylesheet.calendar.header": {
//           monthText: {
//             fontSize: FontSize.large,
//             fontFamily: Font.extraBold,
//             fontWeight: "500", // default is 300
//             color: Colors.border,
//             margin: 10 // default
//           }
//         }
//       }}
//     />
//   );
// }
// Footer.prototype = {};

// function CashDepositCalendarScreen({
//   dropdownoption,
//   hours,
//   mins,
//   captureReceipt,
//   showSuccessModal,
//   getSelectedDayEvents
// }) {
//   return (
//     <RootView pageNo={'14'}>
//       <KeyboardAvoidingView style={styles.mainContainer}>
//         <ScrollView
//           style={styles.flex}
//           contentContainerStyle={styles.contentContainer}
//           showsVerticalScrollIndicator={false}>
//           <Text
//             style={{
//               fontFamily: Font.extraBold,
//               color: Colors.border,
//               margin: 20,
//             }}>
//             {I18n.t('paramedic.deposit.deposit_date')}
//           </Text>
//            <CalendarSection
//             onClickListener={day => getSelectedDayEvents(day)}
//             markedDates={markedDates}
//           />
//           <View
//             style={{
//               borderBottomWidth: 1,
//               borderBottomColor: '#dfdfdf',
//               width: '88%',
//               alignSelf: 'center',
//             }}
//           />
//           <Text
//             style={{
//               fontFamily: Font.extraBold,
//               color: Colors.border,
//               margin: 20,
//             }}>
//             {I18n.t('paramedic.deposit.deposit_time')}
//           </Text>
//           <View
//             style={{
//               alignItems: 'center',
//               justifyContent: 'center',
//               marginHorizontal: wp('35%'),
//             }}>
//             <View
//               style={{flexDirection: 'row', justifyContent: 'space-between'}}>
//               <View style={{width: wp('10%'), alignItems: 'center'}}>
//                 <TouchableOpacity>
//                   <AntDesign
//                     name={'up'}
//                     color={Colors.border}
//                     size={hp('1.5%')}
//                   />
//                 </TouchableOpacity>
//               </View>
//               <View style={{width: wp('10%')}}></View>
//               <View style={{width: wp('10%'), alignItems: 'center'}}>
//                 <TouchableOpacity>
//                   <AntDesign
//                     name={'up'}
//                     color={Colors.border}
//                     size={hp('1.5%')}
//                   />
//                 </TouchableOpacity>
//               </View>
//             </View>
//             <View
//               style={{
//                 flexDirection: 'row',
//                 justifyContent: 'space-between',
//                 backgroundColor: Colors.background,
//                 shadowColor: Colors.bgDarkGray,
//                 shadowOffset: {width: 1, height: 1},
//                 shadowOpacity: 0.4,
//                 shadowRadius: 2,
//                 elevation: 1,
//                 paddingVertical: hp('1%'),
//                 borderRadius: 10,
//                 marginVertical: hp('0.5'),
//               }}>
//               <View style={{width: wp('10%')}}>
//                 <Text
//                   style={{
//                     fontFamily: FontMagneta.bold,
//                     color: Colors.border,
//                     fontSize: FontSize.medium,
//                     textAlign: 'center',
//                   }}>
//                   {hours}
//                 </Text>
//               </View>
//               <View style={{width: wp('10%')}}>
//                 <Text
//                   style={{
//                     fontFamily: FontMagneta.bold,
//                     color: Colors.border,
//                     fontSize: FontSize.medium,
//                     textAlign: 'center',
//                   }}>
//                   :
//                 </Text>
//               </View>
//               <View style={{width: wp('10%')}}>
//                 <Text
//                   style={{
//                     fontFamily: FontMagneta.bold,
//                     color: Colors.border,
//                     fontSize: FontSize.medium,
//                     textAlign: 'center',
//                   }}>
//                   {mins}
//                 </Text>
//               </View>
//             </View>
//             <View
//               style={{flexDirection: 'row', justifyContent: 'space-between'}}>
//               <View style={{width: wp('10%'), alignItems: 'center'}}>
//                 <TouchableOpacity>
//                   <AntDesign
//                     name={'down'}
//                     color={Colors.border}
//                     size={hp('1.5%')}
//                   />
//                 </TouchableOpacity>
//               </View>
//               <View style={{width: wp('10%')}}></View>
//               <View style={{width: wp('10%'), alignItems: 'center'}}>
//                 <TouchableOpacity>
//                   <AntDesign
//                     name={'down'}
//                     color={Colors.border}
//                     size={hp('1.5%')}
//                   />
//                 </TouchableOpacity>
//               </View>
//             </View>
//           </View>

//           <DropDownMenu
//             labelName= {I18n.t('paramedic.deposit.select_bank')}
//             labelKey={'value'}
//             valueKey={'value'}
//             listItems={[
//               {
//                 label: 'PhotoDelivery To RE',
//                 value: 'Delivery To RE',
//               },
//               {
//                 label: 'Deposit To Bank',
//                 value: 'Deposit To Bank',
//               },
//             ]}
//             valueChangeHandler={dropdownoption}
//           />
//           <DropDownMenu
//             labelName= {I18n.t('paramedic.deposit.select_branch')}
//             labelKey={'value'}
//             valueKey={'value'}
//             listItems={[
//               {
//                 label: 'PhotoDelivery To RE',
//                 value: 'Delivery To RE',
//               },
//               {
//                 label: 'Deposit To Bank',
//                 value: 'Deposit To Bank',
//               },
//             ]}
//             valueChangeHandler={dropdownoption}
//           />

//           <TouchableOpacity style={styles.buttonStyle} onPress={captureReceipt}>
//             <Text style={styles.buttonText}>{I18n.t('paramedic.deposit.capture_receipt')}</Text>
//           </TouchableOpacity>
//         </ScrollView>
//         <ModalSuccess
//           visible={showSuccessModal}
//           title={'Success'}
//           message={I18n.t('paramedic.deposit.cash_deposit_captured')}
//           pageNumber={'209'}
//         />
//       </KeyboardAvoidingView>
//     </RootView>
//   );
// }

// CashDepositCalendarScreen.prototype = {
//   isPending: PropTypes.string,
//   pendingState: PropTypes.func,
//   completedState: PropTypes.func,
//   generateQR: PropTypes.func,
//   dropdownoption: PropTypes.func,
//   dropdownValue: PropTypes.string,
// };

// const styles = StyleSheet.create({
//   contentContainer: {
//     flexGrow: 1,
//     paddingBottom: 20,
//   },
//   mainContainer: {
//     flex: 1,
//     backgroundColor: Colors.background,
//   },
//   flex: {
//     flex: 1,
//   },
//   buttonText: {
//     fontFamily: Font.regular,
//     color: Colors.background,
//     fontSize: FontSize.large,
//   },
//   buttonStyle: {
//     backgroundColor: Colors.button,
//     width: '40%',
//     height: '6%',
//     alignSelf: 'center',
//     borderRadius: 40,
//     alignItems: 'center',
//     justifyContent: 'center',
//     marginBottom: 40,
//     marginTop: 10,
//   },


//   optionContainer: {
//     backgroundColor: Colors.white,
//     height: '30%',
//     width: '100%',
//     alignItems: 'center',
//     justifyContent: 'center',
//     paddingBottom: 25,
//   },
// });

// export default CashDepositCalendarScreen;

import { placeholder } from "@babel/types";
import React, { useRef } from "react";
import {
  Image,
  Text,
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  TouchableOpacity,
} from "react-native";
import PropTypes from "prop-types";
import I18n from "../../../locale/i18n";
import RootView from "../../../components/RootView";
import Colors from "../../../config/Colors";
import { Font, FontMagneta, FontSize } from "../../../config/Fonts";
import Images from "../../../constants/Images";
import { Calendar } from "react-native-calendars";
import AntDesign from "react-native-vector-icons/AntDesign";
import { ModalSuccess } from "../../../components/OtpModal";
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp
} from "react-native-responsive-screen";
import DropDownMenu from "../../../components/DropDownMenu";
import Entypo from "react-native-vector-icons/Entypo";
import PageNo from "../../../constants/PageNo";
import AppButton from "../../../components/Button";
import ModalSelector from '../../../components/DepositeModelSelector';
import { Toast } from '../../../components/Toast';


function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: "48%", alignItems: "flex-end" }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: "48%", alignItems: "flex-start" }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function CalendarSection({ onClickListener, markedDates }) {
  return (

    <Calendar
      markingType={'custom'}
      hideDayNames={false}
      minDate={new Date()}
      markedDates={markedDates}
      onDayPress={day => onClickListener(day)}

      style={{
        height: hp('30%'),
        backgroundColor: 'transparent',
        width: wp('100%'),
        marginBottom: hp('2%'),
      }}
      theme={{
        backgroundColor: Colors.white,
        calendarBackground: Colors.white,
        textSectionTitleColor: Colors.border,
        textSectionTitleDisabledColor: '#d9e1e8',
        selectedDayBackgroundColor: Colors.border,
        selectedDayTextColor: Colors.background,
        todayTextColor: Colors.border,
        dayTextColor: '#2d4150',
        textDisabledColor: '#d9e1e8',
        dotColor: Colors.border,
        selectedDotColor: Colors.border,
        arrowColor: Colors.border,
        disabledArrowColor: '#d9e1e8',
        monthTextColor: Colors.border,
        indicatorColor: Colors.border,
        textDayFontFamily: FontMagneta.medium,
        textMonthFontFamily: Font.extraBold,
        textDayHeaderFontFamily: Font.bold,
        textDayFontWeight: '300',
        textMonthFontWeight: 'bold',
        textDayHeaderFontWeight: '400',
        textDayFontSize: 14,
        textMonthFontSize: 14,
        textDayHeaderFontSize: 14,

        'stylesheet.calendar.header': {
          monthText: {
            fontSize: FontSize.large,
            fontFamily: Font.extraBold,
            fontWeight: '500', // default is 300
            color: Colors.border,
            margin: 10, // default
          },
        },
      }}
    />
  );
}
function CashDepositCalendarScreen({
  dropdownoption,
  hours,
  mins,
  captureReceipt,
  showSuccessModal,
  getSelectedDayEvents,
  markedDates,
  bankData,
  branchResponse,
  time,
  Timevalue,
  dropdownBankoption,
  dropdownBranchoption,
  showToast,
  errormsg
}) {
  return (
    <RootView pageNo={PageNo.paramedic_depositBankCalendar}>
      <KeyboardAvoidingView style={styles.mainContainer}>
        <Toast
          showToast={showToast}
          msg={errormsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <ScrollView
          style={styles.flex}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          <Text
            style={{
              fontFamily: Font.extraBold,
              color: Colors.border,
              margin: 20
            }}
          >
            {I18n.t("paramedic.deposit.deposit_date")}
          </Text>
          <View style={{ flex: 1, height: hp('50%') }}>
            <CalendarSection
              onClickListener={day => getSelectedDayEvents(day)}
              markedDates={markedDates}
            />
          </View>
          <View
            style={{
              borderBottomWidth: 1,
              borderBottomColor: "#dfdfdf",
              width: "88%",
              alignSelf: "center"
            }}
          />
          <Text
            style={{
              fontFamily: Font.extraBold,
              color: Colors.border,
              margin: 20
            }}
          >
            {I18n.t("paramedic.deposit.deposit_time")}
          </Text>
          <View style={{ alignItems: "center", justifyContent: "center" }}>
            {
              time != "" && time != undefined ?
                <ModalSelector
                  id="deposittime"
                  data={time.object.BankDepositTimeResponse}
                  initValue={'Select time'}
                  onChange={option => {
                    Timevalue(option.MSG_TIME);
                  }}
                /> : null}

          </View>
          {bankData != '' && bankData != undefined ?
            <DropDownMenu
              labelName={I18n.t("paramedic.deposit.select_bank")}
              labelKey={"LC_B_BANK_NAME"}
              valueKey={"LC_B_BANK_ID"}
              listItems={bankData.object.BankList}
              valueChangeHandler={dropdownBankoption}
            /> : null}
          {branchResponse != "" && branchResponse != undefined ?
            <DropDownMenu
              labelName={I18n.t("paramedic.deposit.select_branch")}
              labelKey={"LC_B_BANK_BRANCH_NAME"}
              valueKey={"LC_B_BANK_BRANCH_ID"}
              listItems={branchResponse.object.BankBranchList}
              valueChangeHandler={dropdownBranchoption}
            /> : null}

          {/* <TouchableOpacity style={styles.buttonStyle} onPress={captureReceipt}>
            <Text style={styles.buttonText}>
              {I18n.t("paramedic.deposit.capture_receipt")}
            </Text>
          </TouchableOpacity> */}

        </ScrollView>
        <AppButton
          title={I18n.t("paramedic.deposit.capture_receipt")}
          buttonStyle={styles.reachedButton}
          onPress={captureReceipt}
        />
        <ModalSuccess
          visible={showSuccessModal}
          title={"Success"}
          message={I18n.t("paramedic.deposit.cash_deposit_captured")}
          pageNumber={"209"}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

CashDepositCalendarScreen.prototype = {
  isPending: PropTypes.string,
  pendingState: PropTypes.func,
  completedState: PropTypes.func,
  generateQR: PropTypes.func,
  dropdownoption: PropTypes.func,
  dropdownValue: PropTypes.string
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20
  },
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background
  },
  flex: {
    flex: 1,
    marginBottom: hp("2%")
  },
  buttonText: {
    fontFamily: Font.regular,
    color: Colors.background,
    fontSize: FontSize.large
  },
  buttonStyle: {
    backgroundColor: Colors.button,
    width: "40%",
    height: "6%",
    alignSelf: "center",
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 40,
    marginTop: 10
  },
  pending_CompletedText: {
    paddingHorizontal: 20,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium
  },
  cardTitle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: 5
  },
  highliteLine: {
    borderBottomWidth: 2,
    width: 50,
    marginTop: 20,
    borderColor: Colors.border
  },
  cashText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.darkBlue
  },
  taskText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  depositCircle: {
    width: 70,
    height: 70,
    backgroundColor: Colors.darkBlue,
    borderRadius: 80,
    marginHorizontal: 20
  },
  depositContainer: {
    flexDirection: "row",
    alignItems: "center",
    width: "80%",
    alignSelf: "center",
    paddingTop: 20,
    justifyContent: "space-between",
    paddingBottom: 20
  },
  inputContainer: {
    paddingHorizontal: 10,
    paddingVertical: 4
  },
  textLabelStyle: {
    width: "92%",
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontWeight: "600",
    alignSelf: "center",
    paddingHorizontal: 10,
    paddingVertical: 2
  },
  textValidationMsg: {
    width: "92%",
    color: Colors.button,
    fontFamily: Font.extraBold,
    fontWeight: "600",
    alignSelf: "center",
    paddingHorizontal: 10,
    paddingVertical: 4
  },
  textInputStyle: {
    height: 46,
    width: "92%",
    alignSelf: "center",
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    elevation: 4,
    fontFamily: Font.regular,
    shadowColor: Colors.bgDarkGray,
    shadowOpacity: 0.6,
    shadowRadius: 1,
    shadowOffset: {
      width: 1,
      height: 1
    },
    borderColor: Colors.card,
    backgroundColor: Colors.background
  },

  firstText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    paddingHorizontal: 4
  },
  secondText: {
    color: Colors.teal,
    fontFamily: Font.extraBold
  },
  dropDownView: {
    alignItems: "center",
    marginVertical: 30,
    width: "80%",
    alignSelf: "center"
  },
  pendingCard: {
    borderRadius: 10,
    marginHorizontal: 20,
    // marginTop: 20,
    minHeight: "30%",
    justifyContent: "center",
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: "85%",
    alignSelf: "center",
    marginVertical: 6,
    marginTop: 6
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingVertical: 5
  },
  optionContainer: {
    backgroundColor: Colors.white,
    height: "30%",
    width: "100%",
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 25
  },
  reachedButton: {
    width: wp("40%"),
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: Colors.button,
    elevation: 2,
    alignSelf: "center",
    bottom: hp("2%")
  }
});

export default CashDepositCalendarScreen;

