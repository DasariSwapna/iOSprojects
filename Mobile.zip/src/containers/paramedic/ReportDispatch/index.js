import React from 'react';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
import ReportDispatchScreen from './Screen';
const data = [
  {
    id: 1,
    customerName: 'Rehman Hospital'
  },
  {
    id: 2,
    customerName: 'Bala clinical laboratory'
  },
];
class ReportDispatch extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  cardClickHandler = () => {
    this.props.navigation.navigate(Paramedic.reportDispatchDetails);
  };
  render() {
    return <ReportDispatchScreen data={data} cardClickHandler={this.cardClickHandler} />;
  }
}

const mapStateToProps = state => {
  return {
    /// loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ReportDispatch);
