import React, { useRef } from 'react';
import {
  Image,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import SearchButtonView from '../../../components/SearchButtonView'
import { FlatList } from 'react-native-gesture-handler';
import AppButton from '../../../components/Button';
import IonIcons from 'react-native-vector-icons/Ionicons';
import MedicalCenterNameView from '../../../components/MedicalCenterNameView';
function ReportDispatchScreen({ data, cardClickHandler }) {
  const renderItem = ({ item }) => (
    <MedicalCenterNameView customerName={item.customerName} cardClickHandler={cardClickHandler} />
  )
  return (
    <RootView pageNo={'296'}>
      <View style={styles.rootView}>
        <View style={styles.flatlistContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.flatlistInnerContainer}
          />
        </View>
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'flex-start'
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.tieuphospitalColor
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTab: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  numberOfTaskContainer:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'flex-start',
  },
  buttonText: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.background
  },
  bottomTabLine:
  {
    width: '35%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2
  },
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomColor: Colors.card,
    borderBottomWidth: 2,
    marginHorizontal: 10,
    flexDirection: 'row',
    paddingHorizontal: 10, marginTop: '6%'
  },

  headerContainer:
  {
    flexDirection: 'column',
    marginVertical: 20,
    marginHorizontal: 10
  },

  rowDirection: {
    width: '100%' ,
    flexDirection: 'row',
    alignItems: 'center',
     justifyContent: 'flex-start', 
     
  },

  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10,
    marginRight: '25%'
  },

  tabRowTwoContainer:
  {
    flex: 1,
    alignItems: 'center'
  },

  flatlistContainer:
    { 
        width: '100%', 
        alignItems: 'center', 
        height: '70%' ,
        marginVertical:'5%'
    },
flatlistInnerContainer:
    { 
    flexGrow: 1,
    paddingBottom: 40

  },
    
  flatList:
    {
       flex: 1, 
       width: '100%',
       paddingHorizontal: 10 
      },
      
      iconContainer:{
        marginLeft:10
      }
})

export default ReportDispatchScreen;
