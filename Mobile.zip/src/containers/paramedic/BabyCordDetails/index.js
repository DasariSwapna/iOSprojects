import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import BabyCordDetailScreen from './Screen';
import moment from 'moment';
import { Linking } from 'react-native';
import {
  mytaskBabyCordDetailsCrmid, mytaskParamedicReached, getCancelReason,
  mytaskUpdateCancelReason, userAvailability,
  updateParamedicRescduled, getOtpPayementMode,
  updateLocation
} from "../../../store/Actions";
import {
  locationPermission,
  getCurrentLocation,
} from '../../../services/Permissions';
import { delay } from '../../../utils/Helpers';
const data = [{ id: 1, name: 'Srikanth', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Annanagar, Chennai - 600040' }
]
var googleurl = "0";
class BabyCordDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isReached: false,
      isStarted: 0,
      showSuccessModal: false,
      showModalCancel: false,
      showModalReschedule: false,
      showModalRescheduleSuccess: false,
      showModalCancelSuccess: false,
      productId: this.props.route.params.productId,
      crmId: this.props.route.params.crmId,
      title: this.props.route.params.title,
      orderId: this.props.route.params.orderId,
      name: '',
      date: '',
      time: '',
      mobileNumber: '',
      address: '',
      payment: '',
      paymentStatus: '',
      data: [],
      cancelReason: '',
      showToast: false,
      errorMsg: '',
      otp: '',
      dateTime: '',
      timeReschedule: '',
      reschduleDate: '',
      selectTimeVisibility: false,
      latitude: "",
      longitude: "",
      clientLatitude: "",
      clientLongitude: ""
    };
  }

  handleGetDirections = () => {
    var lablati = this.state.clientLatitude;
    var lablong = this.state.clientLongitude;
    if (lablati == null || lablati == ""  && lablong == null || lablong == "") {
      this.setState(
        {
          errorMsg: 'Client location not available',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    } else {
      Platform.OS == "ios" ?
        Linking.openURL('maps://app/maps?saddr=' + this.state.latitude + "," + this.state.longitude + '&daddr=' + lablati + "," + lablong)
        :
        googleurl = "https://www.google.com/maps/dir/?api=1&travelmode=driving&dir_action=navigate&destination=" + lablati + "," + lablong;

        Linking.canOpenURL(googleurl).then(supported => {
          if (!supported) {
            this.setState(
              {
                errorMsg: 'Map not supported',
                showToast: true,
              },
              async () => {
                await delay(3000);
                this.resetValidation();
              },
            );
          } else {
            return Linking.openURL(googleurl);
          }
        }).catch(err => console.error('An error occurred', err));
    }

  }


  userTrackHandler = async () => {
    let location = null;
    const permit = await locationPermission();
    if (permit == 'granted') {
      location = await getCurrentLocation();
      console.log('location =========>', location);
      // alert(JSON.stringify(location))
      //this.props.onUpdateLocation(location);
      this.setState({
        latitude: location.latitude,
        longitude: location.longitude
      })
    }
  };
  callHandler = phonenumber => {
    Linking.openURL(`tel:${phonenumber}`);
  };
  onDatePress = (day) => {
    //alert(moment(day.timestamp).format("hh:mm"))
    //alert(day.dateString)
    this.setState({
      // dateTime: `${moment(day.timestamp).format("YYYY-MM-DD")}T${(moment(day.timestamp).format("hh:mm:ss"))}`,
      dateTime: day.dateString,
      selectTimeVisibility: true
    })

    const data = {
      userid: this.props.UserID,
      pickupdate: day.dateString,
    };
    this.props.onUserAvailability(data, this.props.accessToken);
  };

  reachedClickHandler = () => {
    const data = {
      userid: this.props.UserID,
      crmid: this.state.crmId,
      orderid: this.state.orderId,
      lattitude: this.state.latitude,
      longitude: this.state.longitude,
    };
    // alert(JSON.stringify(data))
    this.props.mytaskParamedicReached(data, this.props.accessToken);
  };

  nextClickHandler = () => {
    this.props.navigation.navigate(Paramedic.kitScan, {
      title: this.state.title,
      crmId: this.state.crmId,
      orderId: this.state.orderId,
      productId: this.state.productId,
    });
  };

  cancelHandler = () => {
    this.setState({
      showModalCancel: true,
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  dismissHandler = () => {
    this.setState({
      showModalCancel: false,
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  SubmitHandler = (cancelReason, cancelReasonRemarks) => {
    if (cancelReason == '') {
      //  alert('Please select date');
      this.setState(
        {
          errorMsg: 'Please select cancel reason',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
      return;
    } else if (cancelReasonRemarks == '') {
      //  alert('Please select time');
      this.setState(
        {
          errorMsg: 'Please enter remarks',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    } else {
      // alert('check')
      const data = {
        user_id: this.props.UserID,
        crmid: this.state.crmId,
        orderid: this.state.orderId,
        cancelreason: cancelReason,
        remarks: cancelReasonRemarks,
      };
      this.props.OnMytaskUpdateCancelReason(data, this.props.accessToken);
    }

  };

  rescheduleHandler = () => {
    this.setState({
      showModalReschedule: true,
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
    this.generateOtpHandler();
  };

  generateOtpHandler = () => {
    const data = {
      patient_id: this.state.mobileNumber,
      sms_validtimelimit: '3',
      lang_id: 1,
      paymenttype: 'Reschedule',
    };
    this.props.onGetOtpPayementMode(data, this.props.accessToken);
  };

  otpHandler = val => {
    this.setState({
      otp: val,
    });
  };

  TimeHandler = val => {
    //alert(JSON.stringify(val))
    this.setState({
      timeReschedule: val.msg_TIME,
    });
  };

  rescheduleDismissHandler = () => {
    this.setState({
      showModalReschedule: false,
      selectTimeVisibility: false
    });
    //this.props.navigation.navigate(Sales.ManagerApprovalAddTest);
  };

  cancelReasonHandler = val => {
    this.setState({
      cancelReason: val,
    });
  };

  rescheduleSubmitHandler = () => {
    // this.setState({ showModalReschedule: false })
    // this.setState({ showModalRescheduleSuccess: true })
    // setTimeout(() => {
    //   this.setState({ showModalRescheduleSuccess: false })
    //   this.props.navigation.navigate(Paramedic.babyCord)
    // }, 2000);
    if (this.state.dateTime == '') {
      //  alert('Please select date');
      this.setState(
        {
          errorMsg: 'Please select date',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
      return;
    } else if (this.state.timeReschedule == '') {
      //  alert('Please select time');
      this.setState(
        {
          errorMsg: 'Please select time',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    } else if (this.state.otp == '') {
      // alert('Please enter otp');
      this.setState(
        {
          errorMsg: 'Please enter otp received to patient',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    } else {
      const data1 = {
        "patientid": this.state.mobileNumber,
        "crmid": this.state.crmId,
        "orderid": this.state.orderId,
        "otp": this.state.otp,
        "reschduledate": `${this.state.dateTime}T${this.state.timeReschedule}`,
        "reschduletime": this.state.timeReschedule,
        "user_id": this.props.UserID
      }
      this.props.OnUpdateParamedicRescduled(data1, this.props.accessToken);
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  initialCall = () => {
    this.userTrackHandler();
    const data = {
      userid: this.props.UserID,
      productid: this.state.productId,
      crmid: this.state.crmId,
      orderid: this.state.orderId
    };
    this.props.mytaskBabyCordDetailsCrmid(data, this.props.accessToken);
  };

  componentDidMount() {
    this.props.OnGetCancelReason(null, this.props.accessToken);

    this.initialCall();
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.MytaskdetailsCrmidStatus == false &&
      this.props.MytaskdetailsCrmidStatus != prevProps.MytaskdetailsCrmidStatus
    ) {
      // alert(JSON.stringify(this.props.BabyCordPending))
      if (
        this.props.MytaskdetailsCrmidResponse != null ||
        this.props.MytaskdetailsCrmidResponse != undefined
      ) {
        const data =
          this.props.MytaskdetailsCrmidResponse
            .UserTaskProductCRMIDDetailResModel;
        this.setState({
          data: this.props.MytaskdetailsCrmidResponse
            .UserTaskProductCRMIDDetailResModel,
        });
        var time = moment(data[0].LC_OR_SCHEDULEDATETIME).format(
          'DD/MM/YYYY h:mm:ss',
        );
        this.setState({
          name: data[0].PATIENT_NAME,
          date: time.substring(0, 10),
          time: data[0].LC_OR_APPOINTMENT_TIME.substring(0, 5),
          mobileNumber: data[0].Mobile,
          address: data[0].Address,
          payment: data[0].Payment,
          paymentStatus: data[0].Paymentstatus,
          isReached: data[0].iSReached,
          isStarted: data[0].iSStarted,
          clientLatitude: data[0].LATTITUDE,
          clientLongitude: data[0].LANGITUDE,

        });
      }
    }
    if (
      prevProps.ParamedicReachedStatus == false &&
      this.props.ParamedicReachedStatus != prevProps.ParamedicReachedStatus
    ) {
      this.setState({ showSuccessModal: true });

      setTimeout(() => {
        this.setState({ isReached: true });
        this.setState({ showSuccessModal: false });
      }, 2000);
    }

    if (
      prevProps.UpdateCancelOrderStatus == false &&
      this.props.UpdateCancelOrderStatus != prevProps.UpdateCancelOrderStatus
    ) {
      this.setState({ showModalCancel: false, showModalCancelSuccess: true });
      setTimeout(() => {
        this.setState({ showModalCancelSuccess: false })
        this.props.navigation.goBack()
      }, 2000);
    }

    if (
      prevProps.ParamedicReachedError == false &&
      this.props.ParamedicReachedError != prevProps.ParamedicReachedError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.MytaskdetailsCrmidError == false &&
      this.props.MytaskdetailsCrmidError != prevProps.MytaskdetailsCrmidError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.UpdateCancelOrderError == false &&
      this.props.UpdateCancelOrderError != prevProps.UpdateCancelOrderError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.payementModeOtpStatus == false &&
      this.props.payementModeOtpStatus != prevProps.payementModeOtpStatus
    ) {
      this.setState(
        {
          errorMsg: 'Otp generated successfully',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    if (
      prevProps.updateParamedicRescduledError == false &&
      this.props.updateParamedicRescduledError !=
      prevProps.updateParamedicRescduledError
    ) {
      alert('Rescheduled failed');
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.updateParamedicRescduledStatus == false &&
      this.props.updateParamedicRescduledStatus !=
      prevProps.updateParamedicRescduledStatus
    ) {
      this.setState({ showModalReschedule: false });
      this.setState({ showModalRescheduleSuccess: true });
      setTimeout(() => {
        this.setState({ showModalRescheduleSuccess: false });
        this.props.navigation.goBack();
      }, 2000);
      this.setState(
        {
          errorMsg: this.props.updateParamedicRescduledResponse.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  render() {
    return (
      <BabyCordDetailScreen
        data={data}
        reachedClickHandler={this.reachedClickHandler}
        nextClickHandler={this.nextClickHandler}
        cancelClickHandler={this.cancelClickHandler}
        rescheduleClickHandler={this.rescheduleClickHandler}
        isReached={this.state.isReached}
        showSuccessModal={this.state.showSuccessModal}
        cancelHandler={this.cancelHandler}
        dismissHandler={this.dismissHandler}
        SubmitHandler={this.SubmitHandler}
        rescheduleHandler={this.rescheduleHandler}
        rescheduleDismissHandler={this.rescheduleDismissHandler}
        rescheduleSubmitHandler={this.rescheduleSubmitHandler}
        // states
        showModalCancel={this.state.showModalCancel}
        showModalReschedule={this.state.showModalReschedule}
        showModalRescheduleSuccess={this.state.showModalRescheduleSuccess}
        name={this.state.name}
        date={this.state.date}
        time={this.state.time}
        mobileNumber={this.state.mobileNumber}
        address={this.state.address}
        payment={this.state.payment}
        paymentStatus={this.state.paymentStatus}
        crmid={this.state.crmId}
        cancelReasonHandler={this.cancelReasonHandler}
        cancelData={this.props.GetCancelReason}
        taskTimeresponse={this.props.taskTimeresponse}
        loading={
          this.props.MytaskdetailsCrmidLoading ||
          this.props.ParamedicReachedLoading ||
          this.props.UpdateCancelOrderLoading ||
          this.props.updateParamedicRescduledLoading
        }
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        onDatePress={this.onDatePress}
        otpHandler={this.otpHandler}
        TimeHandler={this.TimeHandler}
        generateOtpHandler={this.generateOtpHandler}
        otp={this.state.otp}
        callHandler={this.callHandler}
        isStarted={this.state.isStarted}
        showModalCancelSuccess={this.state.showModalCancelSuccess}
        selectTimeVisibility={this.state.selectTimeVisibility}
        mapHandler={this.handleGetDirections}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    MytaskdetailsCrmidLoading:
      state.mytask.MytaskPickupBabyCordDetailsCrmidLoading,
    MytaskdetailsCrmidStatus:
      state.mytask.MytaskPickupBabyCordDetailsCrmidStatus,
    MytaskdetailsCrmidError: state.mytask.MytaskPickupBabyCordDetailsCrmidError,
    MytaskdetailsCrmidResponse:
      state.mytask.MytaskPickupBabyCordDetailsCrmidResponse,

    ParamedicReachedLoading: state.mytask.MytaskParamedicReachedLoading,
    ParamedicReachedStatus: state.mytask.MytaskParamedicReachedStatus,
    ParamedicReachedError: state.mytask.MytaskParamedicReachedError,
    UserID: state.signIn.userId,

    UpdateCancelOrderLoading: state.mytask.MytaskUpdateCancelReasonLoading,
    UpdateCancelOrderStatus: state.mytask.MytaskUpdateCancelReasonStatus,
    UpdateCancelOrderError: state.mytask.MytaskUpdateCancelReasonError,

    updateParamedicRescduledLoading:
      state.mytask.updateParamedicRescduledLoading,
    updateParamedicRescduledStatus: state.mytask.updateParamedicRescduledStatus,
    updateParamedicRescduledError: state.mytask.updateParamedicRescduledError,
    updateParamedicRescduledResponse:
      state.mytask.updateParamedicRescduledResponse,

    GetCancelReason: state.common.cancelReasonResponse,

    //taskTimeresponse: state.createtask.taskTimeresponse,
    taskTimeresponse: state.createOrder.userAvailabilityResponse,

    payementModeOtpStatus: state.payementMode.payementModeOtpStatus,
    location: state.dayStart.location,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    mytaskBabyCordDetailsCrmid: (data, token) =>
      dispatch(mytaskBabyCordDetailsCrmid(data, token)),

    mytaskParamedicReached: (data, token) =>
      dispatch(mytaskParamedicReached(data, token)),

    OnGetCancelReason: (data, token) => dispatch(getCancelReason(data, token)),

    // OnTimeapi: (data, token) =>
    //   dispatch(getTaskTime(data, token)),
    // OnTimeapi: (data, token) => dispatch(getTaskTime(data, token)),

    OnMytaskUpdateCancelReason: (data, token) =>
      dispatch(mytaskUpdateCancelReason(data, token)),

    onUserAvailability: (data, token) =>
      dispatch(userAvailability(data, token)),
    OnUpdateParamedicRescduled: (data, token) =>
      dispatch(updateParamedicRescduled(data, token)),
    onGetOtpPayementMode: (data, token) =>
      dispatch(getOtpPayementMode(data, token)),
    onUpdateLocation: (data, token) => dispatch(updateLocation(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(BabyCordDetails);
