import React, { useRef } from 'react';
import { Text, View, TouchableOpacity, StyleSheet, FlatList, Image, Platform, ScrollView } from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import BarCodeButton from '../../../components/BarCodeButton';
import AppButton from '../../../components/Button';
import DetailsCardView from '../../../components/DetailsCardView';
import { ModalSuccess, ModalCancel, ModalReschedule } from '../../../components/OtpModal';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import Images from '../../../constants/Icons';
import I18n from '../../../locale/i18n';
import ModalCalendarForReschedule from '../../../components/ModalCalendarForReschedule';
import { NetworkContext } from '../../../contexts/NetworkContext';
import { Toast } from '../../../components/Toast';
function BabyCordDetailsScreen({

  data,
  nextClickHandler,
  reachedClickHandler,
  isReached,
  showSuccessModal,
  dismissHandler,
  SubmitHandler,
  cancelHandler,
  // states
  rejected,
  showModalCancel,
  rescheduleHandler,
  rescheduleDismissHandler,
  rescheduleSubmitHandler,
  showModalReschedule,
  showModalRescheduleSuccess,
  name,
  date,
  time,
  mobileNumber,
  address,
  payment,
  paymentStatus,
  crmid,
  cancelReasonHandler,
  taskTimeresponse,
  cancelData,
  errorMsg,
  showToast,
  loading,
  onDatePress,
  otpHandler,
  otp,
  TimeHandler,
  generateOtpHandler,
  callHandler ,
  isStarted,
  showModalCancelSuccess,
  selectTimeVisibility,
  mapHandler}) {

  const { isConnected } = React.useContext(NetworkContext);

  return (
    <RootView pageNo={'40'} loading={loading} connected={isConnected}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <View style={styles.rootView}>
        <View style={{ flex: 0.9, alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={{ alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
              {showModalCancel === true && (
                <ModalCancel
                  pageNumber={117}
                  visible={showModalCancel}
                  dismissHandler={dismissHandler}
                  SubmitHandler={SubmitHandler}
                  labelKey={'lc_C_REASON'}
                  valueKey={'lc_C_ID'}
                  listItems={cancelData}
                  stateHandler={cancelReasonHandler}

                />
              )}
              {showModalReschedule === true && (
                <ModalCalendarForReschedule
                  pageNumber={117}
                  visible={showModalReschedule}
                  dismissHandler={rescheduleDismissHandler}
                  SubmitHandler={rescheduleSubmitHandler}
                  time={taskTimeresponse}
                  onDatePress={(val) => onDatePress(val)}
                  otpChangeHandler={otpHandler}
                  TimeHandler={TimeHandler}
                  otpResentHandler={generateOtpHandler}
                  otp={otp}
                  selectTimeVisibility={selectTimeVisibility}
                  errorMsg={errorMsg}
                  showToast={showToast}
                />
              )}
              <View style={styles.flatListContainer}>
                {/* <DetailsCardView
            name={data[0].name}
            crmid={data[0].crmid}
            date={data[0].date}
            time={data[0].time}
            address={data[0].address}
            isReached={isReached}
           // onPress={isReached?null:reachedClickHandler}
            paidAmount={'2500'}
          /> */}
                {data != [] || data != undefined || data != null ?
                  <DetailsCardView
                    name={name}
                    crmid={crmid}
                    date={date}
                    time={time}
                    address={address}
                    mobile={mobileNumber}
                    isReached={isReached == 1 ? true : false}
                    onPress={isReached == 0 ? reachedClickHandler : null}
                    isStarted={isStarted}
                    paidAmount={payment}
                    paymentStatus={paymentStatus == 1 ? "Paid" : "Pending"}
                    paymentStatusColor={paymentStatus == 1 ? Colors.babyCordTextColor : Colors.error}
                    nextClickHandler={nextClickHandler}
                    callPress={()=>callHandler(mobileNumber)}
                    mapPress={()=>mapHandler()}
                    
                  // isPns={true}
                  /> : <renderNodata />}
              </View>

              <View style={styles.nextButtonContainer}>
                {isReached == 1 ? (
                  <>
                    <Text style={[styles.textStyle, { marginTop: hp('5%') }]}>
                      {I18n.t('paramedic.myTask.please_click_the_barcode_label')}
                    </Text>
                    <View style={styles.imageStyle}>
                      <TouchableOpacity onPress={nextClickHandler}>
                        <Image
                          resizeMode={'contain'}
                          source={Images.barcode}
                        />
                      </TouchableOpacity>
                    </View>
                  </>
                ) : null}
              </View>
            </View>
          </ScrollView>
        </View>
        <View style={{ flex: 0.1, flexDirection: 'row' }}>
         
            <View style={styles.bottomButtonContainer}>
              <View style={styles.bottonButtonRowContainer}>
                <AppButton
                  title={I18n.t('paramedic.myTask.reschedule_label')}
                  buttonStyle={styles.startButton}
                  buttonTextStyle={styles.buttonTextReschedule}
                  onPress={rescheduleHandler} />
              </View>
              <View style={styles.bottonButtonRowContainer}>
                <AppButton title={I18n.t('paramedic.myTask.cancel_label')} buttonStyle={styles.viewButton} buttonTextStyle={styles.buttonTextStyle} onPress={cancelHandler} />
              </View>
            </View> 
        </View>
        <ModalSuccess
          visible={showSuccessModal}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.reached_time_success_label')}
          pageNumber={'23'}
        />
        <ModalSuccess
          visible={showModalRescheduleSuccess}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.biobank_kit_collection_is_rescheduled_label')}
          pageNumber={'31'}
        />
          <ModalSuccess
          visible={showModalCancelSuccess}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.biobank_kit_collection_is_cancelled_label')}
          pageNumber={'31'}
        />
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10,
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    color: Colors.babyCordTextColor,
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  textTab: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.regular,
  },
  startButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.background,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 20,
    marginHorizontal: 3,
    borderWidth: Platform.OS == 'ios' ? hp('0.07%') : hp('0.1%'),
    borderColor: Colors.button,
  },
  viewButton: {
    height: hp('5%'),
    width: '90%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3,
  },
  reachedButton: {
    height: 38,
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3,
  },
  buttonText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    alignSelf: 'center',
    color: Colors.background,
  },
  buttonTextReschedule: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.button,
  },
  bottomTabLine: {
    width: '75%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2,
  },
  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: '4%',
  },
  flatListContainer: {
    alignItems: 'flex-start',
    paddingHorizontal: 10,
    height: '60%',
    marginBottom:hp('5%')
  },
  bottomButtonContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
    marginHorizontal: 15,
    marginTop: '5%',
  },
  bottonButtonRowContainer: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  nextButtonContainer: {
    width: '80%',
    height: hp('20%'),
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    flexDirection: 'column',
    marginVertical: hp('5%'),
  },
  buttonTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  },
  textStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    textAlign: 'center',
  },
  imageStyle: {
    marginVertical: hp('5%')
  }
});

export default BabyCordDetailsScreen;
