import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import DepositQRScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import { getPostalService, getLabCenterName } from '../../../store/Actions';
import { BackHandler } from 'react-native';
import moment from 'moment';
import { delay } from '../../../utils/Helpers';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      kitModal: false,
      success_Modal: false,
      labORcenter: '',
      postaltype: '',
      labcenterName: '',
      postalid: '',
      podNumber: '',
      labId: null,
      centerId: null,
      date: moment(new Date()).format('YYYY-MM-DD'),
      open: false,
      // selectedDate: new Date(),
      toast: false,
      errorMsg: '',
      postalValue: false,
      PODvalue: false,
      labORcenterValue: false,
      labcenterNameValue: false
    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidMount = () => {
    // Postal service api
    const data = { lang_id: 1 };

    this.props.getPostal(data, this.props.accessToken);

    // //Lab-center name api
    const lab_centerNameData = {
      stateid: 1,
      search: null,
    };
    this.props.getLanCenterName(lab_centerNameData, this.props.accessToken);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };

  componentDidUpdate = () => { };
  componentWillUnmount() { this.back.remove(); }
  cancelQR = () => {
    this.props.navigation.navigate(Paramedic.kitSampleHandover);
  };
  kitConfirmModal = () => {
    this.setState({
      kitModal: !this.state.kitModal,
    });
  };
  SuccessModal = () => {

    console.log("------------------------->", this.state.postalid, this.state.podNumber, this.state.labORcenter, this.state.selectedDate, this.state.labId, this.state.centerId)

    // if (this.state.postalid == "") {
    //   this.setState({
    //     postalValue: true
    //   })
    // }
    // else if (this.state.podNumber == "") {
    //   this.setState({
    //     PODvalue: true
    //   })
    // }
    // else if (this.state.labORcenter == "") {
    //   this.setState({
    //     labORcenterValue: true
    //   })
    // }
    // else if (this.state.postalid != ""
    //   && this.state.podNumber != ""
    //   && this.state.labORcenter != ""
    //   && this.state.selectedDate != 'Date' && (this.state.labId == null && this.state.centerId == null)) {
    //   this.setState({
    //     labcenterNameValue: true
    //   })
    // }
    // else if (this.state.postalid != ""
    //   && this.state.podNumber != ""
    //   && this.state.labORcenter != ""
    //   && (this.state.labId != null || this.state.centerId != null)) {
    //   this.props.navigation.navigate(Paramedic.kitCourierCamera, {
    //     orderid: this.props.route.params.orderiD,
    //     courierServiceid: this.state.postalid,
    //     pod: this.state.podNumber,
    //     LabORcenter: this.state.labORcenter,
    //     labid: this.state.labId,
    //     centerid: this.state.centerId,
    //     date: this.state.date,
    //   });
    // }
    this.state.postalid == "" ? this.setState({
      postalValue: true
    }) : this.setState({
      postalValue: false
    })
    this.state.podNumber == "" ? this.setState({
      PODvalue: true
    }) : this.setState({
      PODvalue: false
    })
    this.state.labORcenter == "" ? this.setState({
      labORcenterValue: true
    }) : this.setState({
      labORcenterValue: false
    })
    this.state.labId == null && this.state.centerId == null ? this.setState({
      labcenterNameValue: true
    }) :
      this.setState({
        labcenterNameValue: false
      })
    this.state.postalid != ""
      && this.state.podNumber != ""
      && this.state.labORcenter != ""
      && (this.state.labId != null || this.state.centerId != null) ?
      this.props.navigation.navigate(Paramedic.kitCourierCamera, {
        orderid: this.props.route.params.orderiD,
        courierServiceid: this.state.postalid,
        pod: this.state.podNumber,
        LabORcenter: this.state.labORcenter,
        labid: this.state.labId,
        centerid: this.state.centerId,
        date: this.state.date,
      }) : null
  };
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      toast: false,
    });
  };
  labCenter = val => {
    console.log('laborcenter', val);
    this.setState({
      labORcenter: val,
      labORcenterValue: false
    });
  };
  postaloption = val => {
    console.log('postaloption', val);
    this.setState({
      postalid: val,
      postalValue: false
    });
  };
  labcenterNameoption = val => {
    console.log('name->', val);
    {
      this.state.labORcenter == 'LAB'
        ? this.setState({
          labId: val,
          labcenterNameValue: false
        })
        : this.setState({
          centerId: val,
          labcenterNameValue: false
        });
       
    }
  };
  podnumber = val => {
    console.log('postalnumber', val);
    this.setState({
      podNumber: val,
      PODvalue: false
    });
  };
  datehandler = val => {
    this.setState({
      selectedDate: moment(val).format('YYYY-MM-DD'),
      open: false,
    });
  };
  datepicker = () => {
    this.setState({
      open: true,
    });
  };
  render() {
    return (
      <DepositQRScreen
        cancelQR={this.cancelQR}
        kitConfirmModal={this.kitConfirmModal}
        kitModal={this.state.kitModal}
        SuccessModal={this.SuccessModal}
        success_Modal={this.state.success_Modal}
        labCenter={this.labCenter}
        postalservie={this.props.response}
        postaloption={this.postaloption}
        labcentername={this.props.labcentername}
        labcenterNameoption={this.labcenterNameoption}
        orderid={this.props.route.params.orderiD}
        podnumber={this.podnumber}
        datehandler={this.datehandler}
        open={this.state.open}
        datepicker={this.datepicker}
        selectedDate={this.state.selectedDate}
        toast={this.state.toast}
        errorMsg={this.state.errorMsg}
        postalValue={this.state.postalValue}
        PODvalue={this.state.PODvalue}
        labORcenterValue={this.state.labORcenterValue}
        labcenterNameValue={this.state.labcenterNameValue}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    response: state.courier.response,
    labcentername: state.courier.LabCenterNameResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getPostal: (data, token) => dispatch(getPostalService(data, token)),
    getLanCenterName: (data, token) => dispatch(getLabCenterName(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
