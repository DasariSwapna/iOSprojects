import React, { useRef } from 'react';
import {
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import Button from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import { ModalSuccess } from '../../../components/OtpModal';
import DropDownMenu from '../../../components/DropDownMenu';
import DatePicker from 'react-native-date-picker';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import PageNo from '../../../constants/PageNo';
import { Toast } from '../../../components/Toast';
import moment from 'moment';
import AppButton from '../../../components/Button';


const DropDownValue = [
  {
    label: 'Lab',
    value: 'LAB',
  },
  {
    label: 'Center',
    value: 'CENTER',
  },
];
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function DepositQRScreen({

  SuccessModal,
  success_Modal,
  labCenter,
  postalservie,
  postaloption,
  labcentername,
  labcenterNameoption,
  podnumber,
  datehandler,
  open,
  datepicker,
  selectedDate,
  errorMsg,
  toast,
  postalValue,
  PODvalue,
  labORcenterValue,
  labcenterNameValue
}) {
  return (
    <RootView pageNo={PageNo.paramedic_kitSampleCourier}>
      <KeyboardAvoidingView style={styles.container}>
        <Toast
          showToast={toast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <DropDownMenu
          labelName={I18n.t('paramedic.kitSampleHandover.select_courier')}
          labelKey={'courier_name'}
          valueKey={'id'}
          listItems={postalservie}
          valueChangeHandler={postaloption}
        />
        {postalValue && (
          <Text style={styles.textValidationMsg}>
            {"Please select courier service"}
          </Text>
        )}
        <View
          style={{
            width: wp('82%'),
            alignSelf: 'center',
          }}>
          <TextInput
            placeholder={I18n.t('paramedic.kitSampleHandover.pod_no')}
            style={{
              fontFamily: Font.regular,
              paddingVertical: hp('1.5%'),
              fontSize: FontSize.medium,
            }}
            placeholderTextColor={Colors.cWhite}
            onChangeText={podnumber}
          />
          <View
            style={{ borderBottomWidth: 1, borderBottomColor: Colors.dWhite }}
          />

        </View>
        {PODvalue && (
          <Text style={styles.textValidationMsg}>
            {"Please enter POD number"}
          </Text>
        )}
        <View
          style={{ width: wp('82%'), alignSelf: 'center' }}>
          <Text
            style={{
              fontFamily: Font.regular,
              paddingVertical: hp('1.8%'),
              fontSize: FontSize.medium,
              color: Colors.black,
            }}>
            {moment(new Date()).format('YYYY-MM-DD')}
          </Text>
          <View
            style={{ borderBottomWidth: 1, borderBottomColor: Colors.dWhite }}
          />
        </View>
        {/* <TouchableOpacity
          onPress={datepicker}
          style={{ width: wp('82%'), alignSelf: 'center' }}>
          <Text
            style={{
              fontFamily: Font.regular,
              paddingVertical: hp('1.8%'),
              fontSize: FontSize.medium,
              color: selectedDate == "Date" ? Colors.bgDarkGray : Colors.black,
            }}>
            {selectedDate}
          </Text>
          <View
            style={{ borderBottomWidth: 1, borderBottomColor: Colors.dWhite }}
          />
        </TouchableOpacity> */}

        <DropDownMenu
          labelName={I18n.t('paramedic.kitSampleHandover.lab_center')}
          labelKey={'label'}
          valueKey={'value'}
          listItems={DropDownValue}
          valueChangeHandler={labCenter}
        />
        {labORcenterValue && (
          <Text style={styles.textValidationMsg}>
            {"Please select Lab or Center"}
          </Text>
        )}
        <DropDownMenu
          labelName={I18n.t('paramedic.kitSampleHandover.lab_centername')}
          labelKey={'lc_CM_CITY_NAME'}
          valueKey={'lc_CM_ID'}
          listItems={labcentername}
          valueChangeHandler={labcenterNameoption}
        />
        {labcenterNameValue && (
          <Text style={styles.textValidationMsg}>
            {"Please select Lab or Center Name"}
          </Text>
        )}
        {/* <TouchableOpacity style={styles.buttonStyle} onPress={SuccessModal}>
          <Text style={styles.buttonText}>Next</Text>
        </TouchableOpacity> */}
        <AppButton
          title={'Next'}
          buttonStyle={styles.reachedButton}
          buttonTextStyle={{ fontSize: FontSize.large }}
          onPress={SuccessModal}
        />
        <ModalSuccess
          visible={success_Modal}
          title={'Success'}
          message={I18n.t(
            'paramedic.kitSampleHandover.sample_delivered_courier',
          )}
          pageNumber={'209'}
        />
        <DatePicker
          modal
          mode="date"
          open={open}
          date={new Date()}
          onConfirm={date => {
            !open;
            datehandler(date);
          }}
          onCancel={() => {
            !open;
          }}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

DepositQRScreen.prototype = {
  cancelQR: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    paddingVertical: hp('5%')
  },

  buttonText: {
    fontFamily: Font.regular,
    color: Colors.background,
    fontSize: FontSize.large,
  },
  buttonStyle: {
    backgroundColor: Colors.button,
    width: wp('40%'),
    height: hp('6%'),
    alignSelf: 'center',
    position: 'absolute',
    bottom: 15,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('2%'),
    position: 'absolute',
    fontSize: FontSize.large
  },
});

export default DepositQRScreen;
