import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import PNSSelectTestScreen from './Screen';
import {
  mytaskBarcodeSelectTest, mytaskUpdateBarcodeTestPickup
} from "../../../store/Actions";
import { delay } from '../../../utils/Helpers';
const data = [
  {
    id: 1,
    title: 'Maternity Screening - Maternal Serum',
  },
  {
    id: 2,
    title: 'QFPCR - Whole blood',
  },
  {
    id: 3,
    title: 'Hb Pathies - Heel Prick',
  },
  {
    id: 4,
    title: 'TSH+T4 - Heel Prick',
  },
  {
    id: 5,
    title: 'PNS DNA Storage- Aminiotic fluid',
  },
]
class PNSSelectTest extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isReached: false,
      showSuccessModal: false,
      radio: false,
      barcodeNumber:this.props.route.params.barcode,
      crmId:this.props.route.params.crmId,
      orderId:this.props.route.params.orderId,
      data:[],
      dataForButtonEnable:[],
      showToast: false,
      errorMsg:'',
    };
  }

  nextClickHandler = () => {
     //this.props.navigation.navigate(Paramedic.samplePickUp);
   
      const listSelected = this.state.data.filter(item => item.isSelected == true);

      if(listSelected.length<1){
        this.setState(
          {
            errorMsg: 'Please select atleast one test',
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
      
      }else{
        var arr = [];
        for (var i = 0; i < listSelected.length; i++) {
          arr.push({
            sample_id: listSelected[i].lc_SCD_ID,
          });
        }
    
       const data={
        "crmid":this.state.crmId,
        "orderid":this.state.orderId,
        "userid":this.props.UserID,
        "barcode":this.state.barcodeNumber,
        "barcode_test":arr
        }
        //console.log(JSON.stringify(data)); 
        this.props.mytaskBarcodeTestPickupDetails(data, this.props.accessToken);
        
      }
   
    }
  

  cancelClickHandler = () => {

  }


  radioPress = (itemList) => {
    const newData = this.state.data.map(item => {
      if (item.lc_TD_TEST_ID == itemList.lc_TD_TEST_ID) {
        return {
          ...item,
          isSelected: !item.isSelected,
        }
      }
      return item
    })

    console.log(newData);
    this.setState({ data: newData })
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };
  componentDidMount(){
    const data = {
      crmid: this.state.crmId,
      orderid:this.state.orderId
    }
  
    this.props.mytaskBarcodeSelectTestList(data, this.props.accessToken);
}

componentDidUpdate = prevProps => {
  if (
    prevProps.MytaskBarcodeSelectTestStatus == false &&
    this.props.MytaskBarcodeSelectTestStatus != prevProps.MytaskBarcodeSelectTestStatus
  ) {
    try {
      const data = this.props.MytaskBarcodeSelectTestResponse.map(item => {
          item.isSelected = false;
        return item;
      });
      this.setState({ data: data });
      //this.setState({dataForButtonEnable:data})
    } catch (error) {
    }
    //this.setState({data:this.props.MytaskBarcodeSelectTestResponse})
  }

  if (
    prevProps.MytaskBarcodeSelectTestError == false &&
    this.props.MytaskBarcodeSelectTestError != prevProps.MytaskBarcodeSelectTestError
  ) {
    this.setState(
      {
        errorMsg: this.props.message,
        showToast: true,
      },
      async () => {
        await delay(3000);
        this.resetValidation();
      },
    );
  }

  if (
    prevProps.MytaskUpdateBarcodeTestPickupError == false &&
    this.props.MytaskUpdateBarcodeTestPickupError != prevProps.MytaskUpdateBarcodeTestPickupError
  ) {
    this.setState(
      {
        errorMsg: this.props.message,
        showToast: true,
      },
      async () => {
        await delay(3000);
        this.resetValidation();
      },
    );
  }

  if (
    prevProps.MytaskUpdateBarcodeTestPickupStatus == false &&
    this.props.MytaskUpdateBarcodeTestPickupStatus != prevProps.MytaskUpdateBarcodeTestPickupStatus
  ) {
    if(this.props.MytaskUpdateBarcodeTestPickupResponse.statusCode == 200){
      this.props.navigation.navigate(Paramedic.samplePickUp);
    }
  }
}
  render() {
    return (
      <PNSSelectTestScreen
        data={this.state.data}
        nextClickHandler={this.nextClickHandler}
        radioPress={this.radioPress}
        loading={this.props.MytaskBarcodeSelectTestLoading || this.props.MytaskUpdateBarcodeTestPickupLoading}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      //  dataForButtonEnable={this.state.dataForButtonEnable}
      // states
      />
    )
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    MytaskBarcodeSelectTestLoading:state.mytask.MytaskBarcodeSelectTestLoading,
    MytaskBarcodeSelectTestStatus:state.mytask.MytaskBarcodeSelectTestStatus,
    MytaskBarcodeSelectTestError:state.mytask.MytaskBarcodeSelectTestError,
    MytaskBarcodeSelectTestResponse:state.mytask.MytaskBarcodeSelectTestResponse,


    MytaskUpdateBarcodeTestPickupLoading:state.mytask.MytaskUpdateBarcodeTestPickupLoading,
    MytaskUpdateBarcodeTestPickupStatus:state.mytask.MytaskUpdateBarcodeTestPickupStatus,
    MytaskUpdateBarcodeTestPickupError:state.mytask.MytaskUpdateBarcodeTestPickupError,
    MytaskUpdateBarcodeTestPickupResponse:state.mytask.MytaskUpdateBarcodeTestPickupResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    mytaskBarcodeSelectTestList: (data, token) =>
    dispatch(mytaskBarcodeSelectTest(data, token)),

    mytaskBarcodeTestPickupDetails: (data, token) =>
    dispatch(mytaskUpdateBarcodeTestPickup(data, token))
    
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(PNSSelectTest);
