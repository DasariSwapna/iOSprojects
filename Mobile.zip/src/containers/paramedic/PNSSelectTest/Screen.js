import React, { useRef } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  FlatList
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import IonIcons from 'react-native-vector-icons/Ionicons';
import AppButton from '../../../components/Button';
import DetailsCardView from '../../../components/DetailsCardView';
import AppButtonWithIcon from '../../../components/ButtonWithIcon';
import { ModalSuccess, ModalCancel, ModalReschedule } from '../../../components/OtpModal';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import { CheckCircle1 } from "../../../components/CheckCircle";
import I18n from '../../../locale/i18n';
import { NetworkContext } from '../../../contexts/NetworkContext';
import { Toast } from '../../../components/Toast';
function ListComponent({ title, radioPress, preCondition, count, item }) {

  return (
    <View style={{
      width: '90%',
      flexDirection: 'column',
      alignItems: 'flex-start',
      justifyContent: 'flex-start',
      //backgroundColor: 'red',
      alignSelf: 'center',
      borderColor: Colors.card,
      borderBottomWidth: 1,
      marginTop: hp('1.5%'),
    
    }}>
      <View
        style={{
          width: '100%',
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.bold,
          fontSize: FontSize.semiLarge,
          alignSelf: 'center',
          width: wp('72%'),
          // lineHeight:15,
          // paddingTop:10
        }}>{title}</Text>
        <View style={{ flexDirection: 'row', }}>
          <Text
            style={{
              marginRight: hp('2%'),
              color: Colors.border,
              fontFamily: FontMagneta.bold,
              fontSize: FontSize.large
            }}>{count}</Text>
          <CheckCircle1
            style={{
              alignSelf: 'center',
            }}
            length={wp('4%')} onPress={() => radioPress()} selected={item.isSelected} />
        </View>
      </View>
      <View style={{ flexDirection: 'row', marginVertical: hp('1%') }}>
        <Text style={{
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.semiLarge
        }}>Precondition:</Text>
        <Text style={{
          color: Colors.black,
          fontFamily: Font.bold,
          fontSize: FontSize.semiLarge,
          marginLeft: hp('2%')
        }}>{preCondition}</Text>
      </View>
    </View>

  )
}

const renderNodata = () => {
  return (
    <>
      <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
        <Text style={{ fontFamily: FontMagneta.bold }}>No data found</Text>
      </View>
    </>
  )
}
const renderItem = ({ item }, props) => (
  <ListComponent
    title={item.title}
    radioPress={props.radioPress}
  />
);


function PNSSelectTestScreen({
  nextClickHandler,
  reachedClickHandler,
  isReached,
  radioPress,
  data,
  loading, showToast, errorMsg,
  dataForButtonEnable
}) {
  const { isConnected } = React.useContext(NetworkContext);
  return (
    <RootView pageNo={'40'} loading={loading} connected={isConnected}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <View style={styles.rootView}>
        <View style={{
          flex: 0.9,
          backgroundColor: Colors.background,
          marginVertical: hp('2%')
        }}>
          <FlatList
            data={data}
            renderItem={({ item }) => <ListComponent
              title={item.lc_TD_TEST_NAME}
              preCondition={item.lc_TD_PRECONDITION}
              count={item.count}
              item={item}
              radioPress={() => radioPress(item)}
            />}
            keyExtractor={item => item.id}
            ListEmptyComponent={renderNodata}
          />
        </View>
        <View style={{
          flex: 0.1,
          width: wp('100%'),
          backgroundColor: Colors.background,
          alignItems: 'center', justifyContent: 'center'
        }}>
          {/* {dataForButtonEnable.length>0||dataForButtonEnable!=[]||dataForButtonEnable!=null?   
  <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={nextClickHandler} buttonStyle={styles.nextButton} />:
  <AppButton title={I18n.t('paramedic.myTask.next_label')} buttonStyle={[styles.nextButton,{backgroundColor:Colors.inActiveButton}]} />} */}

          <AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={nextClickHandler} buttonStyle={styles.nextButton} />
        </View>
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    color: Colors.babyCordTextColor
  },
  textTaskNumber: {
    fontFamily: FontMagneta.black,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTab: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.regular,
  },


  nextButton: {
    height: hp('5%'),
    width: '38%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3
  },
  reachedButton: {
    height: hp('5%'),
    width: '40%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3
  },
  buttonText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    alignSelf: 'center',
    color: Colors.background
  },
  buttonTextReschedule: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.button
  },
  bottomTabLine:
  {
    width: '75%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2
  },
  buttonContainer:
  {
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: '4%'
  },
  flatListContainer:
  {
    alignItems: 'flex-start',
    paddingHorizontal: 10,
    height: '60%'
  },
  bottomButtonContainer:
  {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 10,
    marginHorizontal: 15,
    marginTop: '35%'
  },
  bottonButtonRowContainer:
  {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
  nextButtonContainer: {
    width: '100%',
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,

  },
  buttonTextStyle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
  }

})


export default PNSSelectTestScreen;