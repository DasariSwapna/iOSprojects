import React, {useState} from 'react';
import I18n from 'i18next';
import {
  Dimensions,
  SafeAreaView,
  TouchableOpacity,
  Text,
  View,
  StyleSheet,
} from 'react-native';
import IonIcons from 'react-native-vector-icons/Ionicons';
import PropTypes from 'prop-types';
import Alert from '../../../components/Alert';
import Colors from '../../../config/Colors';
import RootView from '../../../components/RootView';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import {IconFooter} from '../../../components/Footer';

const {width, height} = Dimensions.get('screen');
const menuHeight = height * 0.07;

const Menu = ({title, icon, action}) => {
  return (
    <View style={styles.menuItemContainer}>
      <TouchableOpacity style={styles.itemContainer} onPress={() => action()}>
        <View style={{width: menuHeight, paddingHorizontal: menuHeight / 8}}>
          <IonIcons
            name={icon}
            color={Colors.primary}
            size={menuHeight / 2.6}
          />
        </View>
        <Text style={styles.itemText}>{title}</Text>
      </TouchableOpacity>
    </View>
  );
};

const SliderMenuScreen = ({
  version,
  name,
  mobileNo,
  homeNavHandler,
  myPerformanceNavHandler,
  sampleTrackingNavHandler,
  myIncentivesNavHandler,
  helplineNavHandler,
  logoutSubmitHandler,
  userSelectionHandler,
}) => {
  const [logoutToggle, setLogoutToggle] = useState(false);

  logoutActionHandler = val => {
    setLogoutToggle(false);
    if (val == true) logoutSubmitHandler();
  };

  return (
    <RootView>
      <Alert
        title={'Do you want to logout'}
        toggle={logoutToggle}
        action={logoutActionHandler}
      />
      <View style={styles.infoContainer}>
        <View style={styles.infoIconContainer}>
          <Text style={styles.infoIconText}>
            {name && name.trim().charAt(0)}
          </Text>
        </View>
        <View style={styles.infoTextContainer}>
          <Text style={styles.infoNameText}>{name}</Text>
          <Text style={styles.infoMobileNoText}>{mobileNo}</Text>
          <Text style={styles.infoMobileNoText}>Paramedic</Text>
        </View>
      </View>
      <View style={{justifyContent: 'center'}}>
        <Menu title={'Home'} icon="ios-home-outline" action={homeNavHandler} />
        <Menu
          title={'My Performance'}
          icon="ios-time-outline"
          action={myPerformanceNavHandler}
        />
        <Menu
          title={'Sample Tracking'}
          icon="ios-location-outline"
          action={sampleTrackingNavHandler}
        />
        <Menu
          title={'My Incentives'}
          icon="ios-wallet-outline"
          action={myIncentivesNavHandler}
        />
        <Menu
          title={'Helpline'}
          icon="ios-help-circle-outline"
          action={helplineNavHandler}
        />
        <Menu
          title={'Logout'}
          icon="ios-log-out-outline"
          // action={() => logoutSubmitHandler()}
          action={() => setLogoutToggle(true)}
        />
      </View>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'flex-end',
          paddingBottom: 20,
        }}>
        <View style={{alignItems: 'center', justifyContent: 'center'}}>
          {version && (
            <Text
              style={[styles.infoMobileNoText, {fontSize: FontSize.medium}]}>
              V {version}
            </Text>
          )}
        </View>
        <IconFooter />
      </View>
    </RootView>
  );
};

SliderMenuScreen.prototype = {
  name: PropTypes.string,
  mobileNo: PropTypes.string,
  loading: PropTypes.bool,
  popUpToggle: PropTypes.bool,
  homeNavHandler: PropTypes.func,
  myPerformanceNavHandler: PropTypes.func,
  sampleTrackingNavHandler: PropTypes.func,
  myIncentivesNavHandler: PropTypes.func,
  helplineNavHandler: PropTypes.func,
  logoutHandler: PropTypes.func,
  userSelectionHandler: PropTypes.func,
};

SliderMenuScreen.defaultProps = {
  name: 'iSolve',
  mobileNo: '9789888777',
};

const styles = StyleSheet.create({
  mainContainer: {
    height: '100%',
    backgroundColor: Colors.bgLightGray,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 30,
    paddingHorizontal: 16,
    borderBottomLeftRadius: 15,
    backgroundColor: Colors.card,
  },
  infoIconText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    fontWeight: '800',
    textTransform: 'capitalize',
  },
  infoIconContainer: {
    width: menuHeight,
    height: menuHeight,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: menuHeight / 2,
    overflow: 'hidden',
    elevation: 1,
    marginHorizontal: 4,
    paddingTop: 2,
    backgroundColor: Colors.background,
  },
  infoTextContainer: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingHorizontal: 10,
  },
  infoNameText: {
    color: Colors.text,
    fontSize: FontSize.extraLarge,
    fontWeight: '800',
    fontFamily: Font.extraBold,
    textTransform: 'capitalize',
    paddingVertical: 2,
  },
  infoMobileNoText: {
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.medium,
    textTransform: 'capitalize',
    paddingVertical: 2,
  },
  menuItemContainer: {
    height: menuHeight,
    justifyContent: 'center',
  },
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    paddingHorizontal: menuHeight / 4,
    paddingVertical: menuHeight / 4,
    borderBottomWidth: 0.8,
    borderBottomColor: Colors.bgDarkGray,
  },
  itemText: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    fontWeight: '600',
  },
});

export default SliderMenuScreen;
