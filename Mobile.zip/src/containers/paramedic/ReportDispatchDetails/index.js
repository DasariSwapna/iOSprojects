import React from 'react';
import ReportDispatchDetailsScreen from './Screen';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
const data=[
{
id:1,name:'Joe',
crmid:'54345',
date:'20.11.2021',
time:'10:10'
},
{
  id:2,
  name:'Srikanth',
  crmid:'12345',
  date:'20.11.2021',
  time:'10:10'
},
{
  id:3,
  name:'Arun',
  crmid:'45463',
  date:'20.11.2021',
  time:'10:10'
},
{
id:4,name:'Joe',
crmid:'54345',
date:'20.11.2021',
time:'10:10'
},
{
  id:5,
  name:'Srikanth',
  crmid:'12345',
  date:'20.11.2021',
  time:'10:10'
},
{
  id:6,
  name:'Arun',
  crmid:'45463',
  date:'20.11.2021',
  time:'10:10'
},
]
class ReportDispatchDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
   
    };
  }

  cardClickHandler=()=>{
 // this.props.navigation.navigate(Paramedic.reportDispatchDetails)
  }
  nextClickHandler=()=>{
    this.props.navigation.navigate(Paramedic.myTask)
  }

  render() {
    return <ReportDispatchDetailsScreen data={data} nextClickHandler={this.nextClickHandler}
    />;
  }
}

const mapStateToProps = state => {
  return {
    //loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(ReportDispatchDetails);