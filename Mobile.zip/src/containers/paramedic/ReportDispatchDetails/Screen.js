import React, { useRef } from 'react';
import {
  Text,
  View,
  StyleSheet,
  FlatList,
  Platform,
  Image
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import IonIcons from 'react-native-vector-icons/Ionicons';
import Button from '../../../components/Button';
import Images from '../../../constants/Icons';
import { heightPercentageToDP as hp,widthPercentageToDP as wp } from 'react-native-responsive-screen';
function ReportDispatchDetailsScreen({ data,nextClickHandler }) {
  const renderItem = ({ item }) => (

    <View style={styles.cardContainer}>
      <View style={styles.mainView}>
        <View style={styles.innerView}>
          <View style={styles.nameContainer}>
            <View style={styles.nameRowContainer}>
              <Text style={styles.nameText}>{item.name}</Text>
            </View>
            <View style={styles.nameRowSecondContainer}>
              <Text style={styles.crmidText}>{item.crmid}</Text>
              <IonIcons name={'checkmark-circle-outline'} color={Colors.border} size={20} />
            </View>
          </View>
          <View style={styles.seperateLine}></View>
        </View>
        <View style={styles.dateContainer}>
          <View style={styles.dateRowContainer}>
            <Text style={styles.dateText}>Date</Text>
            <Text style={styles.dateNumberText}>{item.date}</Text>
          </View>
          <View style={styles.dateRowContainer}>
            <Text style={styles.dateText}>Time</Text>
            <View style={styles.timeInnerContainer}>
              <Text style={styles.dateNumberText}>{item.time}</Text>
              <View style={styles.iconContainer}>
                <Image source={Images.downloadIcon} style={styles.image} />
                <IonIcons style={styles.iconSpace} name={'share-social'} color={Colors.border} size={23} />
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  )

  return (
    <RootView pageNo={'297'}>
      <View style={styles.rootView}>
        <View style={styles.flatListContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={{ flex: 1 }}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.flatListInnerContainer}
          />
        </View>
        <View style={styles.innerMainView}>
          <Button title={'Submit'} buttonStyle={styles.buttonStyle} onPress={nextClickHandler}/>
        </View>
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',alignItems:'center',
  },
  cardContainer: {
    borderRadius: 15,
    borderColor: Colors.border,
    borderWidth: Platform.OS=='ios'?hp('0.04%'):hp('0.1%'),
    backgroundColor: Colors.background,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: .3,
    shadowRadius: 2.5,
    elevation: 2,
    flexDirection: 'row',
    marginTop: '5%',
    maxWidth:'98%'
  },
  mainView: {
    width: '100%',
    flexDirection: 'column',
    paddingVertical:5
  },
  innerView: {
    flex: 1,
    flexDirection: 'column'
  },
  nameContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 15,
    marginTop: 10, 
    paddingHorizontal:10
  },
  nameRowContainer: {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'center'
  },
  nameRowSecondContainer:
  {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    flexDirection: 'row',
   
  },
  nameText:
  {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border
  },
  crmidText:
  {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.bold,
    color: Colors.babyCordTextColor
  },
  seperateLine:
  {
    height: Platform.OS=='ios'?hp('0.04%'):hp('0.1%'),
    width: '100%',
    backgroundColor: Colors.border,
    marginVertical: 4
  },
  dateContainer:
  {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: 15,
    marginVertical: 10, paddingHorizontal:10
  },
  dateRowContainer: {
    flex: 0.5,
    alignItems: 'flex-start',
    justifyContent: 'center',
    flexDirection: 'column',
  }, dateText:
  {
    fontSize: FontSize.regular,
    fontFamily: Font.regular,
    color: Colors.border
  },
  dateNumberText:
  {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.black,
    marginTop: 3
  },
  timeInnerContainer:
  {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start'
  },
  iconContainer: {
    flexDirection: 'row',
    width: '85%',
    alignItems: 'center',
    justifyContent: 'flex-end',
  
  }, iconSpace: {
    marginHorizontal: 15
  },
  innerMainView: {
    alignItems: 'center',
    justifyContent: 'center'
  },
  flatListInnerContainer:
  {
    flexGrow: 1,
    paddingBottom: 40
  },
  flatListContainer:
  {
    alignItems: 'center',
    height: '90%',
    paddingHorizontal:20,
    paddingVertical:10
  },
  image:{
    width:20,height:20
  },
  buttonStyle:{
    width: wp('38%'),
    height:hp('4.5%') 
  }

})

export default ReportDispatchDetailsScreen;