import React from "react";
import { connect } from "react-redux";
import I18n from "i18next";
import PropTypes from "prop-types";
import DepositQRScreen from "./Screen";
import { Paramedic } from "../../../navigations/RouteTypes";
import { BackHandler } from 'react-native';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {

    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidMount = () => {
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };

  componentDidUpdate = () => { };
  componentWillUnmount() { this.back.remove(); }
  cancelQR = () => {
    this.props.navigation.navigate(Paramedic.kitSampleHandover)
  }
  render() {
    return (
      <DepositQRScreen
        cancelQR={this.cancelQR}
        qrvalue={this.props.route.params.Qrcode}
      />
    );
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
