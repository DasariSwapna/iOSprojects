import React, {useRef} from 'react';
import {
  Image,
  Text,
  View,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontSize} from '../../../config/Fonts';
import Images from '../../../constants/Images';
import PageNo from '../../../constants/PageNo';
import QRCode from 'react-native-qrcode-svg';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';

function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{width: '48%', alignItems: 'flex-end'}}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{width: '48%', alignItems: 'flex-start'}}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function DepositQRScreen({cancelQR, qrvalue}) {
  // alert(qrvalue)
  return (
    <RootView pageNo={PageNo.paramedic_kitSampleQR}>
      <KeyboardAvoidingView style={styles.container}>
        <View style={styles.containerView}>
          <Text style={styles.txt}>
            {I18n.t('paramedic.kitSampleHandover.show_qr_runner')}
          </Text>
          <View style={{alignItems: 'center'}}>
            <QRCode value={qrvalue} size={hp('35%')} />
          </View>
        </View>
        <TouchableOpacity style={styles.cancelButton} onPress={cancelQR}>
          <Text style={styles.cancelText}>Cancel</Text>
        </TouchableOpacity>
      </KeyboardAvoidingView>
    </RootView>
  );
}

DepositQRScreen.prototype = {
  cancelQR: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white',
  },
  txt: {
    alignSelf: 'center',
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.large,
    padding: hp('2%'),
  },
  containerView: {
    flex: 1,
    justifyContent: 'center',
  },
  cancelButton: {
    width: wp('40%'),
    height: hp('5.5%'),
    alignSelf: 'center',
    position: 'absolute',
    bottom: 15,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderColor: '#EE2C6C',
    borderWidth: 1,
  },
  cancelText: {
    fontFamily: Font.regular,
    color: '#EE2C6C',
    fontSize: FontSize.large,
  },
  amountText: {
    color: 'black',
  },
});

export default DepositQRScreen;
