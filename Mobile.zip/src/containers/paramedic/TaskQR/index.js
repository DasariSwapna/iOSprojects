import React, {useState, useEffect, useRef} from 'react';
import {
  Button,
  Text,
  View,
  Alert,
  StatusBar,
  Modal,
  TouchableOpacity,
  BackHandler,
} from 'react-native';
import {RNCamera} from 'react-native-camera';
import {connect, useSelector, useDispatch} from 'react-redux';
import {useRoute, useFocusEffect} from '@react-navigation/native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import BarcodeMask from 'react-native-barcode-mask';
import {Paramedic} from '../../../navigations/RouteTypes';
// import { connect } from "react-redux";
import {getKitsampleHandoverBiodataSelectList} from '../../../store/Actions';
const QRScanner = ({navigation, ...props}) => {
  const dispatch = useDispatch();
  const [barcodeCodes, setbarcodeCodes] = useState([]);
  const [isModalVisible, setisModalVisible] = useState(false);
  const [camera, setcamera] = useState(false);
  const route = useRoute();
  useFocusEffect(
    React.useCallback(() => {
      //checkinternet();
      let isActive = true;
      if (isActive) {
        setcamera(true);
      } else {
        setcamera(false);
      }
      const onBackPress = () => {
        // if (route.name === 'BarcodeScanner') {
        //   setcamera(false);
        //   navigation.navigate('PickupTest')
        //   return true;
        // } else {
        //   return false;
        // }
      };
      BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => {
        isActive = false;
        BackHandler.removeEventListener('hardwareBackPress', onBackPress);
      };
    }, [route]),
  );
  const onBarCodeRead = scanResult => {
    console.warn(scanResult.type);
    console.warn(scanResult.data);
    // const data = { paramedicid: 7, orderids: "39,42" };
    if (scanResult.data != null) {
      var qrString = scanResult.data;
      var userIDSpliting = qrString.split('|');
      var orderIdSpliting = userIDSpliting[0].split(',');
      var userId = Number(userIDSpliting[1]);
      var orderid = [];
      orderIdSpliting &&
        orderIdSpliting.map(item => {
          const obj = {};
          obj.id = Number(item);
          orderid.push(obj);
        });
      navigation.navigate(Paramedic.shuttle, {
        shuttledata: orderid,
        userId: userId,
      });
    }
    return;
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="dark-content" hidden={false} translucent={true} />
      {camera === true ? (
        <RNCamera
          defaultTouchToFocus
          captureAudio={false}
          flashMode={RNCamera.Constants.FlashMode.auto}
          mirrorImage={false}
          onBarCodeRead={onBarCodeRead.bind(this)}
          onFocusChanged={() => {}}
          onZoomChanged={() => {}}
          style={styles.preview}
          type={RNCamera.Constants.Type.back}>
          <BarcodeMask
            width={wp('80%')}
            height={hp('40%')}
            edgeColor={'red'}
            showAnimatedLine={true}
            animatedLineColor={'red'}
            edgeBorderWidth={5}
          />
        </RNCamera>
      ) : null}

      <Modal
        animationType="slide"
        transparent={true}
        visible={isModalVisible}
        onRequestClose={() => {
          setisModalVisible(false);
        }}
      />
    </View>
  );
};

const styles = {
  container: {
    flex: 1,
  },
  preview: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    position: 'absolute',
    padding: 16,
    right: 0,
    left: 0,
    alignItems: 'center',
  },
  topOverlay: {
    top: 0,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomOverlay: {
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  enterBarcodeManualButton: {
    padding: 15,
    backgroundColor: 'white',
    borderRadius: 40,
  },
  scanScreenMessage: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
};

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
  };
};

export default connect(mapStateToProps)(QRScanner);
