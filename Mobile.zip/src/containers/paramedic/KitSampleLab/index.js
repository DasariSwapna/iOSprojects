import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import DepositQRScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import { getHanoverLab, kitSampleInsert } from '../../../store/Actions';
import { BackHandler } from 'react-native';
class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      kitModal: false,
      success_Modal: false,
      value: '',
      id: '',
      loading: false
    };
  }

  componentDidMount = () => {
    const data = { lang_id: 1 };
    this.props.getHandoveLab(data, this.props.accessToken);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  componentWillUnmount() { this.back.remove(); }
  componentDidUpdate = prevProps => {
    if (
      prevProps.kitsampleInsertStatus == true &&
      this.props.kitsampleInsertStatus != prevProps.kitsampleInsertStatus
    ) {
      try {
        this.setState({
          kitModal: !this.state.kitModal,
        });
        this.setState({
          success_Modal: !this.state.success_Modal,
        });
        setTimeout(() => {
          this.setState({ success_Modal: false });
          this.props.navigation.navigate(Paramedic.kitSampleHandover);
        }, 2000);
      } catch (error) { }
    }
    if (prevProps.kitsampleInsertLoading == true &&
      this.props.kitsampleInsertLoading != prevProps.kitsampleInsertLoading) {
      try {
        this.setState({
          loading: true
        })
      } catch (error) { }
    }
  };

  cancelQR = () => {
    this.props.navigation.navigate(Paramedic.kitSampleHandover);
  };
  kitConfirmModal = val => {
    this.setState({
      kitModal: !this.state.kitModal,
      id: val.id,
    });
  };
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  SuccessModal = () => {
    //updating center call

    const data = {
      orderIds: this.props.route.params.orderiD,
      userid: this.props.userId,
      type: 'LAB',
      centerid: null,
      labid: this.state.id,
      courierid: null,
      podnumber: null,
      courierdate: null,
      courierlabcenter: null,
      courierlabid: null,
      couriercenterid: null,
      courierimg: null,
      courierimgfname: null,
    };

    this.props.kitInsert(data, this.props.accessToken);
  };
  cancelModal = () => {
    this.setState({
      kitModal: !this.state.kitModal,
    });
  };
  render() {
    return (
      <DepositQRScreen
        cancelQR={this.cancelQR}
        kitConfirmModal={this.kitConfirmModal}
        kitModal={this.state.kitModal}
        SuccessModal={this.SuccessModal}
        success_Modal={this.state.success_Modal}
        lab={this.props.labResponse}
        orderid={this.props.route.params.orderiD}
        cancelModal={this.cancelModal}
        loading={this.state.loading}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    labResponse: state.kitsampleHandoverBiodata.labResponse,
    userId: state.signIn.userId,
    kitsampleInsertStatus: state.kitInsert.kitsampleInsertStatus,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getHandoveLab: (data, token) => dispatch(getHanoverLab(data, token)),
    kitInsert: (data, token) => dispatch(kitSampleInsert(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
