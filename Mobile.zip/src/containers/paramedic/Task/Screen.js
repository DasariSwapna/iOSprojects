import React, { useRef } from 'react';
import {
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  Modal,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import AppButton from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import ModaCustom from '../../../components/ModalCalendar';
import { ModalSuccess } from '../../../components/OtpModal';
import DropDownMenu from '../../../components/DropDownMenu';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import AntDesign from 'react-native-vector-icons/AntDesign';
import PageNo from '../../../constants/PageNo';
import { Toast } from '../../../components/Toast';

function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function TaskScreen({
  SearchTask,
  modalVisible,
  showSuccessModal,
  successModal,
  selectCatDrop,
  category,
  showcalendar,
  showCal,
  response,
  createTaskresponse,
  Taskdropdownoption,
  CRMresponse,
  changeText,
  text,
  task,
  taskTimeresponse,
  Call,
  datecall,
  closeModal,
  toast,
  errorMsg,
  numberTxt
}) {
  console.log('taskres', taskTimeresponse);
  console.log('toast', toast, "errr", errorMsg)
  return (
    <RootView pageNo={PageNo.paramedic_task}>
      <Toast
        showToast={toast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView style={styles.container}>

        <ScrollView style={styles.scrollContainer}>

          <Text style={styles.txt}>
            {I18n.t('paramedic.task.select_category')}
          </Text>
          <DropDownMenu
            labelName={I18n.t('paramedic.task.select_category')}
            labelKey={'lc_TC_TASK_NAME'}
            valueKey={'lc_TC_TASK_NAME'}
            listItems={response}
            valueChangeHandler={selectCatDrop}
          />

          <View style={{ marginVertical: hp('2%') }}>
            <Text style={styles.txt}>
              {I18n.t('paramedic.task.select_task')}
            </Text>
          </View>

          <DropDownMenu
            labelName={I18n.t('paramedic.task.select_task')}
            labelKey={'lc_TT_TASK_NAME'}
            valueKey={'lc_TT_TASK_NAME'}
            listItems={createTaskresponse}
            valueChangeHandler={Taskdropdownoption}
          />

          <View style={{ width: wp('88%'), alignSelf: 'center' }}>
            <TextInput
              placeholder={I18n.t('paramedic.task.crm_no')}
              style={{
                fontFamily: Font.regular,
                marginHorizontal: wp('3.8%'),
                marginVertical: hp('2.5%'),
              }}
              maxLength={12}
              placeholderTextColor={Colors.bgDarkGray}
              value={text}
              // onChangeText={changeText}
              onChangeText={text => changeText(text)}
              keyboardType="numeric"
            />
            <View
              style={{ borderBottomWidth: 1, borderBottomColor: Colors.dWhite }}
            />
          </View>
          {numberTxt && (
            <Text style={styles.textValidationMsg}>
              {"Please enter only number"}
            </Text>
          )}
        </ScrollView>

        <AppButton
          title={I18n.t('paramedic.task.search')}
          buttonStyle={[
            styles.reachedButton,
            {
              backgroundColor:
                category != '' && text != '' && task != ''
                  ? Colors.button
                  : Colors.dWhite,
            },
          ]}
          onPress={
            category != '' && text != '' && task != '' ? SearchTask : null
          }
        />
        {/* CRM user modal */}
        {CRMresponse != '' && CRMresponse != undefined ? (
          <Modal
            transparent={true}
            visible={modalVisible}
            onRequestClose={SearchTask}
            style={styles.crmModal}>
            <View style={styles.crmOverlay}>
              <View style={styles.crmContainer}>
                <View style={styles.crmHeader}>
                  <Text style={styles.crmUser}>
                    {CRMresponse[0].patient_NAME}
                  </Text>
                  <AntDesign
                    name={'closecircle'}
                    color={Colors.darkPink}
                    size={hp('3%')}
                    onPress={closeModal}
                  />
                </View>
                <View style={styles.texInContainer}>
                  <Text
                    style={{
                      fontFamily: Font.extraBold,
                      fontSize: FontSize.extraLarge,
                      color: Colors.border,
                    }}>
                    CRM Number :
                  </Text>
                  <Text
                    style={{
                      fontFamily: FontMagneta.medium,
                      fontSize: FontSize.extraLarge,
                      color: Colors.darkGreen,
                      paddingStart: hp('0.5%'),
                    }}>
                    {CRMresponse[0].crm_ID}
                  </Text>
                </View>
                <View
                  style={{ borderBottomWidth: 1, borderColor: Colors.dWhite }}
                />
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                    paddingTop: hp('2%'),
                  }}>
                  <View style={styles.flex}>
                    <Text style={styles.rowTxt}>Order ID :</Text>
                    <Text style={styles.rowNum}>{CRMresponse[0].orderid}</Text>
                  </View>
                  <View style={styles.flex}>
                    <Text style={styles.rowTxt}>Phone :</Text>
                    <Text style={styles.rowNum}>{CRMresponse[0].phone_NO}</Text>
                  </View>
                </View>
                <View style={{ flexDirection: 'row', paddingTop: hp('2%') }}>
                  <View style={styles.flex}>
                    <Text style={styles.rowTxt}>Date</Text>
                    <Text style={styles.rowNum}>
                      {CRMresponse[0].schedule_DATE}
                    </Text>
                  </View>
                  <View style={styles.flex}>
                    <Text style={styles.rowTxt}>Time :</Text>
                    <Text style={styles.rowNum}>
                      {CRMresponse[0].schedule_TIME}
                    </Text>
                  </View>
                </View>
                <View style={{ paddingTop: hp('2%') }}>
                  <Text style={styles.rowTxt}>Address :</Text>
                  <Text
                    style={{
                      fontFamily: FontMagneta.medium,
                      color: Colors.black,
                    }}>
                    {CRMresponse[0].shipping_ADDRESS}
                  </Text>
                </View>
                <View
                  style={{
                    marginVertical: hp('3%'),
                    borderBottomWidth: 0.9,
                    borderColor: Colors.dWhite,
                  }}
                />
                <AppButton
                  title={'Schedule Task'}
                  buttonStyle={styles.reachedButton}
                  onPress={showcalendar}
                />
              </View>
            </View>
          </Modal>
        ) : null}
        <ModalSuccess
          visible={showSuccessModal}
          title={'Success'}
          message={I18n.t('paramedic.task.task_created')}
          pageNumber={'209'}
        />
        {taskTimeresponse != '' ||
          taskTimeresponse != [] ||
          taskTimeresponse != undefined ? (
          <ModaCustom
            visible={showCal}
            title={'Success'}
            message={I18n.t('paramedic.task.task_created')}
            pageNumber={'209'}
            CallBack={SearchTask}
            call={Call}
            // success={successModal}
            datecall={datecall}
            time={taskTimeresponse}
          />
        ) : null}
      </KeyboardAvoidingView>
    </RootView>
  );
}

TaskScreen.prototype = {
  cancelQR: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },

  rowNum: {
    fontFamily: FontMagneta.medium,
    color: Colors.black,
  },
  txt: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    marginHorizontal: wp('10%'),
  },

  rowTxt: {
    color: Colors.border,
    fontFamily: Font.regular,
  },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.teal,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('1%'),
  },
  crmModal: {
    width: wp('100%'),
    height: hp('100%'),
  },
  crmOverlay: {
    width: wp('100%'),
    height: hp('100%'),
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  crmContainer: {
    width: wp('100%'),
    height: hp('56%'),
    backgroundColor: Colors.white,
    position: 'absolute',
    bottom: 0,
    padding: hp('3%'),
  },
  flex: {
    flex: 1,
  },
  crmHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  crmUser: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.extraLarge,
    color: Colors.black,
    paddingVertical: 10,
  },
  scrollContainer: {
    marginTop: hp('4%'),
  },
  texInContainer: {
    flexDirection: 'row',
    paddingVertical: 10,
  },
});

export default TaskScreen;
