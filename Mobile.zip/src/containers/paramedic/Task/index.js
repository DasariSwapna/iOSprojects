import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import TaskScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import { Modal } from '../../../components/Modal';
import moment from 'moment';
import { delay } from '../../../utils/Helpers';

import {
  getTaskCategory,
  getTask,
  getCRMInfo,
  updatetask,
  getTaskTime,
} from '../../../store/Actions';
class Task extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      showSuccessModal: false,
      category: '',
      showCal: false,
      text: '',
      task: '',
      CRMresponse: this.props.CRMresponse,
      errorMsg: '',
      toast: false,
      numberTxt: false
    };
  }

  componentDidMount = () => {
    //Select Category Dropdwon Api
    const data = {
      search: null,
    };
    this.props.category(data, this.props.accessToken);

    //Selct Task Dropdown api
    const taskData = {
      search: null,
      taskid: null,
    };
    this.props.task(taskData, this.props.accessToken);
    // Calendar time Api
    const timedata = {
      userid: this.props.userId,
      pickupdate: moment(new Date(), 'YYYY-MM-DD'),
    };
    this.props.timeapi(timedata, this.props.accessToken);
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.updateCRMStatus == false &&
      this.props.updateCRMStatus != prevProps.updateCRMStatus
    ) {
      try {
        this.setState({ showCal: false });

        this.setState({
          showSuccessModal: !this.state.showSuccessModal,
        });

        this.setState({
          modalVisible: false,
        });
        setTimeout(() => {
          this.setState({ showSuccessModal: false });
          this.props.navigation.navigate(Paramedic.home);
        }, 2000);
      } catch (error) { }
    }
    if (
      prevProps.getCRMInfoError == false &&
      this.props.getCRMInfoError != prevProps.getCRMInfoError
    ) {
      this.setState(
        {
          toast: true,
          errorMsg: 'CRM ID not available',
        },
        async () => {
          await delay(2000);
          this.resetValidation();
        },
      );
    }
    if (
      prevProps.getCRMInfoStatus == false &&
      this.props.getCRMInfoStatus != prevProps.getCRMInfoStatus
    ) {
      this.setState({
        modalVisible: true,
      })
    }
    if (
      prevProps.updateCRMError == false &&
      this.props.updateCRMError != prevProps.updateCRMError
    ) {
      this.setState(
        {
          showCal: false,
          toast: true,
          errorMsg: 'Update Error',
        },
        async () => {
          await delay(2000);
          this.resetValidation();
        },
      );
    }
  };
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      toast: false,
    });
  };
  SearchTask = val => {
    const data = {
      crmid: this.state.text,
    };
    this.state.category == 'Report Delivery'
      ? this.props.navigation.navigate(Paramedic.taskReports)
      : this.props.crm(data, this.props.accessToken);
    // this.setState({
    //   modalVisible: !this.state.modalVisible,
    // })
  };
  successModal = value => {
    //Create Task Api
    // const dateandTime =
    const data = {
      pickupdatetime: value,
      remarks: 'Testremarks',
      pickupid: 1,
      paramedicid: this.props.userId,
      type: 'Bio',
      orderid: this.props.CRMresponse[0].orderid,
      userid: this.props.userId,
    };
    this.props.updateTask(data, this.props.accessToken);
  };
  selectCatDrop = val => {
    this.setState({
      category: val,
    });
  };
  showcalendar = () => {
    this.setState({
      modalVisible: !this.state.modalVisible,
      showCal: !this.state.showCal,
    });
  };
  closeModal = () => {
    this.setState({
      modalVisible: !this.state.modalVisible,
    });
  };
  Taskdropdownoption = val => {
    this.setState({
      task: val,
    });
  };
  changeText = val => {
    const value = val.replace(/[^0-9]/g, '')
    console.log(value)
    this.setState({
      text: value,
    })
  };
  Call = val => {
    console.log(val);
    this.successModal(val);
  };
  datecall = val => {
    console.log(val);
    const timedata = {
      userid: this.props.userId,
      pickupdate: val,
    };
    this.props.timeapi(timedata, this.props.accessToken);
  };

  render() {
    console.log('timer', this.props.taskTimeresponse);
    return (
      <TaskScreen
        SearchTask={this.SearchTask}
        modalVisible={this.state.modalVisible}
        showSuccessModal={this.state.showSuccessModal}
        successModal={this.successModal}
        selectCatDrop={this.selectCatDrop}
        category={this.state.category}
        showcalendar={this.showcalendar}
        showCal={this.state.showCal}
        response={this.props.response}
        createTaskresponse={this.props.createTaskresponse}
        Taskdropdownoption={this.Taskdropdownoption}
        CRMresponse={this.state.CRMresponse}
        changeText={this.changeText}
        text={this.state.text}
        task={this.state.task}
        taskTimeresponse={this.props.taskTimeresponse}
        Call={this.Call}
        datecall={this.datecall}
        closeModal={this.closeModal}
        CRMmessage={this.props.CRMmessage}
        errorMsg={this.state.errorMsg}
        toast={this.state.toast}
        numberTxt={this.state.numberTxt}

      />
    );
  }
}

const mapStateToProps = state => {
  return {
    userId: state.signIn.userId,
    message: state.createtask.message,
    accessToken: state.signIn.accessToken,
    getTaskCategoryLoading: state.createtask.getTaskCategoryLoading,
    getTaskCategoryStatus: state.createtask.getTaskCategoryStatus,
    getTaskCategoryError: state.createtask.getTaskCategoryError,
    response: state.createtask.response,
    createTaskresponse: state.createtask.createTaskresponse,
    CRMresponse: state.createtask.CRMresponse,
    taskTimeresponse: state.createtask.taskTimeresponse,
    updateCRMStatus: state.createtask.updateCRMStatus,
    CRMmessage: state.createtask.CRMmessage,
    getCRMInfoError: state.createtask.getCRMInfoError,
    getCRMInfoStatus: state.createtask.getCRMInfoStatus,
    updateCRMError: state.createtask.updateCRMError,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    category: (data, token) => dispatch(getTaskCategory(data, token)),
    task: (data, token) => dispatch(getTask(data, token)),
    crm: (data, token) => dispatch(getCRMInfo(data, token)),
    updateTask: (data, token) => dispatch(updatetask(data, token)),
    timeapi: (data, token) => dispatch(getTaskTime(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Task);
