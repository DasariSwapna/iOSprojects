import React, {useState, useEffect, useRef} from 'react';
import {
  Button,
  Text,
  View,
  Alert,
  StatusBar,
  Modal,
  TouchableOpacity,
  BackHandler,
} from 'react-native';
import {RNCamera} from 'react-native-camera';
import {useRoute, useFocusEffect} from '@react-navigation/native';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import BarcodeMask from 'react-native-barcode-mask';
import { Paramedic } from '../../../navigations/RouteTypes';

const BarcodeScanner = (props) => {
  const [barcodeCodes, setbarcodeCodes] = useState([]);
  const [isModalVisible, setisModalVisible] = useState(false);
  const [camera, setcamera] = useState(false);
  const route = useRoute();
  useFocusEffect(
    React.useCallback(() => {
      //checkinternet();
      let isActive = true
      if (isActive) {
        setcamera(true);
      }else{
        setcamera(false);
      }
      const onBackPress=()=>{
        // if (route.name === 'BarcodeScanner') {
        //   setcamera(false);
        //   navigation.navigate('PickupTest')
        //   return true;
        // } else {
        //   return false;
        // }

      }
      BackHandler.addEventListener('hardwareBackPress', onBackPress);
      return () => {
        isActive = false
        BackHandler.removeEventListener('hardwareBackPress', onBackPress);
      }
    }, [route])
  )

  // async function checkinternet() {
  //   //alert('check')
  //   await internetconnection(navigation);
  // }

  const onBarCodeRead = (scanResult) => {
    console.warn(scanResult.type);
    console.warn(scanResult.data);
    if (scanResult.data != null) {
      //navigation.goBack()
      setcamera(false);
      props.navigation.navigate(Paramedic.pnsSelectTest,{barcode:scanResult.data,
        orderId: props.route.params.orderId,crmId:props.route.params.crmId});
    }
    return;
  };

  return (
    <View style={styles.container}>
      <StatusBar
        barStyle="dark-content"
        hidden={false}
        translucent={true}
      />
      {camera === true ? (
        <RNCamera
        // ref={ref => {
        //   camera = ref;
        // }}
          defaultTouchToFocus
          captureAudio={false}
          flashMode={RNCamera.Constants.FlashMode.auto}
          mirrorImage={false}
          onBarCodeRead={onBarCodeRead.bind(this)}
          onFocusChanged={() => {}}
          onZoomChanged={() => {}}
          // permissionDialogTitle={'Permission to use RNCamera'}
          // permissionDialogMessage={'We need your permission to use your RNCamera phone'}
          style={styles.preview}
          type={RNCamera.Constants.Type.back}>
          <BarcodeMask
            width={wp('80%')}
            height={hp('20%')}
            edgeColor={'red'}
            showAnimatedLine={true}
            animatedLineColor={'red'}
            edgeBorderWidth={2}
          />
        </RNCamera>
      ) : null}

      <Modal
        animationType="slide"
        transparent={true}
        visible={isModalVisible}
        onRequestClose={() => {
          // Alert.alert("Modal has been closed.");
          setisModalVisible(false);
        }}>
        {/* <View style={styles.centeredView}>
          <View style={[styles.modalView, {paddingTop: -20}]}>
            <TouchableOpacity
              style={styles.modalButton}
              onPress={() => {
                //  captureImage('photo')
                setshowcamera(true);
                setisModalVisible(false);
              }}>
              <Text style={styles.textStyle}>Testing</Text>
            </TouchableOpacity>
          </View> 
        </View>*/}
      </Modal>
    </View>
  );
};

const styles = {
  container: {
    flex: 1,
  },
  preview: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlay: {
    position: 'absolute',
    padding: 16,
    right: 0,
    left: 0,
    alignItems: 'center',
  },
  topOverlay: {
    top: 0,
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bottomOverlay: {
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.4)',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  enterBarcodeManualButton: {
    padding: 15,
    backgroundColor: 'white',
    borderRadius: 40,
  },
  scanScreenMessage: {
    fontSize: 14,
    color: 'white',
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'center',
  },
};
export default BarcodeScanner;
