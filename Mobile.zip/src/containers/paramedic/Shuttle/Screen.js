import { placeholder } from '@babel/types';
import React, { useRef } from 'react';
import {
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import Button from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontSize, FontMagneta } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import InnerHeader from '../../../components/InnerHeader';
import DropDown from '../../../components/DropDown';
import CheckCircle from '../../../components/CheckCircle';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import PageNo from '../../../constants/PageNo';
import { watchPosition } from 'react-native-geolocation-service';
import { heightPercentageToDP as hp, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import AppButton from '../../../components/Button';

function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};
function renderItem({ item }) {
  return (
    <View key={item.key} style={styles.cardContainer}>
      <View style={{ paddingVertical: 10 }}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
            paddingHorizontal: 20,
          }}>
          <Text style={styles.cardTitle}>{item.patient_NAME}</Text>
          <CheckCircle length={20} selceted={true} onPress={() => { console.log('No Action') }} />
        </View>
        <View
          style={{
            borderBottomColor: '#dcdcdc',
            borderBottomWidth: 1,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row', paddingHorizontal: 20, }}>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.crm_ID}</Text>
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.cardText}>Samples :</Text>
            <Text style={styles.numberTxt}>{item.total_SAMPLES}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function ShuttleScreen({
  nextButton,
  modalVisible,
  showSuccessModal,
  SuccessModal,
  cancelButton,
  response,
}) {
  return (
    <RootView pageNo={PageNo.paramedic_shuttle}>
      <KeyboardAvoidingView style={styles.container}>
        {response &&
          <FlatList
            data={response.BIOBANK}
            renderItem={renderItem}
            keyExtractor={item => item.id}
          />}
        {/* <TouchableOpacity style={styles.nextButton} onPress={nextButton}>
          <Text style={styles.btnText}>Next</Text>
        </TouchableOpacity> */}
        <AppButton
          title={'Next'}
          buttonStyle={styles.reachedButton}
          onPress={nextButton} />
        <ModalConfirmNumber
          visible={modalVisible}
          title={I18n.t('paramedic.shuttle.shuttle_pickup')}
          message={I18n.t('paramedic.shuttle.shuttle_pickuped')}
          okayHandler={SuccessModal}
          cancelHandler={cancelButton}
          dismissHandler={cancelButton}
        />
        <ModalSuccess
          visible={showSuccessModal}
          title={'Success'}
          message={I18n.t('paramedic.shuttle.shuttle_success')}
          pageNumber={'209'}
        />
      </KeyboardAvoidingView>
    </RootView>
  );
}

ShuttleScreen.prototype = {
  nextButton: PropTypes.func,
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
    width: '100%',
  },
  btnText: {
    fontFamily: Font.regular,
    color: Colors.white,
    fontSize: FontSize.large,
  },
  txt: {
    alignSelf: 'center',
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  containerView: {
    flex: 1,
    justifyContent: "center"
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingVertical: 5,
  },

  amountText: {
    color: Colors.black
  },
  nextButton: {
    backgroundColor: Colors.darkPink,
    width: wp('40%'),
    height: hp('6%'),
    alignSelf: 'center',
    position: 'absolute',
    bottom: hp('1%'),
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  cardContainer: {
    borderRadius: 10,
    marginHorizontal: 20,
    marginTop: 20,
    minHeight: 120,
    justifyContent: 'center',
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: '85%',
    alignSelf: 'center',
    marginBottom: '2%',
  },
  cardTitle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: 5,
  },
  numberTxt: { fontFamily: FontMagneta.medium, color: Colors.black },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.darkPink,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('1%'),
    position: 'absolute',
    borderRadius: 40,
  },
});

export default ShuttleScreen;
