import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import ShuttleScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import Modal from '../../../components/ModalCalendar';
import { floor } from 'react-native-reanimated';
import { BackHandler } from 'react-native';

import {
  updateShuttlePickup,
  getKitsampleHandoverBiodataSelectList,
} from '../../../store/Actions';
import { } from '../../../store/Actions';
import { data } from 'browserslist';
class Shuttle extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      modalVisible: false,
      showSuccessModal: false,
    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentDidMount = () => {
    const data = {
      // userid: this.props.userId,
      paramedicid: this.props.route.params.userId,
      orderids: this.props.route.params.shuttledata,
    };
     this.props.GetSelectList(data, this.props.accessToken);
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  componentWillUnmount() { this.back.remove(); }
  componentDidUpdate = prevProps => {
    if (
      prevProps.shuttleUpdateStatus == true &&
      this.props.shuttleUpdateStatus != prevProps.shuttleUpdateStatus
    ) {
      try {
        this.setState({ showSuccessModal: true });
        this.setState({ modalVisible: false });
        setTimeout(() => {
          this.setState({ showSuccessModal: false });
          this.props.navigation.navigate(Paramedic.home);
        }, 2000);
      } catch (error) { }
    }
  };

  nextButton = () => {
    this.setState({ modalVisible: true });
  };
  SuccessModal = () => {
    const data = {
      userid: this.props.userId,
      orderids: this.props.route.params.shuttledata,
    };
    this.props.shuttlepickup(data, this.props.accessToken);
    // this.setState({showSuccessModal: true});
    // this.setState({modalVisible: false});
    // setTimeout(() => {
    //   this.setState({showSuccessModal: false});
    //   this.props.navigation.navigate(Paramedic.home);
    // }, 2000);
  };
  cancelButton = () => {
    this.setState({ modalVisible: false });
  };
  render() {
    return (
      <ShuttleScreen
        nextButton={this.nextButton}
        modalVisible={this.state.modalVisible}
        showSuccessModal={this.state.showSuccessModal}
        SuccessModal={this.SuccessModal}
        cancelButton={this.cancelButton}
        response={this.props.response}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.kitsampleHandoverBiodata.message,
    accessToken: state.signIn.accessToken,
    shuttleUpdateLoading: state.shuttledetailupdate.shuttleUpdateLoading,
    shuttleUpdateStatus: state.shuttledetailupdate.shuttleUpdateStatus,
    shuttleUpdateError: state.shuttledetailupdate.shuttleUpdateError,
    response: state.kitsampleselectlist.response,
    userId: state.signIn.userId,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    shuttlepickup: (data, token) => dispatch(updateShuttlePickup(data, token)),
    GetSelectList: (data, token) =>
      dispatch(getKitsampleHandoverBiodataSelectList(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Shuttle);
