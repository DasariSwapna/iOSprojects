import React, {useRef} from 'react';
import {
  Image,
  Text,
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontSize, FontMagneta} from '../../../config/Fonts';
import Images from '../../../constants/Images';
import CheckCircle from '../../../components/CheckCircle';
import DropDownMenu from '../../../components/DropDownMenu';
import AppButton from '../../../components/Button';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import MyTaskHeader from '../../../components/MyTaskHeader';
import PageNo from '../../../constants/PageNo';
import Icons from '../../../constants/Icons';
const cashDeposite = [
  {
    label: I18n.t('paramedic.deposit.deliver_re'),
    value: I18n.t('paramedic.deposit.deliver_re'),
  },
  {
    label: I18n.t('paramedic.deposit.deliver_bank'),
    value: I18n.t('paramedic.deposit.deliver_bank'),
  },
];
function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{width: '48%', alignItems: 'flex-end'}}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{width: '48%', alignItems: 'flex-start'}}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function RenderItem({item, radioPress}) {
  return (
    <View style={styles.pendingCard}>
      <View style={styles.pendingView}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
            paddingHorizontal: wp('4%'),
          }}>
          <Text style={styles.cardTitle}>{item.item.LC_VD_HOSPITALNAME}</Text>
          <CheckCircle
            length={20}
            onPress={() => radioPress(item.item)}
            selceted={item.item.selected}
          />
        </View>
        <View style={[styles.borderLine]} />
        <View style={[styles.row, {paddingHorizontal: wp('4%')}]}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.item.LC_PYD_CRMID}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Amount :</Text>
            <Text style={styles.numberTxt}>{item.item.LC_PYD_AMOUNT}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function RendercompletedItem({item}) {
  return (
    <View key={item.key} style={styles.pendingCard}>
      <View style={styles.pendingView}>
        <View
          style={{
            paddingHorizontal: wp('4%'),
          }}>
          <Text style={styles.cardTitle}>{item.item.LC_VD_HOSPITALNAME}</Text>
        </View>
        <View style={[styles.borderLine, {marginBottom: hp('1%')}]} />
        <View style={[styles.row, {paddingHorizontal: wp('4%')}]}>
          <View style={[styles.borderLine]} />

          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.item.LC_PYD_CRMID}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Total Amount :</Text>
            <Text style={styles.numberTxt}>{item.item.LC_PYD_AMOUNT}</Text>
          </View>
        </View>
        <View style={[styles.row, {paddingHorizontal: wp('4%')}]}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Date :</Text>
            <Text style={styles.numberTxt}>{item.item.Handover_Date}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Time :</Text>
            <Text style={styles.numberTxt}>{item.item.Handover_Time}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function DepositScreen({
  isPending,
  pendingState,
  completedState,
  generateQR,
  dropdownValue,
  dropdownoption,
  radioPress,
  radio,
  nextNavigation,
  pendingResponse,
  response,
  taskCount,
}) {
  return (
    <RootView pageNo={PageNo.paramedic_deposit}>
      <KeyboardAvoidingView style={styles.mainContainer}>
        <View style={{flex: 1}}>
          <View style={styles.depositContainer}>
            <MyTaskHeader
              title={'Cash deposit'}
              textColor={Colors.darkBlue}
              imageSource={Icons.cash}
              numberOfTask={taskCount == '' ? '0' : taskCount}
              textTask={'Tasks'}
              image={'req'}
            />
          </View>

          <DropDownMenu
            labelName={I18n.t('paramedic.deposit.select_cd_type')}
            labelKey={'label'}
            valueKey={'value'}
            listItems={cashDeposite}
            valueChangeHandler={dropdownoption}
          />
          <View style={{flex: 1}}>
            {dropdownValue != '' && (
              <View>
                <View
                  style={{
                    flexDirection: 'row',
                    justifyContent: 'center',
                    marginTop: hp('4%'),
                  }}>
                  <TouchableOpacity
                    style={{alignItems: 'center'}}
                    onPress={pendingState}>
                    <Text
                      style={[
                        styles.pending_CompletedText,
                        {color: isPending == 0 ? Colors.black : Colors.border},
                      ]}>
                      Pending
                    </Text>
                    {isPending == 0 ? (
                      <View style={styles.highliteLine} />
                    ) : null}
                  </TouchableOpacity>
                  <View style={{borderLeftWidth: 1, height: 25}} />
                  <TouchableOpacity
                    style={{alignItems: 'center'}}
                    onPress={completedState}>
                    <Text
                      style={[
                        styles.pending_CompletedText,
                        {color: isPending == 1 ? Colors.black : Colors.border},
                      ]}>
                      Completed
                    </Text>
                    {isPending == 1 ? (
                      <View style={styles.highliteLine} />
                    ) : null}
                  </TouchableOpacity>
                </View>
                <View
                  style={{borderBottomWidth: 0.3, borderColor: Colors.dWhite}}
                />
                <View style={{alignItems: 'center', justifyContent: 'center'}}>
                  {isPending == 0 ? (
                    pendingResponse == '' ? (
                      <View
                        style={{
                          alignItems: 'center',
                          justifyContent: 'center',
                          height: hp('52%'),
                        }}>
                        <Text
                          style={{
                            alignItems: 'center',
                            justifyContent: 'space-evenly',
                            color: Colors.black,
                            fontSize: hp('2.5%'),
                            fontFamily: Font.extraBold,
                            alignSelf: 'center',
                          }}>
                          No data found
                        </Text>
                      </View>
                    ) : (
                      <FlatList
                        style={{height: hp('52%')}}
                        data={pendingResponse}
                        extraData={pendingResponse}
                        renderItem={item => (
                          <RenderItem item={item} radioPress={radioPress} />
                        )}
                        keyExtractor={item => item.id}
                      />
                    )
                  ) : response.properties.Completed == [] ? (
                    <View
                      style={{
                        alignItems: 'center',
                        justifyContent: 'center',
                        height: hp('52%'),
                      }}>
                      <Text
                        style={{
                          alignItems: 'center',
                          justifyContent: 'space-evenly',
                          color: Colors.black,
                          fontSize: hp('2.5%'),
                          fontFamily: Font.extraBold,
                          alignSelf: 'center',
                        }}>
                        No data found
                      </Text>
                    </View>
                  ) : (
                    <FlatList
                      style={{height: hp('52%')}}
                      data={response.properties.Completed}
                      extraData={response.properties.Completed}
                      renderItem={item => (
                        <RendercompletedItem
                          item={item}
                          radioPress={radioPress}
                        />
                      )}
                      keyExtractor={item => item.id}
                    />
                  )}
                </View>
              </View>
            )}
          </View>
        </View>

        <View style={{height: hp('7%'), backgroundColor: Colors.white}}>
          {radio == true ? (
            dropdownValue == I18n.t('paramedic.deposit.deliver_re') ? (
              isPending == 0 ? (
                <AppButton
                  title={I18n.t('paramedic.deposit.generate_qr')}
                  buttonStyle={styles.reachedButton}
                  onPress={generateQR}
                />
              ) : null
            ) : dropdownValue == I18n.t('paramedic.deposit.deliver_bank') ? (
              isPending == 0 ? (
                <AppButton
                  title={'Next'}
                  buttonStyle={styles.reachedButton}
                  onPress={nextNavigation}
                />
              ) : null
            ) : null
          ) : null}
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

DepositScreen.prototype = {
  isPending: PropTypes.string,
  pendingState: PropTypes.func,
  completedState: PropTypes.func,
  generateQR: PropTypes.func,
  dropdownoption: PropTypes.func,
  dropdownValue: PropTypes.string,
  radio: PropTypes.bool,
  radioPress: PropTypes.func,
  nextNavigation: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },

  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  flex: {
    flex: 1,
    marginBottom: hp('2%'),
  },
  buttonText: {
    fontFamily: Font.regular,
    color: Colors.background,
    fontSize: FontSize.large,
  },
  buttonStyle: {
    backgroundColor: Colors.button,
    width: '40%',
    height: '8%',
    alignSelf: 'center',
    position: 'absolute',
    bottom: 15,
    borderRadius: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pending_CompletedText: {
    paddingHorizontal: wp('5%'),
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
  },
  cardTitle: {
    paddingVertical: hp('2%'),
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
  },
  cashText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.darkBlue,
  },
  taskText: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  depositCircle: {
    width: hp('7.5%'),
    height: hp('7.5%'),
    marginHorizontal: wp('2%'),
    resizeMode: 'contain',
  },
  depositContainer: {
    alignItems: 'center',
    alignSelf: 'center',
    paddingTop: hp('2%'),
  },
  dropDownView: {
    alignItems: 'center',
    width: '80%',
    alignSelf: 'center',
  },
  pendingCard: {
    borderRadius: 10,
    marginVertical: hp('2%'),
    justifyContent: 'center',
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: {width: 1, height: 1},
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: wp('85%'),
    alignSelf: 'center',
    marginHorizontal: hp('4%'),
    minHeight: hp('15%'),
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.thin,
    color: Colors.border,
    paddingVertical: 5,
  },
  numberTxt: {
    fontFamily: FontMagneta.medium,
    color: Colors.black,
    fontSize: FontSize.regular,
    marginTop: hp('0.2%'),
  },
  row: {
    flexDirection: 'row',
  },
  highliteLine: {
    borderBottomWidth: 2,
    width: 50,
    marginTop: 20,
    borderColor: Colors.border,
  },
  pendingView: {},
  borderLine: {
    borderBottomColor: Colors.border,
    borderBottomWidth: 0.2,
  },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('0%'),
  },
});

export default DepositScreen;
