import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import DepositScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import { getDepositCash } from '../../../store/Actions';
import { BackHandler } from 'react-native';
var Qrcode = '';

class Deposit extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      isValidUsername: true,
      isValidPassword: true,
      showToast: false,
      isPending: 0,
      dropdownValue: '',
      radio: false,
      pendingResponse: '',
      completedResponse: '',
      taskCount: ''
    };
  }
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };


  componentDidMount = () => {
    const data = {
      userid: this.props.userId,
    };
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.getDepositCash(data, this.props.accessToken);
    });

    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.cashDepositStatus == false &&
      this.props.cashDepositStatus != prevProps.cashDepositStatus
    ) {
      try {

        const data = this.props.response.properties.Pending.map(item => {
          item.selected = false;
          return item;
        });
        this.setState({ pendingResponse: data, taskCount: data.length });
      } catch (error) { }
    }
  };
  componentWillUnmount() {
    this.back.remove();
    this._unsubscribe();
  }
  pendingState = val => {
    this.setState({
      isPending: 0,
    });
  };
  completedState = val => {
    this.setState({
      isPending: 1,
    });
  };
  dropdownoption = val => {
    this.setState({
      dropdownValue: val,
    });
  };
  generateQr = () => {
    var amount = 0
    var qrvalue = [];
    for (var i = 0; i < this.state.pendingResponse.length; i++) {
      if (this.state.pendingResponse[i].selected == true) {
        qrvalue.push(this.state.pendingResponse[i].LC_PYD_ORDERID);
        amount = amount + this.state.pendingResponse[i].LC_PYD_AMOUNT
      }
    }

    var Qrcode = qrvalue.toString() + '|' + this.props.userId;
    this.props.navigation.navigate(Paramedic.depositQr, {
      Qrcode: Qrcode,
      amt: amount
    });
  };
  radioPress = itemList => {
    this.setState({
      radio: true,
    });
    const newData = this.state.pendingResponse.map(item => {
      if (item.LC_PYD_CRMID == itemList.LC_PYD_CRMID) {
        return {
          ...item,
          selected: !item.selected,
        };
      }
      return item;
    });
    this.setState({ pendingResponse: newData });
  };
  nextNavigation = () => {
    var qrvalue = [];

    for (var i = 0; i < this.state.pendingResponse.length; i++) {
      if (this.state.pendingResponse[i].selected == true) {
        qrvalue.push(this.state.pendingResponse[i].LC_PYD_ORDERID);

      }
    }

    Qrcode = qrvalue.toString() + '|' + this.props.userId;
    var qrString = Qrcode;

    var userIDSpliting = qrString.split('|');
    var orderIdSpliting = userIDSpliting[0].split(',');
    var orderid = [];
    orderIdSpliting &&
      orderIdSpliting.map(item => {
        const obj = {};
        obj.orderid = Number(item);
        orderid.push(obj);
      });

    this.props.navigation.navigate(Paramedic.depositBankCalendar, {
      orderId: orderid,
    });
  };
  render() {
    return (
      <DepositScreen
        isPending={this.state.isPending}
        dropdownValue={this.state.dropdownValue}
        radio={this.state.radio}
        pendingState={this.pendingState}
        completedState={this.completedState}
        dropdownoption={this.dropdownoption}
        generateQR={this.generateQr}
        radioPress={this.radioPress}
        nextNavigation={this.nextNavigation}
        pendingResponse={this.state.pendingResponse}
        response={this.props.response}
        taskCount={this.state.taskCount}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    userId: state.signIn.userId,
    response: state.depositCash.response,
    cashDepositLoading: state.depositCash.cashDepositLoading,
    cashDepositStatus: state.depositCash.cashDepositStatus,
    cashDepositError: state.depositCash.cashDepositError,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getDepositCash: (data, token) => dispatch(getDepositCash(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Deposit);
