import React from 'react';
import { connect } from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import KitSampleHanoverScreen from './Screen';
import { Paramedic } from '../../../navigations/RouteTypes';
import {
  getKitsampleHanoverBiodata,
  getDropdownMode,
} from '../../../store/Actions';
import QRCode from 'react-native-qrcode-svg';
import { BackHandler } from 'react-native';
var qrvalue = [];
var Qrcode = '';
class KitSampleHanover extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      isValidUsername: true,
      isValidPassword: true,
      showToast: false,
      isPending: 0,
      dropdownValue: '',
      radio: false,
      dropdown: false,
      callBack: '',
      data: '',
      Diagnostics: '',
      Biobank: '',
      Qrcode: '',
      orderId: '',
      task: '',
      biotask: '',
      completed: ''
    };
    this.dataRender = this.dataRender.bind(this)
  }

  componentDidMount = () => {
    // Api call for biodata, diagonistic and completed.
    const data = {
      paramedicid: this.props.userId,
    };
    // this.props.getKitsampleHandoverBiodata(data, this.props.accessToken);

    //kit sample hanover mode
    const dropData = {
      search: null,
    };
    // this.props.getHandoveMode(dropData, this.props.accessToken);
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.getKitsampleHandoverBiodata(data, this.props.accessToken);
      this.props.getHandoveMode(dropData, this.props.accessToken);
    });
    this.back = BackHandler.addEventListener('hardwareBackPress', this.backHandler,);
  };
  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };
  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  dataRender = () => {
    const data = this.props.response.DIAGONSIS.map(item => {
      item.selected = false;
      return item;
    });

    this.setState({ Diagnostics: data, task: data.length });
    console.log(this.state.Diagnostics);

    const biodata = this.props.response.BIOBANK.map(item => {
      item.selected = false;
      return item;
    });
    this.setState({ Biobank: biodata, biotask: biodata.length });
    console.log(this.state.Biobank);
    const completed = this.props.response.COMPLETED.map(item => {
      return item;
    });
    this.setState({ completed: completed.length });
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.kitsampleHandoverBiodataStatus == false &&
      this.props.kitsampleHandoverBiodataStatus !=
      prevProps.kitsampleHandoverBiodataStatus
    ) {
      try {
        this.dataRender()
        // const data = this.props.response.DIAGONSIS.map(item => {
        //   item.selected = false;
        //   return item;
        // });
        // this.setState({ Diagnostics: data });
        // console.log(this.state.Diagnostics);
        // const biodata = this.props.response.BIOBANK.map(item => {
        //   item.selected = false;
        //   return item;
        // });
        // this.setState({ Biobank: biodata });
        // console.log(this.state.Biobank);
      } catch (error) { }
    }
  };

  bioState = val => {
    this.setState({
      isPending: 0,
    });
  };
  diagnosticsState = val => {
    this.setState({
      isPending: 1,
    });
  };
  completedState = val => {
    this.setState({
      isPending: 2,
    });
  };
  dropdownoption = val => {
    this.setState({
      dropdownValue: val,
    });
  };
  generateQr = () => {
    this.props.navigation.navigate(Paramedic.depositQr);
  };
  radioPress = itemList => {
    this.setState({
      radio: true,
    });
    if (this.state.isPending == 1) {
      const newData = this.state.Diagnostics.map(item => {
        if (item.crm_ID == itemList.crm_ID) {
          return {
            ...item,
            selected: !item.selected,
          };
        }
        return item;
      });
      this.setState({ Diagnostics: newData });
    } else if (this.state.isPending == 0) {
      const newData = this.state.Biobank.map(item => {
        if (item.crm_ID == itemList.crm_ID) {
          return {
            ...item,
            selected: !item.selected,
          };
        }
        return item;
      });
      this.setState({ Biobank: newData });
    }
  };
  nextNavigation = () => {
    this.setState({
      dropdown: !this.state.dropdown,
    });
    this.setState({
      Qrcode: '',
    });
    qrvalue = [];
    if (this.state.isPending == 1) {
      for (var i = 0; i < this.state.Diagnostics.length; i++) {
        if (this.state.Diagnostics[i].selected == true) {
          qrvalue.push(this.state.Diagnostics[i].orderid);
        }
      }
    } else if (this.state.isPending == 0) {
      for (var i = 0; i < this.state.Biobank.length; i++) {
        if (this.state.Biobank[i].selected == true) {
          qrvalue.push(this.state.Biobank[i].orderid);
        }
      }
    }

    // this.setState(
    //   {
    //     Qrcode: qrvalue.toString() + '|' + this.props.userId,
    //   },
    //   () => console.log('teststtt', this.state.Qrcode),
    // );
    Qrcode = qrvalue.toString() + '|' + this.props.userId;
    //  alert(Qrcode)
    var qrString = Qrcode;

    var userIDSpliting = qrString.split('|');
    var orderIdSpliting = userIDSpliting[0].split(',');
    var orderid = [];
    orderIdSpliting &&
      orderIdSpliting.map(item => {
        const obj = {};
        obj.orderid = Number(item);
        orderid.push(obj);
      });

    this.setState({ orderId: orderid });
  };
  callBack = val => {
    this.setState({
      callBack: val.title,
    });
    this.setState({
      dropdown: false,
    });

    {
      val.lc_TC_TASK_NAME == 'Runner'
        ? this.props.navigation.navigate(Paramedic.kitsampleQr, {
          Qrcode: Qrcode,
        })
        : val.lc_TC_TASK_NAME == 'Center'
          ? this.props.navigation.navigate(Paramedic.kitsampleCenter, {
            orderiD: this.state.orderId,
          })
          : val.lc_TC_TASK_NAME == 'Lab'
            ? this.props.navigation.navigate(Paramedic.kitsampleLab, {
              orderiD: this.state.orderId,
            })
            : val.lc_TC_TASK_NAME == 'Courier'
              ? this.props.navigation.navigate(Paramedic.kitSampleCourier, {
                orderiD: this.state.orderId,
              })
              : null;
    }
  };
  dissmisDropdown = () => {
    this.setState({
      dropdown: false,
    });
  }
  render() {
    return (
      <KitSampleHanoverScreen
        loading={this.props.kitsampleHandoverBiodataLoading}
        isPending={this.state.isPending}
        dropdownValue={this.state.dropdownValue}
        radio={this.state.radio}
        pendingState={this.pendingState}
        response={this.props.response}
        handoverModeResponse={this.props.handoverModeResponse}
        Diagnostics={this.state.Diagnostics}
        dropdown={this.state.dropdown}
        Biobank={this.state.Biobank}
        bioState={this.bioState}
        callBack={this.callBack}
        generateQR={this.generateQr}
        radioPress={this.radioPress}
        completedState={this.completedState}
        dropdownoption={this.dropdownoption}
        nextNavigation={this.nextNavigation}
        diagnosticsState={this.diagnosticsState}
        task={this.state.task}
        biotask={this.state.biotask}
        completed={this.state.completed}
        dissmisDropdown={this.dissmisDropdown}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.kitsampleHandoverBiodata.message,
    userId: state.signIn.userId,
    accessToken: state.signIn.accessToken,
    kitsampleHandoverBiodataLoading:
      state.kitsampleHandoverBiodata.kitsampleHandoverBiodataLoading,
    kitsampleHandoverBiodataStatus:
      state.kitsampleHandoverBiodata.kitsampleHandoverBiodataStatus,
    kitsampleHandoverBiodataError:
      state.kitsampleHandoverBiodata.kitsampleHandoverBiodataError,
    kitsampleHandoverBiodataSelectlistLoading:
      state.kitsampleselectlist.kitsampleHandoverBiodataSelectlistLoading,
    kitsampleHandoverBiodataSelectlistStatus:
      state.kitsampleselectlist.kitsampleHandoverBiodataSelectlistStatus,
    kitsampleHandoverBiodataSelectlistError:
      state.kitsampleselectlist.kitsampleHandoverBiodataSelectlistError,
    response: state.kitsampleHandoverBiodata.response,
    handoverModeResponse: state.kitsampleHandoverBiodata.handoverModeresponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getKitsampleHandoverBiodata: (data, token) =>
      dispatch(getKitsampleHanoverBiodata(data, token)),
    getHandoveMode: (data, token) => dispatch(getDropdownMode(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(KitSampleHanover);
