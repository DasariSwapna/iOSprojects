import { placeholder } from '@babel/types';
import React, { useRef } from 'react';
import {
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../../locale/i18n';
import Button from '../../../components/Button';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Images';
import CheckCircle from '../../../components/CheckCircle';
import Icons from '../../../constants/Icons';
import DropdownModal from '../../../components/DropdownModal';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import MyTaskHeader from '../../../components/MyTaskHeader';
import PageNo from '../../../constants/PageNo';

function Footer() {
  return (
    <View style={styles.footerContainer}>
      <View>
        <Text style={styles.poweredby}>Powered by</Text>
      </View>
      <View style={styles.footerLogoContainer}>
        <View style={{ width: '48%', alignItems: 'flex-end' }}>
          <Image source={Images.iSolveLogo} style={styles.iSolveLogo} />
        </View>
        <View style={styles.seperator} />
        <View style={{ width: '48%', alignItems: 'flex-start' }}>
          <Image source={Images.voilaLogo} style={styles.voilaLogo} />
        </View>
      </View>
    </View>
  );
}

Footer.prototype = {};

function RenderItem({ item, radioPress }) {
  return (
    <View style={styles.pendingCard}>
      <View style={styles.cardSpace}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
          }}>
          <Text style={styles.cardTitle}>{item.item.client_NAME}</Text>
          <CheckCircle
            length={20}
            onPress={() => radioPress(item.item)}
            selceted={item.item.selected}
          />
        </View>
        <View
          style={{
            borderBottomColor: Colors.dWhite,
            borderBottomWidth: 0.6,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.item.crm_ID}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Samples :</Text>
            <Text style={styles.numberTxt}>{item.item.total_SAMPLES}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}

function RenderDiaItem({ item, radioPress }) {
  return (
    <View style={styles.pendingCard}>
      <View style={styles.cardSpace}>
        <View
          style={{
            flexDirection: 'row',
            flex: 1,
            justifyContent: 'space-between',
          }}>
          <Text style={styles.cardTitle}>{item.item.client_NAME}</Text>
          <CheckCircle
            length={20}
            onPress={() => radioPress(item.item)}
            selceted={item.item.selected}
          />
        </View>
        <View
          style={{
            borderBottomColor: Colors.dWhite,
            borderBottomWidth: 0.6,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.item.crm_ID}</Text>
          </View>
          <View style={[styles.flex]}>
            <Text style={styles.cardText}>Samples :</Text>
            <Text style={styles.numberTxt}>{item.item.total_SAMPLES}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function RendercompletedItem({ item, radioPress }) {
  return (
    <View key={item.key} style={styles.pendingCard}>
      <View style={styles.cardSpace}>
        <Text style={styles.cardTitle}>{item.item.client_NAME}</Text>
        <View
          style={{
            borderBottomColor: Colors.dWhite,
            borderBottomWidth: 0.6,
            marginVertical: 5,
          }}
        />
        <View style={{ flexDirection: 'row' }}>
          <View style={styles.flex}>
            <Text style={styles.cardText}>CRM ID :</Text>
            <Text style={styles.numberTxt}>{item.item.crm_ID}</Text>
          </View>
          <View style={[styles.flex, { paddingHorizontal: wp('1%') }]}>
            <Text style={styles.cardText}>Samples : </Text>
            <Text style={styles.numberTxt}>{item.item.total_SAMPLES}</Text>
          </View>
        </View>
        <View style={{ flexDirection: 'row' }}>
          <View style={[styles.flex]}>
            <Text style={styles.cardText}>Date :</Text>
            <Text style={styles.numberTxt}>{item.item.completed_DATE}</Text>
          </View>
          <View style={styles.flex}>
            <Text style={styles.cardText}>Time :</Text>
            <Text style={styles.numberTxt}>{item.item.completed_TIME}</Text>
          </View>
        </View>
      </View>
    </View>
  );
}
function DepositScreen({
  isPending,
  pendingState,
  completedState,
  generateQR,
  dropdownValue,
  dropdownoption,
  radioPress,
  radio,
  nextNavigation,
  bioState,
  diagnosticsState,
  dropdown,
  callBack,
  response,
  handoverModeResponse,
  Diagnostics,
  Biobank,
  loading,
  task,
  biotask,
  completed,
  dissmisDropdown
}) {
  return (
    <RootView pageNo={PageNo.paramedic_kitSampleHandover} loading={loading}>
      <KeyboardAvoidingView style={styles.mainContainer}>
        <View style={styles.depositContainer}>
          <MyTaskHeader
            title={'Kit / Sample Handover'}
            textColor={Colors.border}
            imageSource={Icons.kit}
            numberOfTask={isPending == 0 ? biotask : isPending == 1 ? task : completed}
            textTask={'Tasks'}
            image={"req"}
          />
        </View>
        <View style={{ flex: 1 }}>
          <View
            style={{
              flexDirection: 'row',
              justifyContent: 'center',
              marginTop: 20,
            }}>
            <TouchableOpacity style={{ alignItems: 'center' }} onPress={bioState}>
              <Text
                style={[
                  styles.pending_CompletedText,
                  { color: isPending == 0 ? Colors.black : Colors.border },
                ]}>
                Bio banks
              </Text>
              {isPending == 0 ? <View style={styles.highliteLine} /> : null}
            </TouchableOpacity>
            <View style={{ borderLeftWidth: 1, height: 25 }} />
            <TouchableOpacity
              style={{ alignItems: 'center' }}
              onPress={diagnosticsState}>
              <Text
                style={[
                  styles.pending_CompletedText,
                  { color: isPending == 1 ? Colors.black : Colors.border },
                ]}>
                Diagnostics
              </Text>
              {isPending == 1 ? <View style={styles.highliteLine} /> : null}
            </TouchableOpacity>
            <View style={{ borderLeftWidth: 1, height: 25 }} />
            <TouchableOpacity
              style={{ alignItems: 'center' }}
              onPress={completedState}>
              <Text
                style={[
                  styles.pending_CompletedText,
                  { color: isPending == 2 ? Colors.black : Colors.border },
                ]}>
                Completed
              </Text>
              {isPending == 2 ? <View style={styles.highliteLine} /> : null}
            </TouchableOpacity>
          </View>
          <View style={{ borderBottomWidth: 0.3, borderColor: '#D3D3D3' }} />
          <View style={{ marginBottom: hp('17%') }}>
            {response != null && response != undefined && response != {} ? (
              isPending == 0 ? (
                response.BIOBANK != '' ? (
                  <FlatList
                    data={Biobank}
                    extraData={Biobank}
                    // data={response.BIOBANK}
                    renderItem={item => (
                      <RenderItem item={item} radioPress={radioPress} />
                    )}
                  />
                ) : (
                  <View style={styles.textCenter}>
                    <Text style={styles.nodata}>No data found</Text>
                  </View>
                )
              ) : isPending == 1 ? (
                response.DIAGONSIS != '' ? (
                  <FlatList
                    data={Diagnostics}
                    extraData={Diagnostics}
                    // data={response.DIAGONSIS}
                    renderItem={item => (
                      <RenderDiaItem item={item} radioPress={radioPress} />
                    )}
                  />
                ) : (
                  <View style={styles.textCenter}>
                    <Text style={styles.nodata}>No data found</Text>
                  </View>
                )
              ) : response.COMPLETED != '' ? (
                <FlatList
                  data={response.COMPLETED}
                  renderItem={item => (
                    <RendercompletedItem item={item} radioPress={radioPress} />
                  )}
                />
              ) : (
                <View style={styles.textCenter}>
                  <Text style={styles.nodata}>No data found</Text>
                </View>
              )
            ) : null}
          </View>
          {isPending == 0 || isPending == 1 ? (
            radio == true ? (
              <View
                style={{
                  flex: 1,
                  alignItems: 'center',
                  backgroundColor: "#ffffff",
                  position: 'absolute',
                  bottom: 0,
                  justifyContent: 'space-evenly',
                  alignSelf: 'center',
                  width: wp('100%')
                }}>
                <View style={styles.buttonCont}>
                  <Button
                    buttonStyle={styles.reachedButton}
                    title="Next"
                    buttonTextStyle={{ fontSize: FontSize.large }}
                    onPress={nextNavigation}
                  />
                </View>
              </View>
            ) : null
          ) : null}
        </View>
      </KeyboardAvoidingView>
      <DropdownModal
        visible={dropdown}
        otpDismissHandler={dissmisDropdown}
        title={I18n.t('paramedic.kitSampleHandover.kit_handover')}
        //If enabling api data need to use this data
        // data={handoverModeResponse}
        data={[
          {
            id: 1,
            lc_TC_TASK_NAME: 'Runner',
          },
          {
            id: 2,
            lc_TC_TASK_NAME: 'Center',
          },
          {
            id: 3,
            lc_TC_TASK_NAME: 'Courier',
          },
          {
            id: 4,
            lc_TC_TASK_NAME: 'Lab',
          },
        ]}
        callBack={callBack}
      />
    </RootView>
  );
}

DepositScreen.prototype = {
  isPending: PropTypes.string,
  pendingState: PropTypes.func,
  completedState: PropTypes.func,
  generateQR: PropTypes.func,
  dropdownoption: PropTypes.func,
  dropdownValue: PropTypes.string,
};

const styles = StyleSheet.create({
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  flex: {
    flex: 1,
    paddingTop: hp('1%')
  },
  buttonText: {
    fontFamily: Font.regular,
    color: Colors.background,
    fontSize: FontSize.large,
  },
  pending_CompletedText: {
    paddingHorizontal: 20,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
  },
  cardTitle: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.border,
    paddingVertical: 5,
  },
  highliteLine: {
    borderBottomWidth: 2,
    width: 50,
    marginTop: 20,
    borderColor: Colors.border,
  },

  depositContainer: {
    alignItems: 'center',
    alignSelf: 'center',
    paddingTop: 20,
  },

  pendingCard: {
    borderRadius: 10,
    marginHorizontal: hp('4%'),
    marginVertical: hp('2%'),
    minHeight: hp('15%'),
    justifyContent: 'center',
    backgroundColor: Colors.background,
    shadowColor: Colors.black,
    shadowOffset: { width: 1, height: 1 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 5,
    width: wp('85%'),
    alignSelf: 'center',
  },
  cardText: {
    fontSize: FontSize.medium,
    fontFamily: Font.regular,
    color: Colors.border,
    paddingVertical: 5,
  },
  numberTxt: {
    fontFamily: FontMagneta.medium,
    color: Colors.black,
    fontSize: FontSize.regular,
    marginTop: hp('0.2%'),
  },
  buttonCont: {
    // marginTop: 8,
  },
  nodata: {
    alignItems: 'center',
    justifyContent: 'space-evenly',
    color: Colors.black,
    fontSize: hp('2.5%'),
    fontFamily: Font.extraBold,
    alignSelf: 'center',
  },
  textCenter: {
    alignItems: 'center', justifyContent: 'center', height: hp('56%'),
  },
  cardSpace: {
    paddingHorizontal: wp('6%'),
    paddingVertical: hp('2%')
  },
  reachedButton: {
    width: wp('40%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.button,
    elevation: 2,
    alignSelf: 'center',
    bottom: hp('2%'),
  },
});

export default DepositScreen;
