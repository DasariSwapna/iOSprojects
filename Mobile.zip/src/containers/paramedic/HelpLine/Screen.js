/* eslint-disable react-native/no-inline-styles */
import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontSize} from '../../../config/Fonts';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Feather from 'react-native-vector-icons/Feather';
import Images from '../../../constants/Images';
import {Auth} from '../../../navigations/RouteTypes';
import InnerHeader from '../../../components/InnerHeader';

function HelpLineScreen() {
  return (
    <RootView pageNo={'234'}>
      <InnerHeader headerTitle={'Helpline'} />
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginHorizontal: '10%',
          marginVertical: '2%',
        }}>
        <Text style={styles.landingText}>Srimurugan K A</Text>
        <Text style={styles.landingText}>+919965238730</Text>
        <TouchableOpacity
          onPress={() => this.props.navigation.navigate(Auth.profileStartDay)}>
          <View style={styles.CircleShapeView}>
            <Feather
              name="phone"
              size={15}
              color={Colors.border}
              solid
              style={{textAlign: 'auto'}}
            />
          </View>
        </TouchableOpacity>
      </View>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          alignItems: 'center',
          marginHorizontal: '10%',
          marginVertical: '2%',
        }}>
        <Text style={styles.landingText}>Srimurugan K A</Text>
        <Text style={styles.landingText}>+919965238730</Text>
        <TouchableOpacity
          onPress={() => this.props.navigation.navigate(Auth.profileStartDay)}>
          <View style={styles.CircleShapeView}>
            <Feather
              name="phone"
              size={15}
              color={Colors.border}
              solid
              style={{textAlign: 'auto'}}
            />
          </View>
        </TouchableOpacity>
      </View>
    </RootView>
  );
}

const styles = StyleSheet.create({
  image: {
    height: '105%',
  },
  landingText: {
    color: Colors.border,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    fontWeight: '600',
  },
  CircleShapeView: {
    marginTop: '10%',
    width: 40,
    height: 40,
    borderRadius: 40 / 2,
    borderColor: '#EFDEED',
    borderWidth: 2,
    alignItems: 'center',
    justifyContent: 'center',
  },
});

export default HelpLineScreen;
