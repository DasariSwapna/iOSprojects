import React, { useRef } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  TextInput,
  ScrollView,Image
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { heightPercentageToDP as hp,widthPercentageToDP as wp} from 'react-native-responsive-screen';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import AppButton from '../../../components/Button';
import {Toast} from '../../../components/Toast';
import I18n from '../../../locale/i18n';
import Images from '../../../constants/Icons';
import BarcodeScannerForTieupHospital from '../../../components/BarcodeScannerForTieUpHospital';
function KitScanScreen({showToast,errorMsg,nextClickHandler,onBarCodeRead,camera,barcodeNumber,
  onChangeBarcodeText,barcodeValidationMsg,isValidBarcodeNumber,barcodeScannerClickHandler}) 
  {
//   const Camera=()=>{
//   return (
// <View style={styles.container}>
     
//       {camera === true ? (
//         <RNCamera
//           defaultTouchToFocus
//           captureAudio={false}
//           flashMode={RNCamera.Constants.FlashMode.auto}
//           mirrorImage={false}
//           onBarCodeRead={onBarCodeRead.bind(this)}
//           onFocusChanged={() => {}}
//           onZoomChanged={() => {}}
//           // permissionDialogTitle={'Permission to use RNCamera'}
//           // permissionDialogMessage={'We need your permission to use your RNCamera phone'}
//           style={styles.preview}
//           type={RNCamera.Constants.Type.back}>
//           <BarcodeMask
//             width={wp('70%')}
//             height={hp('15%')}
//             edgeColor={'red'}
//             showAnimatedLine={true}
//             animatedLineColor={'red'}
//             edgeBorderWidth={2}
//           />
//         </RNCamera>
//       ) : null}

       
//     </View>
//   );
// };



  return (
    <RootView pageNo={'25'}>
        <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
  
      <View style={styles.rootView}>
      {camera === true ? (
     <View style={{
         height:hp('100%'),width:wp('100%'),
         justifyContent: 'center',
         alignItems: 'center',
        
     }}>
       <BarcodeScannerForTieupHospital getBarcode={(result) => onBarCodeRead(result)} 
       camera={camera}/>
       </View>
      ) : 
      <>
      <View style={{alignItems:'center',justifyContent:'flex-start',flex:0.9}}>
       <View style={styles.topContainer}>
         <View style={styles.topColOne}>
         <View style={styles.headerTextContainer}>
         <Text style={styles.headerText}>{I18n.t('paramedic.myTask.please_scan_the_kit_barcode_label')}</Text>
         </View>
           </View>
       
       </View>
      <View style={{flexDirection:'row', alignItems:'center',
    justifyContent:'center'}}>
       <View style={styles.barcodeTextContainer}>
       <TextInput 
       placeholder={I18n.t('paramedic.myTask.enter_barcode_label')}
       placeholderTextColor = {Colors.cWhite}
       style={styles.barcodeTextInput}
       maxLength={50}
       value={barcodeNumber}
       onChangeText = {onChangeBarcodeText}
       //onBlur={onChangeBarcodeText}
       />
       
        {!isValidBarcodeNumber && (
              <Text style={styles.textValidationMsg}>
                {!isValidBarcodeNumber ? barcodeValidationMsg : ''}
              </Text>
            )}
       </View>
       <TouchableOpacity style={styles.iconContainer} onPress={barcodeScannerClickHandler}>
                <Image
                  resizeMode={'contain'}
                  source={Images.smallBarcode}
                  style={{ width: wp('10%'), height: hp('5%') }}
                />
              </TouchableOpacity>
              </View>
              </View>
              <View style={{alignItems:'center',justifyContent:'center',flex:0.1}}>
  <View style={{width:wp('100%'),height:hp('6%'),alignItems:'center',justifyContent:'center'}}>
<AppButton title={I18n.t('paramedic.myTask.next_label')} onPress={nextClickHandler} buttonStyle={styles.nextButton}/>
</View>
</View>
</>}
      </View>
     
    </RootView>
  );
}


const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column', 
    alignItems: 'center', 
    justifyContent: 'flex-start'
  },
  topContainer: {
  width:wp('100%'),
  height:hp('10%'),
  padding:wp('3%'),
 
  },
  topColOne:{
    width:wp('88%'),
    height:hp('6%'),
    marginVertical:wp('1%'),
    flexDirection:'row',
    marginHorizontal:wp('3%'),
    alignItems:'center',
    justifyContent:'center'
  },
  headerTextContainer:{
    alignItems:'center',
    justifyContent:'center',
    marginHorizontal:wp('5%')
  },
  headerText:
  {
    fontFamily:Font.extraBold,
    fontSize:FontSize.medium,
    color:Colors.border,
    textAlign:'center'
  },
  barcodeTextInput:
  {
    height:hp('6%'),
    width:wp('65%'),
    borderWidth:1,
    borderRadius:10,
    borderColor:Colors.bWhite,
    paddingHorizontal:wp('3%'),
    alignItems:'center', 
    marginVertical:hp('3%'),
    fontFamily:FontMagneta.semiBold,
    fontSize:FontSize.medium,
    color:Colors.black,
},
barcodeTextContainer:
{
  width:wp('70%'),
  alignItems:'flex-start',
  justifyContent:'center',

 
},
container: {
   height:hp('65%'),
   width:wp('100%'),
   justifyContent: 'center',
   alignItems: 'center',
   backgroundColor:'transparent'
  
},
preview: {
  width:wp('70%'),
  height:hp('60%'),
  justifyContent: 'center',
  alignItems: 'center',
},
nextButton:{
  height: hp('5%'),
  width: wp('38%'),
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: Colors.button,
  elevation: 2,
  borderRadius: 50,
  paddingVertical: 3,
  paddingHorizontal: 10,
  marginHorizontal: 3
},
textValidationMsg: {
  width: '88%',
  color: Colors.button,
  fontFamily: FontMagneta.medium,
  fontSize: FontSize.regular,
  fontWeight: '600',
  alignSelf: 'center',
  paddingHorizontal: 10,
  marginTop:-15
},
iconContainer:
{
  height: hp('5%'),
  width: wp('22%'),
  borderRadius: 50,
  backgroundColor: Colors.vLightGreen,
  alignItems: 'center',
  justifyContent: 'center',
  marginVertical: hp('1%')
},
})


export default KitScanScreen;