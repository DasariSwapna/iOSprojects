import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import KitScanScreen from './Screen';
import {
  barcodeValueEmpty
} from '../../../utils/Validators';
import { delay } from '../../../utils/Helpers';
import {BackHandler} from 'react-native';
const data = []

class KitScan extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      scanCamera: false,
      barcodeNumber: '',
      headerTitle: this.props.route.params.title,
      isValidBarcodeNumber: true,
      barcodeValidationMsg: '',
      showToast: false,
      errorMsg: '',
      productId: this.props.route.params.productId,
      crmId: this.props.route.params.crmId,
      title: this.props.route.params.title,
      orderId: this.props.route.params.orderId,
    };
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  nextClickHandler = () => {
    const valid1 = barcodeValueEmpty(this.state.barcodeNumber);
    if (valid1.val) {
      this.setState({
        isValidBarcodeNumber: valid1.val,
        barcodeValidationMsg: ''
      })
      this.props.navigation.navigate(Paramedic.scanTRF, {
        title: 'Scan TRF',
        message: 'Please capture the purple card',
        barcodeNumber: this.state.barcodeNumber,
        crmId: this.state.crmId,
        orderId: this.state.orderId,
        productId: this.state.productId,
        condition:null
      });
    }
    else {

      this.setState({
        barcodeValidationMsg: valid1.msg,
        isValidBarcodeNumber: valid1.val
      })

    }
  }

  onChangeBarcodeText = val => {
    const validBarcode = val.replace(/[^a-zA-Z0-9- . ]/gm, '');
    this.setState({
      barcodeNumber: validBarcode,
    });
  };

  componentDidMount() {
    this.props.navigation.setOptions({ title: this.state.headerTitle })
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.setState({ scanCamera: false })
    });
   BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );

  }

  backHandler = () => {
    
    if(this.state.scanCamera == true){
      this.setState({scanCamera:false})
    }else{
      this.props.navigation.goBack(null);
    }
    return true;
  };
  componentWillUnmount() {
    this._unsubscribe();
    BackHandler.removeEventListener('hardwareBackPress',this.backHandler);
  }
 

  onBarCodeRead = (scanResult) => {
    console.warn(scanResult.type);
    console.warn(scanResult.data);
    //Alert.alert("Barcode value is" + scanResult.data, "Barcode type is" + scanResult.type);

    if (scanResult.data != null) {
      this.setState({ barcodeNumber: scanResult.data });
      this.setState({ scanCamera: false });
      // this.props.navigation.navigate(Paramedic.samplePickUp);
    }
    return;
  };
  barcodeScannerClickHandler = () => {
    this.setState({
      scanCamera:true
    })
 
  };
  render() {
    return <KitScanScreen
      showToast={this.state.showToast}
      nextClickHandler={this.nextClickHandler}
      onChangeBarcodeText={this.onChangeBarcodeText}
      onBarCodeRead={this.onBarCodeRead}
      camera={this.state.scanCamera}
      isValidBarcodeNumber={this.state.isValidBarcodeNumber}
      barcodeValidationMsg={this.state.barcodeValidationMsg}
      barcodeNumber={this.state.barcodeNumber}
      barcodeScannerClickHandler={this.barcodeScannerClickHandler} />;
  }
}

const mapStateToProps = state => {
  return {
    /// loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(mapStateToProps, mapDispatchToProps)(KitScan);