import React, { useRef } from 'react';
import {
  Image,
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import { heightPercentageToDP as hp,widthPercentageToDP,widthPercentageToDP as wp} from 'react-native-responsive-screen';
import Images from '../../../constants/Icons';
import SearchButtonView from '../../../components/SearchButtonView'
import { FlatList } from 'react-native-gesture-handler';
import AppButton from '../../../components/Button';
import IonIcons from 'react-native-vector-icons/Ionicons';
import MedicalCenterNameView from '../../../components/MedicalCenterNameView';
import MyTaskHeader from '../../../components/MyTaskHeader';
import { VisitFrequencyModal } from '../../../components/VisitFrequencyModal';
import {Toast} from '../../../components/Toast';
import I18n from '../../../locale/i18n';
import {NetworkContext} from '../../../contexts/NetworkContext';
import QrcodeScannerForTieupHospital from '../../../components/QrcodeScannerForTieupHospital';
function TieUpHospitalScreen({ data, visitFrequencyData,cardClickHandler,showModal,cancelModalHandler,visitClickHandler,qrcodeScanner,
  title,imageSrc,taskText,totalCount,titleColor,
loading,showToast,errorMsg,setqrCamera,onQrCodeRead}) {

  const {isConnected} = React.useContext(NetworkContext);

  const renderItem = ({ item }) => (
    <MedicalCenterNameView customerName={item.HOSPITAL_NAME} cardClickHandler={()=>cardClickHandler(item)} />
  )
  const renderNodata=()=>{
    return(
      <>
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontFamily:FontMagneta.bold}}>No data found</Text>
    </View>
    </>
    )
  }
  return (
    <RootView pageNo={'101'} loading={loading} connected={isConnected}>
    {showToast && <Toast
      showToast={showToast}
      msg={errorMsg}
      bgColor={Colors.error}
      txtColor={Colors.background}
    />}
      <View style={styles.rootView}>
      {setqrCamera!=true?
    <>
        <View style={styles.headerContainer}>
          <MyTaskHeader 
          title={title} 
          textColor={titleColor}
          imageSource={imageSrc}
          numberOfTask={totalCount}
          textTask={taskText}
          isQrScannerAvailable={true}
          qrClickHandler={qrcodeScanner}
          />
        </View>
        <View style={styles.tabContainer}>
          <View style={styles.tabRowTwoContainer}>
            <Text style={[styles.textTab, { color: Colors.black }]}>Tie-up hospital regular pickup</Text>
            <View style={[styles.bottomTabLine, { backgroundColor: Colors.border }]} />
          </View>
        </View>
        <View style={styles.flatlistContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.ID}
            contentContainerStyle={styles.flatlistInnerContainer}
            ListEmptyComponent={renderNodata}
          />
        </View>
        <VisitFrequencyModal
         title={'Visit frequency'}
         pageNumber={102}
         visible={showModal}
         data={visitFrequencyData}
         dismissHandler={cancelModalHandler}
         visitClickHandler={(item)=>visitClickHandler(item)}
        />
        </>:
        <View style={{
          height:hp('100%'),width:wp('100%'),
          justifyContent: 'center',
          alignItems: 'center',
         
      }}>
        <QrcodeScannerForTieupHospital getqrcode={(result) => onQrCodeRead(result)} 
        qrcamera={setqrCamera}/>
        </View>}
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column', alignItems: 'flex-start', justifyContent: 'flex-start'
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.tieuphospitalColor
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTab: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  numberOfTaskContainer:{
    flexDirection:'row',
    alignItems:'center',
    justifyContent:'flex-start',
  },
  buttonText: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.background
  },
  bottomTabLine:
  {
    width: '35%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2
  },
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomColor: Colors.card,
    borderBottomWidth: 2,
    marginHorizontal: 10,
    flexDirection: 'row',
    paddingHorizontal: 10, marginTop: '6%'
  },

  headerContainer:
  {
    flexDirection: 'column',
    marginVertical: 20,
    paddingHorizontal: 10
  },


  rowDirection: {
    width: '100%' ,
    flexDirection: 'row',
    alignItems: 'center',
     justifyContent: 'flex-start', 
     
  },


  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10,
    marginRight: '25%'
  },

  tabRowTwoContainer:
  {
    flex: 1,
    alignItems: 'center'
  },

  flatlistContainer:
  { 
      width: '100%', 
      alignItems: 'center', 
      height: '70%' ,
      marginVertical:'3%'
  },
flatlistInnerContainer:
  { 
  flexGrow: 1,
  paddingBottom: 40

},
  flatList:
    {
       flex: 1, 
       width: '100%',
       paddingHorizontal: 10 
      },
      
      
})

export default TieUpHospitalScreen;
