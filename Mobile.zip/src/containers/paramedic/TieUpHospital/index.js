import React from 'react';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
import { mytaskGetTieupHospital, mytaskGetTieupHospitalVisitTime, mytaskGetCrmidOrderidForRegularBeat} from '../../../store/Actions';
import TieUpHospitalScreen from './Screen';
import { delay } from '../../../utils/Helpers';
import { throwStatement } from '@babel/types';
import {BackHandler} from 'react-native';
const data = [
  {
    id: 1,
    customerName: 'Rehman Hospital'
  },
  {
    id: 2,
    customerName: 'Bala clinical laboratory'
  },
  {
    id: 3,
    customerName: 'Alpha diagnostic centre'
  },
  {
    id: 4,
    customerName: 'Joes diagnostic centre'
  },
  {
    id: 5,
    customerName: 'Ramya Nursing home'
  },
  {
    id: 6,
    customerName: 'Udays Laboratory'
  },
];
const visitFrequencyData = [
  {
    id: 1,
    customerName: 'Visit 01 - 10:00'
  },
  {
    id: 2,
    customerName: 'Visit 02 - 10:30'
  },
  {
    id: 3,
    customerName: 'Visit 03 - 11:00'
  },
  {
    id: 4,
    customerName: 'Visit 04 - 11:30'
  },
  {
    id: 5,
    customerName: 'Visit 05 - 12:00'
  },
  {
    id: 6,
    customerName: 'Visit 06 - 12:30'
  },
];
class TieUpHospital extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      showModal:false,
      title: this.props.route.params.title,
      imageSrc: this.props.route.params.imageSrc,
      taskText: this.props.route.params.taskText,
      totalCount: this.props.route.params.totalCount,
      titleColor: this.props.route.params.titleColor,
      productId: this.props.route.params.productId,
      startId: 0,
      showToast: false,
      errorMsg:'',
      data:[],
      visitFrequencyData:[],
      hospitalName:'',
      hospitalId:0,
      setqrCamera:false,qrcodeNumber:''

    };
  }
  initialCall=()=>{
    const data = {
      userid: this.props.UserID
    }
    this.props.onGetTieupHospital(data, this.props.accessToken);
  }
  componentDidMount() {
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.setState({ setqrCamera: false })
      this.initialCall()
    });
   BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  backHandler = () => {
    
    if(this.state.setqrCamera == true){
      this.setState({setqrCamera:false})
    }else{
      this.props.navigation.goBack(null);
    }
    return true;
  };
  componentWillUnmount() {
    this._unsubscribe();
    BackHandler.removeEventListener('hardwareBackPress',this.backHandler);
  }

  visitClickHandler = (item) => {
    this.props.onMytaskGetCrmidOrderidForRegularBeat({
      orderId:null,
      crmId:null
    },this.props.accessToken)
  this.setState({showModal:false})
  this.props.navigation.navigate(Paramedic.regularBeat,{title:'Regular Beat',
// this.props.navigation.navigate(Paramedic.tieupHospitalSampleType,{title:'Regular Beat',
  visitTimeId:item.TIME_ID,
  visitName:item.VISIT_NAME,
  visitTime:item.VISIT_TIME,
  userId:this.props.UserID,
  hospitalName:this.state.hospitalName,
  hospitalId:this.state.hospitalId,
  productId:this.state.productId
});
  };
  cardClickHandler = (item) => {
   // alert(JSON.stringify(item))
   this.setState({
     hospitalId:item.ID,
     hospitalName:item.HOSPITAL_NAME
   })
   const data = {
    "userid": this.props.UserID,
    "hospitalid": item.ID
  }
  this.props.onGetTieupHospitalVisitTime(data, this.props.accessToken);
    //this.setState({showModal:true})
   // this.props.navigation.navigate(Paramedic.tieUpHospital);
  };
  cancelModalHandler = () => {
    this.setState({showModal:false})
   // this.props.navigation.navigate(Paramedic.tieUpHospital);
  };

  qrcodeScanner=()=>{
    this.setState({
      setqrCamera:true
    })
  
  }
  onQrCodeRead = (scanResult) => {
   const qrcode =scanResult.data
      this.setState({
        setqrCamera:false,
        qrcodeNumber: qrcode,
      })

      this.filterDataQrCode(scanResult.data)
  }
filterDataQrCode=(id)=>{
 if(this.props.MytaskGetTieupHospitalResponse.length > 0){
  const filterData = this.props.MytaskGetTieupHospitalResponse.filter((item)=>item.ID == id)
 // alert(JSON.stringify(filterData))
  console.log(filterData==[]||filterData!=""||filterData!=undefined||filterData!=null)
  if(filterData==[]||filterData==""||filterData==undefined||filterData==null){
    this.setState({
      data:this.props.MytaskGetTieupHospitalResponse,
      setqrCamera:false,
    })
    this.setState(
      {
        errorMsg: "Hospial not available",
        showToast: true,
      },
      async () => {
        await delay(2000);
        this.resetValidation();
      },
    );
}
  else{
    this.cardClickHandler(filterData[0])
  }
 }else{
  this.setState({
    data:this.props.MytaskGetTieupHospitalResponse,
    setqrCamera:false,
  })
  this.setState(
    {
      errorMsg: "Hospial not available",
      showToast: true,
    },
    async () => {
      await delay(2000);
      this.resetValidation();
    },
  );
 }
  
}
  
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.MytaskGetTieupHospitalStatus == false &&
      this.props.MytaskGetTieupHospitalStatus != prevProps.MytaskGetTieupHospitalStatus
    ) {
      
      this.setState({ data: this.props.MytaskGetTieupHospitalResponse})
    }
  
    if (
      prevProps.MytaskGetTieupHospitalError == false &&
      this.props.MytaskGetTieupHospitalError != prevProps.MytaskGetTieupHospitalError
    ) this.setState(
      {
        errorMsg: this.props.message,
        showToast: true,
      },
      async () => {
        await delay(2000);
        this.resetValidation();
      },
    );

    if (
      prevProps.MytaskGetTieupHospitalVisitTimeStatus == false &&
      this.props.MytaskGetTieupHospitalVisitTimeStatus != prevProps.MytaskGetTieupHospitalVisitTimeStatus
    ) {
      
      this.setState({ visitFrequencyData: this.props.MytaskGetTieupHospitalVisitTimeResponse})
      this.setState({showModal:true})
    }
  
    if (
      prevProps.MytaskGetTieupHospitalError == false &&
      this.props.MytaskGetTieupHospitalError != prevProps.MytaskGetTieupHospitalError
    ) this.setState(
      {
        errorMsg: this.props.message,
        showToast: true,
      },
      async () => {
        await delay(2000);
        this.resetValidation();
      },
    );

    }

  render() {
    return <TieUpHospitalScreen data={this.state.data}
     visitFrequencyData={this.state.visitFrequencyData}
      cardClickHandler={this.cardClickHandler}
      cancelModalHandler={this.cancelModalHandler}
      visitClickHandler={this.visitClickHandler} 
      showModal={this.state.showModal} 
      qrcodeScanner={this.qrcodeScanner}
      title={this.state.title}
      imageSrc={this.state.imageSrc}
      taskText={this.state.taskText}
      totalCount={this.state.totalCount}
      titleColor={this.state.titleColor}
      startId={this.state.startId}
      loading={this.props.MytaskGetTieupHospitalLoading||this.props.MytaskGetTieupHospitalVisitTimeLoading}
      showToast={this.state.showToast}
      errorMsg={this.state.errorMsg}
      setqrCamera={this.state.setqrCamera}
      onQrCodeRead={this.onQrCodeRead}
      />;
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    MytaskGetTieupHospitalLoading:
      state.mytask.MytaskGetTieupHospitalLoading,
      MytaskGetTieupHospitalStatus:
      state.mytask.MytaskGetTieupHospitalStatus,
      MytaskGetTieupHospitalError:
      state.mytask.MytaskGetTieupHospitalError,
      MytaskGetTieupHospitalResponse:
      state.mytask.MytaskGetTieupHospitalResponse,


      MytaskGetTieupHospitalVisitTimeLoading:
      state.mytask.MytaskGetTieupHospitalVisitTimeLoading,
      MytaskGetTieupHospitalVisitTimeStatus:
      state.mytask.MytaskGetTieupHospitalVisitTimeStatus,
      MytaskGetTieupHospitalVisitTimeError:
      state.mytask.MytaskGetTieupHospitalVisitTimeError,
      MytaskGetTieupHospitalVisitTimeResponse:
      state.mytask.MytaskGetTieupHospitalVisitTimeResponse,

      // MytaskInsertOrderDetailsForRegularBeatLoading:state.mytask.MytaskInsertOrderDetailsForRegularBeatLoading,
      // MytaskInsertOrderDetailsForRegularBeatStatus:state.mytask.MytaskInsertOrderDetailsForRegularBeatStatus,
      // MytaskInsertOrderDetailsForRegularBeatError:state.mytask.MytaskInsertOrderDetailsForRegularBeatError,
      // MytaskInsertOrderDetailsForRegularBeatResponse:state.mytask.MytaskInsertOrderDetailsForRegularBeatResponse,

    // BabyCordPending: state.mytask.mytasklistBabyCordDetailsPending,
    // BabyCordCompleted: state.mytask.mytasklistBabyCordDetailsCompleted,
    // BabyCordCanRes: state.mytask.mytasklistBabyCordDetailsCansRes,
    // UserID: state.signIn.userId,

    // PickupStartLoading: state.mytask.MytaskPickupStartedLoading,
    // PickupStartStatus: state.mytask.MytaskPickupStartedStatus,
    // PickupStartError: state.mytask.MytaskPickupStartedError,

    searchTypeList: state.common.pickupTypeResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetTieupHospital: (data, token) =>
      dispatch(mytaskGetTieupHospital(data, token)),

      onGetTieupHospitalVisitTime: (data, token) =>
      dispatch(mytaskGetTieupHospitalVisitTime(data, token)),

      onMytaskGetCrmidOrderidForRegularBeat: (data, token) =>
      dispatch(mytaskGetCrmidOrderidForRegularBeat(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(TieUpHospital);
