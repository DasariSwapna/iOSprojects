import React, { useRef,useState,useEffect } from 'react';
import {
  Text,
  View,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Platform, Image
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { heightPercentageToDP as hp, widthPercentageToDP, widthPercentageToDP as wp } from 'react-native-responsive-screen';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import { TextInput } from 'react-native-gesture-handler';
import FaIcons from 'react-native-vector-icons/FontAwesome';
import IonIcons from 'react-native-vector-icons/Ionicons';
import AppButton from '../../../components/Button';
import I18n from '../../../locale/i18n';
import { ModalConfirmNumber, ModalSuccess } from '../../../components/OtpModal';
import Images from '../../../constants/Icons';
import { NetworkContext } from '../../../contexts/NetworkContext';
import { Toast } from '../../../components/Toast';
function SamplePickUpScreen({ 
  data, 
  nextClickHandler,
   barcodeScannerClickHandler, 
   addSampleAlert, 
   cancelModalHandler, 
   okayConfirmHandler,
   addClickHandler,
   barcodeNumber,
  onChangeBarcodeText,
  barcodeValidationMsg,
  isValidBarcodeNumber,
  removeClickHandler,
  scanTRFClickHandler,
  sampleCount,
  loading,showToast,errorMsg,
  CustomerName
}) {
  const [completeTRFStatus,setCompleteTRFStatus]=useState(false)
  const [checkSampleNotCollected,setCheckSampleNotCollected]=useState(false)
  const { isConnected } = React.useContext(NetworkContext);
  useEffect(()=>{
    checkTRFCompletedStatus(data)
  },[data])
  // const renderItem = ({ item }) => (
  //   <View style={styles.flatListItemView}>
  //     <View style={styles.mainContainer}>
  //       {item.data != "" ?
  //         <View style={{ flexDirection: 'column' }}>
  //           <Text style={styles.titleText}>{item.title}</Text>
  //           <View style={{ flex: 1 }}>
  //             {item.data.map((data) => (
  //               <>
  //                 <View style={styles.insertBarcodeContainer}>
  //                   <Text style={styles.nameText}>{data.barcode}</Text>
  //                   <Text style={[styles.statusText, { color: data.checktrfstatus == '0' ? Colors.button : Colors.babyCordTextColor }]}>{data.trfstatus}</Text>
  //                   <View style={styles.removeIconContainer}>
  //                     <IonIcons name='remove-circle-outline' size={wp('5%')} style={{ color: Colors.button }} />
  //                   </View>
  //                 </View>
  //                 <View style={styles.bottonLine} />
  //               </>
  //             ))}
  //           </View>
  //           <View style={styles.thickBottonLine} />
  //         </View> :
  //         <View style={{ flexDirection: 'column' }}>
  //           <Text style={styles.sampleNotCollectedText}>{I18n.t('paramedic.myTask.sample_not_collected_label')}</Text>
  //           <View style={styles.nacFlowContainer}>
  //             <Text style={styles.nacFlowTitleText}>{item.title}</Text>
  //           </View>
  //         </View>
  //       }
  //     </View>
  //   </View>
  // )

 const checkTRFCompletedStatus=(data)=>{
     data&& data.map((item)=>{
       item && item.data.map((innerItem)=>{
         if(item.title!=null && innerItem.status==1){
           setCompleteTRFStatus(true)
         }
        })
    }
     )
 }

  const nextActionHandler=()=>{
    var valid=false;
    data&& data.map((item)=>{
      item && item.data.map((innerItem)=>{
        if(item.title!='null' && innerItem.lc_PK_BARCODE=='null'){
          setCheckSampleNotCollected(true)
          return valid=true;
        }
       })
   }
    )

   // var test=checkTRFCompletedStatus()
   // alert(test)
   // alert('check'+checkSampleNotCollected)
    if(completeTRFStatus==true) nextClickHandler()
    else scanTRFClickHandler(valid)
  }

  const renderItem = ({ item ,index}) => (
    <View style={styles.flatListItemView}>
      <View style={styles.mainContainer}>
        <>
        {item.data != null && item.title != null ?
          <View style={{ flexDirection: 'column' }}>
            {item.data.length>0 && item.data[0].lc_PK_BARCODE!='null'&&<Text style={styles.titleText}>{item.title}</Text>}
            <View style={{ flex: 1 }}>
              {item.data.map((data) => (
                 data.lc_PK_BARCODE != 'null' ?
                <>
                  <View style={styles.insertBarcodeContainer}>
                    <Text style={styles.nameText}>{data.lc_PK_BARCODE}</Text>
                    <Text style={[styles.statusText, { color: data.status == '0' ? Colors.button : Colors.babyCordTextColor }]}>{data.status == '0' ? 'TRF Pending':'TRF Captured'}</Text>
                    <View style={styles.removeIconContainer}>
                    <TouchableOpacity onPress={()=>removeClickHandler(data)}>
                      <IonIcons name='remove-circle-outline' size={wp('4.5%')} style={{ color: Colors.button }} />
                      </TouchableOpacity>
                    </View>
                  </View>
                  <View style={styles.bottonLine} />
                </>:
                  <View style={{ flexDirection: 'column' }}>
                  <Text style={styles.sampleNotCollectedText}>{I18n.t('paramedic.myTask.sample_not_collected_label')}</Text>
                  <View style={styles.nacFlowContainer}>
                    <Text style={styles.nacFlowTitleText}>{item.title}</Text>
                  </View>
                </View>
              ))}
            </View>
            <View style={styles.thickBottonLine} />
          </View> :
         null
          // <View style={{ flexDirection: 'column' }}>
          //   <Text style={styles.sampleNotCollectedText}>{I18n.t('paramedic.myTask.sample_not_collected_label')}</Text>
          //   <View style={styles.nacFlowContainer}>
          //     <Text style={styles.nacFlowTitleText}>{item.title}</Text>
          //   </View>
          // </View>
        }</>
      </View>
    </View>
  )


  const renderNodata=()=>{
    return(
      <>
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontFamily:FontMagneta.bold}}>No data found</Text>
    </View>
    </>
    )
  }

  return (
    <RootView pageNo={'45'} loading={loading} connected={isConnected}>
    <Toast
      showToast={showToast}
      msg={errorMsg}
      bgColor={Colors.error}
      txtColor={Colors.background}
    />
      <View style={styles.rootView}>
        <View style={styles.topContainer}>
          <View style={styles.topColOne}>
            {/* <View style={styles.pickedTextContainer}> */}
            <Text style={styles.pickedCountText}>{I18n.t('paramedic.myTask.picked_label')} : </Text>
            <Text style={[styles.pickedCountNumberText]}>{sampleCount}</Text>
            <View style={styles.customerNameTextContainer}>
              <Text style={styles.customerNameText} numberOfLines={2}>{CustomerName}</Text>
            </View>
          </View>
          <View style={styles.topColTwo}>
            <View style={styles.barcodeTextContainer}>
              <Text style={styles.barcodeText}>{I18n.t('paramedic.myTask.barcode_label')} #</Text>
              <TextInput style={styles.barcodeTextInput} 
               maxLength={50}
               value={barcodeNumber}
               onChangeText = {onChangeBarcodeText}/>
            </View>
            <View style={styles.visitContainer}>
              <View style={styles.visitTextContainer}>
                <Text style={styles.barcodeText}></Text>
                <Text style={styles.numberText}></Text>
              </View>
              <TouchableOpacity style={styles.addButtonContainer} onPress={addClickHandler}>
                <Text style={styles.barcodeText}>Add</Text>
              </TouchableOpacity>
            </View>
            <View style={styles.visitContainer}>
              <View style={styles.visitTextContainer}>
                <Text style={styles.numberText}></Text>
              </View>
              <TouchableOpacity style={styles.iconContainer} onPress={barcodeScannerClickHandler}>
                <Image
                  resizeMode={'contain'}
                  source={Images.smallBarcode}
                  style={{ width: wp('10%'), height: hp('5%') }}
                />
              </TouchableOpacity>
            </View>
          </View>
          {!isValidBarcodeNumber && (
              <Text style={styles.textValidationMsg}>
                {!isValidBarcodeNumber ? barcodeValidationMsg : ''}
              </Text>
            )}
        </View>
        <FlatList
          showsVerticalScrollIndicator={false}
          data={data}
          renderItem={renderItem}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.flatListInnerContainer}
          ListEmptyComponent={renderNodata}
        />
        <View style={{ width: wp('100%'), height: hp('12%'), alignItems: 'center', justifyContent: 'center' }}>
          {sampleCount>0?
        <AppButton title={completeTRFStatus==true?'Next':'Scan TRF'} 
          onPress={()=>nextActionHandler()} 
          buttonStyle={styles.nextButton} />:
          <AppButton title={'Scan TRF'} 
          buttonStyle={[styles.nextButton,{backgroundColor:Colors.inActiveButton}]} />
}
        </View>
        <ModalConfirmNumber
          title={'Add barcodes'}
          message={'Some of the sample(s) are not collected.Do you still want to proceed?'}
          pageNumber={27}
          visible={addSampleAlert}
          dismissHandler={cancelModalHandler}
          cancelHandler={cancelModalHandler}
          okayHandler={okayConfirmHandler}
        />
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  topContainer: {
    width: wp('100%'),
    height: hp('22%'),
    padding: wp('3%'),

  },
  topColOne: {
    width: wp('88%'),
    height: hp('6%'),
    marginVertical: wp('1%'),
    flexDirection: 'row',
    marginHorizontal: wp('3%'),


  },
  pickedTextContainer: {

    alignItems: 'flex-start',
    justifyContent: 'flex-start',


  },
  customerNameTextContainer: {
    width: wp('60%'),
    paddingHorizontal: wp('3%')
  },
  customerNameText:
  {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.babyCordTextColor
  },
  pickedCountNumberText:
  {
    fontFamily: FontMagneta.semiBold,
    fontSize: FontSize.large,
    color: Colors.border,
    alignSelf: 'flex-start',
    // marginTop: Platform.OS == 'ios' ? hp('0%') : hp('-0.3%')
  },
  numberText:
  {
    fontFamily: FontMagneta.semiBold,
    fontSize: FontSize.medium,
    color: Colors.border
  },
  pickedCountText:
  {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.border
  },
  topColTwo: {
    width: wp('94%'),
    height: hp('10%'),
    marginVertical: wp('1%'),
    flexDirection: 'row',
  },
  barcodeTextInput:
  {
    height: hp('5%'),
    width: wp('45%'),
    borderWidth: 1,
    borderRadius: 25,
    borderColor: Colors.bWhite,
    paddingHorizontal: wp('3%'),
    alignItems: 'center',
    marginVertical: hp('1%'),
    paddingVertical: hp('1%'),
    fontFamily: FontMagneta.semiBold,
    color: Colors.black,
    fontSize: FontSize.medium

  },
  addButtonContainer:
  {
    height: hp('5%'),
    width: wp('22%'),
    borderRadius: 50,
    backgroundColor: Colors.card,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: hp('1%')
  },
  barcodeText:
  {
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    color: Colors.border,
    marginHorizontal: wp('3%'),

  },
  barcodeTextContainer:
  {
    flex: 0.5,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  visitContainer:
  {
    flex: 0.25,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer:
  {
    height: hp('5%'),
    width: wp('22%'),
    borderRadius: 50,
    backgroundColor: Colors.vLightGreen,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: hp('1%')
  },
  flatListInnerContainer: {
    paddingBottom: 30
  },
  flatListItemView:
  {
    width: wp('100%'),
    //height:hp('5%'),
    paddingHorizontal: wp('2%')
  },
  mainContainer: {
    width: '100%',
    paddingVertical: 5,
    flexDirection: 'column',
    marginTop: '1%',
  },
  nameText: {
    width: wp('45%'),
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.semiBold,
    color: Colors.border,
    paddingHorizontal: wp('4%'),
    // paddingBottom:'2%',

  },
  statusText: {
    width: wp('30%'),
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    paddingHorizontal: wp('2%'),
    // paddingBottom:'2%',

  },
  titleText: {
    width: wp('90%'),
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.semiBold,
    color: Colors.border,
    paddingHorizontal: wp('4%'),
    paddingBottom: '2%',
    lineHeight: 20

  },
  bottonLine:
  {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.card,
    height: 1,
  },
  thickBottonLine: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.border,
    height: hp('0.2%'),
  },
  insertBarcodeContainer:
  {
    height: hp('6%'),
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',

  },
  removeIconContainer:
  {
    width: wp('20%'),
    height: hp('5%'),
    alignItems: 'center',
justifyContent:'center'
  },
  visitTextContainer:
  {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center'
  },
  nextButton: {
    height: hp('5%'),
    width: wp('38%'),
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: Colors.babyCordTextColor,
    elevation: 2,
    borderRadius: 50,
    paddingVertical: 3,
    paddingHorizontal: 10,
    marginHorizontal: 3
  },
  sampleNotCollectedText: {
    width: wp('90%'),
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.babyCordTextColor,
    paddingHorizontal: wp('4%'),
    paddingBottom: '4%',
  },
  nacFlowTitleText: {
    // width:wp('90%'),
    fontSize: FontSize.medium,
    fontFamily: FontMagneta.medium,
    color: Colors.black,
    paddingHorizontal: wp('2%'),
    lineHeight: 20
  },
  nacFlowContainer: {
    padding: wp('3%'),
    backgroundColor: Colors.card,
    borderRadius: 10,
    width: wp('90%'),
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginHorizontal: wp('3%'),
    marginBottom:hp('2%')
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
   // paddingHorizontal: 10,
  
  },
})


export default SamplePickUpScreen;