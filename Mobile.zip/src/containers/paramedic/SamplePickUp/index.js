import React from 'react';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
import SamplePickUpScreen from './Screen';
import {barcodeValueEmpty} from '../../../utils/Validators';
import {
  mytaskBarcodeRemoveSample,
  mytaskGetPickedTestList,
  payDetails,
} from '../../../store/Actions';
import { delay } from '../../../utils/Helpers';
const data = [
  {
    title: 'Maternity Screening - Maternal Serum',
    data: [
      {barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'},
      {barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'},
      {barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'},
    ],
  },
  {
    title: 'QFPCR - White blood',
    data: [{barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'}],
  },
  {
    title: 'Hb Pathies - Heel Prick TSH+T4 - Heel Prick',
    data: [{barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'}],
  },
  {
    title: 'Hb Pathies - Heel Prick TSH+T4 - Heel Prick',
    data: [{barcode: '12345', checktrfstatus: '1', trfstatus: 'TRF completed'}],
  },
  {
    title: 'PNS DNA Storage - Amniotic fluid',
    data: [],
  },
  {
    title: 'Cord Blood + Urine',
    data: [],
  },
];
class SamplePickUp extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      headerTitle: this.props.route.params.title,
      addSampleAlert: false,
      barcodeNumber: '',
      isValidBarcodeNumber: true,
      barcodeValidationMsg: '',
      crmId: this.props.route.params.crmId,
      orderId: this.props.route.params.orderId,
      paymentStatus: this.props.route.params.paymentStatus,
      productId: this.props.route.params.productId,
      CustomerName:this.props.route.params.CustomerName,
      data: [],
      sampleCount: 0,
      showToast: false,
      errorMsg: '',
    };
  }
  componentDidMount() {
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.navigation.setOptions({title: this.state.headerTitle});
      //  alert(this.state.paymentStatus)
      this.setState({barcodeNumber: ''});
      this.initialCall();
    });
  }

  initialCall() {
    const data = {
      crmid: this.state.crmId,
      orderid: this.state.orderId,
    };
    this.props.getPickedTestList(data, this.props.accessToken);
  }

  componentWillUnmount() {
    this._unsubscribe();
  }
  scanTRFClickHandler = checkSampleNotCollected => {
    console.log('========>', checkSampleNotCollected);
    if (checkSampleNotCollected == true) {
      this.setState({addSampleAlert: true});
    } else {
      this.props.navigation.navigate(Paramedic.scanTRFForPNS, {
        title: 'Scan TRF',
        message: 'Please capture the TRF',
        barcodeNumber: '',
        paymentStatus: this.state.paymentStatus,
        crmId: this.state.crmId,
        orderId: this.state.orderId,
        productId: this.state.productId,
      });
    }
    // this.props.navigation.navigate(Paramedic.scanTRFForPNS);
  };

  nextClickHandler = () => {
    //  alert('payment')
    //this.props.navigation.navigate(Paramedic.scanTRFForPNS);

    const data = {
      crmId: this.state.crmId,
      orderid: this.state.orderId,
    };
    this.props.onPayDetails(data);
    this.props.navigation.navigate(Paramedic.paymentCollection, {});
    //  message: 'Please capture the purple card', barcodeNumber: '',
    //  paymentStatus:this.state.paymentStatus,
    //  crmId: this.state.crmId,orderId:this.state.orderId});
  };
  okayConfirmHandler = () => {
    this.setState({addSampleAlert: false});
    this.props.navigation.navigate(Paramedic.scanTRFForPNS, {
      title: 'Scan TRF',
      message: 'Please capture the purple card',
      barcodeNumber: '',
      paymentStatus: this.state.paymentStatus,
      crmId: this.state.crmId,
      orderId: this.state.orderId,
    });
  };
  cancelModalHandler = () => {
    this.setState({addSampleAlert: false});
  };
  barcodeScannerClickHandler = () => {
    this.props.navigation.navigate(Paramedic.barcodeScanner, {
      navigation: this.props.navigation,
      crmId: this.state.crmId,
      orderId: this.state.orderId,
    });
  };
  addClickHandler = () => {
    // alert(this.state.barcodeNumber)
    const valid1 = barcodeValueEmpty(this.state.barcodeNumber);
    if (valid1.val) {
      this.setState({
        isValidBarcodeNumber: valid1.val,
        barcodeValidationMsg: '',
      });
      this.props.navigation.navigate(Paramedic.pnsSelectTest, {
        crmId: this.state.crmId,
        barcode: this.state.barcodeNumber,
        orderId: this.state.orderId,
      });
    } else {
      this.setState({
        barcodeValidationMsg: valid1.msg,
        isValidBarcodeNumber: valid1.val,
      });
    }
  };
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };
  onChangeBarcodeText = val => {
    const validBarcode = val.replace(/[^a-zA-Z0-9- . ]/gm, '');
    this.setState({
      barcodeNumber: validBarcode,
    });
  };
  removeClickHandler = item => {
    const data = {
      pickupid: item.lc_PK_ID,
      userid: this.props.UserID,
    };
    this.props.onMytaskBarcodeRemoveSample(data, this.props.accessToken);
  };
  componentDidUpdate = prevProps => {
    if (
      prevProps.MytaskPickedTestListStatus == false &&
      this.props.MytaskPickedTestListStatus !=
        prevProps.MytaskPickedTestListStatus
    ) {
      if (
        this.props.MytaskGetPickedListResponse != null ||
        this.props.MytaskGetPickedListResponse != undefined ||
        this.props.MytaskGetPickedListResponse != []
      ) {
        this.setState({
          data: this.props.MytaskPickedTestListResponse.pickedTestListModels,
        });
        this.setState({
          sampleCount: this.props.MytaskPickedTestListResponse.SampleCount,
        });
        //console.log('response check'+JSON.stringify(this.props.MytaskPickedTestListResponse))
      }
    }

    if (
      this.props.MytaskRemoveSamplePickupStatus == true &&
      this.props.MytaskRemoveSamplePickupStatus !=
        prevProps.MytaskRemoveSamplePickupStatus
    ) {
      // alert('success')
      this.initialCall();
    }
    if (
      prevProps.MytaskPickedTestListError == false &&
      this.props.MytaskPickedTestListError !=
        prevProps.MytaskPickedTestListError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    if (
      prevProps.MytaskRemoveSamplePickupError == false &&
      this.props.MytaskRemoveSamplePickupError !=
        prevProps.MytaskRemoveSamplePickupError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };
  render() {
    return (
      <SamplePickUpScreen
        data={this.state.data}
        sampleCount={this.state.sampleCount}
        nextClickHandler={this.nextClickHandler}
        barcodeScannerClickHandler={this.barcodeScannerClickHandler}
        addSampleAlert={this.state.addSampleAlert}
        cancelModalHandler={this.cancelModalHandler}
        okayConfirmHandler={this.okayConfirmHandler}
        addClickHandler={this.addClickHandler}
        barcodeNumber={this.state.barcodeNumber}
        isValidBarcodeNumber={this.state.isValidBarcodeNumber}
        barcodeValidationMsg={this.state.barcodeValidationMsg}
        onChangeBarcodeText={this.onChangeBarcodeText}
        removeClickHandler={this.removeClickHandler}
        scanTRFClickHandler={this.scanTRFClickHandler}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        loading={
          this.props.MytaskPickedTestListLoading ||
          this.props.MytaskRemoveSamplePickupLoading
        }
        CustomerName={this.state.CustomerName}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    MytaskPickedTestListLoading: state.mytask.MytaskGetPickedListLoading,
    MytaskPickedTestListStatus: state.mytask.MytaskGetPickedListStatus,
    MytaskPickedTestListError: state.mytask.MytaskGetPickedListError,
    MytaskPickedTestListResponse: state.mytask.MytaskGetPickedListResponse,

    MytaskRemoveSamplePickupLoading:
      state.mytask.MytaskRemoveSamplePickupLoading,
    MytaskRemoveSamplePickupStatus: state.mytask.MytaskRemoveSamplePickupStatus,
    MytaskRemoveSamplePickupError: state.mytask.MytaskRemoveSamplePickupError,
    MytaskRemoveSamplePickupResponse:
      state.mytask.MytaskRemoveSamplePickupResponse,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    getPickedTestList: (data, token) =>
      dispatch(mytaskGetPickedTestList(data, token)),

    onMytaskBarcodeRemoveSample: (data, token) =>
      dispatch(mytaskBarcodeRemoveSample(data, token)),

    onPayDetails: data => dispatch(payDetails(data)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SamplePickUp);
