import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import RegularBeatScreen from './Screen';
import {
  barcodeValueEmpty
} from '../../../utils/Validators';
import {
  mytaskRemoveSampleRegularBeat,
  mytaskGetPickedTestListForRegularBeat,
  mytaskGetCrmidOrderidForRegularBeat,
  mytaskInsertNoSampleRegularBeat,
  updateLocation
} from "../../../store/Actions";
import {
  locationPermission,
  getCurrentLocation,
} from '../../../services/Permissions';
import {BackHandler} from 'react-native';
import { delay } from '../../../utils/Helpers';

const data = [
  {
    "title": "Maternity Screening - Maternal Serum",
    "data": [{ "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" },
    { "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" },
    { "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" }
    ]
  },
  {
    "title": "QFPCR - White blood",
    "data": [{ "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" }]
  },
  {
    "title": "Hb Pathies - Heel Prick TSH+T4 - Heel Prick",
    "data": [{ "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" }]
  },
  {
    "title": "Hb Pathies - Heel Prick TSH+T4 - Heel Prick",
    "data": [{ "barcode": "12345", "checktrfstatus": "1", "trfstatus": "TRF completed" }]
  },
  {
    "title": "PNS DNA Storage - Amniotic fluid",
    "data": []
  },
  {
    "title": "Cord Blood + Urine",
    "data": []
  },
]
class RegularBeat extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      headerTitle: this.props.route.params.title,
      addSampleAlert: false,
      barcodeNumber: '',
      isValidBarcodeNumber: true,
      barcodeValidationMsg: '',
      visitTimeId: this.props.route.params.visitTimeId,
      visitName: this.props.route.params.visitName,
      visitTime: this.props.route.params.visitTime,
      hospitalName: this.props.route.params.hospitalName,
      hospitalId: this.props.route.params.hospitalId,
      orderId: this.props.route.params.orderId,
      crmId: this.props.route.params.crmId,
      productId: this.props.route.params.productId,
      data: [],
      sampleCount: 0,
      showToast: false,
      errorMsg: '',
      sampleCount: 0,
      setCamera: false,
      pickupStatus: false, scanTRFStatusHide: false,
      latitude:"",
      longitude:""
    };
  }

  componentDidMount() {
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.navigation.setOptions({ title: this.state.headerTitle })
      // this.props.onMytaskGetCrmidOrderidForRegularBeat(null, this.props.accessToken)
      //  alert(this.state.paymentStatus)
      this.setState({ setCamera: false })
      this.setState({ barcodeNumber: '' })
      this.initialCall()
    });
    BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  backHandler = () => {
    if(this.state.setCamera == true){
      this.setState({setCamera:false})
    }else{
      this.props.navigation.goBack(null);
    }
    return true;
  };
  componentWillUnmount() {
    this._unsubscribe();
    BackHandler.removeEventListener('hardwareBackPress',this.backHandler);
  }

  initialCall() {

if(this.props.MytaskGetCRMIdOrderId.crmId == null && this.props.MytaskGetCRMIdOrderId.orderId == null){
  null
}else{
  const data = {
    "crmid": this.props.MytaskGetCRMIdOrderId.crmId,
    "orderid": this.props.MytaskGetCRMIdOrderId.orderId
  }
  this.props.onMytaskGetPickedTestListForRegularBeat(data, this.props.accessToken);
}
  
    this.userTrackHandler()
  }
  userTrackHandler = async () => {
    let location = null;
    const permit = await locationPermission();
    if (permit == 'granted') {
      location = await getCurrentLocation();
      console.log('location =========>', location);
     // alert(JSON.stringify(location))
      //this.props.onUpdateLocation(location);
this.setState({
  latitude:location.latitude,
  longitude:location.longitude
})
    }
  };

  componentWillUnmount() {
    this._unsubscribe();
  }
  scanTRFClickHandler = (checkSampleNotCollected) => {
    console.log("========>", checkSampleNotCollected);
    if (checkSampleNotCollected == true) {
      this.setState({ addSampleAlert: true })
    } else {
      this.props.navigation.navigate(Paramedic.scanTRFForPNS, {
        title: 'Scan TRF',
        message: 'Please capture the TRF', barcodeNumber: '',
        paymentStatus: 1,
        productId: this.state.productId,
        crmId: this.props.MytaskGetCRMIdOrderId.crmId,
        orderId: this.props.MytaskGetCRMIdOrderId.orderId
      });
    }
    // this.props.navigation.navigate(Paramedic.scanTRFForPNS);

  }

  nextClickHandler = () => {
    //alert('payment')
    // this.props.navigation.navigate(Paramedic.scanTRFForPNS);

    //  message: 'Please capture the purple card', barcodeNumber: '',
    //  paymentStatus:this.state.paymentStatus,
    //  crmId: this.state.crmId,orderId:this.state.orderId});
  }
  okayConfirmHandler = () => {
    // this.setState({ addSampleAlert: false })
    // this.props.navigation.navigate(Paramedic.scanTRFForPNS, {
    //   title: 'Scan TRF',
    //   message: 'Please capture the purple card', barcodeNumber: '',
    //   paymentStatus: this.state.paymentStatus,
    //   crmId: this.state.crmId, orderId: this.state.orderId
    // });
  }
  cancelModalHandler = () => {
    this.setState({ addSampleAlert: false })
  }
  barcodeScannerClickHandler = () => {
    // this.props.navigation.navigate(Paramedic.barcodeScanner, { navigation: this.props.navigation });
    this.setState({
      setCamera: true
    })

  }
  onBarCodeRead = (scanResult) => {
    const barcode = scanResult.data
    this.setState({
      setCamera: false,
      barcodeNumber: barcode,
    })

  }

  addClickHandler = () => {

    const valid1 = barcodeValueEmpty(this.state.barcodeNumber);
    if (valid1.val) {
      this.setState({
        isValidBarcodeNumber: valid1.val,
        barcodeValidationMsg: ''
      })
      this.checkValidCRM()
    }
    else {
      this.setState({
        barcodeValidationMsg: valid1.msg,
        isValidBarcodeNumber: valid1.val
      })

    }
  }

  navigateToNext = () => {
    this.props.navigation.navigate(Paramedic.tieupHospitalSampleType, {
      title: 'Regular Beat',
      visitTimeId: this.state.visitTimeId,
      visitName: this.state.visitName,
      visitTime: this.state.visitTime,
      userId: this.props.UserID,
      hospitalName: this.state.hospitalName,
      hospitalId: this.state.hospitalId,
      barcodeNumber: this.state.barcodeNumber
    });

  }
  checkValidCRM = () => {
    console.log(this.state.data.length != 0)
    console.log(this.state.data.title != 'null')
    console.log(this.state.data != null)
    console.log(this.state.data != "")
    if (this.state.data.length != 0 && this.state.data != null && this.state.data != "") {
      console.log('1')

      this.state.data.map((item) => {
        console.log('3')
        if (item.data.length != 0) {

          item && item.data.map((innerItem) => {
            console.log(innerItem.status + "," + this.props.MytaskGetCRMIdOrderId.crmId)
            // console.log('Checking===>'+(innerItem.status == "0" && this.props.MytaskGetCRMIdOrderId.crmId==this.state.barcodeNumber))
            if (innerItem.status == "0" && this.props.MytaskGetCRMIdOrderId.crmId == this.state.barcodeNumber) {
              console.log('4')
              this.navigateToNext()
            } else if (innerItem.status == "1") {
              //console.log('5')

              this.navigateToNext()
            }
            else {
              console.log('6')
              this.setState({
                barcodeValidationMsg: "Please Catpture TRF for current CRM ID",
                isValidBarcodeNumber: false
              })
            }
          })
        } else {
          console.log('8')
          this.navigateToNext()
        }
      })

    }
    else {
      console.log('7')
      this.navigateToNext()
    }
  }
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };
  onChangeBarcodeText = val => {
    const validBarcode = val.replace(/[^a-zA-Z0-9- . ]/gm, '');
    this.setState({
      barcodeNumber: validBarcode,
    });
  };
  removeClickHandler = (item) => {
    const data = {
      "pickupid": item.lc_RV_ID,
      "userid": this.props.UserID
    }
    this.props.onMytaskBarcodeRemoveSampleRegularBeat(data, this.props.accessToken);
  }

  noSampleClickHandler = (item) => {
    const data = {
      "visittimeid": this.state.visitTimeId,
      "hospitalid": this.state.hospitalId,
      "latitude": this.state.latitude,
      "longtitude": this.state.longitude,
      "userid": this.props.UserID
    }
    this.props.onMytaskInsertNoSampleRegularBeat(data, this.props.accessToken);
  }
  componentDidUpdate = prevProps => {

    if (
      prevProps.MytaskGetPickedTestListForRegularBeatStatus == false &&
      this.props.MytaskGetPickedTestListForRegularBeatStatus != prevProps.MytaskGetPickedTestListForRegularBeatStatus
    ) {
      if (this.props.MytaskGetPickedTestListForRegularBeatResponse != null ||
        this.props.MytaskGetPickedTestListForRegularBeatResponse != undefined ||
        this.props.MytaskGetPickedTestListForRegularBeatResponse != []) {
        this.setState({ data: this.props.MytaskGetPickedTestListForRegularBeatResponse.PickedTestListResponse });
        this.setState({ sampleCount: this.props.MytaskGetPickedTestListForRegularBeatResponse.SampleCount });

        // if (this.props.MytaskGetCRMIdOrderId.crmId != null &
        //   this.props.MytaskGetCRMIdOrderId.orderId != null) {
        //   this.setState({
        //       scanTRFStatusHide:true,
        //       pickupStatus:true
        //   })
        // }
        this.props.MytaskGetPickedTestListForRegularBeatResponse.PickedTestListResponse.map((item) => {
        
          if (item.data.length != 0) {
  
            item && item.data.map((innerItem) => {

              if(innerItem.status=="1"){
                    this.setState({
              scanTRFStatusHide:true,
              pickupStatus:true
          })
              }else{
                this.setState({
                  scanTRFStatusHide:false,
                  pickupStatus:false
              })
              }
            })
          }

        })
      }
    }

    if (
      this.props.MytaskRemoveSampleRegularBeatStatus == true &&
      this.props.MytaskRemoveSampleRegularBeatStatus != prevProps.MytaskRemoveSampleRegularBeatStatus
    ) {

      this.initialCall()

    }

    if (
      prevProps.MytaskInsertNoSampleForRegularBeatStatus == false &&
      this.props.MytaskInsertNoSampleForRegularBeatStatus != prevProps.MytaskInsertNoSampleForRegularBeatStatus
    ) {
      this.pickupClickHandler()
      //this.initialCall()

    }
    if (
      prevProps.MytaskPickedTestListError == false &&
      this.props.MytaskPickedTestListError != prevProps.MytaskPickedTestListError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    if (
      this.props.MytaskInsertNoSampleForRegularBeatError == true &&
      this.props.MytaskInsertNoSampleForRegularBeatError != prevProps.MytaskRemoveSamplePickupError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    if (
      prevProps.MytaskRemoveSampleRegularBeatError == false &&
      this.props.MytaskRemoveSampleRegularBeatError != prevProps.MytaskRemoveSampleRegularBeatError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

  }
  pickupClickHandler = () => {
   // alert('check')
    this.setState(
      {
        errorMsg: 'No sample updated',
        showToast: true,
      },
      async () => {
        await delay(3000);
        this.resetValidation();
      },
    );
    this.props.navigation.navigate(Paramedic.myTask)
  }
  render() {
    return <RegularBeatScreen data={this.state.data}
      sampleCount={this.state.sampleCount}
      nextClickHandler={this.nextClickHandler}
      barcodeScannerClickHandler={this.barcodeScannerClickHandler}
      addSampleAlert={this.state.addSampleAlert}
      cancelModalHandler={this.cancelModalHandler}
      okayConfirmHandler={this.okayConfirmHandler}
      addClickHandler={this.addClickHandler}
      barcodeNumber={this.state.barcodeNumber}
      isValidBarcodeNumber={this.state.isValidBarcodeNumber}
      barcodeValidationMsg={this.state.barcodeValidationMsg}
      onChangeBarcodeText={this.onChangeBarcodeText}
      removeClickHandler={this.removeClickHandler}
      scanTRFClickHandler={this.scanTRFClickHandler}
      showToast={this.state.showToast}
      errorMsg={this.state.errorMsg}
      loading={this.props.MytaskGetPickedTestListForRegularBeatLoading || this.props.MytaskRemoveSampleRegularBeatLoading || this.props.MytaskInsertNoSampleForRegularBeatLoading}
      visitName={this.state.visitName}
      visitTime={this.state.visitTime}
      hospitalName={this.state.hospitalName}
      noSampleClickHandler={this.noSampleClickHandler}
      sampleCount={this.state.sampleCount}
      pickupClickHandler={this.pickupClickHandler}
      setCamera={this.state.setCamera}
      onBarCodeRead={this.onBarCodeRead}
      pickupStatus={this.state.pickupStatus}
      scanTRFStatusHide={this.state.scanTRFStatusHide}
    />
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,
    MytaskGetPickedTestListForRegularBeatLoading:
      state.mytask.MytaskGetPickedTestListForRegularBeatLoading,
    MytaskGetPickedTestListForRegularBeatStatus:
      state.mytask.MytaskGetPickedTestListForRegularBeatStatus,
    MytaskGetPickedTestListForRegularBeatError:
      state.mytask.MytaskGetPickedTestListForRegularBeatError,
    MytaskGetPickedTestListForRegularBeatResponse:
      state.mytask.MytaskGetPickedTestListForRegularBeatResponse,


    MytaskRemoveSampleRegularBeatLoading:
      state.mytask.MytaskRemoveSampleRegularBeatLoading,
    MytaskRemoveSampleRegularBeatStatus:
      state.mytask.MytaskRemoveSampleRegularBeatStatus,
    MytaskRemoveSampleRegularBeatError:
      state.mytask.MytaskRemoveSampleRegularBeatError,
    MytaskRemoveSampleRegularBeatResponse:
      state.mytask.MytaskRemoveSampleRegularBeatResponse,


    MytaskInsertNoSampleForRegularBeatLoading:
      state.mytask.MytaskInsertNoSampleForRegularBeatLoading,
    MytaskInsertNoSampleForRegularBeatStatus:
      state.mytask.MytaskInsertNoSampleForRegularBeatStatus,
    MytaskInsertNoSampleForRegularBeatError:
      state.mytask.MytaskInsertNoSampleForRegularBeatError,
    MytaskInsertNoSampleForRegularBeatResponse:
      state.mytask.MytaskInsertNoSampleForRegularBeatResponse,

    MytaskGetCRMIdOrderId:
      state.mytask.MytaskGetCRMIdOrderId,
      location: state.dayStart.location,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onMytaskGetPickedTestListForRegularBeat: (data, token) =>
      dispatch(mytaskGetPickedTestListForRegularBeat(data, token)),

    onMytaskBarcodeRemoveSampleRegularBeat: (data, token) =>
      dispatch(mytaskRemoveSampleRegularBeat(data, token)),

    onMytaskGetCrmidOrderidForRegularBeat: (data, token) =>
      dispatch(mytaskGetCrmidOrderidForRegularBeat(data, token)),

    onMytaskInsertNoSampleRegularBeat: (data, token) =>
      dispatch(mytaskInsertNoSampleRegularBeat(data, token)),
      onUpdateLocation: (data, token) => dispatch(updateLocation(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(RegularBeat);


