import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import PNSScreen from './Screen';
import {
  viewMytasklistdetails, mytaskPickupStart,getPickupType,updateLocation
} from "../../../store/Actions";
import { delay } from '../../../utils/Helpers';
import {
  locationPermission,
  getCurrentLocation,
} from '../../../services/Permissions';
const pendingData = [
  { id: 1, name: 'Srikanth', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040' },
  { id: 2, name: 'Joe', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040' },
  { id: 2, name: 'Srikanth', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040' }]
const completedData = [
  { id: 1, name: 'Chandran', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', deliveredTime: '10:10' },
  { id: 2, name: 'Arul Kumar', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', deliveredTime: '10:10' },
  { id: 2, name: 'Srikanth', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', deliveredTime: '10:10' }]
const cancelData = [
  { id: 1, name: 'Gaurav China', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', crtype: '1', reason: 'Customer not available' },
  { id: 2, name: 'Joe', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', crtype: '2', reason: 'Customer not available' },
  { id: 2, name: 'Srikanth', crmid: '12345', date: '20.11.2021', time: '10:10', address: '7/1, 5th main road,Anna nagar, Chennai - 600040', crtype: '1', reason: 'Customer not available' }]
const searchData = [
  { id: 1, name: 'Collection & pickup' },
  { id: 2, name: 'Pickup only' },
  { id: 3, name: 'Report dispatch' },
  { id: 4, name: 'Addcamp collection' },
  { id: 5, name: 'Repeat collection' },
  { id: 6, name: 'Repeatpickup only' },
]
class PNS extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isActive: false,
      isStarted: false,
      selectedSearchId: 0,
      selectedTab: 1,
      data: [],
      showSuccessModal: false,
      title: this.props.route.params.title,
      imageSrc: this.props.route.params.imageSrc,
      taskText: this.props.route.params.taskText,
      totalCount: this.props.route.params.totalCount,
      titleColor: this.props.route.params.titleColor,
      productId: this.props.route.params.productId,
      orderId: '',
      nodata: false,
      startId: 0,
      searchTypeList: [],
      showToast: false,
      errorMsg:'',
      latitude:"",
      longitude:""
    };
  }
  cardClickHandler = (item) => {
    this.props.navigation.navigate(Paramedic.pnsDetails, {
      title: this.state.title,
      crmId: item.lc_OR_CRMID,
      productId: item.lc_OTD_PRODUCTID,
      orderId: item.lc_OR_ORDERID,
    });

  };
 
  startCardClickHandler = (item) => {

    // this.setState(prevState => {
    //   const temp = prevState.startId == item.lc_OR_ORDERID ? 0 : item.lc_OR_ORDERID;
    //   return {
    //     startId: temp,

    //   };
    // });

    const data = {
      "crmid": item.lc_OR_CRMID,
      "orderid": item.lc_OR_ORDERID,
      "userid": this.props.UserID,
      "lattitude": this.state.latitude,
      "longitude": this.state.longitude,
    }
    // alert(JSON.stringify(data))
    this.props.mytaskPickupStart(data, this.props.accessToken)
  }
  searchClickHandler = id => {
    this.setState({selectedSearchId:id})
    this.searchData(id)

  };
  searchData=(id)=>{
    if(this.state.selectedTab==1){
      let tempPendingArray=this.props.BabyCordPending.filter((item)=>parseInt(item.lc_OR_PICKUPID)==id)
      this.setState({data:tempPendingArray})
    }else if(this.state.selectedTab==2){
      let tempCompletedArray=this.props.BabyCordCompleted.filter((item)=>parseInt(item.lc_OR_PICKUPID)==id)
      this.setState({data:tempCompletedArray})
    }else if(this.state.selectedTab==3){
      let tempCanResArray=this.props.BabyCordCanRes.filter((item)=>parseInt(item.lc_OR_PICKUPID)==id)
      this.setState({data:tempCanResArray})
    }
  }

  changeTab = id => {
    this.setState({ selectedTab: id})
    this.fetchData(id);
  };

  fetchData(id) {
    if (id == '1') {
      this.setState({data: this.props.BabyCordPending,selectedSearchId:0 });
    } else if (id == '2') {
      this.setState({ data: this.props.BabyCordCompleted,selectedSearchId:0 });
    } else if (id == '3') {
      this.setState({ data: this.props.BabyCordCanRes,selectedSearchId:0 });
    }
  }
  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };
  initialCall = () => {
    this.userTrackHandler()
    const data = {
      userid: this.props.UserID,
      productid: this.state.productId
    }
    this.props.viewMytasklistdetails(data, this.props.accessToken);
  }
  userTrackHandler = async () => {
    let location = null;
    const permit = await locationPermission();
    if (permit == 'granted') {
      location = await getCurrentLocation();
      console.log('location =========>', location);
     // alert(JSON.stringify(location))
      //this.props.onUpdateLocation(location);
this.setState({
  latitude:location.latitude,
  longitude:location.longitude
})
    }
  };
  componentDidMount() {
    this.props.onGetPickupType(null, this.props.accessToken);
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.initialCall()
    });
  }
  componentWillUnmount() {
    this._unsubscribe();
  }
  componentDidUpdate = prevProps => {

    if (
      prevProps.MytasklistdetailsStatus == false &&
      this.props.MytasklistdetailsStatus != prevProps.MytasklistdetailsStatus
    ) {
      // alert(JSON.stringify(this.props.BabyCordPending))
      this.setState({ pendingData: this.props.BabyCordPending });
      this.setState({ completedData: this.props.BabyCordCompleted });
      this.setState({ canresData: this.props.BabyCordCanRes });
      this.setState({ data: this.props.BabyCordPending })
    }


    if (
      prevProps.PickupStartStatus == false &&
      this.props.PickupStartStatus != prevProps.PickupStartStatus
    ) {
      // this.setState({ isStarted: true });
      this.setState({ showSuccessModal: true });
    
      setTimeout(() => {
        this.setState({ showSuccessModal: false });
        this.initialCall()
      }, 2000);
    }

    if (
      prevProps.MytasklisdetailsError == false &&
      this.props.MytasklisdetailsError != prevProps.MytasklisdetailsError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.PickupStartError == false &&
      this.props.PickupStartError != prevProps.PickupStartError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

  }
  render() {
    return (
      <PNSScreen
        searchData={this.props.searchTypeList}
        data={this.state.data}
        cardClickHandler={this.cardClickHandler}
        searchClickHandler={this.searchClickHandler}
        startCardClickHandler={this.startCardClickHandler}
        selectedSearchId={this.state.selectedSearchId}
        changeTab={this.changeTab}
        selectedTab={this.state.selectedTab}
        isStarted={this.state.isStarted}
        showSuccessModal={this.state.showSuccessModal}
        title={this.state.title}
        imageSrc={this.state.imageSrc}
        taskText={this.state.taskText}
        totalCount={this.state.totalCount}
        titleColor={this.state.titleColor}
        startId={this.state.startId}
        loading={this.props.MytasklistdetailsLoading || this.props.PickupStartLoading}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
      />

    )
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    MytasklistdetailsLoading:
      state.mytask.MytasklistPnsdetailsLoading,
    MytasklistdetailsStatus:
      state.mytask.MytasklistdetailsStatus,
    MytasklisdetailsError:
      state.mytask.MytasklisdetailsError,

    BabyCordPending: state.mytask.mytasklistBabyCordDetailsPending,
    BabyCordCompleted: state.mytask.mytasklistBabyCordDetailsCompleted,
    BabyCordCanRes: state.mytask.mytasklistBabyCordDetailsCansRes,
    UserID: state.signIn.userId,

    PickupStartLoading: state.mytask.MytaskPickupStartedLoading,
    PickupStartStatus: state.mytask.MytaskPickupStartedStatus,
    PickupStartError: state.mytask.MytaskPickupStartedError,

    searchTypeList: state.common.pickupTypeResponse,
    location: state.dayStart.location,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    viewMytasklistdetails: (data, token) =>
      dispatch(viewMytasklistdetails(data, token)),

    mytaskPickupStart: (data, token) =>
      dispatch(mytaskPickupStart(data, token)),

    onGetPickupType: (data, token) => dispatch(getPickupType(data, token)),
    onUpdateLocation: (data, token) => dispatch(updateLocation(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(PNS);
