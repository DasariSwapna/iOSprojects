import React, { useRef } from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import Images from '../../../constants/Icons';
import SearchButtonView from '../../../components/SearchButtonView'
import { FlatList } from 'react-native-gesture-handler';
import MyTaskHeader from '../../../components/MyTaskHeader';
import PendingCardView from '../../../components/PendingCardView';
import TabContainer from '../../../components/TabContainer'
import { ModalSuccess } from '../../../components/OtpModal';
import {Toast} from '../../../components/Toast';
import I18n from '../../../locale/i18n';
import {NetworkContext} from '../../../contexts/NetworkContext';
import { widthPercentageToDP as wp,heightPercentageToDP as hp } from 'react-native-responsive-screen';
function PNSScreen({ searchData, data, cardClickHandler,startCardClickHandler, searchClickHandler, selectedSearchId,
   changeTab, selectedTab,isStarted,showSuccessModal,title,imageSrc,taskText,totalCount,titleColor,
   errorMsg,
   showToast,
   loading }) {
  const {isConnected} = React.useContext(NetworkContext);
  const renderItem = ({ item }) => (
    
<PendingCardView
      crmIdText={I18n.t('paramedic.myTask.crmid_label')}
      clientNameText={I18n.t('paramedic.myTask.clientname_label')}
      crmid={item.lc_OR_CRMID}
      dateText={item.crtype == '2' ? I18n.t('paramedic.myTask.reschedule_date_label')  : I18n.t('paramedic.myTask.date_label') }
      timeText={item.crtype == '2' ? I18n.t('paramedic.myTask.reschedule_time_label')  : I18n.t('paramedic.myTask.time_label') }
      addressText={I18n.t('paramedic.myTask.address_label')}
      deliveredTimeText={I18n.t('paramedic.myTask.delivered_label')}
      isStarted={item.isstarted==1?true:false}
      startText={item.isstarted==1? I18n.t('paramedic.myTask.started_label') : I18n.t('paramedic.myTask.start_label')}
      viewText={I18n.t('paramedic.myTask.view_label')}
      reasonText={item.crtype == '2' ? I18n.t('paramedic.myTask.reschedule_reason_label') : I18n.t('paramedic.myTask.cancel_reason_label')}
      name={item.patient_NAME}
      date={item.lc_OR_SCHEDULEDATETIME}
      time={item.lc_OR_APPOINTMENT_TIME.substring(0,5)}
      address={item.address}
      deliveredTime={item.deleveredtime.substring(11,16)}
      reason={item.cancelreason}
      selectedTab={selectedTab}
      viewCardClickHandler={() => cardClickHandler(item)}
      startCardClickHandler={() => item.isstarted==0?startCardClickHandler(item):null}
    />
  )
  const renderNodata=()=>{
    return(
      <>
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontFamily:FontMagneta.bold}}>No data found</Text>
    </View>
    </>
    )
  }
  const renderSearchItem = ({ item }) => (
    <SearchButtonView title={item.lc_PT_NAME}
      onPress={() => searchClickHandler(item.lc_PT_ID)}
      isActive={selectedSearchId == item.lc_PT_ID} />
  )
  const headerComponent = () => {
    return (
      <>
        <View style={styles.headerContainer}>
        <View style={styles.topTabContainer}>
          <MyTaskHeader
            title={title}
            textColor={titleColor}
            imageSource={imageSrc}
            numberOfTask={totalCount}
            textTask={taskText}
          />
          </View>
          <View style={styles.topSearchContainer}>
            <FlatList
              contentContainerStyle={{ flexGrow: 1, padding: 2 }}
              columnWrapperStyle={{ justifyContent: 'space-between'}}
              data={searchData}
              keyExtractor={(item) => item.id}
              numColumns={3}
              renderItem={renderSearchItem}
            />
          </View>
          <View style={styles.topTabContainer}>
          <TabContainer
            pendingText={I18n.t('paramedic.myTask.pending_label')}
            completedText={I18n.t('paramedic.myTask.completed_label')}
            cancelledAndRescheduleText={I18n.t('paramedic.myTask.cancelledandreschedule_label')}
            selectedTab={selectedTab}
            changeTab={changeTab} />
            </View>
        </View>

      </>
    )
  }
  return (
    <RootView pageNo={'35'} loading={loading} connected={isConnected}>
    <Toast
      showToast={showToast}
      msg={errorMsg}
      bgColor={Colors.error}
      txtColor={Colors.background}
    />
      <View style={styles.rootView}>
        <View style={styles.flatListContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.flatListInnerContainer}
            ListHeaderComponent={headerComponent}
            ListEmptyComponent={renderNodata}
          />
        </View>
        <ModalSuccess
          visible={showSuccessModal}
          title={I18n.t('paramedic.myTask.success_label')}
          message={I18n.t('paramedic.myTask.start_time_success_label')}
          pageNumber={'38'}
        />
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
     alignItems: 'center', 
     justifyContent: 'flex-start'
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.pnsTextColor
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black
  },
  searchFirstContaner:
  {
    flexDirection: 'row',
    marginTop: 20,
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  searchSecondContainer:
  {
    flexDirection: 'row',
    marginVertical: 15,
    alignItems: 'flex-start',
    justifyContent: 'flex-start'
  },
  headerContainer:
  {
    flexDirection: 'column',
    marginVertical: 20,
    width:wp('100%'),
  },
  topTabContainer:{
    width: '100%',
    alignItems: 'center',
    justifyContent:'center'
  },
  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10
  },

  flatListInnerContainer:
  {
    flexGrow: 1,
    paddingBottom: 30
  },
  flatList:
    { flex: 1 },
  flatListContainer:
  {
    alignItems: 'flex-start',
  },
  topSearchContainer: {

    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    overflow: "scroll",
  }
})

export default PNSScreen;
