import React from 'react';
import moment from 'moment';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import ProfileStartDayScreen from './Screen';
import {Paramedic} from '../../../navigations/RouteTypes';
import {dayStart, updateLocation} from '../../../store/Actions';
import {
  locationPermission,
  getCurrentLocation,
} from '../../../services/Permissions';
class ProfileStartDay extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  startDaySubmitHandler = () => {
    const date = new Date();
    const startDate = moment(date).format('DD-MM-YYYY');
    const startTime = moment(date).format('HH:mm');

    const data = {
      technician_id: this.props.userId,
      lang_id: 1,
      date: startDate, // '16-03-2021',
      time: startTime, //'09:00',
      tech_latitude: this.props.location ? this.props.location.latitude : '',
      tech_longitude: this.props.location ? this.props.location.longitude : '',
    };
    this.props.onDaystart(data, this.props.accessToken);
  };

  userTrackHandler = async () => {
    let location = null;
    const permit = await locationPermission();
    if (permit == 'granted') {
      location = await getCurrentLocation();
      console.log('location =========>', location);
      this.props.onUpdateLocation(location);
    }
  };

  componentDidMount = () => {
    this.userTrackHandler();
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.daystartStatus != this.props.daystartStatus &&
      this.props.daystartStatus == true
    ) {
      this.props.navigation.navigate(Paramedic.myDrawer);
    }
  };

  render() {
    return (
      <ProfileStartDayScreen
        startDaySubmitHandler={this.startDaySubmitHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    userId: state.signIn.userId,
    accessToken: state.signIn.accessToken,
    message: state.dayStart.message,
    location: state.dayStart.location,
    daystartLoading: state.dayStart.daystartLoading,
    daystartStatus: state.dayStart.daystartStatus,
    daystartError: state.dayStart.daystartError,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onDaystart: (data, token) => dispatch(dayStart(data, token)),
    onUpdateLocation: (data, token) => dispatch(updateLocation(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ProfileStartDay);
