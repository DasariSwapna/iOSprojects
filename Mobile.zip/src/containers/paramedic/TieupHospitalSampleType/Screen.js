import React, { useRef } from 'react';
import { View, StyleSheet, Platform ,Text} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import { Font, FontMagneta, FontSize } from '../../../config/Fonts';
import { FlatList } from 'react-native-gesture-handler';
import MedicalCenterNameView from '../../../components/MedicalCenterNameView';
import SearchBar from '../../../components/SearchBar';
import {
  widthPercentageToDP as wp,
  heightPercentageToDP as hp,
} from 'react-native-responsive-screen';
import { NetworkContext } from '../../../contexts/NetworkContext';
import { Toast } from '../../../components/Toast';
function TieupHospitalSampleTypeScreen({ data, cardClickHandler,loading,showToast,errorMsg,searchText,actionSearch}) {
  const { isConnected } = React.useContext(NetworkContext);
  const renderItem = ({ item }) => (
    <MedicalCenterNameView
      customerName={item.SAMPLE_TYPE}
      cardClickHandler={()=>cardClickHandler(item)}
    />
  );
  const renderNodata=()=>{
    return(
      <>
    <View style={{flex:1,alignItems:'center',justifyContent:'center'}}>
    <Text style={{fontFamily:FontMagneta.bold}}>No data found</Text>
    </View>
    </>
    )
  }
  return (
    <RootView pageNo={'106'} loading={loading} connected={isConnected}>
    <Toast
      showToast={showToast}
      msg={errorMsg}
      bgColor={Colors.error}
      txtColor={Colors.background}
    />
      <View style={styles.rootView}>
        <View
          style={{
            width: wp('90%'),
            marginHorizontal: wp('5%'),
            height: Platform.OS == 'ios' ? hp('6%') : hp('7%'),
            marginTop: hp('3%'),
            paddingHorizontal: wp('2%'),
            justifyContent: 'center',
          }}>
         <SearchBar onChangehandler={actionSearch} value={searchText} />
        </View>
        <View style={styles.flatlistContainer}>
          <FlatList
            showsVerticalScrollIndicator={false}
            style={styles.flatList}
            data={data}
            renderItem={renderItem}
            keyExtractor={item => item.id}
            contentContainerStyle={styles.flatlistInnerContainer}
            ListEmptyComponent={renderNodata}
          />
        </View>
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10,
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.tieuphospitalColor,
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  textTab: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
  },
  numberOfTaskContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  buttonText: {
    fontFamily: Font.extraBold,
    alignSelf: 'center',
    color: Colors.background,
  },
  bottomTabLine: {
    width: '35%',
    height: 2.5,
    alignItems: 'center',
    marginTop: 10,
    orderRadius: 20,
    marginBottom: -2,
  },
  tabContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomColor: Colors.card,
    borderBottomWidth: 2,
    marginHorizontal: 10,
    flexDirection: 'row',
    paddingHorizontal: 10,
    marginTop: '6%',
  },

  headerContainer: {
    flexDirection: 'column',
    marginVertical: 20,
    marginHorizontal: 10,
  },

  rowDirection: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },

  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10,
    marginRight: '25%',
  },

  tabRowTwoContainer: {
    flex: 1,
    alignItems: 'center',
  },

  flatlistContainer: {
    width: '100%',
    alignItems: 'center',
    height: '70%',
    marginVertical: '5%',
  },
  flatlistInnerContainer: {
    flexGrow: 1,
    paddingBottom: 40,
  },

  flatList: {
    flex: 1,
    width: '100%',
    paddingHorizontal: 10,
  },

  iconContainer: {
    marginLeft: 10,
  },
});

export default TieupHospitalSampleTypeScreen;
