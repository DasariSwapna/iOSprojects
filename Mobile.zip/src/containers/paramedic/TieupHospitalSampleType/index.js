import React from 'react';
import { connect } from 'react-redux';
import { Paramedic } from '../../../navigations/RouteTypes';
import TieupHospitalSampleTypeScreen from './Screen';
import { mytaskGetTieupHospitalSampleType, mytaskInsertOrderRegularBeat, mytaskGetCrmidOrderidForRegularBeat } from '../../../store/Actions';
import { delay } from '../../../utils/Helpers';
const data = [
  {
    id: 1,
    testType: 'Heel Prick + Urine'
  },
  {
    id: 2,
    testType: 'Heel Prick'
  },
  {
    id: 3,
    testType: 'Urine'
  },
  {
    id: 4,
    testType: 'Amniotic fluid'
  },
  {
    id: 5,
    testType: 'Cord Blood + Urine'
  },
  {
    id: 6,
    testType: 'Endometrial Tissue'
  },
];
class TieupHospitalSampleType extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      showToast: false,
      errorMsg: '',
      barcodeNumber: this.props.route.params.barcodeNumber,
      visitTimeId: this.props.route.params.visitTimeId,
      visitName: this.props.route.params.visitName,
      visitTime: this.props.route.params.visitTime,
      hospitalName: this.props.route.params.hospitalName,
      hospitalId: this.props.route.params.hospitalId,
      showToast: false,
      errorMsg: '',
      searchText: ''
    };
  }
  cardClickHandler = (item) => {

    // alert(JSON.stringify(item))

    const data = {
      "crmid": this.state.barcodeNumber,
      "sampletypeid": item.ID,
      "visittimeid": this.state.visitTimeId,
      "hospitalid": this.state.hospitalId,
      "userid": this.props.UserID

    }

    this.props.onMytaskInsertOrderDetailsForRegularBeat(data, this.props.accessToken);
  };
  nextClickHandler = () => {
    //this.props.navigation.navigate(Paramedic.samplePickUp);

    //  const listSelected = this.state.data.filter(item => item.isSelected == true);
    //  var arr = [];
    //  for (var i = 0; i < listSelected.length; i++) {
    //    arr.push({
    //      sample_id: listSelected[i].lc_SCD_ID,
    //    });
    //  }




  }


  cancelClickHandler = () => {

  }
  // componentDidMount(){
  //   alert(this.state.barcodeNumber)
  // }

  //  radioPress = (itemList) => {
  //    const newData = this.state.data.map(item => {
  //      if (item.lc_TD_TEST_ID == itemList.lc_TD_TEST_ID) {
  //        return {
  //          ...item,
  //          isSelected: !item.isSelected,
  //        }
  //      }
  //      return item
  //    })

  //    console.log(newData);
  //    this.setState({ data: newData })
  //  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };
  componentDidMount() {
    this.props.onMytaskGetTieupHospitalSampleType(null, this.props.accessToken);
  }
  componentDidUpdate = prevProps => {
    if (
      prevProps.MytaskGetTieupHospitalSampleTypeStatus == false &&
      this.props.MytaskGetTieupHospitalSampleTypeStatus != prevProps.MytaskGetTieupHospitalSampleTypeStatus
    ) {

      this.setState({ data: this.props.MytaskGetTieupHospitalSampleTypeResponse })

    }

    if (
      prevProps.MytaskGetTieupHospitalSampleTypeError == false &&
      this.props.MytaskGetTieupHospitalSampleTypeError != prevProps.MytaskGetTieupHospitalSampleTypeError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.MytaskInsertOrderDetailsForRegularBeatError == false &&
      this.props.MytaskInsertOrderDetailsForRegularBeatError != prevProps.MytaskInsertOrderDetailsForRegularBeatError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.MytaskInsertOrderDetailsForRegularBeatStatus == false &&
      this.props.MytaskInsertOrderDetailsForRegularBeatStatus != prevProps.MytaskInsertOrderDetailsForRegularBeatStatus
    ) {

      var tempOrderId = this.props.MytaskInsertOrderDetailsForRegularBeatResponse.INSERT_ORDER_DETAILS_REGULAR_VISIT_RESPONSE[0].ORDER_ID
      var tempCrmId = this.props.MytaskInsertOrderDetailsForRegularBeatResponse.INSERT_ORDER_DETAILS_REGULAR_VISIT_RESPONSE[0].CRM_ID

      this.props.onMytaskGetCrmidOrderidForRegularBeat({
        orderId: tempOrderId,
        crmId: tempCrmId
      }, this.props.accessToken)

      this.props.navigation.navigate(Paramedic.regularBeat, {
        title: 'Regular Beat',
        visitTimeId: this.state.visitTimeId,
        visitName: this.state.visitName,
        visitTime: this.state.visitTime,
        userId: this.props.UserID,
        hospitalName: this.state.hospitalName,
        hospitalId: this.state.hospitalId,
      })

    }
  }
  actionSearch = (text) => {

    var arraydata = this.props.MytaskGetTieupHospitalSampleTypeResponse.filter(function (x) {
      return (x.SAMPLE_TYPE.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1)
    });
    if(arraydata.length!=0){
      this.setState({
        data: arraydata,
        searchText: text
      })
    }else{
      this.setState({
      data:[],
      searchText:text
    })
    }
   
  }

  // actionSearch = (e) => {
  //   let text = e.toLowerCase()
  //   let samples = this.state.data
  //   let filteredName = samples.filter((item) => {
  //     return item.SAMPLE_TYPE.toLowerCase().match(text)
  //   })
  //   if (!text || text === '') {
  //     this.setState({
  //       data: this.state.data
  //     })
  //   } else if (!Array.isArray(filteredName) && !filteredName.length) {
  //     // set no data flag to true so as to render flatlist conditionally
  //     this.setState({
  //       data: []
  //     })
  //   } else if (Array.isArray(filteredName)) {
  //     this.setState({
  //       data: filteredName
  //     })
  //   }
  // }
  render() {
    return <TieupHospitalSampleTypeScreen
      data={this.state.data}
      cardClickHandler={this.cardClickHandler}
      loading={this.props.MytaskGetTieupHospitalSampleTypeLoading || this.props.MytaskInsertOrderDetailsForRegularBeatLoading}
      showToast={this.state.showToast}
      errorMsg={this.state.errorMsg}
      searchText={this.state.searchText}
      actionSearch={this.actionSearch}

    />;
  }
}

const mapStateToProps = state => {
  return {
    message: state.mytask.message,
    accessToken: state.signIn.accessToken,
    UserID: state.signIn.userId,

    MytaskGetTieupHospitalSampleTypeLoading: state.mytask.MytaskGetTieupHospitalSampleTypeLoading,
    MytaskGetTieupHospitalSampleTypeStatus: state.mytask.MytaskGetTieupHospitalSampleTypeStatus,
    MytaskGetTieupHospitalSampleTypeError: state.mytask.MytaskGetTieupHospitalSampleTypeError,
    MytaskGetTieupHospitalSampleTypeResponse: state.mytask.MytaskGetTieupHospitalSampleTypeResponse,

    MytaskInsertOrderDetailsForRegularBeatLoading: state.mytask.MytaskInsertOrderDetailsForRegularBeatLoading,
    MytaskInsertOrderDetailsForRegularBeatStatus: state.mytask.MytaskInsertOrderDetailsForRegularBeatStatus,
    MytaskInsertOrderDetailsForRegularBeatError: state.mytask.MytaskInsertOrderDetailsForRegularBeatError,
    MytaskInsertOrderDetailsForRegularBeatResponse: state.mytask.MytaskInsertOrderDetailsForRegularBeatResponse

  };
};

const mapDispatchToProps = dispatch => {
  return {
    onMytaskInsertOrderDetailsForRegularBeat: (data, token) =>
      dispatch(mytaskInsertOrderRegularBeat(data, token)),

    onMytaskGetTieupHospitalSampleType: (data, token) =>
      dispatch(mytaskGetTieupHospitalSampleType(data, token)),

    onMytaskGetCrmidOrderidForRegularBeat: (data, token) =>
      dispatch(mytaskGetCrmidOrderidForRegularBeat(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(TieupHospitalSampleType);
