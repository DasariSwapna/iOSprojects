import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import RootView from '../../../components/RootView';

function CalenderScreen() {
  return (
    <RootView>
      <Text>Home</Text>
    </RootView>
  );
}

export default CalenderScreen;
