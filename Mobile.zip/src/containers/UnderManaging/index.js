import React from "react";
import {
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  Dimensions,
  KeyboardAvoidingView
} from "react-native";
import RootView from "../../components/RootView";
import Colors from "../../config/Colors";
import { Font, FontSize } from "../../config/Fonts";
import Images from "../../constants/Images";
import {
  heightPercentageToDP as hp,
  widthPercentageToDP as wp
} from "react-native-responsive-screen";
import { connect } from "react-redux";
import MaterialIcon from "react-native-vector-icons/MaterialIcons";

function InterNetScreen({}) {
  return (
    <RootView pageNo={"02"}>
      <KeyboardAvoidingView style={{ flex: 1 }}>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.mainContainer}>
            <ImageBackground
              source={Images.loginBg}
              style={styles.bgImageContainer}
              resizeMode="stretch"
            >
              <View style={styles.loginContainer}>
                <Image
                  source={Images.logo}
                  style={styles.logoImageConatiner}
                  resizeMode="cover"
                />
                <Text
                  style={{
                    fontFamily: Font.extraBold,
                    fontSize: FontSize.doubleExtra,
                    color: Colors.border,
                    paddingVertical: hp("4%"),
                    marginTop: hp("5%")
                  }}
                >
                  Under  Maintenance
                </Text>
                <MaterialIcon
                  name={"signal-wifi-off"}
                  size={hp("10%")}
                  color={Colors.border}
                />
                <Text
                  style={{
                    fontFamily: Font.regular,
                    fontSize: FontSize.extraLarge,
                    color: Colors.border,
                    paddingVertical: hp("4%"),
                    textAlign: "center",
                    width: wp("80%")
                  }}
                >
                  You cannot access the apllication now.Application is under going  maintenance
                </Text>
              </View>
            </ImageBackground>
          </View>
          <View style={styles.signUpContainer} />
          <View
            style={{
              flex: 1,
              alignItems: "center",
              justifyContent: "flex-end"
            }}
          />
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

InterNetScreen.prototype = {};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20
  },
  mainContainer: {
    width: "100%",
    height: "80%",
    alignItems: "center",
    justifyContent: "center"
  },
  bgImageContainer: {
    width: "100%",
    height: "100%",
    resizeMode: "contain"
  },
  loginContainer: {
    flex: 1,
    width: "100%",
    height: "100%",
    alignItems: "center",
    justifyContent: "center"
  },

  logoImageConatiner: {
    height: 60,
    alignSelf: "center"
  },

  loginOtpContainer: {},
  signUpContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16
  }
});

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    onGetLogin: kindOf => dispatch(getLogin(kindOf))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(InterNetScreen);
