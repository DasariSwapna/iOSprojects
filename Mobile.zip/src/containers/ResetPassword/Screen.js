import {placeholder} from '@babel/types';
import React, {useRef} from 'react';
import {
  Dimensions,
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../locale/i18n';
import Button from '../../components/Button';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import  {Font, FontMagneta, FontSize} from '../../config/Fonts';
import Images from '../../constants/Images';
import {InputField} from '../../components/InputField';
import OtpModal from '../../components/OtpModal';
import {Toast} from '../../components/Toast';
import PageNo from '../../constants/PageNo';

const {width, height} = Dimensions.get('screen');
const screenHeight = height;
const paddingHr = width * 0.06;

function ResetPasswordScreen({
  password,
  isValidPassword,
  passwordValidationMsg,
  isValidPassword1,
  passwordValidationMsg1,
  passwordChangeHandler,
  confirmPassword,
  isValidconfirmPassword,
  confirmPasswordValidationMsg,
  confirmPasswordChangeHandler,
  passwordSubmitHandler,
  showToast,
  errorMsg,
}) {
  return (
    <RootView pageNo={PageNo.setPassword}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 50 : 70}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={{height: '100%'}}>
            <View style={styles.mainContainer}>
              <ImageBackground
                source={Images.forgotpasswordBg}
                style={styles.bgImageContainer}
                resizeMode="stretch">
                <View style={styles.loginContainer}>
                  <View
                    style={{
                      alignItems: 'flex-start',
                      justifyContent: 'center',
                    }}>
                    <Text
                      style={{
                        fontFamily: Font.extraBold,
                        fontSize: FontSize.semiLarge,
                        color: Colors.text,
                        paddingHorizontal: paddingHr,
                      }}>
                      Enter New Password
                    </Text>
                  </View>
                  <View style={styles.inputFieldConatiner}>
                    <InputField
                      placeholder={'Enter Password'}
                      maxLength={26}
                      value={password}
                      isValid={isValidPassword}
                      validationMsg={passwordValidationMsg}
                      onChangeHandler={passwordChangeHandler}
                      isPassword={true}
                    />
                    <InputField
                      placeholder={'Confirm Password'}
                      maxLength={26}
                      value={confirmPassword}
                      isValid={isValidconfirmPassword}
                      validationMsg={confirmPasswordValidationMsg}
                      onChangeHandler={confirmPasswordChangeHandler}
                      isPassword={true}
                    />
                      {!isValidPassword1 && (
            <Text style={styles.textValidationMsg}>
              {!isValidPassword1 ? passwordValidationMsg1 : ''}
            </Text>
          )}
                  </View>
                  <View style={styles.buttonContainer}>
                    <View style={styles.loginButtonContainer}>
                      <Button
                        title="Submit"
                        onPress={() => passwordSubmitHandler()}
                      />
                    </View>
                  </View>
                </View>
              </ImageBackground>
            </View>
            <View style={styles.signUpContainer}>
              {/* <Text style={styles.firstText}>Are you a new LifeCell?</Text>
              <Button
                title="Sign up"
                isTransparent
                buttonStyle={{minWidth: 60, paddingHorizontal: 2}}
                buttonTextStyle={styles.secondText}
                onPress={signUpHandler}
              /> */}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

ResetPasswordScreen.prototype = {
  otp: PropTypes.string,
  showOtpModal: PropTypes.bool,
  mobileNoOrEmail: PropTypes.string,
  isValidMobileNoOrEmail: PropTypes.string,
  isValidOtp: PropTypes.bool,
  mobileNoOrEmailValidationMsg: PropTypes.string,
  otpValidationMsg: PropTypes.string,
  mobileNoOrEmailChangeHandler: PropTypes.func,
  otpChangeHandler: PropTypes.func,
  requestOtpSubmitHandler: PropTypes.func,
  otpSubmitHandler: PropTypes.func,
  otpDismissHandler: PropTypes.func,
  otpResendHandler: PropTypes.func,
  signUpHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
  },
  mainContainer: {
    width: '100%',
    height: screenHeight * 0.52,
    overflow: 'hidden',
  },
  bgImageContainer: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  loginContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    justifyContent: 'center',
  },
  logoConatiner: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 36,
  },
  logoImageConatiner: {
    height: 60,
    alignSelf: 'center',
  },
  signInText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    fontWeight: '600',
    marginVertical: 10,
  },
  inputFieldConatiner: {
    width: '100%',
    alignSelf: 'center',
    justifyContent: 'center',
    paddingBottom: 5,
  },

  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
  },
  loginButtonContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    paddingTop: 26,
    paddingBottom: 10,
    marginLeft: 26,
  },
  loginOtpContainer: {},
  signUpContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  firstText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    paddingHorizontal: 4,
  },
  secondText: {
    color: Colors.teal,
    fontFamily: Font.extraBold,
  },
  textValidationMsg: {
    width: '88%',
    color: Colors.button,
    fontFamily: FontMagneta.medium,
    fontSize: FontSize.regular,
    fontWeight: '600',
    alignSelf: 'center',
    paddingHorizontal: 10,
    // paddingVertical: 4,
  },
});

export default ResetPasswordScreen;
