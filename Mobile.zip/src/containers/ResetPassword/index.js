import React from 'react';
import {BackHandler} from 'react-native';
import {connect} from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import ResetPasswordScreen from './Screen';
import HelperText from '../../constants/HelperText';
import {Auth} from '../../navigations/RouteTypes';
import {getResetPassword} from '../../store/Actions';
import {validatematchPassword, validatePassword} from '../../utils/Validators';
import {delay} from '../../utils/Helpers';

class ResetPassword extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      password: '',
      isValidPassword: '',
      passwordValidationMsg: '',
      isValidPassword1: '',
      passwordValidationMsg1: '',
      confirmPassword: '',
      isValidconfirmPassword: '',
      confirmPasswordValidationMsg: '',
      ShowToast: false,
      errorMsg: '',
    };
  }

  passwordChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        password: val,
      });
    }
  };

  confirmPasswordChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        confirmPassword: val,
      });
    }
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  passwordSubmitHandler = () => {
    const valid1 = validatePassword(this.state.password);
    const valid2 = validatePassword(this.state.confirmPassword);
    const valid3 = validatematchPassword(
      this.state.password,
      this.state.confirmPassword,
    );

    if (valid1.val && valid2.val && valid3.val) {
      this.setState({
        isValidPassword: valid1.val,
        isValidconfirmPassword: valid2.val,
        passwordValidationMsg: '',
        confirmPasswordValidationMsg: '',
      });
      if (this.state.password == this.state.confirmPassword) {
        const data = {
          user_id: this.props.mobileNo,
          lang_id: '1',
          password: this.state.password,
        };
        this.props.resetPassword(data, this.props.accessToken);
      } else {
        this.setState(
          {
            errorMsg: 'Enter password mismatch with the confirm password',
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
      }
    } else {
      this.setState({
        isValidPassword: valid1.val,
        isValidPassword1: valid3.val,
        isValidconfirmPassword: valid2.val,
        passwordValidationMsg: valid1.msg,
        passwordValidationMsg1: valid3.msg,
        confirmPasswordValidationMsg: valid2.msg,
      });
    }
  };

  backHandler = () => {
    this.props.navigation.navigate(Auth.signUp);
    return true;
  };

  componentDidMount = () => {
    BackHandler.addEventListener('hardwareBackPress', this.backHandler);
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.resetPasswordStatus != this.props.resetPasswordStatus &&
      this.props.resetPasswordStatus == true
    ) {
      this.props.navigation.navigate(Auth.signIn);
    }
    if (
      prevProps.resetPasswordError != this.props.resetPasswordError &&
      this.props.resetPasswordError == true
    ) {
      this.setState({
        errorMsg: this.props.resetPasswordError,
        showToast: true,
      });
    }
  };

  render() {
    return (
      <ResetPasswordScreen
        password={this.state.password}
        isValidPassword={this.state.isValidPassword}
        passwordValidationMsg={this.state.passwordValidationMsg}
        isValidPassword1={this.state.isValidPassword1}
        passwordValidationMsg1={this.state.passwordValidationMsg1}
        confirmPassword={this.state.confirmPassword}
        isValidconfirmPassword={this.state.isValidconfirmPassword}
        confirmPasswordValidationMsg={this.state.confirmPasswordValidationMsg}
        passwordChangeHandler={this.passwordChangeHandler}
        confirmPasswordChangeHandler={this.confirmPasswordChangeHandler}
        passwordSubmitHandler={this.passwordSubmitHandler}
        showToast={this.state.ShowToast}
        errorMsg={this.state.errorMsg}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.resetPassword.message,
    accessToken: state.resetPassword.accessToken,
    resetPasswordLoading: state.resetPassword.resetPasswordLoading,
    resetPasswordStatus: state.resetPassword.resetPasswordStatus,
    resetPasswordError: state.resetPassword.resetPasswordError,
    mobileNo: state.forgetPassword.mobNo,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    resetPassword: (data, token) => dispatch(getResetPassword(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ResetPassword);
