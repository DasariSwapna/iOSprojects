import React from 'react';
import {BackHandler} from 'react-native';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import HomeScreen from './Screen';
import {Paramedic, Sales, Manager} from '../../../navigations/RouteTypes';
import {getApprovalCount} from '../../../store/Actions';
import {delay} from '../../../utils/Helpers';

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      isValidated: false,
      isDiscount: false,
      showToast: false,
      errorMsg: '',
      approavalResponse: '',
      typeid: '',
      type: '',
    };
    this.back = null;
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  backHandler = () => {
    console.log('hardware back button pressed');
  };

  componentDidMount() {
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalcountDetails(null, this.props.accessToken);
    });
    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }

  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.approvalCountError == false &&
      this.props.approvalCountError != prevProps.approvalCountError
    ) {
      this.setState(
        {
          errorMsg: this.props.approvalCountmessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  mouQuotationHandler = (typeid, type) => {
    this.props.navigation.navigate(Manager.quotationhome, {
      isDiscount: false,
      title: type,
      typeid: typeid,
      type: type,
    });
  };

  mouQuotationHandler1 = (typeid, type) => {
    this.props.navigation.navigate(Manager.quotationhome, {
      isDiscount: false,
      title: type,
      typeid: typeid,
      type: type,
    });
  };
  mouQuotationHandler2 = (typeid, type) => {
    this.props.navigation.navigate(Manager.quotationhome, {
      isDiscount: true,
      title: 'Discount',
      typeid: typeid,
      type: type,
    });
  };

  render() {
    return (
      <HomeScreen
        isDiscount={this.state.isDiscount}
        typeid={this.state.typeid}
        typeid={this.state.typeid}
        // approavalResponse = {this.state.approavalResponse}
        mouQuotationHandler={this.mouQuotationHandler}
        mouQuotationHandler1={this.mouQuotationHandler1}
        mouQuotationHandler2={this.mouQuotationHandler2}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        loading={this.props.managerapprovalcountLoading}
        approavalResponse={this.props.managerapprovalCount}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    managerapprovalcountError: state.salesmanagerapprovals.approvalCountError,
    managerapprovalcountStatus: state.salesmanagerapprovals.approvalCountStatus,
    managerapprovalcountLoading:
      state.salesmanagerapprovals.approvalCountLoading,
    managerapprovalCount: state.salesmanagerapprovals.response,
    approvalCountmessage: state.salesmanagerapprovals.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalcountDetails: (data, token) =>
      dispatch(getApprovalCount(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
