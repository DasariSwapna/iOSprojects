import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import PropTypes from 'prop-types';
import FaIcons from 'react-native-vector-icons/FontAwesome5';
import MaComIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import Icons from '../../../constants/Icons';
import HomeType from '../../../components/HomeType';
import BottomNav from '../../../components/BottomNav';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import I18n from '../../../locale/i18n';
import {Toast} from '../../../components/Toast';

const {width, height} = Dimensions.get('screen');
const boardHeight = height * 0.2;

function MenuIcon({label, iconName, onPressHandler}) {
  return (
    <View>
      <TouchableOpacity
        style={styles.iconContainer}
        onPress={() => onPressHandler()}>
        {iconName == 'tasks' ? (
          <FaIcons name={iconName} color={Colors.primary} size={22} />
        ) : (
          <MaComIcons name={iconName} color={Colors.primary} size={28} />
        )}
        <Text>{label}</Text>
      </TouchableOpacity>
    </View>
  );
}

MenuIcon.prototype = {
  label: PropTypes.string,
  iconName: PropTypes.string,
  onPressHandler: PropTypes.func,
};

function BoardItem({title, value}) {
  return (
    <View style={{flexDirection: 'row', alignItems: 'center'}}>
      <View style={{width: '80%', justifyContent: 'center', paddingLeft: 5}}>
        <Text
          style={{
            color: Colors.text,
            fontFamily: Font.extraBold,
            fontSize: FontSize.medium,
          }}>
          {title}
        </Text>
      </View>
      <View
        style={{
          width: '20%',
          alignItems: 'flex-end',
          justifyContent: 'center',
          paddingRight: 2,
          paddingBottom: 6,
        }}>
        <Text
          style={{fontFamily: FontMagneta.semiBold, fontSize: FontSize.medium}}>
          {value}
        </Text>
      </View>
    </View>
  );
}

function Board({}) {
  return (
    <View
      style={{
        width: wp('85%'),
        height: hp('20%'),
        // minWidth: wp('85%'),
        //  minHeight: hp('18%'),
        alignSelf: 'center',
        justifyContent: 'space-between',
        marginTop: hp('2.0%'),
        paddingHorizontal: hp('1.6%'),
        paddingVertical: hp('1.6%'),
        paddingBottom: hp('2.4%'),
        borderRadius: 16,
        backgroundColor: Colors.background,
      }}>
      <BoardItem title={'Order Value (MTD)'} value={20000} />
      <View
        style={{
          width: wp('80%'),
          height: hp('0.1'),
          backgroundColor: Colors.bgDarkGray,
        }}
      />
      <BoardItem title={'Order count (MTD)'} value={26} />
      <View
        style={{
          width: wp('80%'),
          height: hp('0.1'),
          backgroundColor: Colors.bgDarkGray,
        }}
      />
      <BoardItem title={'New MOU Conversions (MTD)'} value={12} />
    </View>
  );
}

function HomeScreen({
  homeNavHandler,
  alertNavHandler,
  createTaskNavHandler,
  myTaskNavHandler,
  calendarNavHandler,
  mouQuotationHandler,
  mouQuotationHandler2,
  mouQuotationHandler1,
  showToast,
  data,
  errorMsg,
  loading,
  approavalResponse,
}) {
  const renderItem = ({item}) => {
    return (
      <HomeType
        imageSource={item.icon_PATH}
        color={Colors.teal}
        label={item.type}
        label1={I18n.t('manager.home.pending_quot_label')}
        label2={I18n.t('manager.home.approved_quot_label')}
        label3={item.pending}
        label4={item.approved}
        //  onPress={mouQuotationHandler1(approavalResponse[1].type_ID)}
        onClickListener={() => mouQuotationHandler1(item.type_ID, item.type)}
      />
    );
  };

  return (
    <RootView pageNo={'5'} isPageWhite loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View
              style={{
                width: wp('100%'),
                height: hp('13%'),
                // height: boardHeight / 1.2,
                borderBottomLeftRadius: 15,
                borderBottomRightRadius: 15,
                backgroundColor: Colors.card,
              }}>
              <View>
                <Board />
              </View>
            </View>
            <View
              style={{
                width: wp('100%'),
                height: hp('13%'),
                // marginVertical : hp('10%'),
                marginTop: hp('9%'),
                //minHeight: hp('10%'),
                // borderBottomLeftRadius: wp('-2%'),
                //  borderBottomRightRadius: wp('-2%'),
              }}>
              <View>
                <Board />
              </View>
            </View>

            {approavalResponse == null ||
            approavalResponse == undefined ||
            approavalResponse == '' ? null : (
              <View
                style={{
                  marginTop: hp('9%'),
                  // width : wp('80%'),
                  //  justifyContent: 'space-between',
                  alignItems: 'center',
                  //  justifyContent: 'center',
                }}>
                <View
                  style={{width: wp('120%'), flex: 1, marginLeft: wp('22%')}}>
                  <FlatList
                    showsVerticalScrollIndicator={false}
                    style={styles.flatList}
                    data={approavalResponse}
                    renderItem={renderItem}
                    keyExtractor={item => item.type_ID}
                    contentContainerStyle={styles.flatListInnerContainer}
                  />
                </View>
              </View>
            )}
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
      <View style={styles.bottomContainer}></View>
    </RootView>
  );
}

HomeScreen.prototype = {};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    // paddingBottom: 20,
  },
  flatList: {flex: 1},
  flatListContainer: {
    // alignItems: 'center',
    // alignSelf : 'center'
    //marginLeft: wp('25%'),
  },
  flatListInnerContainer: {
    flexGrow: 1,
    //  paddingBottom: 30,
  },
  mainContainer: {
    flex: 1,
    width: wp('100%'),
    paddingBottom: hp('6.2%'),
    backgroundColor: Colors.bgLightGray,
  },
  bottomContainer: {
    // flex: 1,
    alignItems: 'center',
  },
  bottomNavContainer: {
    flex: 1,
    position: 'absolute',
    bottom: 0,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 2,
    backgroundColor: Colors.background,
    borderTopWidth: 1,
    borderTopColor: Colors.card,
  },
  iconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 2,
  },
  centerMenuIcon: {
    position: 'absolute',
    top: -66,
    left: -6,
    width: 72,
    height: 72,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 36,
    backgroundColor: Colors.primary,
  },
  bottomContainer: {
    alignItems: 'center',
  },
});

export default HomeScreen;
