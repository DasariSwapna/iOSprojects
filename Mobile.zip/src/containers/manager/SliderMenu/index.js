import React from 'react';
import {connect} from 'react-redux';
import {Paramedic} from '../../../navigations/RouteTypes';
import SliderMenuScreen from './Screen';
import {getLogout} from '../../../store/Actions';

class SliderMenu extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      popupToggle: false,
      userSelection: false,
    };
  }

  homeNavHandler = () => {
    this.props.navigation.navigate(Paramedic.home);
  };

  myPerformanceNavHandler = () => {
    this.props.navigation.navigate(Paramedic.myPerformance);
  };

  sampleTrackingNavHandler = () => {};

  myIncentivesNavHandler = () => {};

  helplineNavHandler = () => {};

  logoutSubmitHandler = () => {
    console.log('logout submit');
    this.props.onGetLogout();
  };

  render() {
    return (
      <SliderMenuScreen
        name={`${this.props.firstName} ${this.props.lastName}`}
        mobileNo={this.props.mobileNo}
        version={this.props.appVersionNumber}
        homeNavHandler={this.homeNavHandler}
        myPerformanceNavHandler={this.myPerformanceNavHandler}
        sampleTrackingNavHandler={this.sampleTrackingNavHandler}
        myIncentivesNavHandler={this.myIncentivesNavHandler}
        helplineNavHandler={this.helplineNavHandler}
        logoutSubmitHandler={this.logoutSubmitHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    name: state.signIn.username,
    firstName: state.signIn.firstName,
    lastName: state.signIn.lastName,
    mobileNo: state.signIn.mobileNo,
    appVersionNumber: state.common.appVersionNumber,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetLogout: () => dispatch(getLogout()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SliderMenu);
