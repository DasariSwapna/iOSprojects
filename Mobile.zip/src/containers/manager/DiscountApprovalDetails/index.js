import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import DiscountApprovedScreen from './Screen';
import Routes, {Manager} from '../../../navigations/RouteTypes';
import {getDiscountapprovaldetails} from '../../../store/Actions';
import {BackHandler} from 'react-native';

const data1 = [
  {
    title: 'Maternity Screening',
    amount: '5000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'QFPCR',
    amount: '8000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'Hb Pathies',
    amount: '9000/-INR',
    type: 'Blood sample',
  },
  {
    title: 'Free Testosterone',
    amount: '9000/-INR',
    type: 'Urine sample',
  },
];

var newtabledatas = [];

class DiscountApproved extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      isApproved: false,
      tableHead: ['Product', 'Test', 'Amount', 'Sample Type'],
      tableData: [
        ['Maternity Screening', '5000/- INR', 'Heel Prick'],
        ['QFPCR', '8000/- INR', 'Heel Prick'],
        ['Hb Pathies', '9000/- INR', 'Blood sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
      ],
      testData1: [],
      testData: [],
      data: data1,
      vendorID: this.props.route.params.vendorID,
      approvalstatus: this.props.route.params.approvalstatus,
      doctorDatas: '',
      headerTitle: this.props.route.params.title,
    };
    this.back = null;
  }

  Quotationhomehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    const data = {
      orderid: this.state.vendorID,
    };

    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalDetails(data, this.props.accessToken);
      this.props.navigation.setOptions({title: this.state.headerTitle});
    });

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  approvedButtonHandler = () => {
    this.props.navigation.navigate(Manager.quotationreviewstatus, {
      isApproved: true,
    });
  };

  reviseButtonHandler = () => {
    this.props.navigation.navigate(Manager.quotationreviewstatus, {
      isApproved: false,
    });
  };

  render() {
    return (
      <DiscountApprovedScreen
        headerTitle={this.state.headerTitle}
        isApproved={this.state.isApproved}
        reviseButtonHandler={this.reviseButtonHandler}
        approvedButtonHandler={this.approvedButtonHandler}
        tableHead={this.state.tableHead}
        tableData={this.props.discountapprovalDetailstestTableDetails}
        data={this.state.data}
        vendorID={this.state.vendorID}
        doctorDatas={this.props.discountapprovalDetails}
        testData1={this.props.managerapprovalproducttestDetails}
        loading={this.props.managerapprovaldetailsLoading}
        Quotationhomehandler={this.Quotationhomehandler}
        approvalstatus={this.state.approvalstatus}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    discountapprovaldetailstError:
      state.salesmanagerapprovals.discountapprovaldetailstError,
    discountapporvaldetailsStatus:
      state.salesmanagerapprovals.discountapporvaldetailsStatus,
    discountapprovaldetailsLoading:
      state.salesmanagerapprovals.discountapprovaldetailsLoading,
    discountapprovalDetailstestTableDetails:
      state.salesmanagerapprovals.discountapprovalDetailstestTableDetails,

    discountapprovalDetails:
      state.salesmanagerapprovals.discountapprovalDetails,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getDiscountapprovaldetails(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(DiscountApproved);
