import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import {isValidUsername, isValidPassword} from '../../../utils/Validators';
import QuotationReviewScreen from './Screen';
import Routes, {Manager, Sales} from '../../../navigations/RouteTypes';
import RNFetchBlob from 'rn-fetch-blob';
import {Platform} from 'react-native';
import {BackHandler} from 'react-native';

class QuotationReviewStatus extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isApproved: this.props.route.params.isApproved,
      isDiscount: this.props.route.params.isDiscount,
      resultID: this.props.route.params.resultID,
      PAYMENT_WAITING: false,
      PAYMENT_RECEIVED: false,
      PDF_name: 'Parthiban',
      accesionpath: 'http://samples.leanpub.com/thereactnativebook-sample.pdf',
    };
    this.back = null;
  }

  Quotationhomehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    // this.props.navigation.navigate(Manager.home);
    this.props.navigation.goBack(null);
    return true;
  };

  homeButtonHandler = () => {
    this.props.navigation.navigate(Manager.quotationhome);
    // {Platform.OS == "ios" ? actualDownloadiOS() : null}
  };
  componentDidMount(props) {
    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  componentWillUnmount = () => {
    this.back.remove();
  };

  render() {
    return (
      <QuotationReviewScreen
        isApproved={this.state.isApproved}
        isDiscount={this.state.isDiscount}
        resultID={this.state.resultID}
        homeButtonHandler={this.homeButtonHandler}
        Quotationhomehandler={this.Quotationhomehandler}
      />
    );
  }
}

actualDownloadiOS = () => {
  try {
    const {config, fs} = RNFetchBlob;
    let dirs = RNFetchBlob.fs.dirs;
    let options = {
      fileCache: false,
      appendExt: 'pdf',
      path: dirs.DocumentDir + '/' + 'Parthiban' + '.pdf',
    };
    config(options)
      .fetch('GET', 'http://samples.leanpub.com/thereactnativebook-sample.pdf')
      .then(res => {
        // do some magic here
        // RNFetchBlob.ios.openDocument();
        //  toastMsg(this.state.downloadtext);
        console.log('File download error 1', res.path());
      });
  } catch (error) {
    console.log('File download error', error);
  }
};

const mapStateToProps = state => {
  return {
    // loading: state.login.loading,
  };
};

const mapDispatchToProps = dispatch => {
  return {};
};

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(QuotationReviewStatus);
