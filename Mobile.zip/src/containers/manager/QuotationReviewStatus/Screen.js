import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import Images from '../../../constants/Images';
import Button from '../../../components/ButtonWhite';
import {Font, FontSize, FontMagneta} from '../../../config/Fonts';

import TextInputComponent from '../../../components/TextInputComponent';
import DropDownMenu from '../../../components/DropDownMenu';
import Data from '../../../constants/Data';
import InnerHeader from '../../../components/InnerHeader';
import Icon from 'react-native-vector-icons/FontAwesome';
import OtpModal from '../../../components/OtpModal';
import Icons from '../../../constants/Icons';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

function QuotationReviewScreen({
  isApproved,
  resultID,
  isDiscount,
  homeButtonHandler,
}) {
  return (
    <RootView pageNo={'M-08'}>
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <View style={{alignItems: 'center', marginTop: hp('25%')}}>
              {isApproved ? (
                <Image
                  source={Icons.approvalQuotation}
                  style={{
                    width: wp('25%'),
                    height: hp('10%'),
                  }}
                  resizeMode="contain"
                />
              ) : (
                <Image
                  source={Icons.revisionQuotation}
                  style={{
                    width: wp('25%'),
                    height: hp('10%'),
                  }}
                  resizeMode="contain"
                />
              )}

              <View style={{flexDirection: 'row'}}>
                {isApproved ? (
                  <View style={{flexDirection: 'row'}}>
                    <Text
                      style={{
                        color: Colors.teal,
                        fontFamily: FontMagneta.medium,
                        fontSize: FontSize.medium,
                        marginTop: hp('2%'),
                      }}>
                      {isDiscount == true ? 'CRM ID: ' : 'Quotation ID:'}
                    </Text>

                    <Text
                      style={{
                        color: Colors.teal,
                        fontFamily: FontMagneta.medium,
                        fontSize: FontSize.medium,
                        marginTop: hp('2%'),
                      }}>
                      {resultID}
                    </Text>
                  </View>
                ) : (
                  <View style={{flexDirection: 'row'}}>
                    <Text
                      style={{
                        color: Colors.darkPink,
                        fontFamily: FontMagneta.medium,
                        fontSize: FontSize.medium,
                        marginTop: hp('2%'),
                      }}>
                      Quotation ID:{' '}
                    </Text>

                    <Text
                      style={{
                        color: Colors.darkPink,
                        fontFamily: FontMagneta.medium,
                        fontSize: FontSize.medium,
                        marginTop: hp('2%'),
                      }}>
                      12340
                    </Text>
                  </View>
                )}
              </View>

              {isDiscount == true ? (
                isApproved ? (
                  <Text
                    style={{
                      color: Colors.black,
                      fontFamily: Font.bold,
                      fontSize: FontSize.large,
                      marginTop: hp('2%'),
                    }}>
                    This discount has been approved
                  </Text>
                ) : (
                  <Text
                    style={{
                      color: Colors.black,
                      fontFamily: Font.bold,
                      fontSize: FontSize.large,
                      marginTop: hp('2%'),
                    }}>
                    This discount is been sent revise
                  </Text>
                )
              ) : isApproved ? (
                <Text
                  style={{
                    color: Colors.black,
                    fontFamily: Font.bold,
                    fontSize: FontSize.large,
                    marginTop: hp('2%'),
                  }}>
                  This Quotation has been approved
                </Text>
              ) : (
                <Text
                  style={{
                    color: Colors.black,
                    fontFamily: Font.bold,
                    fontSize: FontSize.large,
                    marginTop: hp('2%'),
                  }}>
                  This Quotation is been sent revise
                </Text>
              )}

              <View style={styles.buttonContainer}>
                <Button
                  title="Home"
                  buttonTextStyle={{fontSize: FontSize.medium_large}}
                  onPress={homeButtonHandler}
                />
              </View>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
  },
  contentContainer: {
    flexGrow: 1,
  },
  codeContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  buttonContainer: {
    width: wp('30%'),
    alignItems: 'center',
    marginBottom: wp('40%'),
    marginTop: hp('5%'),
  },
  textContainer: {
    width: '90%',
    alignSelf: 'center',
    marginTop: 5,
  },
  textColorBlack: {
    color: Colors.border,
    fontFamily: Font.bold,
    fontSize: FontSize.medium_large,
  },
  textColorPink: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.medium_large,
    flexWrap: 'wrap',
    width: '70%',
  },
  imageStyle: {
    width: 300,
    height: 300,
    marginBottom: 10,
  },
});

export default QuotationReviewScreen;
