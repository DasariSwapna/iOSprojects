import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import QuotationReviewScreen from './Screen';
import Routes, {Manager} from '../../../navigations/RouteTypes';

import {getApprovalDetails, updateApprovalStatus} from '../../../store/Actions';
import {delay} from '../../../utils/Helpers';
import {BackHandler} from 'react-native';

class QuotationReview extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      isApproved: false,
      vendorID: this.props.route.params.vendorID,

      doctorDatas: '',
      productList: '',
      RETAIL: false,

      data: [],
      localProductList: [],
      localProductListOrigin: [],
      productDetailsOrigin: [],

      product_code: '',
      product_id: 0,
      selectedSearchId: 0,
      totalAmount: 0,

      errorMsg: '',
      showToast: false,
      headerTitle: this.props.route.params.title,
      resultID: this.props.route.params.resultID,
      approvedStatus: '',
    };
    this.back = null;
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  Quotationhomehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    // this.props.navigation.navigate(Manager.quotationhome);
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    const data = {
      hospitalid: this.state.vendorID,
    };
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalDetails(data, this.props.accessToken);
      this.props.navigation.setOptions({title: this.state.headerTitle});
    });

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }

  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.managerapprovaldetailsStatus == false &&
      this.props.managerapprovaldetailsStatus !=
        prevProps.managerapprovaldetailsStatus
    ) {
      const data = this.props.managerapprovalproducttestDetails.map(item => {
        item.price = 0;
        item.selected = false;
        return item;
      });
      // console.log(JSON.stringify(data))
      this.setState({productDetailsOrigin: data});
    }

    if (
      prevProps.approvaldetailstapprovedError == false &&
      this.props.approvaldetailstapprovedError !=
        prevProps.approvaldetailstapprovedError
    ) {
      this.setState(
        {
          errorMsg: this.props.updatemanagerapprovalMessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    if (
      prevProps.updatemanagerapprovalStatus == false &&
      this.props.updatemanagerapprovalStatus !=
        prevProps.updatemanagerapprovalStatus
    ) {
      this.setState(
        {
          errorMsg: this.props.updatemanagerapprovalMessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );

      if (this.state.approvedStatus == '1') {
        this.props.navigation.navigate(Manager.quotationreviewstatus, {
          isApproved: true,
          isDiscount: false,
          resultID: this.state.resultID,
        });
      } else {
        this.props.navigation.navigate(Manager.quotationreviewstatus, {
          isApproved: false,
          isDiscount: false,
          resultID: this.state.resultID,
        });
      }
    }

    if (
      prevProps.updatemanagerapprovalError !=
        this.props.updatemanagerapprovalError &&
      this.props.updatemanagerapprovalError == true
    ) {
      this.setState(
        {
          errorMsg: this.props.updatemanagerapprovalMessage,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  approvedButtonHandler = () => {
    this.setState({approvedStatus: '1'});
    var listSelected = this.state.productDetailsOrigin.filter(
      item => item.selected == true,
    );
    if (listSelected.length > 0) {
      const isValid = this.validation();
      console.log('Price validation  ' + isValid);
      if (isValid) {
        this.saveData(1);
      }
    } else {
      this.setState(
        {
          errorMsg: 'Please select at least one test',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }

    /*   this.props.navigation.navigate(Manager.quotationreviewstatus, {
      isApproved: true,
    }); */
  };

  reviseButtonHandler = () => {
    this.setState({approvedStatus: '4'});
    var listSelected = this.state.productDetailsOrigin.filter(
      item => item.selected == true,
    );
    if (listSelected.length > 0) {
      const isValid = this.validation();
      console.log('Price validation  ' + isValid);
      if (isValid) {
        this.saveData(4);
      }
    } else {
      this.setState(
        {
          errorMsg: 'Please select at least one test',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };
  validation = () => {
    var listSelected = this.state.productDetailsOrigin.filter(
      item => item.selected == true,
    );

    var valid = true;

    console.log(listSelected);

    for (var i = 0; i < listSelected.length; i++) {
      if (
        parseInt(listSelected[i].price) > parseInt(listSelected[i].Max_Price)
      ) {
        this.setState(
          {
            errorMsg: `Test name:${listSelected[i].LC_TD_TEST_NAME} \n Price shoul be less than max price`,
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Price shoul be less than max price');
        return (valid = false);
      } else if (
        parseInt(listSelected[i].price < 1) ||
        listSelected[i].price == ''
      ) {
        this.setState(
          {
            errorMsg: `Test name:${listSelected[i].LC_TD_TEST_NAME} \n Please enter price`,
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Please enter price');
        return (valid = false);
      } /*else if (
        parseInt(listSelected[i].price) < parseInt(listSelected[i].Min_Price)
      ) {
        this.setState(
          {
            errorMsg: `Test name:${listSelected[i].LC_TD_TEST_NAME} \n Price shoul be greater than min price`,
            showToast: true,
          },
          async () => {
            await delay(3000);
            this.resetValidation();
          },
        );
        console.log('Please enter price');
        return (valid = false);
      } */

      return valid;
    }
  };

  actionSearch = text => {
    var listSelected = this.state.localProductListOrigin.filter(
      item => item.lc_PTM_PRODUCT_ID == this.state.product_id,
    );
    var filterdata = listSelected;

    var arraydata = filterdata.filter(function (x) {
      return (
        x.lc_TD_TEST_NAME
          .toUpperCase()
          .trim()
          .indexOf(text.toUpperCase().trim()) > -1
      );
    });
    this.setState({
      localProductList: arraydata,
      actionValue: text,
    });
  };

  countTestForProducts = id => {
    const list = this.state.localProductListOrigin.filter(
      item => item.lc_PTM_PRODUCT_ID == id,
    );
    var listSelected = list.filter(item => item.selected == true);
    var count = listSelected.length;

    this.state.productDetailsOrigin.map(item => {
      if (item.lc_PD_PRODUCT_CODE == id) {
        return {
          ...item,
          test_added: count,
        };
      }
      return item;
    });
  };

  radioPress = itemList => {
    const newData = this.state.productDetailsOrigin.map(item => {
      if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE) {
        return {
          ...item,
          selected: !item.selected,
        };
      }
      return item;
    });
    console.log(newData);
    this.setState({productDetailsOrigin: newData});
  };

  saveData = approvedStatus => {
    const listSelected = this.state.productDetailsOrigin.filter(
      item => item.selected == true,
    );

    if (listSelected.length > 0) {
      var arr = [];
      var value = 0;
      //  RETAIL
      for (var i = 0; i < listSelected.length; i++) {
        arr.push({
          testid: parseInt(listSelected[i].LC_TD_TEST_ID),
          suggestedprice: parseInt(listSelected[i].price),
          hospitalid: this.state.vendorID,
        });
        value += parseInt(listSelected[i].price);
      }

      const data = {
        testApprovalModels: arr,
        user_id: this.props.UserID,
        statusid: approvedStatus,
      };
      console.log('Create vendor Array' + JSON.stringify(data));
      this.props.onupdatemanagerApprovalstatus(data, this.props.accessToken);
    } else {
      this.setState(
        {
          errorMsg: 'Please Select atleast one Test',
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
  };

  filterData = id => {
    // console.log('ID' + id)
    const list = this.state.localProductListOrigin.filter(
      item => item.lc_PTM_PRODUCT_ID == id,
    );
    this.setState({localProductList: list});
  };

  countFunction = newDataOrigin => {
    var totalvalues = 0;
    var count = 0;
    var countAuto = 0;
    for (var i = 0; i < newDataOrigin.length; i++) {
      if (newDataOrigin[i].selected) {
        if (
          parseInt(newDataOrigin[i].price) <
          parseInt(newDataOrigin[i].lc_TD_MINPRICE)
        ) {
          count++;
        }
        if (
          parseInt(newDataOrigin[i].price) >
            parseInt(newDataOrigin[i].lc_TD_MINPRICE) &&
          parseInt(newDataOrigin[i].price) <
            parseInt(newDataOrigin[i].lc_TD_MAXPRICE)
        ) {
          countAuto++;
        }
        if (!newDataOrigin[i].price == '')
          totalvalues += parseInt(newDataOrigin[i].price);
      }
    }
    this.setState({
      totalAmount: totalvalues,
      totalOutliner: count,
      toatlAutoApproved: countAuto,
    });
  };

  priceHandler = (val, itemList) => {
    var newData = this.state.productDetailsOrigin.map(item => {
      if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE) {
        return {
          ...item,
          price: val,
        };
      }
      return item;
    });
    this.setState({productDetailsOrigin: newData});

    var newDataOrigin = this.state.localProductListOrigin.map(item => {
      if (item.LC_TD_TEST_CODE == itemList.LC_TD_TEST_CODE) {
        return {
          ...item,
          price: val,
        };
      }
      return item;
    });

    this.setState({
      localProductListOrigin: newDataOrigin,
    });
    this.countFunction(newDataOrigin);
  };

  render() {
    return (
      <QuotationReviewScreen
        headerTitle={this.state.headerTitle}
        isApproved={this.state.isApproved}
        reviseButtonHandler={this.reviseButtonHandler}
        approvedButtonHandler={this.approvedButtonHandler}
        vendorID={this.state.vendorID}
        doctorDatas={this.props.managerapprovaldoctorDetails}
        productList={this.state.productDetailsOrigin}
        RETAIL={this.state.RETAIL}
        radioPress={this.radioPress}
        data={this.state.data}
        selectedSearchId={this.state.selectedSearchId}
        // productList={this.state.localProductList}
        productDetails={this.state.productDetailsOrigin}
        showToast={this.state.showToast}
        errorMsg={this.state.errorMsg}
        priceHandler={this.priceHandler}
        loading={
          this.props.managerapprovaldetailsLoading ||
          this.props.updatemanagerapprovalLoading
        }
        approvedStatus={this.state.approvedStatus}
        Quotationhomehandler={this.Quotationhomehandler}
        resultID={this.state.resultID}
      />
    );
  }
}
const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    managerapprovaldetailsError:
      state.salesmanagerapprovals.approvaldetailstError,
    managerapprovaldetailsStatus:
      state.salesmanagerapprovals.apporvaldetailsStatus,
    managerapprovaldetailsLoading:
      state.salesmanagerapprovals.approvaldetailsLoading,
    managerapprovaldoctorDetails:
      state.salesmanagerapprovals.approvaldoctorDetails,
    managerapprovalproducttestDetails:
      state.salesmanagerapprovals.approvalproducttestDetails,
    UserID: state.signIn.userId,
    approvalDetailsProcessmessage: state.salesmanagerapprovals.message,
    updatemanagerapprovalStatus:
      state.salesmanagerapprovals.apporvaldetailsapprovedStatus,
    updatemanagerapprovalError:
      state.salesmanagerapprovals.approvaldetailstapprovedError,
    updatemanagerapprovalMessage: state.salesmanagerapprovals.message,
    updatemanagerapprovalLoading:
      state.salesmanagerapprovals.approvaldetailapprovedsLoading,
  };
};
const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getApprovalDetails(data, token)),

    onupdatemanagerApprovalstatus: (data, token) =>
      dispatch(updateApprovalStatus(data, token)),
  };
};
export default connect(mapStateToProps, mapDispatchToProps)(QuotationReview);
