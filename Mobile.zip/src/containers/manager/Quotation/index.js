import React from 'react';
import {ThemeProvider} from 'react-native-paper';
import {connect} from 'react-redux';
import {Paramedic, Manager} from '../../../navigations/RouteTypes';
import QuotatioHomeScreen from './Screen';
import {
  getApprovaldetailsProcess,
  getDiscountapproval,
} from '../../../store/Actions';
import {BackHandler} from 'react-native';

/*const pendingData = [
  {
    id: 1,
    name: 'QU06-10684 Dheekshitha',
    crmid: '12345',
    date: '5',
    time: 'Pending',
    address: '25000',
  },
  {
    id: 2,
    name: 'QU06-10684 Dheekshitha',
    crmid: '12345',
    date: '5',
    time: 'Pending',
    address: '25000',
  },
  {
    id: 2,
    name: 'QU06-10684 Dheekshitha',
    crmid: '12345',
    date: '2',
    time: 'Pending',
    address: '25000',
  },
]; */
const pendingData = [];

const completedData = [
  {
    id: 1,
    name: 'QU06-10610 Jothi',
    crmid: '12345',
    date: '5',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
  {
    id: 2,
    name: 'QU06-10611 Laxmi',
    crmid: '12345',
    date: '5',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
  {
    id: 2,
    name: 'QU06-10611 Laxmi',
    crmid: '12345',
    date: '3',
    time: 'Approved',
    address: '25000',
    deliveredTime: '10:10',
  },
];
const cancelData = [
  {
    id: 1,
    name: 'QU06-10500 Pooja',
    crmid: '12345',
    date: '5',
    time: 'Auto Approved',
    address: '25000',
    crtype: '1',
    reason: 'Customer not available',
  },
  {
    id: 2,
    name: 'QU06-10501 Sownbarnya',
    crmid: '12345',
    date: '3',
    time: '1Auto Approved',
    address: '25000',
    crtype: '2',
    reason: 'Customer not available',
  },
  {
    id: 2,
    name: 'QU06-10502 Mrithula',
    crmid: '12345',
    date: '2',
    time: 'Auto Approved',
    address: '25000',
    crtype: '1',
    reason: 'Customer not available',
  },
];
const searchData = [
  {id: 1, name: 'Collection & pickup'},
  {id: 2, name: 'Pickup only'},
  {id: 3, name: 'Maternal'},
  {id: 4, name: 'HeomoglobinoPathy Repeat'},
];

class Home extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isActive: false,
      isStarted: false,
      selectedSearchId: 0,
      selectedTab: 1,
      data: [],
      isDiscount: this.props.route.params.isDiscount,
      typeID: this.props.route.params.typeid,
      type: this.props.route.params.type,
      approvedorAutoapproved: '1',
      headerTitle: this.props.route.params.title,
      showToast: false,
      errorMsg: '',
      vendorID: '',
      actionValue: '',
    };
    this.back = null;
  }

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  startCardClickHandler = (vendorid, approvalstatus, resultID) => {
    {
      this.state.selectedTab == '1'
        ? this.state.typeID == '4'
          ? this.props.navigation.navigate(Manager.discountapproveddetails, {
              vendorID: vendorid,
              resultID: resultID,
              title: this.state.headerTitle,
              approvalstatus: approvalstatus,
            })
          : this.props.navigation.navigate(Manager.quotationreview, {
              vendorID: vendorid,
              title: this.state.headerTitle,
              resultID: resultID,
              approvalstatus: approvalstatus,
            })
        : this.state.selectedTab == '2'
        ? this.state.typeID == '4'
          ? this.props.navigation.navigate(Manager.discountapproved, {
              approvedorAutoapproved: '0',
              vendorID: vendorid,
              resultID: resultID,
              title: this.state.headerTitle,
              approvalstatus: approvalstatus,
            })
          : this.props.navigation.navigate(Manager.quotationapproved, {
              approvedorAutoapproved: '0',
              vendorID: vendorid,
              resultID: resultID,
              title: this.state.headerTitle,
              approvalstatus: approvalstatus,
            })
        : this.state.selectedTab == '3'
        ? this.props.navigation.navigate(Manager.quotationapproved, {
            approvedorAutoapproved: '1',
            vendorID: vendorid,
            resultID: resultID,
            title: this.state.headerTitle,
            approvalstatus: approvalstatus,
          })
        : null;
    }
  };

  searchClickHandler = id => {
    this.setState(prevState => {
      const temp = prevState.selectedSearchId == id ? 0 : id;
      return {
        selectedSearchId: temp,
      };
    });
  };
  changeTab = id => {
    this.setState({selectedTab: id, actionValue: ''});
    this.fetchData(id);
  };
  fetchData(id) {
    if (id == '1') {
      this.state.typeID == '4'
        ? this.setState({data: this.props.managerdiscountapprovalpending})
        : this.setState({data: this.props.managerapprovalDetailsProcess});
    } else if (id == '2') {
      this.state.typeID == '4'
        ? this.setState({data: this.props.managerdiscountapprovalapproved})
        : this.setState({data: this.props.managerapprovalDetailsProcess1});
    } else if (id == '3') {
      this.setState({data: this.props.managerapprovalDetailsProcess2});
    }
  }

  actionSearch = text => {
    var listSelected = '';
    if (this.state.selectedTab == '1') {
      this.state.typeID == '4'
        ? listSelected = this.props.managerdiscountapprovalpending
        : listSelected =  this.props.managerapprovalDetailsProcess
    } else if (this.state.selectedTab == '2') {
      this.state.typeID == '4'
      ? listSelected = this.props.managerdiscountapprovalapproved
      : listSelected = this.props.managerapprovalDetailsProcess1
    } else if (this.state.selectedTab == '3') {
      listSelected = this.props.managerapprovalDetailsProcess2;
    } 

    if( this.state.typeID == '4')
    {
      var filterdata = listSelected;
      // alert(filterdata)
      console.log('Filter data',JSON.stringify(filterdata))
   
       var arraydata = filterdata.filter(function (x) {
         return (
           x.SALES_PERSON.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1
         );
       });
   
       this.setState({
         data: arraydata,
         actionValue: text,
       });
       console.log('Array data',JSON.stringify(arraydata))
    }
    else
    {
      var filterdata = listSelected;
      // alert(filterdata)
      console.log('Filter data',JSON.stringify(filterdata))
   
       var arraydata = filterdata.filter(function (x) {
         return (
           x.SALES_PERSON.toUpperCase().trim().indexOf(text.toUpperCase().trim()) > -1
         );
       });
   
       this.setState({
         data: arraydata,
         actionValue: text,
       });
       console.log('Array data',JSON.stringify(arraydata))
    }
    
  
  };



  Quotationhomehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    const data = {
      typeid: this.state.typeID,
    };
    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.navigation.setOptions({title: this.state.headerTitle});
      this.props.onGetApprovalDetails(data, this.props.accessToken);
      this.props.onGetDiscountApproval(null, this.props.accessToken);
      this.setState({selectedTab: '1'});
    });
    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }

  componentDidUpdate = prevProps => {
    if (
      prevProps.managerapprovaldetailsProcessStatus == false &&
      this.props.managerapprovaldetailsProcessStatus !=
        prevProps.managerapprovaldetailsProcessStatus
    ) {
      {
        this.state.typeID == '4'
          ? this.setState({data: this.props.managerdiscountapprovalpending})
          : this.setState({data: this.props.managerapprovalDetailsProcess});
      }
    }
  };

  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  componentWillUnmount() {
    this._unsubscribe();
  }

  render() {
    return (
      <QuotatioHomeScreen
        headerTitle={this.state.headerTitle}
        isDiscount={this.state.isDiscount}
        typeID={this.state.typeID}
        type={this.state.type}
        searchData={searchData}
        data={this.state.data}
        cardClickHandlerAutoApproved={this.cardClickHandlerAutoApproved}
        searchClickHandler={this.searchClickHandler}
        startCardClickHandler={this.startCardClickHandler}
        selectedSearchId={this.state.selectedSearchId}
        changeTab={this.changeTab}
        selectedTab={this.state.selectedTab}
        isStarted={this.state.isStarted}
        loading={this.props.managerapprovaldetailsProcessLoading}
        actionSearch={this.actionSearch}
        actionValue={this.state.actionValue}
        Quotationhomehandler={this.Quotationhomehandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    managerapprovaldetailsProcessError:
      state.salesmanagerapprovals.approvaldetailstprocessError,
    managerapprovaldetailsProcessStatus:
      state.salesmanagerapprovals.apporvaldetailsprocessStatus,
    managerapprovaldetailsProcessLoading:
      state.salesmanagerapprovals.approvaldetailsprocessLoading,
    managerapprovalDetailsProcess:
      state.salesmanagerapprovals.approvalDetailsprocess,
    managerapprovalDetailsProcess1:
      state.salesmanagerapprovals.approvalDetailsprocess1,
    managerapprovalDetailsProcess2:
      state.salesmanagerapprovals.approvalDetailsprocess2,
    approvalDetailsProcessmessage: state.salesmanagerapprovals.message,

    managerdiscountapprovalapproved:
      state.salesmanagerapprovals.discountapprovalapproved,
    managerdiscountapprovalpending:
      state.salesmanagerapprovals.discountapprovalpending,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getApprovaldetailsProcess(data, token)),

    onGetDiscountApproval: (data, token) =>
      dispatch(getDiscountapproval(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
