import React, {useRef} from 'react';
import {
  Text,
  View,
  StyleSheet,
  TouchableOpacity,
  TextInput,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import Images from '../../../constants/Icons';
import SearchBar from '../../../components/SearchBar';
import {FlatList} from 'react-native-gesture-handler';
import MyTaskHeader from '../../../components/MyTaskHeader';
import ManagerCardView from '../../../components/ManagerCardView';
import ManagerTabContainer from '../../../components/ManagerTabContainer';
import ManagerTabContainerDiscount from '../../../components/ManagerTabContainerDiscount';
import Icon from 'react-native-vector-icons/FontAwesome';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';
import I18n from '../../../locale/i18n';

function QuotatioHomeScreen({
  isDiscount,
  type,
  typeID,
  searchData,
  data,
  cardClickHandlerPending,
  cardClickHandlerApproved,
  cardClickHandlerAutoApproved,
  startCardClickHandler,
  startCardClickHandlerDiscount,
  searchClickHandler,
  selectedSearchId,
  changeTab,
  selectedTab,
  loading,
  isStarted,
  actionSearch,
  actionValue,
}) {
  const renderItem = ({item}) => ({
    ...(item.VENDOR_ID == '0' ? (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: hp('30%'),
        }}>
        <Text style={{fontFamily: FontMagneta.bold, fontSize: FontSize.large}}>
          No data found
        </Text>
      </View>
    ) : (
      <ManagerCardView
        dateText={'Total test '}
        addressText={'Amount'}
        deliveredTimeText={'Delivered Time'}
        viewText={'View'}
        name={item.QUOTATION_ID + '  ' + item.SALES_PERSON}
        testCount={item.Tests}
        address={item.Tests}
        invoiceAmount={item.Invoice_Amount}
        reason={item.Invoice_Amount}
        selectedTab={selectedTab}
        viewCardClickHandler={cardClickHandlerAutoApproved}
        startCardClickHandler={() =>
          startCardClickHandler(item.VENDOR_ID, item.Status, item.QUOTATION_ID)
        }
      />
    )),
  });

  const discountrenderItem = ({item}) => ({
    ...(item.ORDER_ID == '0' ? (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: hp('30%'),
        }}>
        <Text style={{fontFamily: FontMagneta.bold, fontSize: FontSize.large}}>
          No data found
        </Text>
      </View>
    ) : (
      <ManagerCardView
        dateText={'Total test '}
        addressText={'Amount'}
        deliveredTimeText={'Delivered Time'}
        viewText={'View'}
        name={item.CRM_NO + '  ' + item.SALES_PERSON}
        testCount={item.TESTS}
        address={item.TESTS}
        invoiceAmount={item.INVOICE_AMOUNT}
        reason={item.INVOICE_AMOUNT}
        selectedTab={selectedTab}
        viewCardClickHandler={cardClickHandlerAutoApproved}
        startCardClickHandler={() =>
          startCardClickHandler(item.ORDER_ID, item.STATUS, item.CRM_NO)
        }
      />
    )),
  });

  const renderNodata = () => {
    return (
      <>
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
          <Text
            style={{fontFamily: FontMagneta.bold, fontSize: FontSize.large}}>
            No data found
          </Text>
        </View>
      </>
    );
  };

  const headerComponent = () => {
    return (
      <>
       

      </>
    );
  };
  return (
    <RootView pageNo={'M-04'} isPageWhite loading={loading}>
      <View style={styles.rootView}>
      <View style={styles.headerContainer}>
          <View style={styles.topSearchContainer}></View>
          {typeID == '4' ? (
            <ManagerTabContainerDiscount
              pendingText={I18n.t('manager.home.pending_label')}
              completedText={I18n.t('manager.home.approved_label')}
              selectedTab={selectedTab}
              changeTab={changeTab}
            />
          ) : (
            <ManagerTabContainer
              pendingText={I18n.t('manager.home.pending_label')}
              completedText={I18n.t('manager.home.approved_label')}
              cancelledAndRescheduleText={I18n.t(
                'manager.home.auto_approved_label',
              )}
              selectedTab={selectedTab}
              changeTab={changeTab}
            />
          )}
        </View>

      <View style={styles.searchOuterContainer}>
          <SearchBar onChangehandler={actionSearch} value={actionValue} />
        </View>
      
        <View style={styles.flatListContainer}>
          
          {typeID == '4' ? (
            <FlatList
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
              data={data}
              renderItem={discountrenderItem}
              keyExtractor={item => item.ORDER_ID}
              extraData={data}
              contentContainerStyle={styles.flatListInnerContainer}
             
              ListEmptyComponent={renderNodata}
            />
          ) : (
            <FlatList
              showsVerticalScrollIndicator={false}
              style={styles.flatList}
              data={data}
              renderItem={renderItem}
              keyExtractor={item => item.VENDOR_ID}
              extraData={data}
              contentContainerStyle={styles.flatListInnerContainer}
              ListEmptyComponent={renderNodata}
            />
          )}
        </View>
      </View>
    </RootView>
  );
}
const styles = StyleSheet.create({
  rootView: {
    flex: 1,
    backgroundColor: Colors.background,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'flex-start',
  },
  imgStyle: {
    height: 70,
    width: 70,
    marginHorizontal: 10,
  },
  textHeader: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.pnsTextColor,
  },
  textTaskNumber: {
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  textTask: {
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    color: Colors.black,
  },
  searchFirstContaner: {
    flexDirection: 'row',
    marginTop: 20,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  searchSecondContainer: {
    flexDirection: 'row',
    marginVertical: 15,
    alignItems: 'flex-start',
    justifyContent: 'flex-start',
  },
  headerContainer: {
    flexDirection: 'column',
    marginVertical: 20,
    marginHorizontal: 5,
  },
  nameContainer: {
    flexDirection: 'column',
    marginVertical: 10,
  },

  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: hp('20%'),
  },
  flatList: {flex: 1},
  flatListContainer: {
    alignItems: 'flex-start',
  },
  topSearchContainer: {
    width: '100%',
    alignItems: 'center',
    justifyContent: 'space-between',
    overflow: 'scroll',
  },
  topcontentContainerStyle: {
    flexGrow: 1,
    padding: 2,
  },
  searchOuterContainer: {
    width: wp('85%'),
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'center',
    // paddingVertical: hp('3%'),
    marginTop: hp('0.5%'),
  },
  searchSection: {
    width: wp('85%'),
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
    marginHorizontal: wp('0.5%'),
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.black,
    fontFamily: Font.bold,
    fontSize: FontSize.large,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
});

export default QuotatioHomeScreen;
