import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
  FlatList,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import Button from '../../../components/ButtonLarge';
import Button1 from '../../../components/ButtonLargeGreen';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import TimeLineContainer from '../../../components/TimeLineContainer';
import Icons from '../../../constants/Icons';
import CheckCircle, {CheckCircle1} from '../../../components/CheckCircle';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

import {Toast} from '../../../components/Toast';
import I18n from '../../../locale/i18n';

function AddTestPayoutComponent({
  radioPress,
  title,
  RETAIL,
  priceHandler,
  price,
  minPrice,
  maxPrice,
  Selling_Price,
  loading,
  status,
  selected,
  Dr_Payout,
}) {
  return (
    <View style={styles.payoutContainer}>
      <View
        style={[
          {
            justifyContent: 'space-between',
          },
          styles.payoutBottomContainer,
        ]}>
        <View>
          <View style={{marginTop: hp('1.0%'), flexDirection: 'row'}}>
            <View style={{width: wp('25%')}}>
              <Text style={styles.payoutTextContainerBlack}>Plan name</Text>
            </View>
            <View style={{width: wp('45%')}}>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                <Text numberOfLines={1} style={styles.payoutTextContainerBold}>
                  {title}
                </Text>
              </ScrollView>
            </View>
            {status == 'Pending' ? (
              <View
                style={{
                  width: wp('18%'),
                  right: 0,
                  margin: hp('-1%'),
                }}>
                <CheckCircle1
                  length={20}
                  onPress={() => radioPress()}
                  selected={selected}
                />
              </View>
            ) : null}
          </View>
          <View
            style={{
              marginTop: hp('1.0%'),
            }}>
            <View
              style={{
                marginTop: hp('1.0%'),
                flexDirection: 'row',
              }}>
              <View style={{width: wp('20%'), flexDirection: 'column'}}>
                <Text style={styles.payoutTextContainerBlack1}>Min</Text>
                <Text style={styles.payoutTextContainerBlackvalues}>
                  {I18n.t('valitation.rupee')} {minPrice}
                </Text>
              </View>
              <View style={{width: wp('20%'), flexDirection: 'column'}}>
                <Text style={styles.payoutTextContainerBlack1}>Max</Text>
                <Text style={styles.payoutTextContainerBlackvalues}>
                  {I18n.t('valitation.rupee')} {maxPrice}
                </Text>
              </View>
              <View style={{width: wp('20%'), flexDirection: 'column'}}>
                <Text style={styles.payoutTextContainerBlack1}>Dr.Payout</Text>
                <Text style={styles.payoutTextContainerBlackvalues}>
                  {I18n.t('valitation.rupee')} {Dr_Payout}
                </Text>
              </View>

              <View style={{width: wp('20%'), flexDirection: 'column'}}>
                <Text style={styles.payoutTextContainerBlack1}>
                  Selling price
                </Text>
                <Text style={styles.payoutTextContainerBlackvalues}>
                  {I18n.t('valitation.rupee')} {Selling_Price}
                </Text>
              </View>
            </View>
          </View>
          <View
            style={{
              marginTop: hp('1.0%'),
              flexDirection: 'row',
            }}></View>
          <View
            style={{
              marginTop: hp('1.0%'),
              //flexDirection: 'row',
            }}>
            <Text style={styles.payoutTextContainerBlack1}>
              Suggested price
            </Text>
            <View
              style={{
                justifyContent: 'space-between',
                flexDirection: 'row',
              }}>
              <View
                style={[
                  {
                    marginHorizontal: wp('1.5%'),
                    flexDirection: 'row',
                    width: Platform.OS === 'ios' ? hp('11.0%') : hp('11%'),
                    borderWidth: hp('0.1%'),
                    borderColor: Colors.border,
                    marginTop: hp('1.0%'),
                    borderRadius: 7,
                    height: hp('4%'),
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  },
                  {
                    backgroundColor: selected
                      ? Colors.white
                      : Colors.bgLightGray,
                  },
                ]}>
                <TextInput
                  style={styles.payoutTextInputContainer}
                  placeholderTextColor={Colors.bgDarkGray}
                  onChangeText={priceHandler}
                  underlineColorAndroid="transparent"
                  maxLength={8}
                  keyboardType={'numeric'}
                  value={selected ? price : 0}
                  editable={selected ? true : false}
                />
              </View>
              <View
                style={{
                  marginTop: hp('2.0%'),
                  //   width: wp('60%'),
                }}>
                {status == 'Pending' ? (
                  <Text style={styles.Statustext}>{status}</Text>
                ) : (
                  <Text style={styles.Statustext1}>{status}</Text>
                )}
              </View>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const renderNodata = () => {
  return (
    <>
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          marginTop: hp('20%'),
        }}>
        <Text style={{fontFamily: FontMagneta.bold}}>No data found</Text>
      </View>
    </>
  );
};

function TextConatiner({leftText, rightText}) {
  return (
    <View style={{width: '100%', flexDirection: 'row'}}>
      <Text
        style={{
          flex: 1,
          paddingLeft: wp('2.5%'),
          paddingVertical: hp('0.5%'),
          paddingHorizontal: hp('1.0%'),
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>
        {leftText}
      </Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: hp('0.5%'),
          color: Colors.black,
          lineHeight: 15,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>
        {rightText}
      </Text>
    </View>
  );
}

function DiscountReviewScreen({
  addressTypeHandler,
  approvedButtonHandler,
  reviseButtonHandler,
  doctorDatas,
  productList,
  RETAIL,
  radioPress,
  loading,
  showToast,
  errorMsg,
  priceHandler,
}) {
  const renderPayoutContainer = ({item, index}) => {
    return (
      <AddTestPayoutComponent
        radioPress={() => radioPress(item)}
        title={item.LC_TD_TEST_NAME}
        RETAIL={RETAIL}
        priceHandler={val => priceHandler(val, item)}
        price={item.price}
        //price={item.lc_TD_MAXPRICE}
        minPrice={item.LC_TD_MINPRICE}
        maxPrice={item.LC_TD_MAXPRICE}
        Dr_Payout={item.DR_PAYOUT}
        Selling_Price={item.LC_SCD_TEST_PRICE}
        status={item.Status}
        selected={item.selected}
      />
    );
  };

  return (
    <RootView pageNo={'M-07'} isPageWhite loading={loading}>
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 80}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 70}>
        <Toast
          showToast={showToast}
          msg={errorMsg}
          bgColor={Colors.error}
          txtColor={Colors.background}
        />
        <View
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          {doctorDatas == null ||
          doctorDatas == undefined ||
          doctorDatas == '' ? null : (
            <View style={styles.mainContainer}>
              <View
                style={{
                  width: '80%',
                  flexDirection: 'column',
                  alignSelf: 'center',
                  backgroundColor: Colors.white,
                }}>
                <View
                  style={{
                    marginTop: 10,
                  }}
                />
                <TextConatiner
                  leftText={'CRM No.'}
                  rightText={doctorDatas[0].LC_OR_CRMID}
                />
                <TextConatiner
                  leftText={'Customer Name'}
                  rightText={doctorDatas[0].LC_PD_FULLNAME}
                />
                <TextConatiner
                  leftText={'Primary Mobile #'}
                  rightText={doctorDatas[0].LC_PD_PRIMARYCONTACT}
                />

                <TextConatiner
                  leftText={'Alternate Mobile #'}
                  rightText={doctorDatas[0].LC_PD_ALTERNATECONTACT}
                />
                <TextConatiner
                  leftText={'Email ID'}
                  rightText={doctorDatas[0].LC_PD_EMAILID}
                />
                <TextConatiner
                  leftText={'Address'}
                  rightText={doctorDatas[0].ADDRESS}
                />
                <TextConatiner
                  leftText={'Notes'}
                  rightText={doctorDatas[0].Notes}
                />

                <View style={styles.seperateLine}></View>
              </View>
              {/* Payout Section */}
              <View
                style={{
                  alignSelf: 'center',
                  alignContent: 'flex-start',
                  width: wp('88%'),
                  flex: 1,
                  //backgroundColor: 'red'
                }}>
                <FlatList
                  style={styles.flatList}
                  data={productList}
                  keyExtractor={(item, index) => item.key}
                  renderItem={renderPayoutContainer}
                  ListEmptyComponent={renderNodata}
                  contentContainerStyle={styles.flatListInnerContainer}
                  showsVerticalScrollIndicator={false}
                />
              </View>
            </View>
          )}
        </View>
        <View style={styles.buttonContainer}>
          <Button
            title="Revise"
            buttonTextStyle={{fontSize: FontSize.medium}}
            onPress={reviseButtonHandler}
          />
          <Button1
            title="Approve"
            buttonTextStyle={{fontSize: FontSize.medium}}
            onPress={approvedButtonHandler}
          />
        </View>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  flatList: {
    flex: 1,
    // marginBottom : hp('10%')
  },
  flatListInnerContainer: {
    flexGrow: 1,
    paddingBottom: hp('20%'),
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    // alignSelf: 'center',
    //   marginBottom: hp('5%'),
    padding: hp('1%'),
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: wp('8%'),
  },
  //////Top Container start
  topContainer: {
    width: 170,
    height: 90,
    borderRadius: 20,
    padding: 10,
    borderWidth: 0.5,
    borderColor: Colors.border,
    marginRight: 20,
  },
  topContainerLayout: {
    flexDirection: 'column',
    marginLeft: 10,
  },
  topImageContainer: {
    width: 40,
    height: 40,
  },
  topInnerContainer1: {
    width: '70%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'flex-start',
  },
  topInnerContainer2: {
    width: '90%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'center',
    marginTop: 10,
  },
  topContainerTextLarge: {
    color: Colors.black,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  topContainerTextSmall: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  /////////Serach Section
  searchSection: {
    width: '70%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  /////Search outer Style
  searchOuterContainer: {
    width: '85%',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    paddingVertical: 20,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  ////Payout Section Container
  payoutContainer: {
    width: wp('85%'),
    flex: 1,
    // height: hp('29.5%'),
    paddingBottom: hp('1.5%'),
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginTop: hp('1.5%'),
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: wp('85%'),
    justifyContent: 'space-between',

    paddingHorizontal: hp('1.5%'),
    marginTop: hp('1.0%'),
  },
  payoutTextContainerBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    paddingHorizontal: hp('1.0%'),
  },
  payoutTextContainerBlack1: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    paddingHorizontal: hp('1.0%'),
    //alignItems: 'flex-start',
  },
  payoutTextContainerBlackvalues: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    paddingHorizontal: hp('1.0%'),
    marginTop: hp('1.0%'),
    //alignItems: 'flex-start',
  },
  payoutTextContainerBlack11: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    paddingHorizontal: hp('1.0%'),
    //alignItems: 'flex-start',
  },
  payoutTextContainerBlack2: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    // paddingHorizontal: hp('6.0%'),
    // alignItems: 'center',
  },
  payoutTextContainerBlack21: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    paddingHorizontal: hp('6.0%'),
    // alignItems: 'center',
  },
  payoutTextContainerBlack3: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    // paddingHorizontal: hp('5.0%'),
    //alignItems: 'flex-end',
  },
  payoutTextContainerBlack31: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    paddingHorizontal: hp('5.0%'),
    //alignItems: 'flex-end',
  },
  payoutTextContainerBold: {
    color: Colors.black,
    overflow: 'scroll',
    // width: '50%',
    // flexWrap: 'wrap',
    //  margin: hp('0.2%'),

    // lineHeight: 40,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    // marginHorizontal: wp('0.5%'),
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,
  },
  iconContainer: {
    tintColor: '#000000',
  },
  payoutBottomContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutBottomContainerColumn: {
    flexDirection: 'column',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
    marginTop: hp('1.5%'),
  },
  payoutTextContainerBorder1: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    //  alignItems: 'flex-end',
    // textAlign: 'left',
    // marginHorizontal: wp('-3.5%'),
    marginHorizontal: hp('-1.0%'),
  },

  Statustext: {
    color: Colors.button,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    marginRight: wp('8%'),
  },
  Statustext1: {
    color: Colors.babyCordTextColor,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
    marginRight: wp('8%'),
  },
  payoutTextContainerBorder2: {
    color: Colors.greenBlue,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,

    //  alignItems: 'flex-start',
    //  textAlign: 'left',
    // marginHorizontal: wp('-5.0%'),
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.darkPinknew,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    width: wp('25%'),
    // lineHeight: 20,
    alignItems: 'center',
    // borderWidth: 0.5,
    // borderColor: Colors.border,
    //borderRadius: 7,
    height: hp('4.8%'),
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: hp('1.5%'),
    marginTop: hp('0.5%'),
    marginLeft: hp('-0.2%'),
  },
  autoApprovedText: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.button,
    marginLeft: wp('40%'),
    marginTop: hp('1.5%'),
  },
  nameRowContainer1: {
    // flex: 0.1,
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
});

export default DiscountReviewScreen;
