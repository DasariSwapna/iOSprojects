import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  StyleSheet,
  KeyboardAvoidingView,
  TextInput,
} from 'react-native';
import RootView from '../../../components/RootView';
import Colors from '../../../config/Colors';
import Button from '../../../components/ButtonLarge';
import Button1 from '../../../components/ButtonLargeGreen';
import Icon from 'react-native-vector-icons/FontAwesome';
import {Font, FontMagneta, FontSize} from '../../../config/Fonts';
import TimeLineContainer from '../../../components/TimeLineContainer';
import Icons from '../../../constants/Icons';
import CheckCircle from '../../../components/CheckCircle';
import AntDesign from 'react-native-vector-icons/AntDesign';
import {
  Table,
  Row,
  Rows,
  TableWrapper,
  Cell,
  Col,
  Cols,
} from 'react-native-table-component';

import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

function TextConatiner({leftText, rightText}) {
  return (
    <View style={{width: '100%', flexDirection: 'row'}}>
      <Text
        style={{
          flex: 1,
          paddingLeft: wp('2.5%'),
          paddingVertical: hp('0.5%'),
          color: Colors.border,
          fontFamily: Font.bold,
          fontSize: FontSize.regular,
        }}>
        {leftText}
      </Text>
      <Text
        style={{
          flex: 1,
          paddingVertical: hp('0.5%'),
          color: Colors.black,
          lineHeight: 15,
          fontFamily: FontMagneta.medium,
          fontSize: FontSize.regular,
        }}>
        {rightText}
      </Text>
    </View>
  );
}

function QuotationApprovedScreen({
  addressTypeHandler,
  approvedButtonHandler,
  reviseButtonHandler,
  tableHead,
  tableData,
  data,
  doctorDatas,
  loading,
  approvalstatus,
}) {
  return (
    <RootView pageNo={'M-10'} isPageWhite loading={loading}>
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            {doctorDatas == null ||
            doctorDatas == undefined ||
            doctorDatas == '' ? null : (
              <View
                style={{
                  width: '80%',
                  flexDirection: 'column',
                  alignSelf: 'center',
                  backgroundColor: Colors.white,
                }}>
                <View
                  style={{
                    marginTop: 10,
                  }}
                />
                <TextConatiner
                  leftText={'Hospital Name'}
                  rightText={doctorDatas[0].LC_VD_HOSPITALNAME}
                />
                <TextConatiner
                  leftText={'Contact Name'}
                  rightText={doctorDatas[0].LC_VD_CONTACTPERSON_NAME}
                />
                <TextConatiner
                  leftText={'Mobile #'}
                  rightText={doctorDatas[0].LC_VD_PRIMARYCONTACT}
                />

                <TextConatiner
                  leftText={'Email'}
                  rightText={doctorDatas[0].LC_VD_EMAILID}
                />
                <TextConatiner
                  leftText={'Address'}
                  rightText={doctorDatas[0].LC_VD_HOSPITALADDRESS}
                />
                <TextConatiner
                  leftText={'Account Type'}
                  rightText={doctorDatas[0].LC_AT_ACCOUNT_TYPE_NAME}
                />

                <View style={styles.seperateLine}></View>
              </View>
            )}
            <Text
              style={{
                //  flex: 1,
                alignItems: 'flex-start',
                marginHorizontal: wp('12%'),
                // paddingLeft: hp('8.5%'),
                // paddingVertical: hp('0.5%'),
                color: Colors.border,
                fontFamily: Font.bold,
                fontSize: FontSize.medium,
              }}>
              Price and Package Details
            </Text>
            <View
              style={{
                width: wp('78%'),
                alignSelf: 'center',
                marginTop: hp('2%'),
              }}>
              <Table borderStyle={{borderWidth: 1, borderColor: '#cccccc'}}>
                <Row
                  data={tableHead}
                  style={styles.head}
                  textStyle={styles.textBorder}
                />
                <Rows data={tableData} textStyle={styles.text} />
              </Table>
            </View>

            {/* Payout Section */}

            <View style={styles.buttonContainer}>
              <Text
                style={{
                  color: Colors.teal,
                  fontFamily: Font.bold,
                  fontSize: FontSize.medium,
                  marginTop: hp('10%'),
                  //  alignItems : 'center',
                  //  justifyContent : 'space-between'
                }}>
                {approvalstatus}
              </Text>
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

const styles = StyleSheet.create({
  mainContainer: {
    width: '100%',
    height: '100%',
    backgroundColor: '#fff',
    // overflow: 'hidden',
  },
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 50,
    backgroundColor: '#fff',
  },
  lineLargeContainer: {
    width: '95%',
    height: 1,
    backgroundColor: Colors.eWhite,
    alignSelf: 'center',
  },
  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  //////Top Container start
  topContainer: {
    width: 170,
    height: 90,
    borderRadius: 20,
    padding: 10,
    borderWidth: 0.5,
    borderColor: Colors.border,
    marginRight: 20,
  },
  topContainerLayout: {
    flexDirection: 'column',
    marginLeft: 10,
  },
  topImageContainer: {
    width: 40,
    height: 40,
  },
  topInnerContainer1: {
    width: '70%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'flex-start',
  },
  topInnerContainer2: {
    width: '90%',
    justifyContent: 'space-between',
    flexDirection: 'row',
    alignSelf: 'center',
    marginTop: 10,
  },
  topContainerTextLarge: {
    color: Colors.black,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  topContainerTextSmall: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  //////ScrollView Container
  scrollViewContainer: {
    height: 100,
    marginTop: 20,
    width: '100%',
  },
  scrollViewContainerLayout: {
    paddingLeft: '8%',
    paddingRight: 100,
  },
  /////////Serach Section
  searchSection: {
    width: '70%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'transparent',
    borderWidth: 1,
    borderColor: Colors.bWhite,
    borderRadius: 25,
  },
  searchIcon: {
    padding: 10,
  },
  input: {
    paddingTop: 10,
    paddingRight: 10,
    paddingBottom: 10,
    paddingLeft: 20,
    color: Colors.cWhite,
    fontFamily: Font.bold,
    fontSize: FontSize.medium,
  },
  /////Search outer Style
  searchOuterContainer: {
    width: '85%',
    flexDirection: 'row',
    alignSelf: 'center',
    justifyContent: 'space-between',
    paddingVertical: 20,
  },
  textStyle: {
    color: Colors.black,
    fontSize: FontSize.large,
    alignSelf: 'center',
  },
  ////Payout Section Container
  payoutContainer: {
    width: wp('85%'),
    height: hp('17%'),
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 15,
    alignSelf: 'center',
    marginTop: hp('1.5%'),
  },
  payoutInnerContainer: {
    flexDirection: 'row',
    width: wp('85%'),
    justifyContent: 'space-between',

    paddingHorizontal: hp('1.5%'),
    marginTop: hp('1.0%'),
  },
  payoutTextContainerBlack: {
    color: Colors.black,
    fontFamily: Font.regular,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBold: {
    marginRight: hp('15%'),
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    // marginHorizontal: wp('-50%'),
  },
  payoutCircleContainer: {
    height: 20,
    width: 20,
    borderWidth: 0.5,
    borderColor: Colors.bWhite,
    borderRadius: 20 / 2,
  },
  iconContainer: {
    tintColor: '#000000',
  },
  payoutBottomContainer: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutBottomContainerColumn: {
    flexDirection: 'column',
    width: '100%',
    justifyContent: 'space-between',
    paddingHorizontal: 15,
    marginTop: 10,
  },
  payoutTextContainerBorder: {
    color: Colors.border,
    fontFamily: Font.regular,
    fontSize: FontSize.small,
  },
  payoutTextContainerMagenta: {
    marginTop: 5,
    color: Colors.black,
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
  },
  payoutTextContainerBlackRegular: {
    color: Colors.darkPinknew,
    fontFamily: Font.regular,
    fontSize: FontSize.regular,
  },
  payoutTextInputContainer: {
    width: wp('25%'),
    borderWidth: 0.5,
    borderColor: Colors.border,
    borderRadius: 7,
    height: hp('4%'),
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.medium,
    paddingLeft: 10,
    marginTop: 5,
    marginLeft: -2,
  },
  autoApprovedText: {
    fontSize: FontSize.medium,
    fontFamily: Font.extraBold,
    color: Colors.button,
    marginLeft: wp('40%'),
    marginTop: hp('0.5%'),
  },
  nameRowContainer1: {
    // flex: 0.1,
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    flexDirection: 'row',
  },
  seperateLine: {
    height: Platform.OS == 'ios' ? hp('0.03%') : hp('0.1%'),
    width: '100%',
    backgroundColor: Colors.button,
    marginVertical: hp('1.5%'),
  },
  head: {
    height: hp('4%'),
    backgroundColor: '#fff',
    color: Colors.border,
  },
  text: {
    margin: hp('1.0%'),
    fontFamily: FontMagneta.thin,
    fontSize: FontSize.regular,
    color: Colors.black,
  },
  textBorder: {
    margin: hp('0.5%'),
    fontFamily: FontMagneta.bold,
    fontSize: FontSize.regular,
    color: Colors.border,
  },
});

export default QuotationApprovedScreen;