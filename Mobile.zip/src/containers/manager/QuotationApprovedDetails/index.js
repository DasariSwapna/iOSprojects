import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import QuotationApprovedScreen from './Screen';
import Routes, {Manager} from '../../../navigations/RouteTypes';
import {getApprovalDetails} from '../../../store/Actions';
import {BackHandler} from 'react-native';

const data1 = [
  {
    title: 'Maternity Screening',
    amount: '5000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'QFPCR',
    amount: '8000/-INR',
    type: 'Heel Prick',
  },
  {
    title: 'Hb Pathies',
    amount: '9000/-INR',
    type: 'Blood sample',
  },
  {
    title: 'Free Testosterone',
    amount: '9000/-INR',
    type: 'Urine sample',
  },
];

var newtabledatas = [];

class QuotationApproved extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
      isApproved: false,
      tableHead: ['Product', 'Test', 'Amount', 'Sample Type'],
      tableData: [
        ['Maternity Screening', '5000/- INR', 'Heel Prick'],
        ['QFPCR', '8000/- INR', 'Heel Prick'],
        ['Hb Pathies', '9000/- INR', 'Blood sample'],
        ['Free Tetosterone', '9000/- INR', 'Urine sample'],
      ],
      testData1: [],
      testData: [],
      data: data1,
      vendorID: this.props.route.params.vendorID,
      approvalstatus: this.props.route.params.approvalstatus,
      doctorDatas: '',
      headerTitle: this.props.route.params.title,
    };
    this.back = null;
  }

  Quotationhomehandler = () => {
    this.backHandler();
  };

  backHandler = () => {
    // this.props.navigation.navigate(Manager.quotationhome);
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount() {
    const data = {
      hospitalid: this.state.vendorID,
    };

    this._unsubscribe = this.props.navigation.addListener('focus', () => {
      this.props.onGetApprovalDetails(data, this.props.accessToken);
      this.props.navigation.setOptions({title: this.state.headerTitle});
    });

    this.back = BackHandler.addEventListener(
      'hardwareBackPress',
      this.backHandler,
    );
  }
  componentWillUnmount() {
    this._unsubscribe();
    this.back.remove();
  }

  approvedButtonHandler = () => {
    this.props.navigation.navigate(Manager.quotationreviewstatus, {
      isApproved: true,
    });
  };

  reviseButtonHandler = () => {
    this.props.navigation.navigate(Manager.quotationreviewstatus, {
      isApproved: false,
    });
  };

  render() {
    return (
      <QuotationApprovedScreen
        headerTitle={this.state.headerTitle}
        isApproved={this.state.isApproved}
        reviseButtonHandler={this.reviseButtonHandler}
        approvedButtonHandler={this.approvedButtonHandler}
        tableHead={this.state.tableHead}
        //  testData={this.state.testData[0].LC_VPTM_PRODUCT_ID,this.state.testData[0].LC_VPTM_PRODUCT_ID,this.state.testData[0].LC_VPTM_PRODUCT_ID}
        tableData={this.props.managerapprovaltestTableDetails}
        data={this.state.data}
        vendorID={this.state.vendorID}
        doctorDatas={this.props.managerapprovaldoctorDetails}
        testData1={this.props.managerapprovalproducttestDetails}
        loading={this.props.managerapprovaldetailsLoading}
        Quotationhomehandler={this.Quotationhomehandler}
        approvalstatus={this.state.approvalstatus}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    accessToken: state.signIn.accessToken,
    managerapprovaldetailsError:
      state.salesmanagerapprovals.approvaldetailstError,
    managerapprovaldetailsStatus:
      state.salesmanagerapprovals.apporvaldetailsStatus,
    managerapprovaldetailsLoading:
      state.salesmanagerapprovals.approvaldetailsLoading,
    managerapprovaldoctorDetails:
      state.salesmanagerapprovals.approvaldoctorDetails,
    managerapprovalproducttestDetails:
      state.salesmanagerapprovals.approvalproducttestDetails,
    managerapprovaltestTableDetails:
      state.salesmanagerapprovals.approvalproducttesttableDetails,
    approvalDetailsProcessmessage: state.salesmanagerapprovals.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetApprovalDetails: (data, token) =>
      dispatch(getApprovalDetails(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(QuotationApproved);
