import {placeholder} from '@babel/types';
import React, {useRef} from 'react';
import {
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  Dimensions,
  KeyboardAvoidingView,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../locale/i18n';
import Button from '../../components/Button';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import Images from '../../constants/Images';
import {IconFooter} from '../../components/Footer';
import {InputField} from '../../components/InputField';
import {Toast} from '../../components/Toast';
import Loader from '../../components/Loader';
import PageNo from '../../constants/PageNo';

const {width, height} = Dimensions.get('screen');
const inputFieldContainerHeight = height * 0.25;

function SignInScreen({
  loading,
  showToast,
  errorMsg,
  username,
  password,
  isValidUsername,
  isValidPassword,
  usernameValidationMsg,
  passwordValidationMsg,
  usernaneChangeHandler,
  passwordChangeHandler,
  loginSubmitHandler,
  forgotPasswordHandler,
  loginWithOtpHandler,
  signUpHandler,
}) {
  return (
    <RootView pageNo={PageNo.signIn} loading={loading}>
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      {/* <Loader loading={showToast} /> */}
      <KeyboardAvoidingView style={{flex: 1}}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={styles.mainContainer}>
            <ImageBackground
              source={Images.loginBg}
              style={styles.bgImageContainer}
              resizeMode="stretch">
              <View style={styles.loginContainer}>
                <View style={styles.logoConatiner}>
                  <Image
                    source={Images.logo}
                    style={styles.logoImageConatiner}
                    resizeMode="cover"
                  />
                  <Text style={styles.signInText}>
                    {I18n.t('signIn.sign_in')}
                  </Text>
                </View>
                <View style={styles.inputFieldConatiner}>
                  <InputField
                    label={I18n.t('signIn.username_label')}
                    placeholder={I18n.t('signIn.username_placeholder')}
                    maxLength={250}
                    value={username}
                    isValid={isValidUsername}
                    validationMsg={usernameValidationMsg}
                    onChangeHandler={usernaneChangeHandler}
                  />

                  <InputField
                    label={I18n.t('signIn.password_label')}
                    placeholder={I18n.t('signIn.password_placeholder')}
                    maxLength={15}
                    value={password}
                    isValid={isValidPassword}
                    validationMsg={passwordValidationMsg}
                    onChangeHandler={passwordChangeHandler}
                    isPassword={true}
                    icon
                  />
                </View>
                <View style={styles.buttonContainer}>
                  <View style={styles.loginButtonContainer}>
                    <View style={{width: '46%', alignItems: 'flex-start'}}>
                      <Button
                        title={I18n.t('signIn.login_button')}
                        onPress={loginSubmitHandler}
                      />
                    </View>
                    <View style={{width: '56%', alignItems: 'flex-end'}}>
                      <Button
                        title={I18n.t('signIn.forgot_button')}
                        isTransparent
                        // buttonStyle={{paddingHorizontal: 10}}
                        buttonTextStyle={{color: Colors.text}}
                        onPress={forgotPasswordHandler}
                      />
                    </View>
                  </View>
                  <View style={styles.loginOtpContainer}>
                    <Button
                      title={I18n.t('signIn.login_with_otp_button')}
                      isTransparent
                      buttonTextStyle={{
                        color: Colors.text,
                        textDecorationLine: 'underline',
                      }}
                      onPress={loginWithOtpHandler}
                    />
                  </View>
                </View>
              </View>
            </ImageBackground>
          </View>
          <View style={styles.signUpContainer}>
            <Text style={styles.firstText}>{I18n.t('signIn.description')}</Text>
            <Button
              title={I18n.t('signIn.sign_up')}
              isTransparent
              buttonStyle={{minWidth: 60, paddingHorizontal: 2}}
              buttonTextStyle={styles.secondText}
              onPress={signUpHandler}
            />
          </View>
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'flex-end'}}>
            <IconFooter />
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

SignInScreen.prototype = {
  username: PropTypes.string,
  password: PropTypes.string,
  isValidUsername: PropTypes.bool,
  isValidPassword: PropTypes.bool,
  usernameValidationMsg: PropTypes.string,
  passwordValidationMsg: PropTypes.string,
  usernaneChangeHandler: PropTypes.func,
  passwordChangeHandler: PropTypes.func,
  loginSubmitHandler: PropTypes.func,
  forgotPasswordHandler: PropTypes.func,
  loginWithOtpHandler: PropTypes.func,
  signUpHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    paddingBottom: 20,
  },
  mainContainer: {
    width: '100%',
    height: '80%',
    // overflow: 'hidden',
  },
  bgImageContainer: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  loginContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: '#aaa',
  },
  logoConatiner: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 36,
    // backgroundColor: '#bbb',
  },
  logoImageConatiner: {
    height: 60,
    alignSelf: 'center',
  },
  signInText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    fontWeight: '600',
    marginVertical: 10,
  },
  inputFieldConatiner: {
    width: '100%',
    height: '42%',
    minHeight: inputFieldContainerHeight,
    alignSelf: 'center',
    justifyContent: 'space-evenly',
    paddingHorizontal: 10,
    paddingTop: 25,
    paddingBottom: 5,
  },
  buttonContainer: {
    width: '94%',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    // backgroundColor: '#ddd',
  },
  loginButtonContainer: {
    // width: '90%',
    flexDirection: 'row',
    alignSelf: 'center',
    // alignItems: 'center',
    // justifyContent: 'space-evenly',
    paddingTop: 26,
    paddingBottom: 10,
    marginLeft: 30,
    // backgroundColor: 'green',
  },
  loginOtpContainer: {},
  signUpContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  firstText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    paddingHorizontal: 4,
  },
  secondText: {
    color: Colors.teal,
    fontFamily: Font.extraBold,
  },
});

export default SignInScreen;
