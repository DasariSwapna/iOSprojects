import React from 'react';
import {connect} from 'react-redux';
import PropTypes from 'prop-types';
import {
  validatePassword,
  validatePasswordEmpty,
  validateUsername,
} from '../../utils/Validators';
import {routeNameRef} from '../../navigations';
import SignInScreen from './Screen';
import {Auth} from '../../navigations/RouteTypes';
import {getLogin, getToken} from '../../store/Actions';
import {delay} from '../../utils/Helpers';
import {ScreenTrackContext} from '../../contexts/ScreenTrackContext';

class SignIn extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      usernameValidationMsg: '',
      passwordValidationMsg: '',
      isValidUsername: true,
      isValidPassword: true,
      showToast: false,
    };
  }

  static contextType = ScreenTrackContext;

  usernameChangeHandler = val => {
    if (/^[ A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        username: val,
      });
    }
  };

  passwordChangeHandler = val => {
    if (/^[ A-Za-z0-9_@.*/#&+-]*$/.test(val)) {
      this.setState({
        password: val,
      });
    }
  };

  loginSubmitHandler = () => {
    const valid1 = validateUsername(this.state.username);
    const valid2 = validatePasswordEmpty(this.state.password);

    if (valid1.val && valid2.val) {
      this.setState({
        isValidUsername: valid1.val,
        isValidPassword: valid2.val,
        usernameValidationMsg: '',
        passwordValidationMsg: '',
      });

      const data = {
        loginUser: this.state.username,
        password: this.state.password,
        loginType: 'PASSWORD',
        // loginType: 'OTP',
        loginMode: null,
        langId: '1',
        firebaseId: '',
      };
      this.props.onGetLogin(data, this.props.accessToken);
      // this.props.onGetToken(data, this.props.accessToken);
    } else {
      this.setState({
        isValidUsername: valid1.val,
        isValidPassword: valid2.val,
        usernameValidationMsg: valid1.msg,
        passwordValidationMsg: valid2.msg,
      });
    }
  };

  forgotPasswordHandler = () => {
    this.props.navigation.navigate(Auth.forgotPassword);
  };

  loginWithOtpHandler = () => {
    this.props.navigation.navigate(Auth.signUpWithOtp);
  };

  signUpHandler = () => {
    this.props.navigation.navigate(Auth.signUp);
  };

  resetValidation = () => {
    this.setState({
      errorMsg: '',
      showToast: false,
    });
  };

  componentDidMount = () => {};

  componentDidUpdate = prevProps => {
    if (
      prevProps.loginError == false &&
      this.props.loginError != prevProps.loginError
    ) {
      this.setState(
        {
          errorMsg: this.props.message,
          showToast: true,
        },
        async () => {
          await delay(3000);
          this.resetValidation();
        },
      );
    }
    if (
      prevProps.loginStatus == false &&
      this.props.loginStatus != prevProps.loginStatus &&
      !this.props.accessToken
    ) {
      // this.props.onGetToken(data, this.props.accessToken);
      if (this.props.activationStatus == false)
        this.props.navigation.navigate(Auth.profilePending);
    }
    if (
      this.props.loginStatus != prevProps.loginStatus &&
      this.props.loginStatus == true &&
      this.props.activationStatus == false
    ) {
      this.props.navigation.navigate(Auth.profilePending);
    }
  };

  render() {
    // console.log('......>', routeNameRef.current);
    // console.log('......>', this.props.loginLoading);
    return (
      <SignInScreen
        loading={
          routeNameRef.current == Auth.signIn ? this.props.loginLoading : false
        }
        showToast={this.state.showToast}
        username={this.state.username}
        password={this.state.password}
        errorMsg={this.state.errorMsg}
        usernameValidationMsg={this.state.usernameValidationMsg}
        passwordValidationMsg={this.state.passwordValidationMsg}
        isValidUsername={this.state.isValidUsername}
        isValidPassword={this.state.isValidPassword}
        usernaneChangeHandler={this.usernameChangeHandler}
        passwordChangeHandler={this.passwordChangeHandler}
        loginSubmitHandler={this.loginSubmitHandler}
        signUpHandler={this.signUpHandler}
        forgotPasswordHandler={this.forgotPasswordHandler}
        loginWithOtpHandler={this.loginWithOtpHandler}
        signUpHandler={this.signUpHandler}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.signIn.message,
    loginLoading: state.signIn.loginLoading,
    loginStatus: state.signIn.loginStatus,
    loginError: state.signIn.loginError,
    accessToken: state.signIn.accessToken,
    activationStatus: state.signIn.activationStatus,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetLogin: (data, token) => dispatch(getLogin(data, token)),
    onGetToken: (data, token) => dispatch(getToken(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(SignIn);
