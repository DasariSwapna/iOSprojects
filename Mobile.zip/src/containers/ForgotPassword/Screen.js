import {placeholder} from '@babel/types';
import React, {useRef} from 'react';
import {
  Dimensions,
  ImageBackground,
  Image,
  Text,
  TextInput,
  View,
  StyleSheet,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
} from 'react-native';
import PropTypes from 'prop-types';
import I18n from '../../locale/i18n';
import Button from '../../components/Button';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import Images from '../../constants/Images';
import {InputField} from '../../components/InputField';
import OtpModal from '../../components/OtpModal';
import {Toast} from '../../components/Toast';
import PageNo from '../../constants/PageNo';

const screenHeight = Dimensions.get('screen').height;

function ForgotPasswordScreen({
  otp,
  showOtpModal,
  mobileNoOrEmail,
  isValidMobileNoOrEmail,
  isValidOtp,
  mobileNoOrEmailValidationMsg,
  otpValidationMsg,
  mobileNoOrEmailChangeHandler,
  otpChangeHandler,
  requestOtpSubmitHandler,
  otpSubmitHandler,
  otpDismissHandler,
  otpResendHandler,
  signUpHandler,
  errorMsg,
  showToast,
}) {
  console.log('-----> forget validation msg:', otpValidationMsg);
  return (
    <RootView pageNo={PageNo.forgotPassword}>
      {showOtpModal === true && (
        <OtpModal
          page={PageNo.forgotOtpModal}
          otp={otp}
          mobileNo={mobileNoOrEmail}
          visible={showOtpModal}
          isValidOtp={!isValidOtp}
          otpValidationMsg={otpValidationMsg}
          otpChangeHandler={otpChangeHandler}
          otpDismissHandler={otpDismissHandler}
          otpSubmitHandler={otpSubmitHandler}
          resendOtpHandler={otpResendHandler}
        />
      )}
      <Toast
        showToast={showToast}
        msg={errorMsg}
        bgColor={Colors.error}
        txtColor={Colors.background}
      />
      <KeyboardAvoidingView
        enabled
        style={{flex: 1}}
        contentContainerStyle={{paddingBottom: 40}}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 50 : 70}>
        <ScrollView
          style={{flex: 1}}
          contentContainerStyle={styles.contentContainer}
          showsVerticalScrollIndicator={false}>
          <View style={{height: '100%'}}>
            <View style={styles.mainContainer}>
              <ImageBackground
                source={Images.forgotpasswordBg}
                style={styles.bgImageContainer}
                resizeMode="stretch">
                <View style={styles.loginContainer}>
                  <View style={styles.logoConatiner}>
                    <Image
                      source={Images.logo}
                      style={styles.logoImageConatiner}
                      resizeMode="cover"
                    />
                    <Text style={styles.signInText}>Forgot Password</Text>
                  </View>
                  <View style={styles.inputFieldConatiner}>
                    <InputField
                      placeholder={'Enter the Mobile Number / Email'}
                      maxLength={250}
                      value={mobileNoOrEmail}
                      isValid={isValidMobileNoOrEmail}
                      validationMsg={mobileNoOrEmailValidationMsg}
                      onChangeHandler={mobileNoOrEmailChangeHandler}
                      isEmail={true}
                    />
                  </View>
                  <View style={styles.buttonContainer}>
                    <View style={styles.loginButtonContainer}>
                      <Button
                        title="Request OTP"
                        onPress={() => requestOtpSubmitHandler()}
                      />
                    </View>
                  </View>
                </View>
              </ImageBackground>
            </View>
            <View style={styles.signUpContainer}>
              <Text style={styles.firstText}>Are you new to LifeCell?</Text>
              <Button
                title="Sign up"
                isTransparent
                buttonStyle={{minWidth: 60, paddingHorizontal: 2}}
                buttonTextStyle={styles.secondText}
                onPress={signUpHandler}
              />
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </RootView>
  );
}

ForgotPasswordScreen.prototype = {
  otp: PropTypes.string,
  showOtpModal: PropTypes.bool,
  mobileNoOrEmail: PropTypes.string,
  isValidMobileNoOrEmail: PropTypes.string,
  isValidOtp: PropTypes.bool,
  mobileNoOrEmailValidationMsg: PropTypes.string,
  otpValidationMsg: PropTypes.string,
  mobileNoOrEmailChangeHandler: PropTypes.func,
  otpChangeHandler: PropTypes.func,
  requestOtpSubmitHandler: PropTypes.func,
  otpSubmitHandler: PropTypes.func,
  otpDismissHandler: PropTypes.func,
  otpResendHandler: PropTypes.func,
  signUpHandler: PropTypes.func,
};

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    // paddingBottom: 20,
  },
  mainContainer: {
    width: '100%',
    height: screenHeight * 0.48,
    overflow: 'hidden',
  },
  bgImageContainer: {
    width: '100%',
    height: '100%',
    resizeMode: 'contain',
  },
  loginContainer: {
    flex: 1,
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    // backgroundColor: '#aaa',
  },
  logoConatiner: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 36,
    // backgroundColor: '#bbb',
  },
  logoImageConatiner: {
    height: 60,
    alignSelf: 'center',
  },
  signInText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.large,
    fontWeight: '600',
    marginVertical: 10,
  },
  inputFieldConatiner: {
    width: '100%',
    alignSelf: 'center',
    justifyContent: 'center',
    paddingHorizontal: 10,
    paddingTop: 25,
    paddingBottom: 5,
  },

  buttonContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 15,
    // backgroundColor: '#ddd',
  },
  loginButtonContainer: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    paddingTop: 26,
    paddingBottom: 10,
    marginLeft: 26,
  },
  loginOtpContainer: {},
  signUpContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  firstText: {
    color: Colors.text,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    paddingHorizontal: 4,
  },
  secondText: {
    color: Colors.teal,
    fontFamily: Font.extraBold,
  },
});

export default ForgotPasswordScreen;
