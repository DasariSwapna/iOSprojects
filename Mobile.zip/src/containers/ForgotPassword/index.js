import React from 'react';
import {BackHandler} from 'react-native';
import {connect} from 'react-redux';
import I18n from 'i18next';
import PropTypes from 'prop-types';
import {
  isValidUsername,
  isValidPassword,
  validateEmpty,
  validateMobileNo,
  validateOTP,
  validateEmail,
  validateEmail1,
  validateMobileNoOrEmail,
} from '../../utils/Validators';
import ForgotPasswordScreen from './Screen';
import HelperText from '../../constants/HelperText';
import {Auth} from '../../navigations/RouteTypes';
import {getForgetPassword, verifyForgetPassword} from '../../store/Actions';
class ForgotPassword extends React.Component {
  static propTypes = {
    // ...prop type definitions here
  };

  constructor(props) {
    super(props);
    this.state = {
      otp: '',
      mobileNoOrEmail: '',
      errorMsg: '',
      otpValidationMsg: '',
      mobileNoOrEmailValidationMsg: '',
      passwordValidationMsg: '',
      isValidMobileNoOrEmail: true,
      isValidOtp: true,
      showOtpModal: false,
      showToast: false,
      errorMsg: '',
    };
  }

  mobileNoOrEmailChangeHandler = val => {
    if (/^[A-Za-z0-9_@./#&+-]*$/.test(val)) {
      this.setState({
        mobileNoOrEmail: val,
      });
    }
  };

  otpChangeHandler = val => {
    if (/^[0-9]*$/.test(val)) {
      this.setState({
        otp: val,
      });
    }
  };

  otpModalDismissHandler = () => {
    this.setState({
      showOtpModal: false,
    });
  };

  requestOtpSubmitHandler = () => {
    const valid1 = validateMobileNoOrEmail(this.state.mobileNoOrEmail);
    if (valid1.val) {
      this.setState({
        isValidMobileNoOrEmail: valid1.val,
        mobileNoOrEmailValidationMsg: '',
      });
      const data = {
        user_id: this.state.mobileNoOrEmail,
        sms_validtimelimit: '3',
        lang_id: '1',
        user_type: '4',
      };
      this.props.onGetOtp(data, this.props.accessToken);
    } else {
      this.setState({
        isValidMobileNoOrEmail: valid1.val,
        mobileNoOrEmailValidationMsg: valid1.msg,
      });
    }
  };

  otpResendHandler = () => {
    const data = {
      user_id: this.state.mobileNoOrEmail,
      sms_validtimelimit: '3',
      lang_id: '1',
      user_type: '4',
    };
    this.props.onGetOtp(data, this.props.accessToken);
  };

  otpSubmitHandler = () => {
    const valid1 = validateOTP(this.state.otp);
    console.log('validated', valid1, this.state.otp);

    if (valid1.val == true) {
      this.setState({
        otp: '',
        mobileNoOrEmail: '',
        showOtpModal: false,
        otpValidationMsg: '',
        isValidOtp: valid1.val,
      });
      const data = {
        user_id: this.state.mobileNoOrEmail,
        lang_id: '1',
        otp: this.state.otp,
        otp_purpose: 'FORGOT',
      };
      this.props.verifyOTP(data, this.props.verifyaccessToken);
    } else {
      this.setState({
        isValidOtp: valid1.val,
        otpValidationMsg: valid1.msg,
      });
    }
  };

  // signUpHandler = () => {
  //   this.backHandler();
  // };

  signUpHandler = () => {
    this.props.navigation.navigate(Auth.signUp);
  };

  backHandler = () => {
    // this.props.navigation.navigate(Auth.signUp);
    this.props.navigation.goBack(null);
    return true;
  };

  componentDidMount = () => {
    BackHandler.addEventListener('hardwareBackPress', this.backHandler);
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.forgetPasswordError != this.props.forgetPasswordError &&
      this.props.forgetPasswordError == true
    ) {
      this.setState({
        errorMsg: this.props.message,
        showToast: true,
      });
    }
    if (
      prevProps.forgetPasswordStatus != this.props.forgetPasswordStatus &&
      this.props.forgetPasswordStatus == true
    ) {
      this.otpmodal();
    }

    if (
      prevProps.verifyError != this.props.verifyError &&
      this.props.verifyError == true
    ) {
      this.setState({
        errorMsg: this.props.verifyMessage,
        showToast: true,
      });
    }
    if (
      prevProps.verifyStatus != this.props.verifyStatus &&
      this.props.verifyStatus == true
    ) {
      this.props.navigation.navigate(Auth.resetPassword);
    }
  };

  otpmodal = () => {
    this.setState({
      showToast: false,
      showOtpModal: true,
      mobileNoOrEmailValidationMsg: '',
    });
  };

  render() {
    console.log(
      this.state.isValidMobileNoOrEmail,
      this.state.mobileNoOrEmailValidationMsg,
    );
    return (
      <ForgotPasswordScreen
        showOtpModal={this.state.showOtpModal}
        mobileNoOrEmail={this.state.mobileNoOrEmail}
        otp={this.state.otp}
        isValidMobileNoOrEmail={this.state.isValidMobileNoOrEmail}
        isValidOtp={this.state.isValidOtp}
        otpValidationMsg={this.state.otpValidationMsg}
        mobileNoOrEmailValidationMsg={this.state.mobileNoOrEmailValidationMsg}
        mobileNoOrEmailChangeHandler={this.mobileNoOrEmailChangeHandler}
        otpChangeHandler={this.otpChangeHandler}
        otpSubmitHandler={this.otpSubmitHandler}
        requestOtpSubmitHandler={this.requestOtpSubmitHandler}
        otpDismissHandler={this.otpModalDismissHandler}
        signUpHandler={this.signUpHandler}
        otpResendHandler={this.otpResendHandler}
        errorMsg={this.state.errorMsg}
        showToast={this.state.showToast}
      />
    );
  }
}

const mapStateToProps = state => {
  return {
    message: state.forgetPassword.message,
    accessToken: state.forgetPassword.accessToken,
    forgetPasswordLoading: state.forgetPassword.forgetPasswordLoading,
    forgetPasswordStatus: state.forgetPassword.forgetPasswordStatus,
    forgetPasswordError: state.forgetPassword.forgetPasswordError,
    verifyaccessToken: state.forgetPassword.verifyaccessToken,
    verifyLoading: state.forgetPassword.verifyLoading,
    verifyStatus: state.forgetPassword.verifyStatus,
    verifyError: state.forgetPassword.verifyError,
    verifyMessage: state.forgetPassword.verifyMessage,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetOtp: (data, token) => dispatch(getForgetPassword(data, token)),
    verifyOTP: (data, token) => dispatch(verifyForgetPassword(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(ForgotPassword);
