/* eslint-disable react-native/no-inline-styles */
import React, {useRef} from 'react';
import {
  ActivityIndicator,
  Dimensions,
  ImageBackground,
  Image,
  SafeAreaView,
  Text,
  View,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import {Font, FontSize} from '../../config/Fonts';
import Fa5Icons from 'react-native-vector-icons/FontAwesome5';
import Images from '../../constants/Images';
import InnerHeader from '../../components/InnerHeader';
import {CircularButton} from '../../components/Button';

const {width, height} = Dimensions.get('screen');
const paddingHr = width * 0.05;
const paddingVr = height * 0.02;
const bottomImageWidth = width;
const bottomImageHeight = height * 0.5;
const bottomPaddingIos = height * 0.01;
const bottomPadding = height * 0.02;
import {
  heightPercentageToDP as hp,
  widthPercentageToDP,
  widthPercentageToDP as wp,
} from 'react-native-responsive-screen';

function LandingScreen({appLangingHandler}) {
  return (
    // <RootView pageNo={'01'} isWhite isPageCard>
    //   <KeyboardAvoidingView style={{flex: 1}}>
    <View style={{flex: 1}}>
      {/* <ScrollView
        style={{flex: 1}}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}> */}
      <View style={styles.mainContainer}>
        <View style={styles.firstHalfContainer}>
          <View style={styles.logoContainer}>
            <Image
              source={Images.logo}
              style={styles.logoImage}
              resizeMode="contain"
            />
          </View>
          <View style={styles.textContainer}>
            <Text style={styles.landingText}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit.Nulla
              tempus, facilisis
            </Text>
          </View>
          <View style={styles.buttonContainer}>
            <CircularButton onPress={() => appLangingHandler()} />
          </View>
        </View>
        <View style={styles.bottomConatiner}>
          <ImageBackground
            style={styles.bottomImageContainer}
            resizeMode="stretch"
            source={Images.landingBg}
          />
        </View>
      </View>
      {/* </ScrollView> */}
    </View>
    //   </KeyboardAvoidingView>
    // </RootView>
  );
}

const styles = StyleSheet.create({
  contentContainer: {
    flexGrow: 1,
    // paddingBottom: 20,
  },
  mainContainer: {
    flex: 1,
    backgroundColor: Colors.background,
  },
  firstHalfContainer: {
    width: '100%',
    height: Platform.OS == 'ios' ? '40%' : '39%',
    paddingHorizontal: paddingHr,
  },
  logoContainer: {
    height: '50%',
    justifyContent: 'flex-end',
    paddingVertical: 16,
    // backgroundColor: 'green',
  },
  textContainer: {
    justifyContent: 'center',
    paddingVertical: paddingVr,
    paddingHorizontal: paddingHr,
  },
  buttonContainer: {
    height: hp('5%'),
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    overflow: 'visible',
  },
  landingText: {
    color: Colors.black,
    fontFamily: Font.extraBold,
    fontSize: FontSize.medium,
    textAlign: 'center',
    fontWeight: '600',
    marginVertical: 10,
  },
  logoImage: {
    height: hp('10%'),
    width: hp('20%'),
    alignSelf: 'center',
  },
  bottomConatiner: {
    // flex: 1,
    height: '118%',
    // width: '100%',
    // bottom: -paddingVr,
    // height: height / 2.1,
    // alignItems: 'center',
    // justifyContent: 'flex-end',
  },
  bottomImageContainer: {
    flex: 1,
    width: '100%',
    height: '50%',
    // width: bottomImageWidth,
    // height: bottomImageHeight,
    justifyContent: 'flex-end',
    bottom: Platform.OS == 'ios' ? -bottomPaddingIos : -bottomPadding,
  },
});

export default LandingScreen;
