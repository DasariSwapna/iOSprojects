import React from 'react';
import {connect} from 'react-redux';
import I18n from 'i18next';
import LandingScreen from './Screen';
import {setLaunchApp} from '../../store/Actions';

class AppLanding extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
      errorMsg: '',
      isValidated: false,
      showToast: false,
    };
  }

  appLandingHandler = () => {
    this.props.onSetLanchApp();
  };

  render() {
    return <LandingScreen appLangingHandler={this.appLandingHandler} />;
  }
}

const mapStateToProps = state => {
  return {};
};

const mapDispatchToProps = dispatch => {
  return {
    onSetLanchApp: () => dispatch(setLaunchApp()),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(AppLanding);
