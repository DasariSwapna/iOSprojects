import React from 'react';
import {connect} from 'react-redux';
import {ActivityIndicator, StyleSheet, View} from 'react-native';
import {ScreenTrackContext} from '../../contexts/ScreenTrackContext';
import {Auth} from '../../navigations/RouteTypes';
import RootView from '../../components/RootView';
import Colors from '../../config/Colors';
import {
  getLebel,
  getTheme,
  getPageNo,
  getLanguage,
  getAppConfig,
  getImage,
  getIcon,
} from '../../store/Actions';
import {
  themeChangeHandler,
  labelChangeHandler,
  pageNoChangeHandler,
} from '../../utils/Helpers';

class Splash extends React.Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  componentDidMount = async () => {
    const data = {
      langId: 1,
      controllerId: 0,
      userType: 0,
      pageId: 1,
      appID: 0,
    };
    const data1 = {
      langId: 1,
      appID: 1,
    };
    await this.props.onGetAppConfig(data1, null);
    await this.props.onGetPageNo(data, null);
    await this.props.onGetLanguage(data, null);
    await this.props.onGetTheme(data, null);
    await this.props.onGetLabel(data, null);
    await this.props.onGetImage(data, null);
    await this.props.onGetIcon(data, null);

    if (this.props.isAppLaunched == false) {
      setTimeout(() => {
        this.props.navigation.navigate(Auth.landing);
      }, 3000);
    }
  };

  componentDidUpdate = prevProps => {
    if (
      prevProps.themeStatus != this.props.themeStatus &&
      this.props.themeStatus == true
    ) {
      themeChangeHandler(this.props.theme);
    }
    if (
      prevProps.labelStatus != this.props.labelStatus &&
      this.props.labelStatus == true
    ) {
      labelChangeHandler(this.props.label);
    }
    if (
      prevProps.pageNoLoading != this.props.pageNoLoading &&
      this.props.pageNoLoading == true
    ) {
      pageNoChangeHandler(this.props.pageNo);
    }
  };

  static contextType = ScreenTrackContext;

  render() {
    return (
      <RootView isWhite>
        <View style={[styles.container, styles.horizontal]}>
          <ActivityIndicator size="large" />
        </View>
      </RootView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: Colors.background,
  },
  horizontal: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    padding: 10,
  },
});

const mapStateToProps = state => {
  return {
    isAppLaunched: state.common.isAppLaunched,
    pageNoLoading: state.common.pageNoLoading,
    pageNoStatus: state.common.pageNoStatus,
    themeStatus: state.common.themeStatus,
    labelStatus: state.common.labelStatus,
    theme: state.common.themeResponse,
    label: state.common.labelResponse,
    pageNo: state.common.pageNoResponse,
    message: state.common.message,
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onGetAppConfig: (data, token) => dispatch(getAppConfig(data, token)),
    onGetLanguage: (data, token) => dispatch(getLanguage(data, token)),
    onGetLabel: (data, token) => dispatch(getLebel(data, token)),
    onGetTheme: (data, token) => dispatch(getTheme(data, token)),
    onGetPageNo: (data, token) => dispatch(getPageNo(data, token)),
    onGetImage: (data, token) => dispatch(getImage(data, token)),
    onGetIcon: (data, token) => dispatch(getIcon(data, token)),
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Splash);
