import React, {useState, useEffect} from 'react';
import {View, Text, SafeAreaView} from 'react-native';
import Geocoder from 'react-native-geocoding';
import MapView, {Marker} from 'react-native-maps';
import Config from 'react-native-config';
import Button from '../../components/Button';
import Colors from '../../config/Colors';
import {locationPermission} from '../../services/Permissions';
import {getAddress, getCurrentLocation} from '../../services/Location';
import MapLocation from '../../components/MapLocation';
import SampleScreen from './Screen';

const INITIAL_REGION = {
  latitude: 13.0827,
  longitude: 80.2707,
  latitudeDelta: 0.0922,
  longitudeDelta: 0.0421,
};

class Sample extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      coords: null,
      addressLine1: '',
      addressLine2: '',
      userCoords: null,
      showModal: true,
      updateCoords: null,
    };
  }

  coordinateChangeHandler = async coords => {
    this.setState({
      coords: coords,
    });
    const addrs = await getAddress(coords);
    if (addrs) {
      this.setState({
        addressLine1: addrs.addrFirstLine,
        addressLine2: addrs.addrSecondLine,
      });
    }
  };

  updateCoordinates = coords => {
    console.log('==+++++>', coords);
    const temp = {
      latitude: coords.lat,
      longitude: coords.lng,
    };
    this.coordinateChangeHandler(temp);
    this.setState({
      updateCoords: temp,
    });
  };

  userTrackHandler = async () => {
    const permit = await locationPermission();
    if (permit == 'granted') {
      const location = await getCurrentLocation();
      this.setState({
        userCoords: {...INITIAL_REGION, ...location},
      });
      this.coordinateChangeHandler(location);
    }
  };

  showAddressModalHandler = () => {
    this.setState(prevState => {
      return {
        showModal: !prevState.showModal,
      };
    });
  };

  componentDidMount = async () => {
    this.userTrackHandler();
  };

  render() {
    return (
      <SampleScreen
        initialCoords={
          this.state.userCoords ? this.state.userCoords : INITIAL_REGION
        }
        updatedCoords={this.state.updatedCoords}
        showModal={this.state.showModal}
        addressLine1={this.state.addressLine1}
        addressLine2={this.state.addressLine2}
        getCoordinates={this.coordinateChangeHandler}
        showAddressModalHandler={this.showAddressModalHandler}
        updateCoordinates={this.updateCoordinates}
      />
    );
  }
}

export default Sample;
